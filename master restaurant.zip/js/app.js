/* =========================================
   BK PREMIUM RESTAURANT PLATFORM
   MAIN APPLICATION
========================================= */

"use strict";


/* =========================================
   BK APP
========================================= */

const BKApp = {

    /* -----------------------------------------
       INITIALIZE
    ----------------------------------------- */

    init: function () {

        console.log("BK Platform initialized.");

        this.setupNavigation();
        this.setupButtons();
        this.setupScrollEffects();

    },


    /* -----------------------------------------
       NAVIGATION
    ----------------------------------------- */

    setupNavigation: function () {

        const navLinks = document.querySelectorAll(
            ".nav-menu a"
        );

        navLinks.forEach(function (link) {

            link.addEventListener("click", function (event) {

                const targetId =
                    link.getAttribute("href");

                if (
                    targetId &&
                    targetId.startsWith("#")
                ) {

                    const target =
                        document.querySelector(targetId);

                    if (target) {

                        event.preventDefault();

                        target.scrollIntoView({
                            behavior: "smooth",
                            block: "start"
                        });

                    }

                }

            });

        });

    },


    /* -----------------------------------------
       BUTTONS
    ----------------------------------------- */

    setupButtons: function () {


        /* =====================================
           GET STARTED
           → REGISTRATION PAGE
        ===================================== */

        const getStartedButtons =
            document.querySelectorAll(
                ".js-get-started"
            );

        getStartedButtons.forEach(function (button) {

            button.addEventListener(
                "click",
                function () {

                    /*
                     * Get Started now opens
                     * the BK Registration Page.
                     *
                     * Registration page will be
                     * created separately later.
                     */

                    window.location.href =
                        "registration.html";

                }
            );

        });



        /* =====================================
           EXPLORE PLATFORM
        ===================================== */

        const exploreButton =
            document.querySelector(".js-explore");

        if (exploreButton) {

            exploreButton.addEventListener(
                "click",
                function () {

                    const featuresSection =
                        document.querySelector("#features");

                    if (featuresSection) {

                        featuresSection.scrollIntoView({
                            behavior: "smooth",
                            block: "start"
                        });

                    }

                }
            );

        }



        /* =====================================
           LOGIN
        ===================================== */

        const loginButton =
            document.querySelector(".btn-login");

        if (loginButton) {

            loginButton.addEventListener(
                "click",
                function () {

                    window.location.href =
                        "login.html";

                }
            );

        }

    },


    /* -----------------------------------------
       SCROLL EFFECTS
    ----------------------------------------- */

    setupScrollEffects: function () {

        const navbar =
            document.querySelector(".navbar");

        if (!navbar) {
            return;
        }


        window.addEventListener(
            "scroll",
            function () {

                if (window.scrollY > 30) {

                    navbar.classList.add(
                        "navbar-scrolled"
                    );

                } else {

                    navbar.classList.remove(
                        "navbar-scrolled"
                    );

                }

            }
        );

    }

};


/* =========================================
   START BK APPLICATION
========================================= */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        BKApp.init();

    }
);

/* =====================================================
   BK HIDDEN MASTER ACCESS — LOGO FIVE TAPS
===================================================== */

(() => {
    const logo = document.querySelector(".bk-brand");
    const overlay = document.getElementById("masterAccessOverlay");

    if (!logo || !overlay) return;

    let tapCount = 0;
    let tapTimer = null;

    function openMasterPanel() {
        overlay.hidden = false;
        overlay.setAttribute("aria-hidden", "false");
    }

    function closeMasterPanel() {
        overlay.hidden = true;
        overlay.setAttribute("aria-hidden", "true");
    }

    logo.addEventListener("click", (event) => {
        event.preventDefault();

        tapCount++;

        clearTimeout(tapTimer);

        tapTimer = setTimeout(() => {
            tapCount = 0;
        }, 2000);

        if (tapCount >= 5) {
            tapCount = 0;
            clearTimeout(tapTimer);
            openMasterPanel();
        }
    });

    overlay.querySelectorAll("[data-close-master-access]")
        .forEach((element) => {
            element.addEventListener("click", closeMasterPanel);
        });

    document.addEventListener("keydown", (event) => {
        if (event.key === "Escape" && !overlay.hidden) {
            closeMasterPanel();
        }
    });
})();