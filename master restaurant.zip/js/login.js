"use strict";


/* ============================================================
   BK RESTAURANT PLATFORM
   OWNER LOGIN SYSTEM
   PART 1 — CORE + UI CONTROLS
============================================================ */


/* ============================================================
   FIREBASE IMPORTS
============================================================ */
import "./firebase-sessions.js";
import {
    ownerAuth as auth,
    ownerDb as db
} from "./firebase-sessions.js";


import {
    signInWithEmailAndPassword,
    onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-auth.js";


import {
    doc,
    getDoc
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";


/* ============================================================
   BK LOGIN OBJECT
============================================================ */

const BKLogin = {

    state: {

        loginInProgress: false,

        authChecked: false,

        currentUser: null

    },


    /* ========================================================
       INITIALIZE
    ======================================================== */

    init: function () {

        console.log(
            "=========================================="
        );

        console.log(
            "BK Owner Login System initializing..."
        );

        console.log(
            "Firebase Authentication: READY"
        );

        console.log(
            "=========================================="
        );


        this.setupPasswordToggle();

        this.setupLoginForm();

        this.setupForgotPassword();

        this.checkExistingSession();


        console.log(
            "BK Login UI Controls: READY"
        );

    },


    /* ========================================================
       PASSWORD SHOW / HIDE
    ======================================================== */

    setupPasswordToggle: function () {

        const passwordInput =
            document.getElementById(
                "loginPassword"
            );


        const toggleButton =
            document.getElementById(
                "togglePasswordButton"
            );


        if (
            !passwordInput ||
            !toggleButton
        ) {

            console.warn(
                "Password toggle elements not found."
            );

            return;

        }


        toggleButton.addEventListener(
            "click",
            function () {

                const isPassword =
                    passwordInput.type === "password";


                if (isPassword) {

                    passwordInput.type =
                        "text";

                    toggleButton.textContent =
                        "Hide";

                    toggleButton.setAttribute(
                        "aria-label",
                        "Hide password"
                    );

                } else {

                    passwordInput.type =
                        "password";

                    toggleButton.textContent =
                        "Show";

                    toggleButton.setAttribute(
                        "aria-label",
                        "Show password"
                    );

                }

            }
        );


        console.log(
            "Password Toggle: READY"
        );

    },


    /* ========================================================
       LOGIN FORM
    ======================================================== */

    setupLoginForm: function () {

        const loginForm =
            document.getElementById(
                "loginForm"
            );


        if (!loginForm) {

            console.warn(
                "Login form not found."
            );

            return;

        }


        loginForm.addEventListener(
            "submit",
            async function (event) {

                event.preventDefault();


                await BKLogin.handleLogin();

            }
        );


        console.log(
            "Login Form: READY"
        );

    },


    /* ========================================================
       LOGIN INPUT VALIDATION
    ======================================================== */

    validateInputs: function (
        email,
        password
    ) {

        const emailValue =
            email.trim();


        const passwordValue =
            password.trim();


        if (!emailValue) {

            return {
                valid: false,
                message:
                    "Please enter your email address."
            };

        }


        if (!emailValue.includes("@")) {

            return {
                valid: false,
                message:
                    "Please enter a valid email address."
            };

        }


        if (!passwordValue) {

            return {
                valid: false,
                message:
                    "Please enter your password."
            };

        }


        return {
            valid: true,
            message: ""
        };

    },


    /* ========================================================
       SHOW ERROR
    ======================================================== */

    showError: function (message) {

        const errorElement =
            document.getElementById(
                "loginError"
            );


        if (!errorElement) return;


        errorElement.textContent =
            message;

    },


    /* ========================================================
       CLEAR ERROR
    ======================================================== */

    clearError: function () {

        const errorElement =
            document.getElementById(
                "loginError"
            );


        if (!errorElement) return;


        errorElement.textContent =
            "";

    },


    /* ========================================================
       BUTTON LOADING STATE
    ======================================================== */

    setLoading: function (loading) {

        const loginButton =
            document.getElementById(
                "loginButton"
            );


        const loginButtonText =
            document.getElementById(
                "loginButtonText"
            );


        if (
            !loginButton ||
            !loginButtonText
        ) {

            return;

        }


        if (loading) {

            loginButton.disabled =
                true;

            loginButtonText.textContent =
                "Signing In...";

        } else {

            loginButton.disabled =
                false;

            loginButtonText.textContent =
                "Sign In";

        }

    },


    /* ========================================================
       HANDLE LOGIN
    ======================================================== */

    handleLogin: async function () {

        if (
            this.state.loginInProgress
        ) {

            return;

        }


        const emailInput =
            document.getElementById(
                "loginEmail"
            );


        const passwordInput =
            document.getElementById(
                "loginPassword"
            );


        if (
            !emailInput ||
            !passwordInput
        ) {

            console.error(
                "Login input elements missing."
            );

            return;

        }


        const email =
            emailInput.value;


        const password =
            passwordInput.value;


        const validation =
            this.validateInputs(
                email,
                password
            );


        if (!validation.valid) {

            this.showError(
                validation.message
            );

            return;

        }


        this.clearError();


        this.state.loginInProgress =
            true;


        this.setLoading(true);


        try {

            console.log(
                "Attempting Firebase owner login..."
            );


            const credential =
                await signInWithEmailAndPassword(
                    auth,
                    email.trim(),
                    password
                );


            this.state.currentUser =
                credential.user;


            console.log(
                "Firebase Authentication: SUCCESS"
            );


            console.log(
                "Owner UID:",
                credential.user.uid
            );


            /*
             * Firestore owner profile verification
             * will be handled in Part 2.
             */

        } catch (error) {

            console.error(
                "Owner login failed:",
                error
            );


            this.handleFirebaseError(
                error
            );


        } finally {

            this.state.loginInProgress =
                false;

            this.setLoading(false);

        }

    },


    /* ========================================================
       FIREBASE ERROR HANDLER
    ======================================================== */

    handleFirebaseError: function (error) {

        let message =
            "Unable to sign in. Please try again.";


        switch (error.code) {

            case "auth/invalid-credential":

                message =
                    "Email or password is incorrect.";

                break;


            case "auth/invalid-email":

                message =
                    "Please enter a valid email address.";

                break;


            case "auth/user-disabled":

                message =
                    "This account has been disabled.";

                break;


            case "auth/too-many-requests":

                message =
                    "Too many attempts. Please try again later.";

                break;


            case "auth/network-request-failed":

                message =
                    "Network error. Please check your internet connection.";

                break;


            default:

                message =
                    "Unable to sign in. Please check your details and try again.";

        }


        this.showError(message);

    },


    /* ========================================================
       EXISTING SESSION CHECK
    ======================================================== */

    checkExistingSession: function () {

        console.log(
            "Checking existing Firebase session..."
        );


        onAuthStateChanged(
            auth,
            function (user) {

                BKLogin.state.authChecked =
                    true;


                if (user) {

                    BKLogin.state.currentUser =
                        user;


                    console.log(
                        "Existing Firebase session found."
                    );

                    console.log(
                        "UID:",
                        user.uid
                    );


                    /*
                     * Redirect logic will be completed
                     * in Part 2 after Firestore verification.
                     */

                } else {

                    console.log(
                        "No existing owner session."
                    );

                }

            }
        );

    },


    /* ========================================================
       FORGOT PASSWORD
    ======================================================== */

    setupForgotPassword: function () {

        const button =
            document.getElementById(
                "forgotPasswordButton"
            );


        if (!button) {

            console.warn(
                "Forgot Password button not found."
            );

            return;

        }


        button.addEventListener(
            "click",
            function () {

                BKLogin.showError(
                    "Password recovery will be connected in the next login module step."
                );

            }
        );


        console.log(
            "Forgot Password Control: READY"
        );

    }

};


/* ============================================================
   START LOGIN SYSTEM
============================================================ */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        BKLogin.init();

    }
);


/* ============================================================
   END — LOGIN JS PART 1
============================================================ */
/* ============================================================
   BK OWNER LOGIN
   PART 2 — FIRESTORE OWNER VERIFICATION + DASHBOARD REDIRECT
============================================================ */


/* ============================================================
   LOAD OWNER PROFILE
============================================================ */

BKLogin.loadOwnerProfile =
    async function (user) {

        if (!user || !user.uid) {

            throw new Error(
                "Authenticated owner information is missing."
            );

        }


        console.log(
            "Loading owner profile from Firestore..."
        );


        const userRef =
            doc(
                db,
                "users",
                user.uid
            );


        const userSnapshot =
            await getDoc(userRef);


        if (!userSnapshot.exists()) {

            throw new Error(
                "OWNER_PROFILE_NOT_FOUND"
            );

        }


        const ownerData =
            userSnapshot.data();


        console.log(
            "Owner profile loaded successfully."
        );


        return ownerData;

    };


/* ============================================================
   VERIFY RESTAURANT PROFILE
============================================================ */

BKLogin.verifyRestaurant =
    async function (restaurantId, user) {

        if (
            !restaurantId ||
            !user ||
            !user.uid
        ) {

            throw new Error(
                "RESTAURANT_INFORMATION_MISSING"
            );

        }


        console.log(
            "Verifying restaurant profile..."
        );


        const restaurantRef =
            doc(
                db,
                "restaurants",
                restaurantId
            );


        const restaurantSnapshot =
            await getDoc(
                restaurantRef
            );


        if (!restaurantSnapshot.exists()) {

            throw new Error(
                "RESTAURANT_NOT_FOUND"
            );

        }


        const restaurantData =
            restaurantSnapshot.data();


        /*
         * Make sure this restaurant actually
         * belongs to the authenticated owner.
         */

        if (
            restaurantData.ownerId !==
            user.uid
        ) {

            throw new Error(
                "RESTAURANT_OWNER_MISMATCH"
            );

        }


        console.log(
            "Restaurant verification: SUCCESS"
        );


        return restaurantData;

    };


/* ============================================================
   COMPLETE LOGIN
============================================================ */

BKLogin.completeLogin =
    async function (user) {

        try {

            const ownerData =
                await BKLogin.loadOwnerProfile(
                    user
                );


            const restaurantId =
                ownerData.restaurantId;


            if (!restaurantId) {

                throw new Error(
                    "RESTAURANT_ID_MISSING"
                );

            }


            const restaurantData =
                await BKLogin.verifyRestaurant(
                    restaurantId,
                    user
                );


            /*
             * Save only the identifiers required
             * by the dashboard session.
             */

            localStorage.setItem(
                "bkOwnerUid",
                user.uid
            );


            localStorage.setItem(
                "bkRestaurantId",
                restaurantId
            );


            localStorage.setItem(
                "bkOwnerEmail",
                user.email || ""
            );


            console.log(
                "=========================================="
            );

            console.log(
                "BK OWNER LOGIN SUCCESS"
            );

            console.log(
                "Owner UID:",
                user.uid
            );

            console.log(
                "Restaurant ID:",
                restaurantId
            );

            console.log(
                "Restaurant:",
                restaurantData.name || "Restaurant"
            );

            console.log(
                "=========================================="
            );


            /*
             * Give Firebase session a moment to settle,
             * then open the private owner dashboard.
             */

            window.location.href =
                "owner.html";

        } catch (error) {

            console.error(
                "Owner profile verification failed:",
                error
            );


            BKLogin.handleProfileError(
                error
            );

        }

    };


/* ============================================================
   PROFILE ERROR HANDLER
============================================================ */

BKLogin.handleProfileError =
    function (error) {

        let message =
            "Unable to verify your owner account.";


        switch (error.message) {

            case "OWNER_PROFILE_NOT_FOUND":

                message =
                    "Owner profile was not found. Please contact BK support.";

                break;


            case "RESTAURANT_ID_MISSING":

                message =
                    "Your restaurant profile is not connected to this account.";

                break;


            case "RESTAURANT_NOT_FOUND":

                message =
                    "Your restaurant profile could not be found.";

                break;


            case "RESTAURANT_OWNER_MISMATCH":

                message =
                    "This restaurant is not connected to your owner account.";

                break;


            case "RESTAURANT_INFORMATION_MISSING":

                message =
                    "Restaurant information is incomplete.";

                break;


            default:

                message =
                    "Unable to verify your restaurant account. Please try again.";

        }


        BKLogin.showError(
            message
        );

    };


/* ============================================================
   OVERRIDE LOGIN SUCCESS FLOW
============================================================ */

BKLogin.handleLogin =
    async function () {

        if (
            BKLogin.state.loginInProgress
        ) {

            return;

        }


        const emailInput =
            document.getElementById(
                "loginEmail"
            );


        const passwordInput =
            document.getElementById(
                "loginPassword"
            );


        if (
            !emailInput ||
            !passwordInput
        ) {

            return;

        }


        const email =
            emailInput.value.trim();


        const password =
            passwordInput.value;


        const validation =
            BKLogin.validateInputs(
                email,
                password
            );


        if (!validation.valid) {

            BKLogin.showError(
                validation.message
            );

            return;

        }


        BKLogin.clearError();


        BKLogin.state.loginInProgress =
            true;


        BKLogin.setLoading(true);


        try {

            console.log(
                "Signing in owner..."
            );


            const credential =
                await signInWithEmailAndPassword(
                    auth,
                    email,
                    password
                );


            BKLogin.state.currentUser =
                credential.user;


            console.log(
                "Firebase Authentication: SUCCESS"
            );


            await BKLogin.completeLogin(
                credential.user
            );


        } catch (error) {

            console.error(
                "Login process failed:",
                error
            );


            BKLogin.handleFirebaseError(
                error
            );

        } finally {

            BKLogin.state.loginInProgress =
                false;

            BKLogin.setLoading(false);

        }

    };


/* ============================================================
   COMPLETE EXISTING SESSION CHECK
============================================================ */

BKLogin.handleExistingSession =
    async function (user) {

        try {

            BKLogin.setLoading(true);


            console.log(
                "Existing owner session detected."
            );


            await BKLogin.completeLogin(
                user
            );

        } catch (error) {

            console.error(
                "Existing session verification failed:",
                error
            );


            BKLogin.setLoading(false);

        }

    };


/* ============================================================
   END — LOGIN JS PART 2
============================================================ */
/* ============================================================
   BK OWNER LOGIN
   PART 3 — SESSION REDIRECT + PASSWORD RECOVERY
============================================================ */


/* ============================================================
   EXISTING SESSION CHECK
============================================================ */

BKLogin.checkExistingSession =
    function () {

        console.log(
            "Checking existing Firebase session..."
        );


        onAuthStateChanged(
            auth,
            async function (user) {

                BKLogin.state.authChecked =
                    true;


                if (!user) {

                    console.log(
                        "No existing owner session."
                    );

                    return;

                }


                BKLogin.state.currentUser =
                    user;


                console.log(
                    "Existing Firebase session found."
                );


                console.log(
                    "Owner UID:",
                    user.uid
                );


                /*
                 * Verify the existing session
                 * before opening the dashboard.
                 */

                await BKLogin.handleExistingSession(
                    user
                );

            }
        );

    };


/* ============================================================
   FORGOT PASSWORD — FIREBASE
============================================================ */

BKLogin.setupForgotPassword =
    function () {

        const button =
            document.getElementById(
                "forgotPasswordButton"
            );


        const emailInput =
            document.getElementById(
                "loginEmail"
            );


        if (
            !button ||
            !emailInput
        ) {

            console.warn(
                "Forgot Password elements not found."
            );

            return;

        }


        /*
         * Prevent duplicate click handlers.
         */

        if (
            button.dataset.bkForgotReady ===
            "true"
        ) {

            return;

        }


        button.dataset.bkForgotReady =
            "true";


        button.addEventListener(
            "click",
            async function () {

                BKLogin.clearError();


                const email =
                    emailInput.value.trim();


                if (!email) {

                    BKLogin.showError(
                        "Enter your email address first."
                    );

                    emailInput.focus();

                    return;

                }


                if (!email.includes("@")) {

                    BKLogin.showError(
                        "Please enter a valid email address."
                    );

                    emailInput.focus();

                    return;

                }


                button.disabled =
                    true;


                const originalText =
                    button.textContent;


                button.textContent =
                    "Sending...";


                try {

                    const {
                        sendPasswordResetEmail
                    } = await import(
                        "https://www.gstatic.com/firebasejs/12.1.0/firebase-auth.js"
                    );


                    await sendPasswordResetEmail(
                        auth,
                        email
                    );


                    BKLogin.showError(
                        "Password reset email sent. Please check your inbox."
                    );


                    console.log(
                        "Password reset email sent."
                    );


                } catch (error) {

                    console.error(
                        "Password reset failed:",
                        error
                    );


                    switch (error.code) {

                        case "auth/invalid-email":

                            BKLogin.showError(
                                "Please enter a valid email address."
                            );

                            break;


                        case "auth/user-not-found":

                            BKLogin.showError(
                                "No BK owner account was found for this email."
                            );

                            break;


                        case "auth/too-many-requests":

                            BKLogin.showError(
                                "Too many requests. Please try again later."
                            );

                            break;


                        case "auth/network-request-failed":

                            BKLogin.showError(
                                "Network error. Please check your internet connection."
                            );

                            break;


                        default:

                            BKLogin.showError(
                                "Unable to send the password reset email."
                            );

                    }

                } finally {

                    button.disabled =
                        false;

                    button.textContent =
                        originalText;

                }

            }
        );


        console.log(
            "Forgot Password: READY"
        );

    };


/* ============================================================
   FINAL LOGIN SYSTEM STATUS
============================================================ */

console.log(
    "=========================================="
);

console.log(
    "BK OWNER LOGIN SYSTEM — READY"
);

console.log(
    "Authentication: Firebase"
);

console.log(
    "Owner Verification: Firestore"
);

console.log(
    "Restaurant Verification: ENABLED"
);

console.log(
    "Session Persistence: ENABLED"
);

console.log(
    "Password Recovery: ENABLED"
);

console.log(
    "Dashboard Redirect: ENABLED"
);

console.log(
    "=========================================="
);


/* ============================================================
   END — LOGIN JS PART 3
============================================================ */