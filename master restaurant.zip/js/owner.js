/* ============================================================
   BK RESTAURANT PLATFORM
   OWNER DASHBOARD — JAVASCRIPT PART 1/3
   Firebase Auth + Owner Core
   Version: 2.0.0
============================================================ */

"use strict";


/* ============================================================
   FIREBASE IMPORTS
============================================================ */

import {
    ownerAuth as auth,
    ownerDb as db
} from "./firebase-sessions.js";


import {
    onAuthStateChanged,
    setPersistence,
    browserLocalPersistence,
    signOut
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-auth.js";

import {
    doc,
    getDoc,
    getDocs,
    updateDoc,
    deleteDoc,
    writeBatch,
    serverTimestamp,
    collection,
    query,
    where,
    orderBy,
    limit,
    onSnapshot
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";
/* ============================================================
   BK OWNER APPLICATION
============================================================ */

const BKOwner = {

    /* ========================================================
       STATE
    ======================================================== */

    state: {

        currentUser: null,

        ownerData: null,

        restaurantData: null,

        restaurantId: null,

        currentSection: "overview",

        authChecked: false,

        ready: false
    },


    /* ========================================================
       INITIALIZE APPLICATION
    ======================================================== */

    init: async function () {

        console.log(
            "=========================================="
        );

        console.log(
            "BK Owner Dashboard initializing..."
        );

        console.log(
            "=========================================="
        );


        try {

            /*
             * Keep Firebase login active
             * when the owner closes/reopens the site.
             */

            await setPersistence(
                auth,
                browserLocalPersistence
            );


            console.log(
                "Firebase Auth persistence: LOCAL"
            );


        } catch (error) {

            /*
             * Persistence failure should NOT
             * stop the dashboard.
             */

            console.warn(
                "Firebase Auth persistence setup warning:",
                error
            );

        }


        /*
         * Start authentication listener.
         *
         * IMPORTANT:
         * setupAuthListener() now returns a Promise.
         * Therefore Part 3 can safely wait until
         * owner + restaurant data are loaded.
         */

        await this.setupAuthListener();

    },


    /* ========================================================
       AUTHENTICATION LISTENER
    ======================================================== */

    setupAuthListener: function () {

        console.log(
            "Waiting for Firebase Auth session..."
        );


        return new Promise(
            function (resolve, reject) {

                let firstAuthCheck = true;


                onAuthStateChanged(
                    auth,
                    async function (user) {

                        /*
                         * Firebase has completed
                         * its authentication check.
                         */

                        BKOwner.state.authChecked =
                            true;


                        /* ========================================
                           NO OWNER SESSION
                        ======================================== */

                        if (!user) {

                            console.warn(
                                "Firebase Auth: No owner session found."
                            );


                            /*
                             * Only redirect after Firebase
                             * actually confirms there is no user.
                             */

                            if (firstAuthCheck) {

                                firstAuthCheck = false;


                                window.location.href =
                                    "index.html";

                            }


                            resolve();

                            return;
                        }


                        firstAuthCheck = false;


                        /* ========================================
                           OWNER SESSION FOUND
                        ======================================== */

                        console.log(
                            "Firebase Auth: Owner session found."
                        );


                        console.log(
                            "Owner UID:",
                            user.uid
                        );


                        BKOwner.state.currentUser =
                            user;


                        try {

                            /* ------------------------------------
                               LOAD OWNER
                            ------------------------------------ */

                            await BKOwner.loadOwnerData();


                            /* ------------------------------------
                               LOAD RESTAURANT
                            ------------------------------------ */

                            await BKOwner.loadRestaurantData();


                            /* ------------------------------------
                               POPULATE UI
                            ------------------------------------ */

                            BKOwner.populateOwnerUI();

                            BKOwner.populateRestaurantUI();


                            BKOwner.state.ready =
                                true;


                            console.log(
                                "=========================================="
                            );

                            console.log(
                                "BK OWNER DASHBOARD READY"
                            );

                            console.log(
                                "Owner:",
                                BKOwner.state.ownerData.ownerName
                            );

                            console.log(
                                "Restaurant:",
                                BKOwner.state.restaurantData.name
                            );

                            console.log(
                                "Restaurant ID:",
                                BKOwner.state.restaurantId
                            );

                            console.log(
                                "=========================================="
                            );


                            resolve();


                        } catch (error) {

                            console.error(
                                "Owner Dashboard loading failed:",
                                error
                            );


                            BKOwner.showSystemError(
                                "Unable to load your restaurant account. Please refresh and try again."
                            );


                            reject(error);

                        }

                    }
                );

            }
        );
    },


    /* ========================================================
       LOAD OWNER DATA
       users/{uid}
    ======================================================== */

    loadOwnerData: async function () {

        const user =
            this.state.currentUser;


        if (!user) {

            throw new Error(
                "Authenticated user is missing."
            );
        }


        console.log(
            "Loading owner profile..."
        );


        const userRef =
            doc(
                db,
                "users",
                user.uid
            );


        const userSnapshot =
            await getDoc(
                userRef
            );


        if (!userSnapshot.exists()) {

            throw new Error(
                "Owner profile was not found."
            );
        }


        const ownerData =
            userSnapshot.data();


        this.state.ownerData =
            ownerData;


        if (!ownerData.restaurantId) {

            throw new Error(
                "Restaurant ID is missing from owner profile."
            );
        }


        this.state.restaurantId =
            ownerData.restaurantId;


        console.log(
            "Owner profile loaded successfully."
        );


        console.log(
            "Restaurant ID:",
            this.state.restaurantId
        );
    },


    /* ========================================================
       LOAD RESTAURANT DATA
       restaurants/{restaurantId}
    ======================================================== */

    loadRestaurantData: async function () {

        const restaurantId =
            this.state.restaurantId;


        if (!restaurantId) {

            throw new Error(
                "Restaurant ID is unavailable."
            );
        }


        console.log(
            "Loading restaurant profile..."
        );


        const restaurantRef =
            doc(
                db,
                "restaurants",
                restaurantId
            );


        const restaurantSnapshot =
            await getDoc(
                restaurantRef
            );


        if (!restaurantSnapshot.exists()) {

            throw new Error(
                "Restaurant profile was not found."
            );
        }


        const restaurantData =
            restaurantSnapshot.data();


        /*
         * Multi-tenant security check.
         *
         * Owner can only access their own restaurant.
         */

        if (
            restaurantData.ownerId !==
            this.state.currentUser.uid
        ) {

            throw new Error(
                "Restaurant ownership verification failed."
            );
        }


        this.state.restaurantData =
            restaurantData;


        console.log(
            "Restaurant profile loaded successfully."
        );


        console.log(
            "Restaurant name:",
            restaurantData.name
        );
    },


    /* ========================================================
       POPULATE OWNER UI
    ======================================================== */

    populateOwnerUI: function () {

        const ownerData =
            this.state.ownerData;


        const user =
            this.state.currentUser;


        if (!ownerData) {
            return;
        }


        const ownerNameElements =
            document.querySelectorAll(
                "[data-owner-name]"
            );


        ownerNameElements.forEach(
            function (element) {

                element.textContent =
                    ownerData.ownerName ||
                    "Owner";

            }
        );


        const ownerEmailElements =
            document.querySelectorAll(
                "[data-owner-email]"
            );


        ownerEmailElements.forEach(
            function (element) {

                element.textContent =
                    ownerData.email ||
                    (user && user.email) ||
                    "";

            }
        );


        const ownerAvatarElements =
            document.querySelectorAll(
                "[data-owner-avatar]"
            );


        const ownerName =
            ownerData.ownerName ||
            "Owner";


        const initials =
            this.getInitials(
                ownerName
            );


        ownerAvatarElements.forEach(
            function (element) {

                element.textContent =
                    initials;

            }
        );
    },


    /* ========================================================
       POPULATE RESTAURANT UI
    ======================================================== */

    populateRestaurantUI: function () {

        const restaurant =
            this.state.restaurantData;


        if (!restaurant) {
            return;
        }


        const restaurantNameElements =
            document.querySelectorAll(
                "[data-restaurant-name]"
            );


        restaurantNameElements.forEach(
            function (element) {

                element.textContent =
                    restaurant.name ||
                    "Restaurant";

            }
        );


        const restaurantTypeElements =
            document.querySelectorAll(
                "[data-restaurant-type]"
            );


        restaurantTypeElements.forEach(
            function (element) {

                element.textContent =
                    restaurant.type ||
                    "Restaurant";

            }
        );


        const cuisineElements =
            document.querySelectorAll(
                "[data-restaurant-cuisine]"
            );


        cuisineElements.forEach(
            function (element) {

                element.textContent =
                    restaurant.cuisine ||
                    "";

            }
        );
    },


    /* ========================================================
       GET INITIALS
    ======================================================== */

    getInitials: function (name) {

        if (!name) {
            return "BK";
        }


        const words =
            name
                .trim()
                .split(/\s+/)
                .filter(Boolean);


        if (words.length === 1) {

            return words[0]
                .substring(0, 2)
                .toUpperCase();

        }


        return (
            words[0].charAt(0) +
            words[words.length - 1].charAt(0)
        ).toUpperCase();
    },


    /* ========================================================
       SYSTEM ERROR
    ======================================================== */

    showSystemError: function (message) {

        console.error(
            "BK SYSTEM ERROR:",
            message
        );


        alert(
            message
        );
    },


    /* ========================================================
       LOGOUT
    ======================================================== */

    logout: async function () {

        try {

            console.log(
                "Logging out owner..."
            );


            await signOut(
                auth
            );


            console.log(
                "Owner logged out successfully."
            );


        } catch (error) {

            console.error(
                "Logout failed:",
                error
            );


            this.showSystemError(
                "Logout failed. Please try again."
            );
        }
    }

};

/* =====================================================
   BK ORDERS MODULE
   Real-time Firestore Order Management
====================================================== */

BKOwner.orders = {

    allOrders: [],
    currentFilter: "all",
    unsubscribe: null,
    pendingDeleteOrderId: null,

    init: function () {

        console.log("BK Orders Module initializing...");

        const restaurantId = BKOwner.state.restaurantId;

        if (!restaurantId) {
            console.warn("Orders: Restaurant ID unavailable.");
            return;
        }

        this.startRealtimeOrders(restaurantId);
        this.setupOrderFilters();
        this.setupRefreshButton();
        this.setupDeleteModal();

        console.log("BK Orders Module ready.");
    },


    /* =================================================
       REAL-TIME ORDERS
    ================================================= */

    startRealtimeOrders: function (restaurantId) {

        if (this.unsubscribe) {
            this.unsubscribe();
            this.unsubscribe = null;
        }

        const ordersRef = collection(
            db,
            "restaurants",
            restaurantId,
            "orders"
        );

        this.unsubscribe = onSnapshot(
            ordersRef,
            (snapshot) => {

                const orders = [];

                snapshot.forEach((orderDoc) => {

                    orders.push({
                        id: orderDoc.id,
                        ...orderDoc.data()
                    });

                });

                /*
                 * Newest orders first.
                 * createdAt currently comes from
                 * the customer order as ISO string.
                 */

                orders.sort((a, b) => {

                    const timeA = Date.parse(a.createdAt || "") || 0;
                    const timeB = Date.parse(b.createdAt || "") || 0;

                    return timeB - timeA;

                });

                this.allOrders = orders;

                console.log(
                    "BK Orders updated:",
                    this.allOrders
                );

                this.updateOrderSummary();
                this.renderOrders();

            },
            (error) => {

                console.error(
                    "BK Orders realtime listener failed:",
                    error
                );

                this.showOrdersError();

            }
        );
    },


    /* =================================================
       SUMMARY COUNTS
    ================================================= */

    updateOrderSummary: function () {

        const orders = this.allOrders;

        const total = orders.length;

        const pending = orders.filter(
            order => order.status === "pending"
        ).length;

        const confirmed = orders.filter(
            order => order.status === "confirmed"
        ).length;

        const preparing = orders.filter(
            order => order.status === "preparing"
        ).length;

        const ready = orders.filter(
            order => order.status === "ready"
        ).length;

        const completed = orders.filter(
            order => order.status === "completed"
        ).length;


        this.setText(
            "ordersTotalCount",
            total
        );

        this.setText(
            "ordersPendingCount",
            pending
        );

        this.setText(
            "ordersConfirmedCount",
            confirmed
        );

        this.setText(
            "ordersPreparingCount",
            preparing
        );

        this.setText(
            "ordersReadyCount",
            ready
        );

        this.setText(
            "ordersCompletedCount",
            completed
        );
    },


    /* =================================================
       FILTERS
    ================================================= */

    setupOrderFilters: function () {

        const filterCards = document.querySelectorAll(
            "[data-order-filter]"
        );

        filterCards.forEach((card) => {

            if (card.dataset.ordersFilterReady === "true") {
                return;
            }

            card.dataset.ordersFilterReady = "true";

            card.addEventListener("click", () => {

                const filter =
                    card.getAttribute("data-order-filter");

                this.currentFilter = filter || "all";

                this.updateFilterLabel();

                this.renderOrders();

            });

        });

    },


    updateFilterLabel: function () {

        const label =
            document.getElementById(
                "ordersCurrentFilterLabel"
            );

        if (!label) return;

        const labels = {

            all: "All Orders",
            pending: "Pending Orders",
            confirmed: "Confirmed Orders",
            preparing: "Preparing Orders",
            ready: "Ready Orders",
            completed: "Completed Orders"

        };

        label.textContent =
            labels[this.currentFilter] ||
            "All Orders";
    },


    /* =================================================
       REFRESH
    ================================================= */

    setupRefreshButton: function () {

        const button =
            document.getElementById(
                "refreshOrdersButton"
            );

        if (!button) return;

        if (button.dataset.ordersRefreshReady === "true") {
            return;
        }

        button.dataset.ordersRefreshReady = "true";

        button.addEventListener("click", () => {

            const restaurantId =
                BKOwner.state.restaurantId;

            if (!restaurantId) return;

            this.startRealtimeOrders(
                restaurantId
            );

        });

    },
    setupDeleteModal: function () {

    const modal = document.getElementById(
        "bkOrderDeleteModal"
    );

    const cancelButton = document.getElementById(
        "bkOrderDeleteCancelButton"
    );

    const confirmButton = document.getElementById(
        "bkOrderDeleteConfirmButton"
    );

    const backdrop = modal
        ? modal.querySelector(
            "[data-close-order-delete]"
        )
        : null;

    if (!modal) {
        console.warn(
            "Delete Order Modal: Modal element not found."
        );
        return;
    }

    if (modal.dataset.deleteModalReady === "true") {
        return;
    }

    modal.dataset.deleteModalReady = "true";

    if (cancelButton) {
        cancelButton.addEventListener(
            "click",
            () => {
                this.closeDeleteModal();
            }
        );
    }

    if (backdrop) {
        backdrop.addEventListener(
            "click",
            () => {
                this.closeDeleteModal();
            }
        );
    }

if (confirmButton) {
    confirmButton.addEventListener(
        "click",
        async () => {

            const orderId =
                this.pendingDeleteOrderId;

            if (!orderId) {
                console.warn(
                    "Delete Order: No pending order selected."
                );
                return;
            }

            await this.deleteOrder(orderId);
        }
    );
}
    console.log(
        "BK Order Delete Modal: READY"
    );
},

confirmDeleteOrder: function (orderId) {

    if (!orderId) {
        console.warn(
            "Delete Order: Order ID unavailable."
        );
        return;
    }

    const order = this.allOrders.find(
        item => item.id === orderId
    );

    if (!order) {
        console.warn(
            "Delete Order: Order not found.",
            orderId
        );
        return;
    }

    this.pendingDeleteOrderId = orderId;

    const modal = document.getElementById(
        "bkOrderDeleteModal"
    );

    const orderIdElement = document.getElementById(
        "bkDeleteOrderId"
    );

    const statusElement = document.getElementById(
        "bkDeleteOrderStatus"
    );

    if (!modal) {
        console.warn(
            "Delete Order: Confirmation modal not found."
        );
        return;
    }

    if (orderIdElement) {
        orderIdElement.textContent =
            "#" + order.id.slice(-6).toUpperCase();
    }

    if (statusElement) {
        statusElement.textContent =
            this.formatStatus(
                order.status || "pending"
            );
    }

    modal.hidden = false;

    document.body.classList.add(
        "bk-order-delete-open"
    );

    console.log(
        "Delete Order: Confirmation modal opened.",
        orderId
    );
},
closeDeleteModal: function () {

    const modal = document.getElementById(
        "bkOrderDeleteModal"
    );

    if (!modal) {
        return;
    }

    modal.hidden = true;

    this.pendingDeleteOrderId = null;

    document.body.classList.remove(
        "bk-order-delete-open"
    );

    console.log(
        "Delete Order: Confirmation modal closed."
    );
},

deleteOrder: async function (orderId) {

    const restaurantId =
        BKOwner.state.restaurantId;

    if (!restaurantId || !orderId) {
        console.warn(
            "Delete Order: Missing restaurant or order ID."
        );
        return;
    }

    try {

        console.log(
            "Delete Order: Permanently deleting...",
            orderId
        );

        const orderRef = doc(
            db,
            "restaurants",
            restaurantId,
            "orders",
            orderId
        );

        await deleteDoc(orderRef);

        this.pendingDeleteOrderId = null;

        this.closeDeleteModal();

        console.log(
            "Delete Order: Firestore document deleted successfully.",
            orderId
        );

        if (typeof BKOwner.showToast === "function") {

            BKOwner.showToast(
                "Order deleted permanently."
            );

        }

    } catch (error) {

        console.error(
            "Delete Order: Firestore deletion failed:",
            error
        );

        if (
            typeof BKOwner.showSystemError ===
            "function"
        ) {

            BKOwner.showSystemError(
                "Unable to delete the order."
            );

        }
    }
},

    /* =================================================
       RENDER ORDERS
    ================================================= */

    renderOrders: function () {

        const list =
            document.getElementById(
                "ordersList"
            );

        const emptyState =
            document.getElementById(
                "ordersEmptyState"
            );

        if (!list) return;


        let orders = [...this.allOrders];


        if (this.currentFilter !== "all") {

            orders = orders.filter(
                order =>
                    order.status === this.currentFilter
            );

        }


        /*
         * No matching orders
         */

        if (orders.length === 0) {

            if (emptyState) {
                emptyState.style.display = "block";
            }

            const existingCards =
                list.querySelectorAll(
                    ".bk-order-card"
                );

            existingCards.forEach(
                card => card.remove()
            );

            return;
        }


        if (emptyState) {
            emptyState.style.display = "none";
        }


        const existingCards =
            list.querySelectorAll(
                ".bk-order-card"
            );

        existingCards.forEach(
            card => card.remove()
        );


        orders.forEach((order) => {

            const card =
                this.createOrderCard(order);

            list.appendChild(card);

        });

    },


    /* =================================================
       ORDER CARD
    ================================================= */

    createOrderCard: function (order) {

        const card =
            document.createElement("article");

        card.className =
            "bk-order-card";

        const customerName =
            order.customerName ||
            "Guest";

        const tableId =
            order.tableId ||
            "Table —";

        const status =
            order.status ||
            "pending";

        const total =
            Number(order.total || 0);


        const orderTime =
            this.formatOrderTime(
                order.createdAt
            );


        const items =
            Array.isArray(order.items)
                ? order.items
                : [];


        const itemsHTML =
            items.map((item) => {

                const quantity =
                    Number(item.quantity || 1);

                const price =
                    Number(item.price || 0);

                const itemTotal =
                    price * quantity;

                return `
                    <div class="bk-order-item">

                        <div class="bk-order-item-main">

                            <strong>
                                ${this.escapeHTML(
                                    item.name || "Item"
                                )}
                            </strong>

                            <span>
                                × ${quantity}
                            </span>

                        </div>

                        <b>
                            ₹${itemTotal.toFixed(2)}
                        </b>

                    </div>
                `;

            }).join("");


        card.innerHTML = `

            <div class="bk-order-card-top">

                <div>

                    <span class="bk-order-number">
                        ORDER #${this.escapeHTML(
                            order.id.slice(-6).toUpperCase()
                        )}
                    </span>

                    <strong class="bk-order-customer">
                        ${this.escapeHTML(customerName)}
                    </strong>

                </div>


                <div class="bk-order-status-area">

    <span class="
        bk-order-status
        bk-order-status-${this.escapeHTML(status)}
    ">
        ${this.formatStatus(status)}
    </span>

${
    status === "pending"
        ? `
            <button
                type="button"
                class="bk-order-confirm-button"
                data-order-status-action="confirmed"
                data-order-id="${this.escapeHTML(order.id)}"
            >
                ✓ Confirm Order
            </button>
          `
        : status === "confirmed"
        ? `
            <button
                type="button"
                class="bk-order-prepare-button"
                data-order-status-action="preparing"
                data-order-id="${this.escapeHTML(order.id)}"
            >
                ◇ Start Preparing
            </button>
          `
                : status === "preparing"
        ? `
            <button
                type="button"
                class="bk-order-ready-button"
                data-order-status-action="ready"
                data-order-id="${this.escapeHTML(order.id)}"
            >
                ✦ Mark Ready
            </button>
          `
        : status === "ready"
        ? `
            <button
                type="button"
                class="bk-order-complete-button"
                data-order-status-action="completed"
                data-order-id="${this.escapeHTML(order.id)}"
            >
                ✓ Complete Order
            </button>
          `
        : ""
}        
</div>
            </div>


            <div class="bk-order-meta">

                <span>
                    ◫ ${this.escapeHTML(tableId)}
                </span>

                <span>
                    ◷ ${orderTime}
                </span>

            </div>


            <div class="bk-order-items">

                ${itemsHTML}

            </div>


            <div class="bk-order-card-bottom">

    <div>

        <small>
            ORDER TOTAL
        </small>

        <strong>
            ₹${total.toFixed(2)}
        </strong>

    </div>


    <div class="bk-order-card-actions">

        <div class="bk-order-status-note">

            ${this.getNextStatusText(status)}

        </div>

        <button
            type="button"
            class="bk-order-delete-button"
            data-order-delete
            data-order-id="${this.escapeHTML(order.id)}"
        >
            🗑 DELETE ORDER
        </button>

    </div>

</div>
        `;
const deleteOrderButton =
    card.querySelector("[data-order-delete]");

if (deleteOrderButton) {

    deleteOrderButton.addEventListener(
        "click",
        (event) => {

            event.stopPropagation();

            const orderId =
                deleteOrderButton.getAttribute(
                    "data-order-id"
                );

            if (!orderId) {
                console.warn(
                    "Delete order: Order ID unavailable."
                );
                return;
            }

            this.confirmDeleteOrder(orderId);

        }
    );
    /* =================================================
   ORDER STATUS BUTTON
================================================= */

const statusButton =
    card.querySelector(
        "[data-order-status-action]"
    );

if (statusButton) {

    statusButton.addEventListener(
        "click",
        async (event) => {

            event.preventDefault();
            event.stopPropagation();

            const orderId =
                statusButton.getAttribute(
                    "data-order-id"
                );

            const newStatus =
                statusButton.getAttribute(
                    "data-order-status-action"
                );

            if (!orderId || !newStatus) {

                console.warn(
                    "Order status action: missing data.",
                    {
                        orderId,
                        newStatus
                    }
                );

                return;
            }

            console.log(
                "BK ORDER STATUS CLICK:",
                orderId,
                "→",
                newStatus
            );

            statusButton.disabled = true;

            try {

                await this.updateOrderStatus(
                    orderId,
                    newStatus
                );

            } finally {

                statusButton.disabled = false;

            }

        }
    );

}

}      return card;
    },


    /* =================================================
       HELPERS
    ================================================= */

    formatStatus: function (status) {

        const labels = {

            pending: "PENDING",
            confirmed: "CONFIRMED",
            preparing: "PREPARING",
            ready: "READY",
            completed: "COMPLETED"

        };

        return labels[status] || "PENDING";
    },


    getNextStatusText: function (status) {

        const messages = {

            pending:
                "Awaiting confirmation",

            confirmed:
                "Ready for preparation",

            preparing:
                "Currently preparing",

            ready:
                "Ready for customer",

            completed:
                "Order completed"

        };

        return messages[status] ||
            "Order received";

    },


    formatOrderTime: function (value) {

        if (!value) {
            return "Time unavailable";
        }

        const date =
            new Date(value);

        if (Number.isNaN(date.getTime())) {
            return "Time unavailable";
        }

        return date.toLocaleString(
            "en-IN",
            {
                day: "2-digit",
                month: "short",
                hour: "2-digit",
                minute: "2-digit"
            }
        );

    },


    setText: function (id, value) {

        const element =
            document.getElementById(id);

        if (element) {
            element.textContent = value;
        }

    },


    escapeHTML: function (value) {

        const div =
            document.createElement("div");

        div.textContent =
            String(value);

        return div.innerHTML;

    },
    
/* =================================================
   UPDATE ORDER STATUS
================================================= */

updateOrderStatus: async function (
    orderId,
    newStatus
) {

    const restaurantId =
        BKOwner.state.restaurantId;

    if (!restaurantId || !orderId) {

        console.warn(
            "Order status update: missing data."
        );

        return;
    }


    try {

        console.log(
            "Updating order:",
            orderId,
            "→",
            newStatus
        );


        const orderRef = doc(
            db,
            "restaurants",
            restaurantId,
            "orders",
            orderId
        );


        await updateDoc(
            orderRef,
            {
                status: newStatus,
                updatedAt: serverTimestamp()
            }
        );


        console.log(
            "Order status updated successfully."
        );


        if (
            typeof BKOwner.showToast ===
            "function"
        ) {

const statusMessages = {
    confirmed: "Order confirmed successfully.",
    preparing: "Order moved to preparation.",
    ready: "Order marked ready.",
    completed: "Order completed successfully."
};

if (typeof BKOwner.showToast === "function") {
    BKOwner.showToast(
        statusMessages[newStatus] ||
        "Order status updated successfully."
    );
}
        }


    } catch (error) {

        console.error(
            "Order status update failed:",
            error
        );


        if (
            typeof BKOwner.showSystemError ===
            "function"
        ) {

            BKOwner.showSystemError(
                "Unable to update the order status."
            );

        }

    }

},

    showOrdersError: function () {

        const list =
            document.getElementById(
                "ordersList"
            );

        if (!list) return;

        list.innerHTML = `

            <div class="bk-orders-empty">

                <div class="bk-orders-empty-mark">
                    !
                </div>

                <span>
                    ORDER SYSTEM
                </span>

                <h3>
                    Unable to Load Orders
                </h3>

                <p>
                    Please refresh the dashboard
                    and try again.
                </p>

            </div>

        `;

    }

};


BKOwner.firebase = {
    auth: auth,
    db: db
};
/* ============================================================
   GLOBAL ACCESS
============================================================ */

window.BKOwner =
    BKOwner;
/*
========================================================
BK OWNER — MONTHLY BILLING FIRESTORE BRIDGE
STEP M3 — READ ACCESS
========================================================
*/
BKOwner.getMonthlyBillingFirebaseModules = function () {

    return {
        db,
        doc,
        getDoc,
        getDocs,
        collection,
        query,
        where,
        orderBy,
        limit
    };

};

console.info(
    "BK OWNER MONTHLY BILLING: FIRESTORE BRIDGE READY."
);

/* ============================================================
   DOM READY
============================================================ */

document.addEventListener(
    "DOMContentLoaded",
    async function () {

        try {

            await BKOwner.init();

        } catch (error) {

            console.error(
                "BK Owner initialization failed:",
                error
            );

        }

    }
);


/* ============================================================
   END — PART 1/3
============================================================ */
/* ============================================================
   BK RESTAURANT PLATFORM
   OWNER DASHBOARD — JAVASCRIPT PART 2/3
   Navigation + Dashboard Interaction
============================================================ */


/* ============================================================
   DASHBOARD NAVIGATION
============================================================ */

BKOwner.setupNavigation = function () {

    const navigationItems =
        document.querySelectorAll(
            "[data-section]"
        );


    navigationItems.forEach(
        function (item) {

            item.addEventListener(
                "click",
                function (event) {

                    event.preventDefault();


                    const sectionName =
                        item.getAttribute(
                            "data-section"
                        );


                    if (!sectionName) {
                        return;
                    }


                    BKOwner.showSection(
                        sectionName
                    );


                    /*
                     * Close mobile sidebar
                     * after navigation.
                     */

                    BKOwner.closeMobileSidebar();

                }
            );

        }
    );


    console.log(
        "Navigation: READY"
    );
};


/* ============================================================
   SHOW DASHBOARD SECTION
============================================================ */

BKOwner.showSection = function (
    sectionName
) {

    if (!sectionName) {
        return;
    }


    /*
     * MONTHLY BILLING OVERDUE NAVIGATION LOCK
     */

    const monthlyBilling =
        window.BKOwnerMonthlyBilling;

    const isBillingLocked =
        Boolean(
            monthlyBilling &&
            monthlyBilling.state &&
            monthlyBilling.state.billingLockActive
        );

    const restrictedSections = [
        "overview",
        "restaurant",
        "menu",
        "orders",
        "bookings",
        "tables",
        "website",
        "customers",
        "analytics",
        "settings"
    ];

    if (
        isBillingLocked &&
        restrictedSections.includes(sectionName)
    ) {

        console.warn(
            "BK OWNER: Monthly billing overdue. Access restricted."
        );

        sectionName = "subscription";

    }


    const sections =
        document.querySelectorAll(
            ".dashboard-section"
        );


    /*
     * Hide all sections.
     */

    sections.forEach(
        function (section) {

            section.classList.remove(
                "active"
            );

        }
    );


    /*
     * Find requested section.
     */

    const targetSection =
        document.querySelector(
            '[data-dashboard-section="' +
            sectionName +
            '"]'
        );


    if (targetSection) {

        targetSection.classList.add(
            "active"
        );


        BKOwner.state.currentSection =
            sectionName;


    } else {

        /*
         * Section module may not be built yet.
         * Keep Overview visible.
         */

        const overviewSection =
            document.querySelector(
                '[data-dashboard-section="overview"]'
            );


        if (overviewSection) {

            overviewSection.classList.add(
                "active"
            );

        }


        BKOwner.state.currentSection =
            "overview";


        console.warn(
            "Dashboard section not implemented yet:",
            sectionName
        );

    }


    /*
     * Update sidebar active state.
     */

    BKOwner.updateActiveNavigation(
        BKOwner.state.currentSection
    );

    /* ============================================================
       BK UNIVERSAL NOTIFICATION — OVERVIEW INTEGRATION
    ============================================================ */

    if (
        BKOwner.state.currentSection === "overview"
    ) {

        const ownerNotifications =
            window.BKUniversalOwnerNotifications;

        if (
            ownerNotifications &&
            typeof ownerNotifications.onOverviewOpened === "function"
        ) {

            ownerNotifications.onOverviewOpened();

        }

    }


    /*
     * Scroll content to top.
     */

    const mainContent =
        document.querySelector(
            ".owner-content"
        );


    if (mainContent) {

        mainContent.scrollTo({
            top: 0,
            behavior: "smooth"
        });

    } else {

        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });

    }

};


/* ============================================================
   ACTIVE NAVIGATION
============================================================ */

BKOwner.updateActiveNavigation =
    function (sectionName) {

        const navigationItems =
            document.querySelectorAll(
                "[data-section]"
            );


        navigationItems.forEach(
            function (item) {

                const itemSection =
                    item.getAttribute(
                        "data-section"
                    );


                if (
                    itemSection ===
                    sectionName
                ) {

                    item.classList.add(
                        "active"
                    );

                } else {

                    item.classList.remove(
                        "active"
                    );

                }

            }
        );

    };


/* ============================================================
   QUICK ACTIONS
============================================================ */

BKOwner.setupQuickActions =
    function () {

        const quickActions =
            document.querySelectorAll(
                "[data-action]"
            );


        quickActions.forEach(
            function (action) {

                action.addEventListener(
                    "click",
                    function (event) {

                        event.preventDefault();


                        const actionName =
                            action.getAttribute(
                                "data-action"
                            );


                        BKOwner.handleAction(
                            actionName
                        );

                    }
                );

            }
        );


        console.log(
            "Quick Actions: READY"
        );

    };


/* ============================================================
   QUICK ACTION HANDLER
============================================================ */

BKOwner.handleAction =
    function (actionName) {

        if (!actionName) {
            return;
        }


        switch (actionName) {


            /* ================================================
               ADD MENU ITEM
            ================================================ */

            case "add-menu-item":

                BKOwner.showSection(
                    "menu"
                );


                console.log(
                    "Action: Add Menu Item"
                );

                break;


            /* ================================================
               NEW BOOKING
            ================================================ */

            case "new-booking":

                BKOwner.showSection(
                    "bookings"
                );


                console.log(
                    "Action: New Booking"
                );

                break;


            /* ================================================
               MANAGE TABLES
            ================================================ */

            case "manage-tables":

                BKOwner.showSection(
                    "tables"
                );


                console.log(
                    "Action: Manage Tables"
                );

                break;


            /* ================================================
               OPEN CUSTOMER WEBSITE
            ================================================ */

            case "open-website":

                BKOwner.openCustomerWebsite();

                break;


            /* ================================================
               VIEW QR
            ================================================ */

            case "view-qr":

    BKOwner.showSection(
        "website"
    );

    console.log(
        "Action: View QR Code"
    );

    break;

            /* ================================================
               COPY LINK
            ================================================ */

            case "copy-link":

                BKOwner.copyWebsiteLink();

                break;


            /* ================================================
               PROFILE
            ================================================ */

            case "profile":

                BKOwner.showSection(
                    "settings"
                );

                break;


            /* ================================================
               LOGOUT
            ================================================ */

            case "logout":

                BKOwner.logout();

                break;


            /* ================================================
               DEFAULT
            ================================================ */

            default:

                console.warn(
                    "Unknown dashboard action:",
                    actionName
                );

        }

    };
    


/* ============================================================
   MOBILE SIDEBAR
============================================================ */

BKOwner.setupMobileSidebar =
    function () {

        const menuButton =
            document.querySelector(
                ".mobile-menu-button"
            );


        const sidebar =
            document.querySelector(
                ".owner-sidebar"
            );


        const overlay =
            document.querySelector(
                ".sidebar-overlay"
            );


        if (!sidebar) {

            console.warn(
                "Mobile sidebar element not found."
            );

            return;
        }


        if (menuButton) {

            menuButton.addEventListener(
                "click",
                function () {

                    BKOwner.openMobileSidebar();

                }
            );

        }


        if (overlay) {

            overlay.addEventListener(
                "click",
                function () {

                    BKOwner.closeMobileSidebar();

                }
            );

        }


        console.log(
            "Mobile Sidebar: READY"
        );

    };


/* ============================================================
   OPEN MOBILE SIDEBAR
============================================================ */

BKOwner.openMobileSidebar =
    function () {

        const sidebar =
            document.querySelector(
                ".owner-sidebar"
            );


        const overlay =
            document.querySelector(
                ".sidebar-overlay"
            );


        if (sidebar) {

            sidebar.classList.add(
                "mobile-open"
            );

        }


        if (overlay) {

            overlay.classList.add(
                "show"
            );

        }


        document.body.classList.add(
            "sidebar-open"
        );

    };


/* ============================================================
   CLOSE MOBILE SIDEBAR
============================================================ */

BKOwner.closeMobileSidebar =
    function () {

        const sidebar =
            document.querySelector(
                ".owner-sidebar"
            );


        const overlay =
            document.querySelector(
                ".sidebar-overlay"
            );


        if (sidebar) {

            sidebar.classList.remove(
                "mobile-open"
            );

        }


        if (overlay) {

            overlay.classList.remove(
                "show"
            );

        }


        document.body.classList.remove(
            "sidebar-open"
        );

    };


/* ============================================================
   PROFILE DROPDOWN
============================================================ */

BKOwner.setupProfileDropdown =
    function () {

        const profileButton =
            document.querySelector(
                ".owner-profile"
            );


        const dropdown =
            document.querySelector(
                ".profile-dropdown"
            );


        if (
            !profileButton ||
            !dropdown
        ) {

            console.warn(
                "Profile dropdown elements not found."
            );

            return;
        }


        profileButton.addEventListener(
            "click",
            function (event) {

                event.stopPropagation();


                dropdown.classList.toggle(
                    "show"
                );

            }
        );


        document.addEventListener(
            "click",
            function (event) {

                if (
                    !dropdown.contains(
                        event.target
                    ) &&
                    !profileButton.contains(
                        event.target
                    )
                ) {

                    dropdown.classList.remove(
                        "show"
                    );

                }

            }
        );


        console.log(
            "Profile Controls: READY"
        );

    };


/* ============================================================
   LOGOUT BUTTONS
============================================================ */

BKOwner.setupLogoutButtons =
    function () {

        const logoutButtons =
            document.querySelectorAll(
                "#logoutButton, #profileLogoutButton"
            );


        logoutButtons.forEach(
            function (button) {

                button.addEventListener(
                    "click",
                    async function (event) {

                        event.preventDefault();


                        const confirmed =
                            window.confirm(
                                "Are you sure you want to log out?"
                            );


                        if (!confirmed) {
                            return;
                        }


                        await BKOwner.logout();

                    }
                );

            }
        );


        console.log(
            "Logout Controls: READY"
        );

    };


/* ============================================================
   CUSTOMER WEBSITE URL
============================================================ */

BKOwner.getCustomerWebsiteUrl =
    function () {

        const restaurantId =
            BKOwner.state.restaurantId;


        if (!restaurantId) {
            return "";
        }


        const currentPath =
            window.location.pathname;


        const directory =
            currentPath.substring(
                0,
                currentPath.lastIndexOf("/")
            );


        return (
            window.location.origin +
            directory +
            "/customer.html?restaurant=" +
            encodeURIComponent(
                restaurantId
            )
        );

    };
/* ============================================================
   OPEN CUSTOMER WEBSITE
============================================================ */

BKOwner.openCustomerWebsite =
    function () {

        const websiteUrl =
            BKOwner.getCustomerWebsiteUrl();


        if (!websiteUrl) {

            BKOwner.showSystemError(
                "Customer website link is not available yet."
            );

            return;
        }


        /*
         * customer.html will be created
         * during the Mini Website phase.
         */

        window.open(
            websiteUrl,
            "_blank"
        );


        console.log(
            "Customer website:",
            websiteUrl
        );

    };


/* ============================================================
   COPY WEBSITE LINK
============================================================ */

BKOwner.copyWebsiteLink =
    async function () {

        const websiteUrl =
            BKOwner.getCustomerWebsiteUrl();


        if (!websiteUrl) {

            BKOwner.showSystemError(
                "Website link is not available yet."
            );

            return;
        }


        try {

            await navigator.clipboard.writeText(
                websiteUrl
            );


            BKOwner.showToast(
                "Website link copied successfully."
            );


        } catch (error) {

            console.error(
                "Website link copy failed:",
                error
            );


            BKOwner.showSystemError(
                "Unable to copy the website link."
            );

        }

    };


/* ============================================================
   TOAST
============================================================ */

BKOwner.showToast =
    function (message) {

        let toast =
            document.querySelector(
                ".bk-toast"
            );


        if (!toast) {

            toast =
                document.createElement(
                    "div"
                );


            toast.className =
                "bk-toast";


            document.body.appendChild(
                toast
            );

        }


        toast.textContent =
            message;


        toast.classList.add(
            "show"
        );


        clearTimeout(
            BKOwner.toastTimer
        );


        BKOwner.toastTimer =
            setTimeout(
                function () {

                    toast.classList.remove(
                        "show"
                    );

                },
                2600
            );

    };



/* ============================================================
   NOTIFICATION BUTTON — BK UNIVERSAL ENGINE
============================================================ */

BKOwner.setupNotificationButton =
    function () {

        const notificationButton =
            document.getElementById(
                "notificationButton"
            );

        if (!notificationButton) {
            console.warn(
                "BK Notification Button: NOT FOUND"
            );
            return;
        }

        /*
         * Prevent duplicate event listeners.
         */

        if (
            notificationButton.dataset.bkNotificationReady ===
            "true"
        ) {
            return;
        }

        notificationButton.dataset.bkNotificationReady =
            "true";

        notificationButton.addEventListener(
            "click",
            function () {

                BKOwner.showSection(
                    "overview"
                );

            }
        );

        console.log(
            "BK Notification Button: READY"
        );

    };


/* ============================================================
   DASHBOARD INTERACTIONS
============================================================ */

BKOwner.setupDashboardInteractions =
    function () {

        /*
         * IMPORTANT:
         * These functions are called only after
         * Firebase owner data is ready.
         */

        BKOwner.setupNavigation();

        BKOwner.setupQuickActions();

        BKOwner.setupMobileSidebar();

        BKOwner.setupProfileDropdown();

        BKOwner.setupLogoutButtons();

        BKOwner.setupNotificationButton();


        /*
         * Start on Overview.
         */

        BKOwner.showSection(
            "overview"
        );


        console.log(
            "Dashboard Interactions: READY"
        );

    };


/* ============================================================
   END — NEW PART 2/3
============================================================ */
/* ============================================================
   BK RESTAURANT PLATFORM
   OWNER DASHBOARD — JAVASCRIPT PART 3/3
   Final Integration + Website + Profile Controls
   Version: 2.0.0
============================================================ */


/* ============================================================
   WEBSITE LINK UI
============================================================ */

BKOwner.populateWebsiteUI =
    function () {

        /*
         * Firebase data is already loaded
         * before this function is called.
         */

        const websiteUrl =
            BKOwner.getCustomerWebsiteUrl();


        if (!websiteUrl) {
            return;
        }


        /* ----------------------------------------------------
           WEBSITE LINK TEXT / INPUTS
        ---------------------------------------------------- */

        const websiteElements =
            document.querySelectorAll(
                "[data-website-link]"
            );


        websiteElements.forEach(
            function (element) {

                if (
                    element.tagName ===
                    "INPUT"
                ) {

                    element.value =
                        websiteUrl;

                } else {

                    element.textContent =
                        websiteUrl;

                }

            }
        );


        /* ----------------------------------------------------
           WEBSITE ANCHORS
        ---------------------------------------------------- */

        const websiteAnchors =
            document.querySelectorAll(
                "[data-website-url]"
            );


        websiteAnchors.forEach(
            function (anchor) {

                anchor.href =
                    websiteUrl;


                anchor.target =
                    "_blank";


                anchor.rel =
                    "noopener noreferrer";

            }
        );


        console.log(
            "Website URL UI: READY"
        );

    };


/* ============================================================
   COPY LINK BUTTONS
============================================================ */

BKOwner.setupCopyLinkButtons =
    function () {

        const copyButtons =
            document.querySelectorAll(
                "[data-action='copy-link']"
            );


        copyButtons.forEach(
            function (button) {

                /*
                 * Prevent duplicate event listeners.
                 */

                if (
                    button.dataset.bkCopyReady ===
                    "true"
                ) {
                    return;
                }


                button.dataset.bkCopyReady =
                    "true";


                button.addEventListener(
                    "click",
                    async function (event) {

                        event.preventDefault();


                        await BKOwner.copyWebsiteLink();

                    }
                );

            }
        );


        console.log(
            "Copy Link Controls: READY"
        );

    };


/* ============================================================
   CUSTOMER WEBSITE BUTTONS
============================================================ */

BKOwner.setupWebsiteButtons =
    function () {

        const websiteButtons =
            document.querySelectorAll(
                "[data-action='open-website']"
            );


        websiteButtons.forEach(
            function (button) {

                /*
                 * Prevent duplicate listeners.
                 */

                if (
                    button.dataset.bkWebsiteReady ===
                    "true"
                ) {
                    return;
                }


                button.dataset.bkWebsiteReady =
                    "true";


                button.addEventListener(
                    "click",
                    function (event) {

                        event.preventDefault();


                        BKOwner.openCustomerWebsite();

                    }
                );

            }
        );


        console.log(
            "Website Controls: READY"
        );

    };


/* ============================================================
   PROFILE ACTIONS
============================================================ */

BKOwner.setupProfileActions =
    function () {

        const profileButtons =
            document.querySelectorAll(
                "[data-action='profile']"
            );


        profileButtons.forEach(
            function (button) {

                /*
                 * Prevent duplicate listeners.
                 */

                if (
                    button.dataset.bkProfileReady ===
                    "true"
                ) {
                    return;
                }


                button.dataset.bkProfileReady =
                    "true";


                button.addEventListener(
                    "click",
                    function (event) {

                        event.preventDefault();


                        /*
                         * Close profile dropdown.
                         */

                        const dropdown =
                            document.querySelector(
                                ".profile-dropdown"
                            );


                        if (dropdown) {

                            dropdown.classList.remove(
                                "show"
                            );

                        }


                        /*
                         * Open Settings.
                         */

                        BKOwner.showSection(
                            "settings"
                        );

                    }
                );

            }
        );


        console.log(
            "Profile Actions: READY"
        );

    };


/* ============================================================
   FINAL DASHBOARD CONTROLS
============================================================ */

BKOwner.setupFinalControls =
    function () {

        /*
         * Website link UI
         */

        BKOwner.populateWebsiteUI();


        /*
         * Copy link buttons
         */

        BKOwner.setupCopyLinkButtons();


        /*
         * Website buttons
         */

        BKOwner.setupWebsiteButtons();


        /*
         * Profile actions
         */

        BKOwner.setupProfileActions();


        console.log(
            "Final Dashboard Controls: READY"
        );

    };
    
    /* ============================================================
   COMPLETE DASHBOARD STARTUP
============================================================ */


/* ============================================================
   BK BOOKING ENGINE
   REALTIME RESTAURANT BOOKINGS
============================================================ */

BKOwner.bookings = {

    allBookings: [],
    currentFilter: "all",
    searchTerm: "",
    unsubscribe: null,


    /* ========================================================
       INITIALIZE BOOKING ENGINE
    ======================================================== */

    init: function () {

        const restaurantId =
            BKOwner.state.restaurantId;

        if (!restaurantId) {

            console.warn(
                "BK Bookings: Restaurant ID not ready."
            );

            return;
        }


        this.setupFilters();

        this.setupRefreshButton();
        this.setupSearch();

        this.startRealtimeBookings(
            restaurantId
        );


        console.log(
            "BK BOOKING ENGINE: READY"
        );

    },


    /* ========================================================
       REALTIME FIRESTORE LISTENER
    ======================================================== */

    startRealtimeBookings:
        function (restaurantId) {

            /*
             * Remove previous listener
             * if one already exists.
             */

            if (this.unsubscribe) {

                this.unsubscribe();

                this.unsubscribe = null;

            }


            const bookingsRef =
                collection(
                    db,
                    "restaurants",
                    restaurantId,
                    "bookings"
                );


            this.unsubscribe =
                onSnapshot(
                    bookingsRef,

                    function (snapshot) {

                        const bookings = [];


                        snapshot.forEach(
                            function (docSnapshot) {

                                bookings.push({

                                    id:
                                        docSnapshot.id,

                                    ...docSnapshot.data()

                                });

                            }
                        );


                        BKOwner.bookings.allBookings =
                            bookings;


                        BKOwner.bookings.render();

                        BKOwner.bookings.updateSummary();


                        console.log(
                            "BK Bookings: Realtime update",
                            bookings.length
                        );

                    },

                    function (error) {

                        console.error(
                            "BK Bookings realtime listener failed:",
                            error
                        );


                        BKOwner.bookings.showError();

                    }
                );

        },


    /* ========================================================
       FILTER SETUP
    ======================================================== */

    setupFilters: function () {

        const filterButtons =
            document.querySelectorAll(
                "[data-booking-filter]"
            );


        filterButtons.forEach(
            function (button) {

                if (
                    button.dataset.bkBookingReady ===
                    "true"
                ) {

                    return;

                }


                button.dataset.bkBookingReady =
                    "true";


                button.addEventListener(
                    "click",
                    function () {

                        const filter =
                            button.getAttribute(
                                "data-booking-filter"
                            );


                        if (!filter) {
                            return;
                        }


                        BKOwner.bookings.currentFilter =
                            filter;


                        BKOwner.bookings.updateFilterLabel();

                        BKOwner.bookings.render();

                    }
                );

            }
        );

    },


    /* ========================================================
       REFRESH BUTTON
    ======================================================== */

    setupRefreshButton: function () {

        const refreshButton =
            document.getElementById(
                "refreshBookingsButton"
            );


        if (!refreshButton) {

            console.warn(
                "BK Bookings: Refresh button not found."
            );

            return;

        }


        if (
            refreshButton.dataset.bkBookingReady ===
            "true"
        ) {

            return;

        }


        refreshButton.dataset.bkBookingReady =
            "true";


        refreshButton.addEventListener(
            "click",
            function () {

                BKOwner.bookings.render();

                BKOwner.bookings.updateSummary();

                BKOwner.showToast(
                    "Bookings refreshed."
                );

            }
        );

    },
    /* ========================================================
   BOOKING SEARCH ENGINE
======================================================== */

setupSearch: function () {

    const searchInput =
        document.getElementById(
            "bookingSearchInput"
        );

    const clearButton =
        document.getElementById(
            "clearBookingSearchButton"
        );

    const searchBox =
        document.querySelector(
            ".bk-bookings-search"
        );


    if (!searchInput) {

        console.warn(
            "BK Bookings: Search input not found."
        );

        return;

    }


    if (
        searchInput.dataset.bkBookingReady ===
        "true"
    ) {

        return;

    }


    searchInput.dataset.bkBookingReady =
        "true";


    searchInput.addEventListener(
        "input",
        function () {

            BKOwner.bookings.searchTerm =
                String(
                    searchInput.value || ""
                )
                .trim()
                .toLowerCase();


            if (searchBox) {

                searchBox.classList.toggle(
                    "has-value",
                    searchInput.value.length > 0
                );

            }


            BKOwner.bookings.render();

        }
    );


    if (clearButton) {

        clearButton.addEventListener(
            "click",
            function () {

                searchInput.value = "";

                BKOwner.bookings.searchTerm =
                    "";


                if (searchBox) {

                    searchBox.classList.remove(
                        "has-value"
                    );

                }


                searchInput.focus();

                BKOwner.bookings.render();

            }
        );

    }

},


    /* ========================================================
       UPDATE SUMMARY COUNTS
    ======================================================== */

    updateSummary: function () {

        const bookings =
            this.allBookings;


        const counts = {

            all: bookings.length,

            pending: 0,

            confirmed: 0,

            rejected: 0,

            cancelled: 0,

            completed: 0

        };


        bookings.forEach(
            function (booking) {

                const status =
                    String(
                        booking.status || ""
                    ).toLowerCase();


                if (
                    Object.prototype.hasOwnProperty.call(
                        counts,
                        status
                    )
                ) {

                    counts[status]++;

                }

            }
        );


        this.setCount(
            "bookingsTotalCount",
            counts.all
        );


        this.setCount(
            "bookingsPendingCount",
            counts.pending
        );


        this.setCount(
            "bookingsConfirmedCount",
            counts.confirmed
        );


        this.setCount(
            "bookingsRejectedCount",
            counts.rejected
        );


        this.setCount(
            "bookingsCancelledCount",
            counts.cancelled
        );


        this.setCount(
            "bookingsCompletedCount",
            counts.completed
        );


        this.updateFilterLabel();

    },


    /* ========================================================
       SET COUNT
    ======================================================== */

    setCount: function (
        elementId,
        value
    ) {

        const element =
            document.getElementById(
                elementId
            );


        if (!element) {
            return;
        }


        element.textContent =
            String(value);

    },


    /* ========================================================
       FILTER LABEL
    ======================================================== */

    updateFilterLabel: function () {

        const label =
            document.getElementById(
                "bookingsCurrentFilterLabel"
            );


        if (!label) {
            return;
        }


        const labels = {

            all:
                "All bookings",

            pending:
                "Pending bookings",

            confirmed:
                "Confirmed bookings",

            rejected:
                "Rejected bookings",

            cancelled:
                "Cancelled bookings",

            completed:
                "Completed bookings"

        };


        label.textContent =
            labels[this.currentFilter] ||
            "All bookings";

    },


    /* ========================================================
       RENDER BOOKINGS
    ======================================================== */

    render: function () {

        const list =
            document.getElementById(
                "bookingsList"
            );


        const emptyState =
            document.getElementById(
                "bookingsEmptyState"
            );


        if (!list) {

            console.warn(
                "BK Bookings: bookingsList not found."
            );

            return;

        }


        let bookings =
            this.allBookings.slice();


        /*
         * Apply current filter.
         */

        if (
            this.currentFilter !==
            "all"
        ) {

            bookings =
                bookings.filter(
                    function (booking) {

                        return String(
                            booking.status || ""
                        ).toLowerCase() ===
                        BKOwner.bookings.currentFilter;

                    }
                );

        }
        /* ========================================================
   APPLY BOOKING SEARCH
======================================================== */

if (this.searchTerm) {

    const searchTerm =
        this.searchTerm;


    bookings =
        bookings.filter(
            function (booking) {

                const searchableText = [

                    booking.customerName,

                    booking.mobile,

                    booking.bookingId,

                    booking.id,

                    booking.date,

                    booking.time,

                    booking.tableId,

                    booking.specialRequest,

                    booking.status

                ]
                .map(
                    function (value) {

                        return String(
                            value || ""
                        ).toLowerCase();

                    }
                )
                .join(" ");


                return searchableText.includes(
                    searchTerm
                );

            }
        );

}


        /*
         * Newest bookings first.
         */

        bookings.sort(
            function (a, b) {

                return BKOwner.bookings
                    .getTimeValue(
                        b.createdAt
                    ) -
                    BKOwner.bookings
                    .getTimeValue(
                        a.createdAt
                    );

            }
        );


        /*
         * Empty state.
         */

        if (!bookings.length) {

            list.innerHTML = "";


            if (emptyState) {

                emptyState.classList.remove(
                    "hidden"
                );

            }


            return;

        }


        if (emptyState) {

            emptyState.classList.add(
                "hidden"
            );

        }


        list.innerHTML =
            bookings
                .map(
                    function (booking) {

                        return BKOwner.bookings
                            .createBookingCard(
                                booking
                            );

                    }
                )
                .join("");


        this.setupBookingCardActions();

    },


    /* ========================================================
       FIRESTORE TIMESTAMP → NUMBER
    ======================================================== */

    getTimeValue: function (
        timestamp
    ) {

        if (!timestamp) {
            return 0;
        }


        if (
            typeof timestamp.toMillis ===
            "function"
        ) {

            return timestamp.toMillis();

        }


        if (
            timestamp.seconds !==
            undefined
        ) {

            return Number(
                timestamp.seconds
            ) * 1000;

        }


        if (
            timestamp instanceof Date
        ) {

            return timestamp.getTime();

        }


        const parsed =
            Date.parse(timestamp);


        return Number.isNaN(parsed)
            ? 0
            : parsed;

    },


    /* ========================================================
       CREATE BOOKING CARD
    ======================================================== */

    createBookingCard:
        function (booking) {

            const status =
                String(
                    booking.status || "pending"
                ).toLowerCase();


            const customerName =
                this.escapeHTML(
                    booking.customerName ||
                    "Guest"
                );


            const mobile =
                this.escapeHTML(
                    booking.mobile ||
                    "Not provided"
                );


            const date =
                this.escapeHTML(
                    booking.date ||
                    "—"
                );


            const time =
                this.escapeHTML(
                    booking.time ||
                    "—"
                );


            const guestCount =
                Number(
                    booking.guestCount || 1
                );


            const specialRequest =
                this.escapeHTML(
                    booking.specialRequest ||
                    "No special request"
                );


            const tableId =
                this.escapeHTML(
                    booking.tableId ||
                    "Table not assigned"
                );


            const bookingId =
                this.escapeHTML(
                    booking.bookingId ||
                    booking.id ||
                    ""
                );


            let actionHTML = "";


if (status === "pending") {

    actionHTML = `

        <div class="bk-booking-actions">

            <button
                type="button"
                class="bk-booking-confirm"
                data-booking-action="confirm"
                data-booking-id="${bookingId}"
            >
                Confirm
            </button>

            <button
                type="button"
                class="bk-booking-reject"
                data-booking-action="reject"
                data-booking-id="${bookingId}"
            >
                Reject
            </button>

            <button
                type="button"
                class="bk-booking-delete"
                data-booking-action="delete"
                data-booking-id="${bookingId}"
            >
                Delete
            </button>

        </div>

    `;

} else {

    actionHTML = `

        <div class="bk-booking-actions bk-booking-actions-delete-only">

            <button
                type="button"
                class="bk-booking-delete"
                data-booking-action="delete"
                data-booking-id="${bookingId}"
            >
                Delete
            </button>

        </div>

    `;

}

            return `

                <article
                    class="bk-booking-card"
                    data-booking-id="${bookingId}"
                >

                    <div class="bk-booking-card-top">

                        <div>

                            <span class="bk-booking-label">
                                BK • TABLE BOOKING
                            </span>

                            <h3>
                                ${customerName}
                            </h3>

                        </div>

                        <span
                            class="bk-booking-status bk-booking-status-${status}"
                        >
                            ${this.formatStatus(status)}
                        </span>

                    </div>


                    <div class="bk-booking-details">

                        <div class="bk-booking-detail">

                            <span>
                                DATE
                            </span>

                            <strong>
                                ${date}
                            </strong>

                        </div>


                        <div class="bk-booking-detail">

                            <span>
                                TIME
                            </span>

                            <strong>
                                ${time}
                            </strong>

                        </div>


                        <div class="bk-booking-detail">

                            <span>
                                GUESTS
                            </span>

                            <strong>
                                ${guestCount}
                            </strong>

                        </div>


                        <div class="bk-booking-detail">

                            <span>
                                TABLE
                            </span>

                            <strong>
                                ${tableId}
                            </strong>

                        </div>

                    </div>


                    <div class="bk-booking-contact">

                        <span>
                            MOBILE
                        </span>

                        <strong>
                            ${mobile}
                        </strong>

                    </div>


                    <div class="bk-booking-request">

                        <span>
                            SPECIAL REQUEST
                        </span>

                        <p>
                            ${specialRequest}
                        </p>

                    </div>


                    ${actionHTML}

                </article>

            `;

        },


    /* ========================================================
       BOOKING CARD ACTIONS
    ======================================================== */

    setupBookingCardActions:
        function () {

            const actionButtons =
                document.querySelectorAll(
                    "[data-booking-action]"
                );


            actionButtons.forEach(
                function (button) {

                    if (
                        button.dataset.bkBookingActionReady ===
                        "true"
                    ) {

                        return;

                    }


                    button.dataset.bkBookingActionReady =
                        "true";


                    button.addEventListener(
                        "click",
                        async function () {

                            const action =
                                button.getAttribute(
                                    "data-booking-action"
                                );


                            const bookingId =
                                button.getAttribute(
                                    "data-booking-id"
                                );


                            if (
                                !action ||
                                !bookingId
                            ) {

                                return;

                            }


                            if (
                                action ===
                                "confirm"
                            ) {

                                await BKOwner.bookings
                                    .updateStatus(
                                        bookingId,
                                        "confirmed"
                                    );

                            }


                            if (
                                action ===
                                "reject"
                            ) {

                                await BKOwner.bookings
                                    .updateStatus(
                                        bookingId,
                                        "rejected"
                                    );

                            }
                            if (
    action ===
    "delete"
) {

    await BKOwner.bookings
        .deleteBooking(
            bookingId
        );

}

                        }
                    );

                }
            );

        },


    /* ========================================================
       UPDATE BOOKING STATUS
    ======================================================== */

updateStatus:
        async function (
            bookingId,
            newStatus
        ) {

            const restaurantId =
                BKOwner.state.restaurantId;


            if (
                !restaurantId ||
                !bookingId
            ) {

                console.warn(
                    "BK Booking status update: missing data."
                );

                return;

            }


            try {

                const bookingRef =
                    doc(
                        db,
                        "restaurants",
                        restaurantId,
                        "bookings",
                        bookingId
                    );


                await updateDoc(
                    bookingRef,
                    {
                        status:
                            newStatus
                    }
                );


                const messages = {

                    confirmed:
                        "Booking confirmed successfully.",

                    rejected:
                        "Booking rejected successfully."

                };


                BKOwner.showToast(
                    messages[newStatus] ||
                    "Booking status updated."
                );


            } catch (error) {

                console.error(
                    "BK Booking status update failed:",
                    error
                );


                BKOwner.showSystemError(
                    "Unable to update booking status."
                );

            }

        },
        
        
/* ========================================================
   PERMANENT BOOKING DELETE
   BOOKING + BOOKING SLOT CLEANUP
======================================================== */

deleteBooking:
    async function (
        bookingId
    ) {

        const restaurantId =
            BKOwner.state.restaurantId;


        if (
            !restaurantId ||
            !bookingId
        ) {

            console.warn(
                "BK Booking delete: missing data."
            );

            return;

        }


        const booking =
            this.allBookings.find(
                function (item) {

                    return String(
                        item.bookingId ||
                        item.id ||
                        ""
                    ) ===
                    String(bookingId);

                }
            );


        if (!booking) {

            BKOwner.showSystemError(
                "Booking could not be found."
            );

            return;

        }


        const customerName =
            String(
                booking.customerName ||
                "this guest"
            );


        const confirmed =
            window.confirm(
                "Permanently delete the booking for " +
                customerName +
                "?\n\n" +
                "This will also release its reserved time slot."
            );


        if (!confirmed) {

            return;

        }


        try {

            /*
             * Create Firestore batch.
             *
             * Both documents are deleted together:
             *
             * 1. bookings/{bookingId}
             * 2. bookingSlots/{slotKey}
             */

            const batch =
                writeBatch(db);


            const bookingRef =
                doc(
                    db,
                    "restaurants",
                    restaurantId,
                    "bookings",
                    bookingId
                );


            batch.delete(
                bookingRef
            );


            /*
             * Delete the corresponding
             * booking slot when available.
             */

            if (booking.slotKey) {

                const slotRef =
                    doc(
                        db,
                        "restaurants",
                        restaurantId,
                        "bookingSlots",
                        String(
                            booking.slotKey
                        )
                    );


                batch.delete(
                    slotRef
                );

            }


            /*
             * Commit both deletes atomically.
             */

            await batch.commit();


            BKOwner.showToast(
                "Booking permanently deleted."
            );


            console.log(
                "BK Booking: Permanently deleted",
                bookingId
            );


        } catch (error) {

            console.error(
                "BK Booking permanent delete failed:",
                error
            );


            BKOwner.showSystemError(
                "Unable to permanently delete booking."
            );

        }

    },

    /* ========================================================
       STATUS LABEL
    ======================================================== */

    formatStatus:
        function (status) {

            const labels = {

                pending:
                    "Pending",

                confirmed:
                    "Confirmed",

                rejected:
                    "Rejected",

                cancelled:
                    "Cancelled",

                completed:
                    "Completed"

            };


            return labels[status] ||
                "Pending";

        },


    /* ========================================================
       HTML SAFETY
    ======================================================== */

    escapeHTML:
        function (value) {

            return String(value)
                .replace(
                    /&/g,
                    "&amp;"
                )
                .replace(
                    /</g,
                    "&lt;"
                )
                .replace(
                    />/g,
                    "&gt;"
                )
                .replace(
                    /"/g,
                    "&quot;"
                )
                .replace(
                    /'/g,
                    "&#039;"
                );

        },


    /* ========================================================
       ERROR STATE
    ======================================================== */

    showError:
        function () {

            const list =
                document.getElementById(
                    "bookingsList"
                );


            if (!list) {
                return;
            }


            list.innerHTML = `

                <div class="bk-bookings-error">

                    <strong>
                        BOOKING SYSTEM
                    </strong>

                    <h3>
                        Unable to Load Bookings
                    </h3>

                    <p>
                        Please refresh the dashboard
                        and try again.
                    </p>

                </div>

            `;

        }

};


/* ============================================================
   BOOKING ENGINE STARTUP
============================================================ */

BKOwner.startBookingEngine =
    function () {

        if (
            !BKOwner.state.currentUser ||
            !BKOwner.state.restaurantData ||
            !BKOwner.state.restaurantId
        ) {

            console.warn(
                "BK Bookings: Firebase data not ready."
            );

            return;

        }


        if (
            BKOwner.bookings &&
            typeof BKOwner.bookings.init ===
            "function"
        ) {

            BKOwner.bookings.init();

        }

    };


/* ============================================================
   COMPLETE DASHBOARD STARTUP
============================================================ */

BKOwner.startDashboard =
    function () {
        console.count("BK startDashboard called");

        /*
         * Safety check.
         */

        if (
            !BKOwner.state.currentUser ||
            !BKOwner.state.ownerData ||
            !BKOwner.state.restaurantData
        ) {

            console.warn(
                "Dashboard startup delayed: Firebase data not ready."
            );

            return;

        }


        /*
         * Initialize all dashboard interactions.
         */

        BKOwner.setupDashboardInteractions();


        /*
         * Initialize website/profile controls.
         */

/*
 * Initialize Monthly Billing Module.
 */

if (window.BKOwnerMonthlyBilling) {

    const billingReady =
        window.BKOwnerMonthlyBilling.init();

    console.log(
        "BK Monthly Billing Initialization:",
        billingReady ? "READY" : "WAITING FOR OWNER CONTEXT"
    );

} else {

    console.warn(
        "BK Monthly Billing module is not loaded yet."
    );

}

/*
========================================================
BK OWNER MONTHLY BILLING
STEP 2G — AUTO-LOAD PREMIUM BILLING UI
========================================================
*/

if (
    window.BKOwnerMonthlyBilling &&
    typeof window.BKOwnerMonthlyBilling.loadPremiumBillingUI === "function"
) {
    if (
        window.BKOwnerMonthlyBilling.state?.ready
    ) {
        window.BKOwnerMonthlyBilling
            .loadPremiumBillingUI()
            .then(function (result) {
                console.log(
                    "BK MONTHLY BILLING UI:",
                    result ? "PASS" : "LOAD FAILED"
                );
            })
            .catch(function (error) {
                console.error(
                    "BK MONTHLY BILLING UI ERROR:",
                    error
                );
            });
    } else {
        console.warn(
            "BK MONTHLY BILLING UI: OWNER CONTEXT NOT READY."
        );
    }
}


        BKOwner.setupFinalControls();


        /*
         * Initialize Restaurant Profile.
         */

        BKOwner.setupRestaurantProfileSection();


        /* =====================================================
           ORDERS MODULE
        ====================================================== */

        if (BKOwner.orders) {

            BKOwner.orders.init();

        }


        /* =====================================================
           BOOKING MODULE
        ====================================================== */

        BKOwner.startBookingEngine();


        /*
         * Mark application as fully ready.
         */

        BKOwner.state.ready = true;


        console.log(
            "=========================================="
        );

        console.log(
            "BK OWNER DASHBOARD CONTROLS READY"
        );

        console.log(
            "Owner:",
            BKOwner.state.ownerData.ownerName
        );

        console.log(
            "Restaurant:",
            BKOwner.state.restaurantData.name
        );

        console.log(
            "Current Section:",
            BKOwner.state.currentSection
        );

        console.log(
            "=========================================="
        );

    };


/* ============================================================
   IMPORTANT:
   CONNECT DASHBOARD STARTUP AFTER FIREBASE INIT
============================================================ */

BKOwner.initDashboard =
    async function () {

        try {

            /*
             * Part 1 waits until:
             *
             * Firebase Auth
             *      ↓
             * Owner Data
             *      ↓
             * Restaurant Data
             *
             * are completely ready.
             */

            await BKOwner.init();


            /*
             * Now it is safe to initialize
             * the dashboard controls.
             */

            BKOwner.startDashboard();


        } catch (error) {

            console.error(
                "BK Dashboard startup failed:",
                error
            );

        }

    };


/* ============================================================
   REPLACE INITIAL DOM STARTUP
============================================================ */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        /*
         * Give the first Firebase initialization
         * a moment to finish.
         */

        const waitForDashboard =
            setInterval(
                function () {

                    if (
                        BKOwner.state.ready ===
                        true
                    ) {

                        clearInterval(
                            waitForDashboard
                        );


                        BKOwner.startDashboard();

                    }

                },
                100
            );


        /*
         * Safety timeout:
         * never keep checking forever.
         */

        setTimeout(
            function () {

                clearInterval(
                    waitForDashboard
                );


                if (
                    !BKOwner.state.ready
                ) {

                    console.warn(
                        "Dashboard controls waiting for Firebase session."
                    );

                }

            },
            10000
        );

    }
);
/* ============================================================
   FINAL STATUS
============================================================ */

console.log(
    "BK Owner Dashboard JavaScript loaded."
);

console.log(
    "Firebase Core: READY"
);

console.log(
    "Navigation: READY"
);

console.log(
    "Quick Actions: READY"
);

console.log(
    "Mobile Sidebar: READY"
);

console.log(
    "Profile Controls: READY"
);

console.log(
    "Logout Controls: READY"
);

console.log(
    "Website Controls: READY"
);

console.log(
    "Booking Controls: READY"
);

console.log(
    "=========================================="
);

console.log(
    "BK OWNER JS CORE — COMPLETE"
);

console.log(
    "=========================================="
);


/* ============================================================
   END — NEW PART 3/3
============================================================ */
    

/* ============================================================
   BK — RESTAURANT PROFILE MODULE
   PART 1 — LOAD FIRESTORE DATA INTO FORM
============================================================ */

BKOwner.loadRestaurantProfileForm =
    function () {

        /*
         * ----------------------------------------------------
         * Safety Check
         * ----------------------------------------------------
         */

        if (
            !BKOwner.state.currentUser ||
            !BKOwner.state.restaurantData
        ) {

            console.warn(
                "Restaurant Profile: Firebase data not ready."
            );

            return;
        }


        /*
         * ----------------------------------------------------
         * Get Restaurant Data
         * ----------------------------------------------------
         */

        const restaurant =
            BKOwner.state.restaurantData;


        /*
         * ----------------------------------------------------
         * Find Form Elements
         * ----------------------------------------------------
         */

        const restaurantName =
            document.getElementById(
                "restaurantProfileName"
            );


        const restaurantType =
            document.getElementById(
                "restaurantProfileType"
            );


        const restaurantCuisine =
            document.getElementById(
                "restaurantProfileCuisine"
            );


        const restaurantDescription =
            document.getElementById(
                "restaurantProfileDescription"
            );


        const restaurantContact =
            document.getElementById(
                "restaurantProfileContact"
            );


        const restaurantWhatsapp =
            document.getElementById(
                "restaurantProfileWhatsapp"
            );


        const restaurantEmail =
            document.getElementById(
                "restaurantProfileEmail"
            );


        const restaurantAddress =
            document.getElementById(
                "restaurantProfileAddress"
            );


        const restaurantCity =
            document.getElementById(
                "restaurantProfileCity"
            );


        const restaurantState =
            document.getElementById(
                "restaurantProfileState"
            );


        const restaurantOpeningTime =
            document.getElementById(
                "restaurantProfileOpeningTime"
            );


        const restaurantClosingTime =
            document.getElementById(
                "restaurantProfileClosingTime"
            );


        /*
         * ----------------------------------------------------
         * Restaurant Name
         * ----------------------------------------------------
         */

        if (restaurantName) {

            restaurantName.value =
                restaurant.name || "";

        }


        /*
         * ----------------------------------------------------
         * Restaurant Type
         * ----------------------------------------------------
         */

        if (restaurantType) {

            restaurantType.value =
                restaurant.type || "";

        }


        /*
         * ----------------------------------------------------
         * Cuisine
         * ----------------------------------------------------
         */

        if (restaurantCuisine) {

            restaurantCuisine.value =
                restaurant.cuisine || "";

        }


        /*
         * ----------------------------------------------------
         * Description
         * ----------------------------------------------------
         */

        if (restaurantDescription) {

            restaurantDescription.value =
                restaurant.description || "";

        }


        /*
         * ----------------------------------------------------
         * Contact Number
         * ----------------------------------------------------
         */

        if (restaurantContact) {

            restaurantContact.value =
                restaurant.contact || "";

        }


        /*
         * ----------------------------------------------------
         * WhatsApp Number
         * ----------------------------------------------------
         */

        if (restaurantWhatsapp) {

            restaurantWhatsapp.value =
                restaurant.whatsapp || "";

        }


        /*
         * ----------------------------------------------------
         * Restaurant Email
         * ----------------------------------------------------
         */

        if (restaurantEmail) {

            restaurantEmail.value =
                restaurant.email || "";

        }


        /*
         * ----------------------------------------------------
         * Address
         * ----------------------------------------------------
         */

        if (restaurantAddress) {

            restaurantAddress.value =
                restaurant.address || "";

        }


        /*
         * ----------------------------------------------------
         * City
         * ----------------------------------------------------
         */

        if (restaurantCity) {

            restaurantCity.value =
                restaurant.city || "";

        }


        /*
         * ----------------------------------------------------
         * State
         * ----------------------------------------------------
         */

        if (restaurantState) {

            restaurantState.value =
                restaurant.state || "";

        }


        /*
         * ----------------------------------------------------
         * Opening Time
         * ----------------------------------------------------
         */

        if (restaurantOpeningTime) {

            restaurantOpeningTime.value =
                restaurant.timings?.opening || "";

        }


        /*
         * ----------------------------------------------------
         * Closing Time
         * ----------------------------------------------------
         */

        if (restaurantClosingTime) {

            restaurantClosingTime.value =
                restaurant.timings?.closing || "";

        }


        /*
         * ----------------------------------------------------
         * Console Confirmation
         * ----------------------------------------------------
         */

        console.log(
            "Restaurant Profile Form: DATA LOADED"
        );

    };


/* ============================================================
   END — RESTAURANT PROFILE MODULE PART 1
============================================================ */
/* ============================================================
   BK — RESTAURANT PROFILE MODULE
   PART 2 — SAVE FIRESTORE DATA
============================================================ */

BKOwner.saveRestaurantProfile =
    async function () {

        /*
         * ----------------------------------------------------
         * Safety Check
         * ----------------------------------------------------
         */

        if (
            !BKOwner.state.currentUser ||
            !BKOwner.state.restaurantId
        ) {

            BKOwner.showSystemError(
                "Restaurant session is not ready."
            );

            return;
        }


        /*
         * ----------------------------------------------------
         * Get Form Elements
         * ----------------------------------------------------
         */

        const restaurantName =
            document.getElementById(
                "restaurantProfileName"
            );


        const restaurantType =
            document.getElementById(
                "restaurantProfileType"
            );


        const restaurantCuisine =
            document.getElementById(
                "restaurantProfileCuisine"
            );


        const restaurantDescription =
            document.getElementById(
                "restaurantProfileDescription"
            );


        const restaurantContact =
            document.getElementById(
                "restaurantProfileContact"
            );


        const restaurantWhatsapp =
            document.getElementById(
                "restaurantProfileWhatsapp"
            );


        const restaurantEmail =
            document.getElementById(
                "restaurantProfileEmail"
            );


        const restaurantAddress =
            document.getElementById(
                "restaurantProfileAddress"
            );


        const restaurantCity =
            document.getElementById(
                "restaurantProfileCity"
            );


        const restaurantState =
            document.getElementById(
                "restaurantProfileState"
            );


        const restaurantOpeningTime =
            document.getElementById(
                "restaurantProfileOpeningTime"
            );


        const restaurantClosingTime =
            document.getElementById(
                "restaurantProfileClosingTime"
            );


        const saveButton =
            document.getElementById(
                "saveRestaurantProfileButton"
            );


        const saveMessage =
            document.getElementById(
                "restaurantSaveMessage"
            );


        /*
         * ----------------------------------------------------
         * Basic Validation
         * ----------------------------------------------------
         */

        const name =
            restaurantName?.value.trim() || "";


        if (!name) {

            if (saveMessage) {

                saveMessage.textContent =
                    "Restaurant name is required.";

                saveMessage.style.color =
                    "#a45b4d";

            }

            restaurantName?.focus();

            return;
        }


        /*
         * ----------------------------------------------------
         * Collect Form Data
         * ----------------------------------------------------
         */

        const updatedRestaurantData = {

            name: name,

            type:
                restaurantType?.value.trim() || "",

            cuisine:
                restaurantCuisine?.value.trim() || "",

            description:
                restaurantDescription?.value.trim() || "",

            contact:
                restaurantContact?.value.trim() || "",

            whatsapp:
                restaurantWhatsapp?.value.trim() || "",

            email:
                restaurantEmail?.value.trim() || "",

            address:
                restaurantAddress?.value.trim() || "",

            city:
                restaurantCity?.value.trim() || "",

            state:
                restaurantState?.value.trim() || "",

            timings: {

                opening:
                    restaurantOpeningTime?.value || "",

                closing:
                    restaurantClosingTime?.value || ""

            },

            updatedAt:
                serverTimestamp()

        };


        /*
         * ----------------------------------------------------
         * Save Button State
         * ----------------------------------------------------
         */

        if (saveButton) {

            saveButton.disabled =
                true;

            saveButton.dataset.originalText =
                saveButton.innerText;

            saveButton.innerText =
                "Saving...";

        }


        if (saveMessage) {

            saveMessage.textContent =
                "Saving restaurant information...";

            saveMessage.style.color =
                "#806f60";

        }


        /*
         * ----------------------------------------------------
         * Firestore Restaurant Document
         * ----------------------------------------------------
         */

        try {

            const restaurantRef =
                doc(
                    db,
                    "restaurants",
                    BKOwner.state.restaurantId
                );


            /*
             * Update only restaurant profile
             * fields.
             */

            await updateDoc(
                restaurantRef,
                updatedRestaurantData
            );


            /*
             * Update local dashboard state.
             */

            BKOwner.state.restaurantData = {

                ...BKOwner.state.restaurantData,

                ...updatedRestaurantData,

                timings: {

                    ...BKOwner.state.restaurantData.timings,

                    ...updatedRestaurantData.timings

                }

            };


            /*
             * Refresh dashboard restaurant UI.
             */

            if (
                typeof BKOwner.populateRestaurantUI ===
                "function"
            ) {

                BKOwner.populateRestaurantUI();

            }


            /*
             * Success message.
             */

            if (saveMessage) {

                saveMessage.textContent =
                    "Restaurant information saved successfully.";

                saveMessage.style.color =
                    "#8a6a32";

            }


            console.log(
                "Restaurant Profile: SAVED SUCCESSFULLY"
            );


        } catch (error) {

            console.error(
                "Restaurant Profile save failed:",
                error
            );


            if (saveMessage) {

                saveMessage.textContent =
                    "Unable to save changes. Please try again.";

                saveMessage.style.color =
                    "#a45b4d";

            }


            if (
                typeof BKOwner.showSystemError ===
                "function"
            ) {

                BKOwner.showSystemError(
                    "Restaurant profile could not be saved."
                );

            }

        } finally {

            /*
             * Restore Save Button.
             */

            if (saveButton) {

                saveButton.disabled =
                    false;

                saveButton.innerText =
                    saveButton.dataset.originalText ||
                    "Save Changes";

            }

        }

    };


/* ============================================================
   END — RESTAURANT PROFILE MODULE PART 2
============================================================ */
/* ============================================================
   BK — RESTAURANT PROFILE MODULE
   PART 3 — FORM LOAD + SAVE BUTTON CONNECTION
============================================================ */


/* ============================================================
   LOAD RESTAURANT PROFILE FORM
============================================================ */

BKOwner.loadRestaurantProfileForm =
    function () {

        /*
         * ----------------------------------------------------
         * Safety Check
         * ----------------------------------------------------
         */

        if (
            !BKOwner.state.currentUser ||
            !BKOwner.state.restaurantData
        ) {

            console.warn(
                "Restaurant Profile: Data not ready."
            );

            return;
        }


        const restaurant =
            BKOwner.state.restaurantData;


        /*
         * ----------------------------------------------------
         * FORM ELEMENTS
         * ----------------------------------------------------
         */

        const fields = {

            name:
                document.getElementById(
                    "restaurantProfileName"
                ),

            type:
                document.getElementById(
                    "restaurantProfileType"
                ),

            cuisine:
                document.getElementById(
                    "restaurantProfileCuisine"
                ),

            description:
                document.getElementById(
                    "restaurantProfileDescription"
                ),

            contact:
                document.getElementById(
                    "restaurantProfileContact"
                ),

            whatsapp:
                document.getElementById(
                    "restaurantProfileWhatsapp"
                ),

            email:
                document.getElementById(
                    "restaurantProfileEmail"
                ),

            address:
                document.getElementById(
                    "restaurantProfileAddress"
                ),

            city:
                document.getElementById(
                    "restaurantProfileCity"
                ),

            state:
                document.getElementById(
                    "restaurantProfileState"
                ),

            opening:
                document.getElementById(
                    "restaurantProfileOpeningTime"
                ),

            closing:
                document.getElementById(
                    "restaurantProfileClosingTime"
                )

        };


        /*
         * ----------------------------------------------------
         * FILL FORM
         * ----------------------------------------------------
         */

        if (fields.name) {

            fields.name.value =
                restaurant.name || "";

        }


        if (fields.type) {

            fields.type.value =
                restaurant.type || "";

        }


        if (fields.cuisine) {

            fields.cuisine.value =
                restaurant.cuisine || "";

        }


        if (fields.description) {

            fields.description.value =
                restaurant.description || "";

        }


        if (fields.contact) {

            fields.contact.value =
                restaurant.contact || "";

        }


        if (fields.whatsapp) {

            fields.whatsapp.value =
                restaurant.whatsapp || "";

        }


        if (fields.email) {

            fields.email.value =
                restaurant.email || "";

        }


        if (fields.address) {

            fields.address.value =
                restaurant.address || "";

        }


        if (fields.city) {

            fields.city.value =
                restaurant.city || "";

        }


        if (fields.state) {

            fields.state.value =
                restaurant.state || "";

        }


        if (fields.opening) {

            fields.opening.value =
                restaurant.timings?.opening || "";

        }


        if (fields.closing) {

            fields.closing.value =
                restaurant.timings?.closing || "";

        }


        console.log(
            "Restaurant Profile Form: LOADED"
        );

    };


/* ============================================================
   CONNECT RESTAURANT PROFILE SAVE BUTTON
============================================================ */

BKOwner.setupRestaurantProfile =
    function () {

        const saveButton =
            document.getElementById(
                "saveRestaurantProfileButton"
            );


        if (!saveButton) {

            console.warn(
                "Restaurant Profile: Save button not found."
            );

            return;

        }


        /*
         * Prevent duplicate event listeners.
         */

        if (
            saveButton.dataset.bkProfileReady ===
            "true"
        ) {

            return;

        }


        saveButton.dataset.bkProfileReady =
            "true";


        saveButton.addEventListener(
            "click",
            async function (event) {

                event.preventDefault();


                await BKOwner.saveRestaurantProfile();

            }
        );


        /*
         * Load existing Firebase data
         * into the form.
         */

        BKOwner.loadRestaurantProfileForm();


        console.log(
            "Restaurant Profile Controls: READY"
        );

    };


/* ============================================================
   RESTAURANT PROFILE SECTION HOOK
============================================================ */

BKOwner.setupRestaurantProfileSection =
    function () {

        /*
         * Firebase data must already be available.
         */

        if (
            !BKOwner.state.currentUser ||
            !BKOwner.state.restaurantData
        ) {

            console.warn(
                "Restaurant Profile setup delayed."
            );

            return;

        }


        BKOwner.setupRestaurantProfile();


        console.log(
            "Restaurant Profile Section: READY"
        );

    };


/* ============================================================
   END — RESTAURANT PROFILE MODULE PART 3
============================================================ */
/* ============================================================
   BK RESTAURANT QR ENGINE
   ONE RESTAURANT → ONE QR CODE
   ============================================================ */

BKOwner.setupRestaurantQR =
    async function () {

        /*
         * ----------------------------------------------------
         * SAFETY CHECK
         * ----------------------------------------------------
         */

        const restaurantId =
            BKOwner.state.restaurantId;

        if (!restaurantId) {

            console.warn(
                "BK QR: Restaurant ID not ready."
            );

            return;

        }


        /*
         * ----------------------------------------------------
         * QR ELEMENT
         * ----------------------------------------------------
         */

        const qrContainer =
            document.getElementById(
                "restaurantQRCode"
            );

        if (!qrContainer) {

            console.warn(
                "BK QR: QR container not found."
            );

            return;

        }


        /*
         * ----------------------------------------------------
         * CUSTOMER WEBSITE URL
         * ----------------------------------------------------
         */

        const customerUrl =
            BKOwner.getCustomerWebsiteUrl();

        if (!customerUrl) {

            console.warn(
                "BK QR: Customer website URL unavailable."
            );

            return;

        }


        /*
         * ----------------------------------------------------
         * LOAD QR LIBRARY
         *
         * Dynamic import keeps the existing
         * owner.js Firebase imports untouched.
         * ----------------------------------------------------
         */

        let QRCode;

        try {

            QRCode =
                await import(
                    "https://cdn.jsdelivr.net/npm/qrcode@1.5.4/+esm"
                );

        } catch (error) {

            console.error(
                "BK QR: QR library failed to load.",
                error
            );

            return;

        }


        /*
         * ----------------------------------------------------
         * CREATE CANVAS
         * ----------------------------------------------------
         */

        qrContainer.innerHTML = "";

        const canvas =
            document.createElement(
                "canvas"
            );

        canvas.setAttribute(
            "aria-label",
            "Restaurant QR Code"
        );

        qrContainer.appendChild(
            canvas
        );


        /*
         * ----------------------------------------------------
         * GENERATE QR
         * ----------------------------------------------------
         */

        try {

            await QRCode.toCanvas(
                canvas,
                customerUrl,
                {
                    width: 166,
                    margin: 2,
                    errorCorrectionLevel: "H"
                }
            );

            console.log(
                "BK QR: GENERATED",
                customerUrl
            );

        } catch (error) {

            console.error(
                "BK QR: Generation failed.",
                error
            );

            qrContainer.innerHTML = "";

            const fallback =
                document.createElement(
                    "div"
                );

            fallback.className =
                "bk-qr-placeholder";

            fallback.innerHTML = `
                <span>BK</span>
                <small>QR ERROR</small>
            `;

            qrContainer.appendChild(
                fallback
            );

            return;

        }


        /*
         * ----------------------------------------------------
         * DOWNLOAD QR
         * ----------------------------------------------------
         */

        const downloadButton =
            document.getElementById(
                "downloadRestaurantQRButton"
            );

        if (
            downloadButton &&
            downloadButton.dataset.bkQrReady !==
            "true"
        ) {

            downloadButton.dataset.bkQrReady =
                "true";

            downloadButton.addEventListener(
                "click",
                function () {

                    try {

                        const image =
                            canvas.toDataURL(
                                "image/png"
                            );

                        const link =
                            document.createElement(
                                "a"
                            );

                        link.href =
                            image;

                        link.download =
                            "BK-Restaurant-QR-" +
                            restaurantId +
                            ".png";

                        document.body.appendChild(
                            link
                        );

                        link.click();

                        link.remove();

                        BKOwner.showToast(
                            "Restaurant QR downloaded."
                        );

                    } catch (error) {

                        console.error(
                            "BK QR download failed:",
                            error
                        );

                        BKOwner.showSystemError(
                            "Unable to download QR code."
                        );

                    }

                }
            );

        }


        /*
         * ----------------------------------------------------
         * PRINT QR
         * ----------------------------------------------------
         */

        const printButton =
            document.getElementById(
                "printRestaurantQRButton"
            );

        if (
            printButton &&
            printButton.dataset.bkQrReady !==
            "true"
        ) {

            printButton.dataset.bkQrReady =
                "true";

            printButton.addEventListener(
                "click",
                function () {

                    try {

                        const image =
                            canvas.toDataURL(
                                "image/png"
                            );

                        const printWindow =
                            window.open(
                                "",
                                "_blank",
                                "width=700,height=800"
                            );

                        if (!printWindow) {

                            BKOwner.showSystemError(
                                "Please allow the print window."
                            );

                            return;

                        }


                        printWindow.document.write(`
                            <!DOCTYPE html>

                            <html>

                            <head>

                                <title>
                                    BK Restaurant QR
                                </title>

                                <style>

                                    body {
                                        margin: 0;
                                        min-height: 100vh;

                                        display: flex;
                                        align-items: center;
                                        justify-content: center;

                                        background: #ffffff;

                                        font-family:
                                            Arial,
                                            sans-serif;

                                        text-align: center;
                                    }

                                    .print-card {
                                        padding: 40px;
                                    }

                                    img {
                                        width: 360px;
                                        height: 360px;
                                    }

                                    h1 {
                                        margin: 20px 0 8px;

                                        font-family:
                                            Georgia,
                                            serif;

                                        color: #3d3021;
                                    }

                                    p {
                                        margin: 0;

                                        color: #806f60;

                                        font-size: 14px;
                                    }

                                </style>

                            </head>

                            <body>

                                <div class="print-card">

                                    <img
                                        src="${image}"
                                        alt="Restaurant QR Code"
                                    >

                                    <h1>
                                        Scan to Visit
                                    </h1>

                                    <p>
                                        Restaurant Customer Website
                                    </p>

                                </div>

                            </body>

                            </html>
                        `);

                        printWindow.document.close();

                        printWindow.focus();

                        printWindow.onload =
                            function () {

                                printWindow.print();

                            };

                    } catch (error) {

                        console.error(
                            "BK QR print failed:",
                            error
                        );

                        BKOwner.showSystemError(
                            "Unable to print QR code."
                        );

                    }

                }
            );

        }


        /*
         * ----------------------------------------------------
         * COPY CUSTOMER LINK
         * ----------------------------------------------------
         */

        const copyButton =
            document.getElementById(
                "copyRestaurantQRLinkButton"
            );

        if (
            copyButton &&
            copyButton.dataset.bkQrReady !==
            "true"
        ) {

            copyButton.dataset.bkQrReady =
                "true";

            copyButton.addEventListener(
                "click",
                async function () {

                    try {

                        await navigator.clipboard.writeText(
                            customerUrl
                        );

                        BKOwner.showToast(
                            "Customer link copied."
                        );

                    } catch (error) {

                        console.error(
                            "BK QR link copy failed:",
                            error
                        );

                        BKOwner.showSystemError(
                            "Unable to copy customer link."
                        );

                    }

                }
            );

        }


        /*
         * ----------------------------------------------------
         * STORE URL FOR DEBUGGING
         * ----------------------------------------------------
         */

        qrContainer.dataset.restaurantId =
            restaurantId;

        qrContainer.dataset.customerUrl =
            customerUrl;


        console.log(
            "BK QR ENGINE: READY"
        );

    };


/* ============================================================
   QR ENGINE STARTUP
   ============================================================ */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        const qrStartup =
            setInterval(
                function () {

                    if (
                        BKOwner.state &&
                        BKOwner.state.ready === true
                    ) {

                        clearInterval(
                            qrStartup
                        );

                        BKOwner.setupRestaurantQR();

                    }

                },
                150
            );


        setTimeout(
            function () {

                clearInterval(
                    qrStartup
                );

            },
            12000
        );

    }
);


/* ============================================================
   END — BK RESTAURANT QR ENGINE
============================================================ */
/* ============================================================
   BK OWNER ACCOUNT GUARD
   PART 1 — FOUNDATION
============================================================ */

const BKOwnerAccountGuard = {

    state: {

        initialized: false,

        ready: false,

        currentUser: null,

        restaurantId: null,

        restaurantData: null,

        accountStatus: null,

        accountControlled: false,

        unsubscribeStatus: null

    },


    STATUS: {

        ACTIVE: "ACTIVE",

        INACTIVE: "INACTIVE",

        SUSPENDED: "SUSPENDED",

        BLOCKED: "BLOCKED"

    },


    normalizeStatus:
        function (status) {

            const normalizedStatus =
                String(
                    status || ""
                )
                .trim()
                .toUpperCase();


            if (
                normalizedStatus ===
                this.STATUS.ACTIVE
            ) {

                return this.STATUS.ACTIVE;

            }


            if (
                normalizedStatus ===
                this.STATUS.INACTIVE
            ) {

                return this.STATUS.INACTIVE;

            }


            if (
                normalizedStatus ===
                this.STATUS.SUSPENDED
            ) {

                return this.STATUS.SUSPENDED;

            }


            if (
                normalizedStatus ===
                this.STATUS.BLOCKED
            ) {

                return this.STATUS.BLOCKED;

            }


            return null;

        },


    isControlledStatus:
        function (status) {

            const normalizedStatus =
                this.normalizeStatus(
                    status
                );


            return (

                normalizedStatus ===
                this.STATUS.INACTIVE

                ||

                normalizedStatus ===
                this.STATUS.SUSPENDED

                ||

                normalizedStatus ===
                this.STATUS.BLOCKED

            );

        },


    getStatus:
        function () {

            return this.state.accountStatus;

        },


    isControlled:
        function () {

            return (
                this.state.accountControlled ===
                true
            );

        },


    isReady:
        function () {

            return (
                this.state.ready ===
                true
            );

        }

};


/*
 * ------------------------------------------------------------
 * GLOBAL ACCESS
 * ------------------------------------------------------------
 */

window.BKOwnerAccountGuard =
    BKOwnerAccountGuard;


/*
 * ------------------------------------------------------------
 * FOUNDATION CONFIRMATION
 * ------------------------------------------------------------
 */

console.log(
    "=========================================="
);

console.log(
    "BK OWNER ACCOUNT GUARD: FOUNDATION LOADED."
);

console.log(
    "Status Engine: READY"
);

console.log(
    "Account Control Engine: READY"
);

console.log(
    "=========================================="
);

/* ============================================================
   BK OWNER ACCOUNT GUARD
   PART 2 — OWNER SESSION CONNECTION
============================================================ */

BKOwnerAccountGuard.init =
    async function () {

        console.log(
            "=========================================="
        );

        console.log(
            "BK OWNER ACCOUNT GUARD: INITIALIZING"
        );

        console.log(
            "=========================================="
        );


        try {

            /*
             * ------------------------------------------------
             * Wait for the existing BK Owner session.
             * We do NOT create another Firebase Auth listener.
             * We reuse the already working BKOwner system.
             * ------------------------------------------------
             */

            await this.waitForOwnerSession();


            /*
             * ------------------------------------------------
             * Session safety check
             * ------------------------------------------------
             */

            if (
                !this.state.currentUser ||
                !this.state.restaurantId
            ) {

                console.warn(
                    "BK OWNER ACCOUNT GUARD: Owner session not ready."
                );

                return;

            }


            /*
             * ------------------------------------------------
             * Mark Guard initialized
             * ------------------------------------------------
             */

            this.state.initialized =
                true;

            this.state.ready =
                true;


            console.log(
                "BK OWNER ACCOUNT GUARD: OWNER SESSION CONNECTED."
            );

            console.log(
                "BK OWNER ACCOUNT GUARD: Owner UID:",
                this.state.currentUser.uid
            );

            console.log(
                "BK OWNER ACCOUNT GUARD: Restaurant ID:",
                this.state.restaurantId
            );

            console.log(
                "BK OWNER ACCOUNT GUARD: READY."
            );


        } catch (error) {

            console.error(
                "BK OWNER ACCOUNT GUARD ERROR:",
                error
            );

        }

    };


/* ============================================================
   WAIT FOR EXISTING OWNER SESSION
============================================================ */

BKOwnerAccountGuard.waitForOwnerSession =
    function () {

        return new Promise(
            function (resolve) {

                let attempts =
                    0;

                const maxAttempts =
                    100;


                const checkOwner =
                    function () {

                        attempts++;


                        /*
                         * ------------------------------------
                         * Existing BKOwner must be ready.
                         * ------------------------------------
                         */

                        const owner =
                            window.BKOwner;


                        if (

                            owner &&

                            owner.state &&

                            owner.state.ready === true &&

                            owner.state.currentUser &&

                            owner.state.restaurantId

                        ) {

                            BKOwnerAccountGuard.state.currentUser =
                                owner.state.currentUser;


                            BKOwnerAccountGuard.state.restaurantId =
                                owner.state.restaurantId;


                            BKOwnerAccountGuard.state.restaurantData =
                                owner.state.restaurantData ||
                                null;


                            resolve();

                            return;

                        }


                        /*
                         * ------------------------------------
                         * Safety timeout.
                         * ------------------------------------
                         */

                        if (
                            attempts >= maxAttempts
                        ) {

                            console.warn(
                                "BK OWNER ACCOUNT GUARD: Owner session timeout."
                            );

                            resolve();

                            return;

                        }


                        /*
                         * ------------------------------------
                         * Check again shortly.
                         * ------------------------------------
                         */

                        setTimeout(
                            checkOwner,
                            100
                        );

                    };


                checkOwner();

            }
        );

    };


/* ============================================================
   GUARD STARTUP
============================================================ */

BKOwnerAccountGuard.start =
    function () {

        if (
            this.state.ready !== true
        ) {

            console.warn(
                "BK OWNER ACCOUNT GUARD: Waiting for owner session."
            );

            return;

        }


        console.log(
            "BK OWNER ACCOUNT GUARD: STARTED."
        );

    };


/* ============================================================
   CONNECT GUARD TO EXISTING OWNER STARTUP
============================================================ */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        BKOwnerAccountGuard.init()
            .then(
                function () {

                    BKOwnerAccountGuard.start();

                }
            );

    }
);

/* ============================================================
   BK OWNER ACCOUNT GUARD
   PART 3 — REALTIME ACCOUNT STATUS LISTENER
============================================================ */

BKOwnerAccountGuard.startStatusListener =
    function () {

        /*
         * ----------------------------------------------------
         * Restaurant ID safety check
         * ----------------------------------------------------
         */

        if (
            !this.state.restaurantId
        ) {

            console.warn(
                "BK OWNER ACCOUNT GUARD: Restaurant ID missing."
            );

            return;

        }


        /*
         * ----------------------------------------------------
         * Prevent duplicate listeners
         * ----------------------------------------------------
         */

        if (
            this.state.unsubscribeStatus
        ) {

            console.log(
                "BK OWNER ACCOUNT GUARD: Status listener already active."
            );

            return;

        }


        /*
         * ----------------------------------------------------
         * Restaurant Firestore document
         * ----------------------------------------------------
         */

        const restaurantRef =
            doc(
                db,
                "restaurants",
                this.state.restaurantId
            );


        console.log(
            "BK OWNER ACCOUNT GUARD: Starting status listener..."
        );


        /*
         * ----------------------------------------------------
         * REALTIME LISTENER
         * ----------------------------------------------------
         */

        this.state.unsubscribeStatus =
            onSnapshot(

                restaurantRef,

                (snapshot) => {

                    /*
                     * ----------------------------------------
                     * Restaurant document check
                     * ----------------------------------------
                     */

                    if (
                        !snapshot.exists()
                    ) {

                        console.warn(
                            "BK OWNER ACCOUNT GUARD: Restaurant document not found."
                        );

                        this.state.restaurantData =
                            null;

                        this.state.accountStatus =
                            null;

                        this.state.accountControlled =
                            false;

                        return;

                    }


                    /*
                     * ----------------------------------------
                     * Read latest restaurant data
                     * ----------------------------------------
                     */

                    const restaurantData =
                        snapshot.data();


                    /*
                     * ----------------------------------------
                     * Normalize account status
                     * ----------------------------------------
                     */

                    const status =
                        this.normalizeStatus(
                            restaurantData.status
                        );


                    /*
                     * ----------------------------------------
                     * Update Guard state
                     * ----------------------------------------
                     */

                    this.state.restaurantData =
                        restaurantData;


                    this.state.accountStatus =
                        status;


                    this.state.accountControlled =
                        this.isControlledStatus(
                            status
                        );


                    /*
                     * ----------------------------------------
                     * STATUS LOG
                     * ----------------------------------------
                     */

                    console.log(
                        "BK OWNER ACCOUNT GUARD: Restaurant status:",
                        status || "UNKNOWN"
                    );


                    /*
                     * ----------------------------------------
                     * CONTROLLED ACCOUNT
                     * ----------------------------------------
                     */

                    if (
                        this.state.accountControlled
                    ) {

                        console.warn(
                            "BK OWNER ACCOUNT GUARD: ACCOUNT CONTROLLED:",
                            status
                        );

                    }

                    /*
                     * ----------------------------------------
                     * ACTIVE ACCOUNT
                     * ----------------------------------------
                     */

                    else {

                        console.log(
                            "BK OWNER ACCOUNT GUARD: ACCOUNT ACTIVE."
                        );

                    }

                },

                (error) => {

                    console.error(
                        "BK OWNER ACCOUNT GUARD: Status listener error:",
                        error
                    );

                }

            );


        console.log(
            "BK OWNER ACCOUNT GUARD: Status listener READY."
        );

    };


/* ============================================================
   CONNECT STATUS LISTENER AFTER GUARD READY
============================================================ */

const originalGuardStart =
    BKOwnerAccountGuard.start;


BKOwnerAccountGuard.start =
    function () {

        /*
         * ----------------------------------------------------
         * Run original Guard startup
         * ----------------------------------------------------
         */

        originalGuardStart.call(
            this
        );


        /*
         * ----------------------------------------------------
         * Start realtime status monitoring
         * ----------------------------------------------------
         */

        if (
            this.state.ready !== true
        ) {

            console.warn(
                "BK OWNER ACCOUNT GUARD: Cannot start status listener."
            );

            return;

        }


        this.startStatusListener();

    };


/* ============================================================
   PART 3 COMPLETE
============================================================ */
/* ============================================================
   BK OWNER ACCOUNT GUARD
   PART 4 — ACCOUNT-CONTROL STATE ENGINE
============================================================ */

BKOwnerAccountGuard.state.previousStatus = null;
BKOwnerAccountGuard.state.statusChanged = false;
BKOwnerAccountGuard.state.controlEvent = null;

BKOwnerAccountGuard.createControlEvent = function (
    previousStatus,
    newStatus,
    restaurantData
) {
    const normalizedPrevious = this.normalizeStatus(previousStatus);
    const normalizedNew = this.normalizeStatus(newStatus);

    return {
        restaurantId: this.state.restaurantId,
        ownerId: this.state.currentUser
            ? this.state.currentUser.uid
            : null,

        previousStatus: normalizedPrevious,
        newStatus: normalizedNew,

        controlled: this.isControlledStatus(normalizedNew),

        masterAction: restaurantData
            ? restaurantData.lastMasterAction || null
            : null,

        masterActionReason: restaurantData
            ? restaurantData.lastMasterActionReason || null
            : null,

        changedAt: restaurantData
            ? restaurantData.lastMasterActionAt || null
            : null,

        detectedAt: new Date()
    };
};

BKOwnerAccountGuard.handleStatusChange = function (
    previousStatus,
    newStatus,
    restaurantData
) {
    const previous = this.normalizeStatus(previousStatus);
    const current = this.normalizeStatus(newStatus);

    if (!current) {
        console.warn(
            "BK OWNER ACCOUNT GUARD: Unknown account status."
        );
        return;
    }

    if (previous === current) {
        return;
    }

    this.state.previousStatus = previous;
    this.state.accountStatus = current;
    this.state.accountControlled =
        this.isControlledStatus(current);

    this.state.statusChanged = true;

    this.state.controlEvent =
        this.createControlEvent(
            previous,
            current,
            restaurantData
        );

    console.log(
        "=========================================="
    );

    console.log(
        "BK OWNER ACCOUNT GUARD: ACCOUNT STATUS CHANGED"
    );

    console.log(
        "Previous Status:",
        previous || "NONE"
    );

    console.log(
        "Current Status:",
        current
    );

    console.log(
        "Account Controlled:",
        this.state.accountControlled
    );

    console.log(
        "Master Action:",
        this.state.controlEvent.masterAction || "NONE"
    );

    console.log(
        "Master Reason:",
        this.state.controlEvent.masterActionReason || "NONE"
    );

    console.log(
        "BK OWNER ACCOUNT GUARD: CONTROL EVENT READY."
    );

    console.log(
        "=========================================="
    );
};

const originalStatusListener =
    BKOwnerAccountGuard.startStatusListener;

BKOwnerAccountGuard.startStatusListener = function () {

    if (!this.state.restaurantId) {
        console.warn(
            "BK OWNER ACCOUNT GUARD: Restaurant ID missing."
        );
        return;
    }

    if (this.state.unsubscribeStatus) {
        console.log(
            "BK OWNER ACCOUNT GUARD: Status listener already active."
        );
        return;
    }

    const restaurantRef =
        doc(db, "restaurants", this.state.restaurantId);

    console.log(
        "BK OWNER ACCOUNT GUARD: Starting enhanced status listener..."
    );

    this.state.unsubscribeStatus = onSnapshot(
        restaurantRef,

        (snapshot) => {

            if (!snapshot.exists()) {

                console.warn(
                    "BK OWNER ACCOUNT GUARD: Restaurant document not found."
                );

                this.state.restaurantData = null;
                this.state.accountStatus = null;
                this.state.accountControlled = false;

                return;
            }

            const restaurantData =
    snapshot.data();

/*
 * ----------------------------------------------------
 * PRESERVE MASTER CONTROL DATA
 * ----------------------------------------------------
 * This must happen on EVERY Firestore snapshot,
 * including the initial snapshot after page reload.
 */

this.captureMasterControl(
    restaurantData
);

const status =
    this.normalizeStatus(
        restaurantData.status
    );

if (!status) {

                console.warn(
                    "BK OWNER ACCOUNT GUARD: Invalid restaurant status."
                );

                return;
            }

            const previousStatus =
                this.state.accountStatus;

            this.state.restaurantData =
                restaurantData;

            if (previousStatus === null) {

                this.state.accountStatus =
                    status;

                this.state.accountControlled =
                    this.isControlledStatus(status);

                this.state.previousStatus =
                    null;

                console.log(
                    "BK OWNER ACCOUNT GUARD: Initial status:",
                    status
                );

                if (this.state.accountControlled) {

                    console.warn(
                        "BK OWNER ACCOUNT GUARD: ACCOUNT CONTROLLED:",
                        status
                    );

                } else {

                    console.log(
                        "BK OWNER ACCOUNT GUARD: ACCOUNT ACTIVE."
                    );
                }

                return;
            }

            this.handleStatusChange(
                previousStatus,
                status,
                restaurantData
            );

        },

        (error) => {

            console.error(
                "BK OWNER ACCOUNT GUARD: Enhanced status listener error:",
                error
            );

        }
    );

    console.log(
        "BK OWNER ACCOUNT GUARD: Enhanced status listener READY."
    );
};

/* ============================================================
   PART 4 COMPLETE
============================================================ */

console.log(
    "BK OWNER ACCOUNT GUARD: PART 4 STATE ENGINE LOADED."
);
console.log(
    "Status Transition Engine: READY"
);
console.log(
    "Control Event Engine: READY"
);

/* ============================================================
   BK OWNER ACCOUNT GUARD
   PART 5 — MASTER ACTION & REASON PRESERVATION
============================================================ */

BKOwnerAccountGuard.state.masterControl = {
    action: null,
    reason: null,
    changedAt: null,
    source: null,
    mode: null
};

BKOwnerAccountGuard.state.ownerResponse = {
    message: null,
    submittedAt: null,
    requestId: null,
    status: null
};

BKOwnerAccountGuard.captureMasterControl = function (
    restaurantData
) {
    if (!restaurantData) {
        console.warn(
            "BK OWNER ACCOUNT GUARD: Master control data missing."
        );
        return;
    }

    const masterAction =
        restaurantData.lastMasterAction || null;

    const masterReason =
        restaurantData.lastMasterActionReason || null;

    const masterChangedAt =
        restaurantData.lastMasterActionAt || null;

    this.state.masterControl = {
        action: masterAction,
        reason: masterReason,
        changedAt: masterChangedAt,
        source: "BK_MASTER_CONTROL",
        mode: "MANUAL"
    };

    console.log(
        "BK OWNER ACCOUNT GUARD: MASTER CONTROL PRESERVED."
    );

    console.log(
        "Master Action:",
        this.state.masterControl.action || "NONE"
    );

    console.log(
        "Master Reason:",
        this.state.masterControl.reason || "NONE"
    );

    console.log(
        "Master Changed At:",
        this.state.masterControl.changedAt || "NONE"
    );

    console.log(
        "Master Source:",
        this.state.masterControl.source
    );

    console.log(
        "Master Mode:",
        this.state.masterControl.mode
    );
};

BKOwnerAccountGuard.getMasterControl = function () {
    return {
        action: this.state.masterControl.action,
        reason: this.state.masterControl.reason,
        changedAt: this.state.masterControl.changedAt,
        source: this.state.masterControl.source,
        mode: this.state.masterControl.mode
    };
};

BKOwnerAccountGuard.setOwnerResponse = function (
    message,
    requestId,
    status
) {
    this.state.ownerResponse = {
        message: message || null,
        submittedAt: new Date(),
        requestId: requestId || null,
        status: status || "SUBMITTED"
    };

    console.log(
        "BK OWNER ACCOUNT GUARD: OWNER RESPONSE STORED."
    );
};

BKOwnerAccountGuard.getOwnerResponse = function () {
    return {
        message: this.state.ownerResponse.message,
        submittedAt: this.state.ownerResponse.submittedAt,
        requestId: this.state.ownerResponse.requestId,
        status: this.state.ownerResponse.status
    };
};

BKOwnerAccountGuard.captureMasterControlFromEvent =
    function (controlEvent) {

        if (!controlEvent) {
            console.warn(
                "BK OWNER ACCOUNT GUARD: Control event missing."
            );
            return;
        }

        this.state.masterControl = {
            action: controlEvent.masterAction || null,
            reason: controlEvent.masterActionReason || null,
            changedAt: controlEvent.changedAt || null,
            source: "BK_MASTER_CONTROL",
            mode: "MANUAL"
        };

        console.log(
            "BK OWNER ACCOUNT GUARD: MASTER CONTROL EVENT PRESERVED."
        );

        console.log(
            "Action:",
            this.state.masterControl.action || "NONE"
        );

        console.log(
            "Reason:",
            this.state.masterControl.reason || "NONE"
        );
    };

/* ============================================================
   PART 5 COMPLETE
============================================================ */

console.log(
    "BK OWNER ACCOUNT GUARD: PART 5 MASTER PRESERVATION LOADED."
);

console.log(
    "Master Action Preservation: READY"
);

console.log(
    "Master Reason Preservation: READY"
);

console.log(
    "Owner Response Separation: READY"
);

/* ============================================================
   BK OWNER ACCOUNT GUARD
   PART 6 — OWNER ACCOUNT NOTICE ENGINE
   FOUNDATION
============================================================ */

BKOwnerAccountGuard.state.notice = {
    available: false,
    type: null,
    status: null,
    priority: null,
    title: null,
    message: null,
    action: null,
    reason: null,
    restaurantId: null,
    ownerId: null,
    masterAction: null,
    createdAt: null
};

BKOwnerAccountGuard.createAccountNotice = function (
    controlEvent
) {
    if (!controlEvent) {
        console.warn(
            "BK OWNER ACCOUNT GUARD: Cannot create notice. Control event missing."
        );
        return null;
    }

    const controlled =
        controlEvent.controlled === true;

    const currentStatus =
        controlEvent.newStatus || null;

    const masterAction =
        controlEvent.masterAction || null;

    const masterReason =
        controlEvent.masterActionReason || null;

    let noticeType = "ACCOUNT_STATUS";
    let noticePriority = "NORMAL";
    let noticeTitle = "Account Status Updated";
    let noticeAction = "VIEW_ACCOUNT_STATUS";
    let noticeMessage =
        "Your restaurant account status has been updated.";

    if (currentStatus === "INACTIVE") {
        noticePriority = "HIGH";
        noticeTitle = "Account Deactivated";
        noticeAction = "CONTACT_SUPPORT";
        noticeMessage =
            "Your restaurant account has been deactivated by BK Master Control.";
    }

    if (currentStatus === "SUSPENDED") {
        noticePriority = "HIGH";
        noticeTitle = "Account Suspended";
        noticeAction = "CONTACT_SUPPORT";
        noticeMessage =
            "Your restaurant account has been suspended by BK Master Control.";
    }

    if (currentStatus === "BLOCKED") {
        noticePriority = "CRITICAL";
        noticeTitle = "Account Blocked";
        noticeAction = "CONTACT_SUPPORT";
        noticeMessage =
            "Your restaurant account has been blocked by BK Master Control.";
    }

    if (currentStatus === "ACTIVE") {
        noticePriority = "NORMAL";
        noticeTitle = "Account Activated";
        noticeAction = "OPEN_DASHBOARD";
        noticeMessage =
            "Your restaurant account is active again.";
    }

    this.state.notice = {
        available: true,

        type: noticeType,

        status: "UNREAD",

        priority: noticePriority,

        title: noticeTitle,

        message: noticeMessage,

        action: noticeAction,

        reason: masterReason,

        restaurantId:
            controlEvent.restaurantId || null,

        ownerId:
            controlEvent.ownerId || null,

        masterAction: masterAction,

        createdAt:
            controlEvent.detectedAt || new Date()
    };

    console.log(
        "=========================================="
    );

    console.log(
        "BK OWNER ACCOUNT GUARD: ACCOUNT NOTICE CREATED."
    );

    console.log(
        "Notice Type:",
        this.state.notice.type
    );

    console.log(
        "Notice Status:",
        this.state.notice.status
    );

    console.log(
        "Notice Priority:",
        this.state.notice.priority
    );

    console.log(
        "Notice Title:",
        this.state.notice.title
    );

    console.log(
        "Notice Action:",
        this.state.notice.action
    );

    console.log(
        "Master Action:",
        this.state.notice.masterAction || "NONE"
    );

    console.log(
        "Master Reason:",
        this.state.notice.reason || "NONE"
    );

    console.log(
        "BK OWNER ACCOUNT GUARD: NOTICE READY."
    );

    console.log(
        "=========================================="
    );

    return this.state.notice;
};

BKOwnerAccountGuard.getAccountNotice = function () {

    return {
        available: this.state.notice.available,

        type: this.state.notice.type,

        status: this.state.notice.status,

        priority: this.state.notice.priority,

        title: this.state.notice.title,

        message: this.state.notice.message,

        action: this.state.notice.action,

        reason: this.state.notice.reason,

        restaurantId: this.state.notice.restaurantId,

        ownerId: this.state.notice.ownerId,

        masterAction: this.state.notice.masterAction,

        createdAt: this.state.notice.createdAt
    };
};

BKOwnerAccountGuard.clearAccountNotice = function () {

    this.state.notice = {
        available: false,
        type: null,
        status: null,
        priority: null,
        title: null,
        message: null,
        action: null,
        reason: null,
        restaurantId: null,
        ownerId: null,
        masterAction: null,
        createdAt: null
    };

    console.log(
        "BK OWNER ACCOUNT GUARD: ACCOUNT NOTICE CLEARED."
    );
};

/* ============================================================
   PART 6 FOUNDATION COMPLETE
============================================================ */

console.log(
    "BK OWNER ACCOUNT GUARD: PART 6 NOTICE ENGINE LOADED."
);

console.log(
    "Account Notice Engine: READY"
);

console.log(
    "Notice State Engine: READY"
);

console.log(
    "Master Reason → Notice Mapping: READY"
);

/* ============================================================
   BK OWNER ACCOUNT GUARD
   PART 7 — OWNER ACCOUNT LOCK ENGINE
   FOUNDATION
============================================================ */

BKOwnerAccountGuard.state.lock = {
    initialized: false,

    locked: false,

    status: null,

    level: "NONE",

    reason: null,

    source: null,

    mode: null,

    checkedAt: null
};

BKOwnerAccountGuard.LOCK_LEVEL = {
    NONE: "NONE",
    CONTROLLED: "CONTROLLED"
};

BKOwnerAccountGuard.calculateLockState = function () {

    const currentStatus =
        this.normalizeStatus(
            this.state.accountStatus
        );

    if (!currentStatus) {

        console.warn(
            "BK OWNER ACCOUNT GUARD: Cannot calculate lock state. Status unavailable."
        );

        this.state.lock = {
            initialized: false,
            locked: false,
            status: null,
            level: "NONE",
            reason: null,
            source: null,
            mode: null,
            checkedAt: new Date()
        };

        return this.state.lock;
    }

    const controlled =
        this.isControlledStatus(
            currentStatus
        );

    this.state.lock = {

        initialized: true,

        locked: controlled,

        status: currentStatus,

        level: controlled
            ? this.LOCK_LEVEL.CONTROLLED
            : this.LOCK_LEVEL.NONE,

        reason:
            this.state.masterControl
                ? this.state.masterControl.reason || null
                : null,

        source:
            this.state.masterControl
                ? this.state.masterControl.source || null
                : null,

        mode:
            this.state.masterControl
                ? this.state.masterControl.mode || null
                : null,

        checkedAt: new Date()
    };

    console.log(
        "=========================================="
    );

    console.log(
        "BK OWNER ACCOUNT GUARD: LOCK STATE CALCULATED."
    );

    console.log(
        "Account Status:",
        this.state.lock.status
    );

    console.log(
        "Account Locked:",
        this.state.lock.locked
    );

    console.log(
        "Lock Level:",
        this.state.lock.level
    );

    console.log(
        "Lock Reason:",
        this.state.lock.reason || "NONE"
    );

    console.log(
        "Lock Source:",
        this.state.lock.source || "NONE"
    );

    console.log(
        "Lock Mode:",
        this.state.lock.mode || "NONE"
    );

    console.log(
        "BK OWNER ACCOUNT GUARD: LOCK ENGINE READY."
    );

    console.log(
        "=========================================="
    );

    return this.state.lock;
};

BKOwnerAccountGuard.getLockState = function () {

    return {

        initialized:
            this.state.lock.initialized,

        locked:
            this.state.lock.locked,

        status:
            this.state.lock.status,

        level:
            this.state.lock.level,

        reason:
            this.state.lock.reason,

        source:
            this.state.lock.source,

        mode:
            this.state.lock.mode,

        checkedAt:
            this.state.lock.checkedAt
    };
};

BKOwnerAccountGuard.isAccountLocked = function () {

    return this.state.lock.locked === true;
};

BKOwnerAccountGuard.isAccountControlled = function () {

    return this.state.lock.level ===
        this.LOCK_LEVEL.CONTROLLED;
};

/* ============================================================
   PART 7 FOUNDATION COMPLETE
============================================================ */

console.log(
    "BK OWNER ACCOUNT GUARD: PART 7 LOCK ENGINE LOADED."
);

console.log(
    "Account Lock State Engine: READY"
);

console.log(
    "Controlled State Detection: READY"
);

console.log(
    "Sensitive Operation Lock Foundation: READY"
);

/* ============================================================
   BK OWNER ACCOUNT GUARD
   PART 7 — OPERATIONAL PERMISSION ENGINE
   FOUNDATION
============================================================ */

BKOwnerAccountGuard.state.permissions = {
    initialized: false,

    accountView: false,
    notices: false,
    support: false,
    logout: false,

    restaurantEdit: false,
    menuManagement: false,
    ordersManagement: false,
    bookingsManagement: false
};

BKOwnerAccountGuard.OPERATION = {
    ACCOUNT_VIEW: "ACCOUNT_VIEW",
    NOTICES: "NOTICES",
    SUPPORT: "SUPPORT",
    LOGOUT: "LOGOUT",

    RESTAURANT_EDIT: "RESTAURANT_EDIT",
    MENU_MANAGEMENT: "MENU_MANAGEMENT",
    ORDERS_MANAGEMENT: "ORDERS_MANAGEMENT",
    BOOKINGS_MANAGEMENT: "BOOKINGS_MANAGEMENT"
};

BKOwnerAccountGuard.calculatePermissions = function () {

    const status =
        this.normalizeStatus(
            this.state.accountStatus
        );

    if (!status) {

        console.warn(
            "BK OWNER ACCOUNT GUARD: Cannot calculate permissions. Status unavailable."
        );

        this.state.permissions = {
            initialized: false,

            accountView: false,
            notices: false,
            support: false,
            logout: false,

            restaurantEdit: false,
            menuManagement: false,
            ordersManagement: false,
            bookingsManagement: false
        };

        return this.state.permissions;
    }

    const controlled =
        this.isControlledStatus(status);

    const active =
        status === this.STATUS.ACTIVE;

    this.state.permissions = {

        initialized: true,

        /* Always available */
        accountView: true,
        notices: true,
        support: true,
        logout: true,

        /* Operational controls */
        restaurantEdit: active,
        menuManagement: active,
        ordersManagement: active,
        bookingsManagement: active
    };

    console.log(
        "=========================================="
    );

    console.log(
        "BK OWNER ACCOUNT GUARD: PERMISSIONS CALCULATED."
    );

    console.log(
        "Account Status:",
        status
    );

    console.log(
        "Account Controlled:",
        controlled
    );

    console.log(
        "Account View:",
        this.state.permissions.accountView
    );

    console.log(
        "Notices:",
        this.state.permissions.notices
    );

    console.log(
        "Support:",
        this.state.permissions.support
    );

    console.log(
        "Logout:",
        this.state.permissions.logout
    );

    console.log(
        "Restaurant Edit:",
        this.state.permissions.restaurantEdit
    );

    console.log(
        "Menu Management:",
        this.state.permissions.menuManagement
    );

    console.log(
        "Orders Management:",
        this.state.permissions.ordersManagement
    );

    console.log(
        "Bookings Management:",
        this.state.permissions.bookingsManagement
    );

    console.log(
        "BK OWNER ACCOUNT GUARD: PERMISSION ENGINE READY."
    );

    console.log(
        "=========================================="
    );

    return this.state.permissions;
};

BKOwnerAccountGuard.canPerform = function (
    operation
) {

    if (!operation) {
        return false;
    }

    const permissions =
        this.state.permissions;

    switch (operation) {

        case this.OPERATION.ACCOUNT_VIEW:
            return permissions.accountView === true;

        case this.OPERATION.NOTICES:
            return permissions.notices === true;

        case this.OPERATION.SUPPORT:
            return permissions.support === true;

        case this.OPERATION.LOGOUT:
            return permissions.logout === true;

        case this.OPERATION.RESTAURANT_EDIT:
            return permissions.restaurantEdit === true;

        case this.OPERATION.MENU_MANAGEMENT:
            return permissions.menuManagement === true;

        case this.OPERATION.ORDERS_MANAGEMENT:
            return permissions.ordersManagement === true;

        case this.OPERATION.BOOKINGS_MANAGEMENT:
            return permissions.bookingsManagement === true;

        default:
            console.warn(
                "BK OWNER ACCOUNT GUARD: Unknown operation:",
                operation
            );

            return false;
    }
};

BKOwnerAccountGuard.getPermissions = function () {

    return {
        initialized:
            this.state.permissions.initialized,

        accountView:
            this.state.permissions.accountView,

        notices:
            this.state.permissions.notices,

        support:
            this.state.permissions.support,

        logout:
            this.state.permissions.logout,

        restaurantEdit:
            this.state.permissions.restaurantEdit,

        menuManagement:
            this.state.permissions.menuManagement,

        ordersManagement:
            this.state.permissions.ordersManagement,

        bookingsManagement:
            this.state.permissions.bookingsManagement
    };
};

/* ============================================================
   PART 7 PERMISSION FOUNDATION COMPLETE
============================================================ */

console.log(
    "BK OWNER ACCOUNT GUARD: PART 7 PERMISSION ENGINE LOADED."
);

console.log(
    "Operational Permission State: READY"
);

console.log(
    "Permission Calculation: READY"
);

console.log(
    "Operation Access Resolver: READY"
);

/* ============================================================
   BK OWNER ACCOUNT GUARD
   PART 8 — NOTICE INTEGRATION ENGINE
   PART 1 — AUTOMATIC NOTICE BRIDGE
============================================================ */

BKOwnerAccountGuard.state.noticeIntegration = {
    initialized: false,

    lastProcessedEvent: null,

    lastNotice: null
};

BKOwnerAccountGuard.processControlEventNotice =
    function (controlEvent) {

        if (!controlEvent) {

            console.warn(
                "BK OWNER ACCOUNT GUARD: Notice bridge received no control event."
            );

            return null;
        }

        if (!controlEvent.newStatus) {

            console.warn(
                "BK OWNER ACCOUNT GUARD: Notice bridge received invalid status."
            );

            return null;
        }

        const notice =
            this.createAccountNotice(
                controlEvent
            );

        if (!notice) {

            console.warn(
                "BK OWNER ACCOUNT GUARD: Notice creation failed."
            );

            return null;
        }

        this.state.noticeIntegration = {

            initialized: true,

            lastProcessedEvent: {
                previousStatus:
                    controlEvent.previousStatus || null,

                newStatus:
                    controlEvent.newStatus || null,

                masterAction:
                    controlEvent.masterAction || null,

                masterReason:
                    controlEvent.masterActionReason || null
            },

            lastNotice: notice
        };

        console.log(
            "=========================================="
        );

        console.log(
            "BK OWNER ACCOUNT GUARD: NOTICE BRIDGE PROCESSED."
        );

        console.log(
            "Previous Status:",
            controlEvent.previousStatus || "NONE"
        );

        console.log(
            "New Status:",
            controlEvent.newStatus
        );

        console.log(
            "Master Action:",
            controlEvent.masterAction || "NONE"
        );

        console.log(
            "Master Reason:",
            controlEvent.masterActionReason || "NONE"
        );

        console.log(
            "Notice Created:",
            notice.title
        );

        console.log(
            "BK OWNER ACCOUNT GUARD: NOTICE BRIDGE READY."
        );

        console.log(
            "=========================================="
        );

        return notice;
    };

BKOwnerAccountGuard.getNoticeIntegrationState =
    function () {

        return {

            initialized:
                this.state.noticeIntegration.initialized,

            lastProcessedEvent:
                this.state.noticeIntegration
                    .lastProcessedEvent,

            lastNotice:
                this.state.noticeIntegration
                    .lastNotice
        };
    };

/* ============================================================
   PART 8 — PART 1 FOUNDATION COMPLETE
============================================================ */

console.log(
    "BK OWNER ACCOUNT GUARD: PART 8 NOTICE BRIDGE LOADED."
);

console.log(
    "Automatic Notice Bridge: READY"
);

console.log(
    "Control Event → Notice Mapping: READY"
);

console.log(
    "Notice Integration State: READY"
);

/* ============================================================
   BK OWNER ACCOUNT GUARD
   PART 8 — UNIFIED REALTIME NOTICE INTEGRATION
   CLEAN VERSION
============================================================ */

const originalHandleStatusChangeForPart8 =
    BKOwnerAccountGuard.handleStatusChange;

BKOwnerAccountGuard.handleStatusChange = function (
    previousStatus,
    newStatus,
    restaurantData
) {

    /* --------------------------------------------------------
       1. EXISTING PART 4 STATUS ENGINE
       -------------------------------------------------------- */

    originalHandleStatusChangeForPart8.call(
        this,
        previousStatus,
        newStatus,
        restaurantData
    );

    /* --------------------------------------------------------
       2. GET REAL CONTROL EVENT
       -------------------------------------------------------- */

    const controlEvent =
        this.state.controlEvent;

    if (!controlEvent) {

        console.warn(
            "BK OWNER ACCOUNT GUARD: No control event available for Part 8."
        );

        return;
    }

    /* --------------------------------------------------------
       3. PRESERVE MASTER CONTROL
       -------------------------------------------------------- */

    this.captureMasterControlFromEvent(
        controlEvent
    );

    /* --------------------------------------------------------
       4. AUTOMATIC NOTICE BRIDGE
       -------------------------------------------------------- */

    const notice =
        this.processControlEventNotice(
            controlEvent
        );

    if (!notice) {

        console.warn(
            "BK OWNER ACCOUNT GUARD: Part 8 notice creation failed."
        );

        return;
    }

    /* --------------------------------------------------------
       5. FINAL REALTIME INTEGRATION LOG
       -------------------------------------------------------- */

    console.log(
        "=========================================="
    );

    console.log(
        "BK OWNER ACCOUNT GUARD: REALTIME NOTICE INTEGRATION ACTIVE."
    );

    console.log(
        "Previous Status:",
        controlEvent.previousStatus || "NONE"
    );

    console.log(
        "New Status:",
        controlEvent.newStatus || "NONE"
    );

    console.log(
        "Master Action:",
        controlEvent.masterAction || "NONE"
    );

    console.log(
        "Master Reason:",
        controlEvent.masterActionReason || "NONE"
    );

    console.log(
        "Notice:",
        notice.title
    );

    console.log(
        "Notice Priority:",
        notice.priority
    );

    console.log(
        "Notice Action:",
        notice.action
    );

    console.log(
        "BK OWNER ACCOUNT GUARD: REALTIME NOTICE COMPLETE."
    );

    console.log(
        "=========================================="
    );
};

/* ============================================================
   PART 8 — UNIFIED INTEGRATION COMPLETE
============================================================ */

console.log(
    "BK OWNER ACCOUNT GUARD: PART 8 UNIFIED INTEGRATION LOADED."
);

console.log(
    "Firestore Status → Control Event: READY"
);

console.log(
    "Control Event → Master Preservation: READY"
);

console.log(
    "Control Event → Notice Bridge: READY"
);

console.log(
    "Realtime Notice Integration: READY"
);

/* ============================================================
   BK OWNER ACCOUNT GUARD
   PART 9 — OWNER ACCOUNT CONTROL UI
   PART 1 — UI STATE FOUNDATION
============================================================ */

BKOwnerAccountGuard.state.ui = {
    initialized: false,

    accountStatus: null,
    controlled: false,

    masterAction: null,
    masterReason: null,
    masterChangedAt: null,

    noticeAvailable: false,
    noticeTitle: null,
    noticePriority: null,
    noticeAction: null,

    lockActive: false,
    lockLevel: "NONE",

    lastUpdatedAt: null
};

/* ------------------------------------------------------------
   UI STATE BUILDER
------------------------------------------------------------ */

BKOwnerAccountGuard.buildUIState = function () {

    const status =
        this.normalizeStatus(
            this.state.accountStatus
        );

    const masterControl =
        this.getMasterControl();

    const notice =
        this.getAccountNotice();

    const lock =
        this.getLockState();

    if (!status) {

        console.warn(
            "BK OWNER ACCOUNT GUARD: UI state cannot be built. Status unavailable."
        );

        this.state.ui.initialized = false;

        return this.state.ui;
    }

    this.state.ui = {

        initialized: true,

        accountStatus:
            status,

        controlled:
            this.isControlledStatus(status),

        masterAction:
            masterControl.action || null,

        masterReason:
            masterControl.reason || null,

        masterChangedAt:
            masterControl.changedAt || null,

        noticeAvailable:
            notice.available === true,

        noticeTitle:
            notice.title || null,

        noticePriority:
            notice.priority || null,

        noticeAction:
            notice.action || null,

        lockActive:
            lock.locked === true,

        lockLevel:
            lock.level || "NONE",

        lastUpdatedAt:
            new Date()
    };

    console.log(
        "=========================================="
    );

    console.log(
        "BK OWNER ACCOUNT GUARD: UI STATE BUILT."
    );

    console.log(
        "Account Status:",
        this.state.ui.accountStatus
    );

    console.log(
        "Account Controlled:",
        this.state.ui.controlled
    );

    console.log(
        "Master Action:",
        this.state.ui.masterAction || "NONE"
    );

    console.log(
        "Master Reason:",
        this.state.ui.masterReason || "NONE"
    );

    console.log(
        "Notice Available:",
        this.state.ui.noticeAvailable
    );

    console.log(
        "Notice Title:",
        this.state.ui.noticeTitle || "NONE"
    );

    console.log(
        "Lock Active:",
        this.state.ui.lockActive
    );

    console.log(
        "Lock Level:",
        this.state.ui.lockLevel
    );

    console.log(
        "BK OWNER ACCOUNT GUARD: UI STATE READY."
    );

    console.log(
        "=========================================="
    );

    return this.state.ui;
};

/* ------------------------------------------------------------
   UI STATE GETTER
------------------------------------------------------------ */

BKOwnerAccountGuard.getUIState = function () {

    return {

        initialized:
            this.state.ui.initialized,

        accountStatus:
            this.state.ui.accountStatus,

        controlled:
            this.state.ui.controlled,

        masterAction:
            this.state.ui.masterAction,

        masterReason:
            this.state.ui.masterReason,

        masterChangedAt:
            this.state.ui.masterChangedAt,

        noticeAvailable:
            this.state.ui.noticeAvailable,

        noticeTitle:
            this.state.ui.noticeTitle,

        noticePriority:
            this.state.ui.noticePriority,

        noticeAction:
            this.state.ui.noticeAction,

        lockActive:
            this.state.ui.lockActive,

        lockLevel:
            this.state.ui.lockLevel,

        lastUpdatedAt:
            this.state.ui.lastUpdatedAt
    };
};

/* ============================================================
   PART 9 — PART 1 FOUNDATION COMPLETE
============================================================ */

console.log(
    "BK OWNER ACCOUNT GUARD: PART 9 UI STATE ENGINE LOADED."
);

console.log(
    "Account UI State: READY"
);

console.log(
    "Master Control → UI Mapping: READY"
);

console.log(
    "Notice → UI Mapping: READY"
);

console.log(
    "Lock → UI Mapping: READY"
);

/* ============================================================
   BK OWNER ACCOUNT GUARD
   PART 9 — ACCOUNT CONTROL UI
   PART 2 — PREMIUM MODAL FOUNDATION
============================================================ */

BKOwnerAccountGuard.state.accountModal = {
    initialized: false,
    open: false,

    status: null,
    title: null,
    message: null,

    masterAction: null,
    masterReason: null,

    priority: null,
    action: null,

    openedAt: null
};

/* ------------------------------------------------------------
   ACCOUNT MODAL STATE BUILDER
------------------------------------------------------------ */

BKOwnerAccountGuard.buildAccountModalState = function () {

    const uiState =
        this.getUIState();

    if (!uiState.initialized) {

        console.warn(
            "BK OWNER ACCOUNT GUARD: Cannot build modal state. UI state unavailable."
        );

        return this.state.accountModal;
    }

    let title =
        "Account Status Updated";

    let message =
        "Your restaurant account status has been updated.";

    if (uiState.accountStatus === "INACTIVE") {

        title =
            "Account Deactivated";

        message =
            "Your restaurant account has been deactivated by BK Master Control.";
    }

    if (uiState.accountStatus === "SUSPENDED") {

        title =
            "Account Suspended";

        message =
            "Your restaurant account has been suspended by BK Master Control.";
    }

    if (uiState.accountStatus === "BLOCKED") {

        title =
            "Account Access Restricted";

        message =
            "Your restaurant account access has been restricted by BK Master Control.";
    }

    if (uiState.accountStatus === "ACTIVE") {

        title =
            "Account Activated";

        message =
            "Your restaurant account is active again.";
    }

    this.state.accountModal = {

        initialized: true,

        open: false,

        status:
            uiState.accountStatus,

        title:
            title,

        message:
            message,

        masterAction:
            uiState.masterAction,

        masterReason:
            uiState.masterReason,

        priority:
            uiState.noticePriority || "NORMAL",

        action:
            uiState.noticeAction || "VIEW_ACCOUNT_STATUS",

        openedAt:
            null
    };

    console.log(
        "=========================================="
    );

    console.log(
        "BK OWNER ACCOUNT GUARD: ACCOUNT MODAL STATE BUILT."
    );

    console.log(
        "Modal Status:",
        this.state.accountModal.status
    );

    console.log(
        "Modal Title:",
        this.state.accountModal.title
    );

    console.log(
        "Modal Priority:",
        this.state.accountModal.priority
    );

    console.log(
        "Master Action:",
        this.state.accountModal.masterAction || "NONE"
    );

    console.log(
        "Master Reason:",
        this.state.accountModal.masterReason || "NONE"
    );

    console.log(
        "BK OWNER ACCOUNT GUARD: MODAL STATE READY."
    );

    console.log(
        "=========================================="
    );

    return this.state.accountModal;
};

/* ------------------------------------------------------------
   OPEN MODAL STATE
------------------------------------------------------------ */

BKOwnerAccountGuard.openAccountModal = function () {

    if (!this.state.accountModal.initialized) {

        this.buildAccountModalState();
    }

    this.state.accountModal.open = true;

    this.state.accountModal.openedAt =
        new Date();

    console.log(
        "BK OWNER ACCOUNT GUARD: ACCOUNT MODAL OPEN STATE ACTIVE."
    );

    return this.state.accountModal;
};

/* ------------------------------------------------------------
   CLOSE MODAL STATE
------------------------------------------------------------ */

BKOwnerAccountGuard.closeAccountModal = function () {

    this.state.accountModal.open = false;

    console.log(
        "BK OWNER ACCOUNT GUARD: ACCOUNT MODAL CLOSED."
    );
};

/* ------------------------------------------------------------
   MODAL STATE GETTER
------------------------------------------------------------ */

BKOwnerAccountGuard.getAccountModalState = function () {

    return {

        initialized:
            this.state.accountModal.initialized,

        open:
            this.state.accountModal.open,

        status:
            this.state.accountModal.status,

        title:
            this.state.accountModal.title,

        message:
            this.state.accountModal.message,

        masterAction:
            this.state.accountModal.masterAction,

        masterReason:
            this.state.accountModal.masterReason,

        priority:
            this.state.accountModal.priority,

        action:
            this.state.accountModal.action,

        openedAt:
            this.state.accountModal.openedAt
    };
};

/* ============================================================
   PART 9 — PART 2 FOUNDATION COMPLETE
============================================================ */

console.log(
    "BK OWNER ACCOUNT GUARD: PART 9 ACCOUNT MODAL ENGINE LOADED."
);

console.log(
    "Account Modal State: READY"
);

console.log(
    "Master Reason → Modal: READY"
);

console.log(
    "Account Status → Modal: READY"
);

console.log(
    "Modal Open/Close State: READY"
);

/* ============================================================
   BK OWNER ACCOUNT GUARD
   PART 9 — PREMIUM ACCOUNT CONTROL MODAL
   PART 3 — UI ENGINE
============================================================ */

BKOwnerAccountGuard.renderAccountModal = function () {

    const modalState =
        this.getAccountModalState();

    if (!modalState.initialized) {

        console.warn(
            "BK OWNER ACCOUNT GUARD: Cannot render modal. Modal state unavailable."
        );

        return;
    }

    console.log(
        "BK OWNER ACCOUNT GUARD: ACCOUNT MODAL UI STATE READY."
    );

    console.log(
        "Modal Status:",
        modalState.status
    );

    console.log(
        "Modal Title:",
        modalState.title
    );

    console.log(
        "Modal Priority:",
        modalState.priority
    );

    console.log(
        "Master Action:",
        modalState.masterAction || "NONE"
    );

    console.log(
        "Master Reason:",
        modalState.masterReason || "NONE"
    );

    console.log(
        "Modal Action:",
        modalState.action
    );
};

/* ------------------------------------------------------------
   ACCOUNT MODAL UI REFRESH
------------------------------------------------------------ */

BKOwnerAccountGuard.refreshAccountModal =
    function () {

        if (!this.state.accountModal.initialized) {

            this.buildAccountModalState();
        }

        this.renderAccountModal();

        console.log(
            "BK OWNER ACCOUNT GUARD: ACCOUNT MODAL UI REFRESHED."
        );
    };

/* ------------------------------------------------------------
   CONTROLLED ACCOUNT UI CHECK
------------------------------------------------------------ */

BKOwnerAccountGuard.shouldShowAccountControl =
    function () {

        const status =
            this.normalizeStatus(
                this.state.accountStatus
            );

        return this.isControlledStatus(
            status
        );
    };

/* ============================================================
   PART 9 — PART 3 FOUNDATION COMPLETE
============================================================ */

console.log(
    "BK OWNER ACCOUNT GUARD: PART 9 MODAL UI ENGINE LOADED."
);

console.log(
    "Account Modal Renderer: READY"
);

console.log(
    "Account Modal Refresh: READY"
);

console.log(
    "Controlled Account UI Resolver: READY"
);

/* ============================================================
   BK OWNER ACCOUNT GUARD
   PART 9 — PART 5
   MODAL RENDERER + OPEN/CLOSE ENGINE
============================================================ */


/* ------------------------------------------------------------
   MODAL ELEMENT CACHE
------------------------------------------------------------ */

BKOwnerAccountGuard.state.modalElements = {
    initialized: false,

    modal: null,
    status: null,
    title: null,
    message: null,
    masterAction: null,
    masterReason: null,
    noticePriority: null,

    closeButton: null,
    noticeButton: null,
    supportButton: null,

    closeTargets: []
};


/* ------------------------------------------------------------
   CACHE MODAL ELEMENTS
------------------------------------------------------------ */

BKOwnerAccountGuard.cacheAccountModalElements =
    function () {

        const modal =
            document.getElementById(
                "bkOwnerAccountModal"
            );

        if (!modal) {

            console.warn(
                "BK OWNER ACCOUNT GUARD: Account modal element not found."
            );

            return false;
        }

        this.state.modalElements = {

            initialized: true,

            modal: modal,

            status:
                document.getElementById(
                    "bkOwnerAccountModalStatus"
                ),

            title:
                document.getElementById(
                    "bkOwnerAccountModalTitle"
                ),

            message:
                document.getElementById(
                    "bkOwnerAccountModalMessage"
                ),

            masterAction:
                document.getElementById(
                    "bkOwnerAccountModalMasterAction"
                ),

            masterReason:
                document.getElementById(
                    "bkOwnerAccountModalMasterReason"
                ),

            noticePriority:
                document.getElementById(
                    "bkOwnerAccountModalNoticePriority"
                ),

            closeButton:
                document.getElementById(
                    "bkOwnerAccountModalClose"
                ),

            noticeButton:
                document.getElementById(
                    "bkOwnerAccountModalNoticeButton"
                ),

            supportButton:
                document.getElementById(
                    "bkOwnerAccountModalSupportButton"
                ),

            closeTargets:
                modal.querySelectorAll(
                    "[data-account-modal-close]"
                )
        };

        console.log(
            "BK OWNER ACCOUNT GUARD: MODAL ELEMENTS CACHED."
        );

        return true;
    };


/* ------------------------------------------------------------
   RENDER MODAL CONTENT
------------------------------------------------------------ */

BKOwnerAccountGuard.renderAccountControlModal =
    function () {

        if (
            !this.state.modalElements.initialized
        ) {

            const cached =
                this.cacheAccountModalElements();

            if (!cached) {
                return false;
            }
        }

        const modalState =
            this.getAccountModalState();

        if (!modalState.initialized) {

            console.warn(
                "BK OWNER ACCOUNT GUARD: Modal state unavailable."
            );

            return false;
        }

        const elements =
            this.state.modalElements;


        /* STATUS */

        if (elements.status) {

            elements.status.textContent =
                modalState.status
                    ? modalState.status
                    : "ACCOUNT STATUS";
        }


        /* TITLE */

        if (elements.title) {

            elements.title.textContent =
                modalState.title
                    || "Account Status Updated";
        }


        /* MESSAGE */

        if (elements.message) {

            elements.message.textContent =
                modalState.message
                    || "Your restaurant account status has been updated.";
        }


        /* MASTER ACTION */

        if (elements.masterAction) {

            elements.masterAction.textContent =
                modalState.masterAction
                    || "—";
        }


        /* MASTER REASON */

        if (elements.masterReason) {

            elements.masterReason.textContent =
                modalState.masterReason
                    || "No reason provided.";
        }


        /* NOTICE PRIORITY */

        if (elements.noticePriority) {

            elements.noticePriority.textContent =
                modalState.priority
                    || "NORMAL";
        }


        console.log(
            "BK OWNER ACCOUNT GUARD: MODAL CONTENT RENDERED."
        );

        console.log(
            "Modal Status:",
            modalState.status
        );

        console.log(
            "Modal Title:",
            modalState.title
        );

        console.log(
            "Master Action:",
            modalState.masterAction || "NONE"
        );

        console.log(
            "Master Reason:",
            modalState.masterReason || "NONE"
        );

        console.log(
            "Notice Priority:",
            modalState.priority || "NORMAL"
        );

        return true;
    };


/* ------------------------------------------------------------
   OPEN MODAL
------------------------------------------------------------ */

BKOwnerAccountGuard.showAccountControlModal =
    function () {

        if (
            !this.state.modalElements.initialized
        ) {

            const cached =
                this.cacheAccountModalElements();

            if (!cached) {
                return false;
            }
        }

        if (
            !this.state.accountModal.initialized
        ) {

            this.buildAccountModalState();
        }

        const rendered =
            this.renderAccountControlModal();

        if (!rendered) {
            return false;
        }

        const modal =
            this.state.modalElements.modal;

        modal.classList.add("is-open");

        modal.setAttribute(
            "aria-hidden",
            "false"
        );

        this.state.accountModal.open = true;

        this.state.accountModal.openedAt =
            new Date();

        console.log(
            "=========================================="
        );

        console.log(
            "BK OWNER ACCOUNT GUARD: ACCOUNT CONTROL MODAL OPENED."
        );

        console.log(
            "Status:",
            this.state.accountModal.status
        );

        console.log(
            "Master Action:",
            this.state.accountModal.masterAction
                || "NONE"
        );

        console.log(
            "Master Reason:",
            this.state.accountModal.masterReason
                || "NONE"
        );

        console.log(
            "=========================================="
        );

        return true;
    };


/* ------------------------------------------------------------
   CLOSE MODAL
------------------------------------------------------------ */

BKOwnerAccountGuard.hideAccountControlModal =
    function () {

        if (
            !this.state.modalElements.initialized
        ) {
            return;
        }

        const modal =
            this.state.modalElements.modal;

        modal.classList.remove(
            "is-open"
        );

        modal.setAttribute(
            "aria-hidden",
            "true"
        );

        this.state.accountModal.open =
            false;

        console.log(
            "BK OWNER ACCOUNT GUARD: ACCOUNT CONTROL MODAL CLOSED."
        );
    };


/* ------------------------------------------------------------
   MODAL EVENT BINDINGS
------------------------------------------------------------ */

BKOwnerAccountGuard.bindAccountModalEvents =
    function () {

        if (
            !this.state.modalElements.initialized
        ) {

            const cached =
                this.cacheAccountModalElements();

            if (!cached) {
                return;
            }
        }

        const elements =
            this.state.modalElements;


        /* CLOSE BUTTONS */

        elements.closeTargets.forEach(
            (element) => {

                element.addEventListener(
                    "click",
                    () => {

                        this.hideAccountControlModal();

                    }
                );

            }
        );


        /* NOTICE BUTTON */

        if (elements.noticeButton) {

            elements.noticeButton.addEventListener(
                "click",
                () => {

                    console.log(
                        "BK OWNER ACCOUNT GUARD: VIEW NOTICE REQUESTED."
                    );

                    /*
                     * Notice Board module will be connected here
                     * in the next account-control stage.
                     */

                }
            );
        }


        /* SUPPORT BUTTON */

        if (elements.supportButton) {

            elements.supportButton.addEventListener(
                "click",
                () => {

                    console.log(
                        "BK OWNER ACCOUNT GUARD: CONTACT SUPPORT REQUESTED."
                    );

                    /*
                     * Owner Support module will be connected here
                     * in the next account-control stage.
                     */

                }
            );
        }


        /* ESCAPE KEY */

        document.addEventListener(
            "keydown",
            (event) => {

                if (
                    event.key === "Escape"
                    &&
                    this.state.accountModal.open === true
                ) {

                    this.hideAccountControlModal();

                }

            }
        );


        console.log(
            "BK OWNER ACCOUNT GUARD: MODAL EVENTS BOUND."
        );
    };


/* ------------------------------------------------------------
   UI STATE → MODAL REFRESH
------------------------------------------------------------ */

BKOwnerAccountGuard.refreshAccountControlModal =
    function () {

        const uiState =
            this.buildUIState();

        if (!uiState.initialized) {

            console.warn(
                "BK OWNER ACCOUNT GUARD: Cannot refresh account modal."
            );

            return false;
        }

        this.buildAccountModalState();

        this.renderAccountControlModal();

        return true;
    };


/* ============================================================
   REALTIME STATUS → UI → MODAL BRIDGE
============================================================ */

const originalHandleStatusChangeForPart9 =
    BKOwnerAccountGuard.handleStatusChange;


BKOwnerAccountGuard.handleStatusChange =
    function (
        previousStatus,
        newStatus,
        restaurantData
    ) {

        /*
         * Preserve Part 4 + Part 8 behavior.
         */

        originalHandleStatusChangeForPart9.call(
            this,
            previousStatus,
            newStatus,
            restaurantData
        );


        /*
         * Build the latest UI state.
         */

        const uiState =
            this.buildUIState();

        if (!uiState.initialized) {

            console.warn(
                "BK OWNER ACCOUNT GUARD: Part 9 UI state unavailable."
            );

            return;
        }


        /*
         * Build latest modal state.
         */

        this.buildAccountModalState();


        /*
         * Controlled OR restored account:
         * show the status modal.
         */

        const currentStatus =
            this.normalizeStatus(
                newStatus
            );

        if (!currentStatus) {
            return;
        }


        this.renderAccountControlModal();

        this.showAccountControlModal();


        console.log(
            "=========================================="
        );

        console.log(
            "BK OWNER ACCOUNT GUARD: PART 9 REALTIME MODAL BRIDGE ACTIVE."
        );

        console.log(
            "Previous Status:",
            previousStatus || "NONE"
        );

        console.log(
            "New Status:",
            currentStatus
        );

        console.log(
            "Modal:",
            "OPENED"
        );

        console.log(
            "=========================================="
        );
    };


/* ============================================================
   INITIAL MODAL ENGINE STARTUP
============================================================ */

BKOwnerAccountGuard.initAccountControlModal =
    function () {

        const cached =
            this.cacheAccountModalElements();

        if (!cached) {
            return false;
        }

        this.bindAccountModalEvents();

        console.log(
            "BK OWNER ACCOUNT GUARD: ACCOUNT CONTROL MODAL ENGINE READY."
        );

        return true;
    };


/* ============================================================
   DOM STARTUP
============================================================ */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        setTimeout(
            function () {

                if (
                    window.BKOwnerAccountGuard
                ) {

                    BKOwnerAccountGuard
                        .initAccountControlModal();

                }

            },
            250
        );

    }
);


/* ============================================================
   PART 9 — PART 5 COMPLETE
============================================================ */

console.log(
    "BK OWNER ACCOUNT GUARD: PART 9 MODAL RENDERER LOADED."
);

console.log(
    "Modal Element Resolver: READY"
);

console.log(
    "Modal Content Renderer: READY"
);

console.log(
    "Modal Open/Close Engine: READY"
);

console.log(
    "Modal Event Engine: READY"
);

console.log(
    "Realtime Status → UI → Modal Bridge: READY"
);


/* ============================================================
   BK OWNER ACCOUNT GUARD
   PART 9 — PART 6
   UI STATE SYNCHRONIZATION ENGINE
============================================================ */


/* ------------------------------------------------------------
   UI SYNCHRONIZATION STATE
------------------------------------------------------------ */

BKOwnerAccountGuard.state.uiSync = {
    initialized: false,
    lastStatus: null,
    lastControlled: false,
    lastSyncedAt: null
};


/* ------------------------------------------------------------
   SYNCHRONIZE CURRENT ACCOUNT STATE
------------------------------------------------------------ */

BKOwnerAccountGuard.syncAccountControlUI =
    function () {

        const status =
            this.normalizeStatus(
                this.state.accountStatus
            );

        if (!status) {

            console.warn(
                "BK OWNER ACCOUNT GUARD: UI sync skipped. Account status unavailable."
            );

            return false;
        }


        /*
         * 1. Recalculate lock state.
         */

        this.calculateLockState();


        /*
         * 2. Recalculate permissions.
         */

        this.calculatePermissions();


        /*
         * 3. Build latest UI state.
         */

        const uiState =
            this.buildUIState();

        if (!uiState.initialized) {

            console.warn(
                "BK OWNER ACCOUNT GUARD: UI sync failed. UI state unavailable."
            );

            return false;
        }


        /*
         * 4. Build latest modal state.
         */

        this.buildAccountModalState();


        /*
         * 5. Save synchronization state.
         */

        this.state.uiSync = {

            initialized: true,

            lastStatus:
                status,

            lastControlled:
                this.isControlledStatus(
                    status
                ),

            lastSyncedAt:
                new Date()
        };


        console.log(
            "=========================================="
        );

        console.log(
            "BK OWNER ACCOUNT GUARD: UI STATE SYNCHRONIZED."
        );

        console.log(
            "Account Status:",
            status
        );

        console.log(
            "Account Controlled:",
            this.isControlledStatus(
                status
            )
        );

        console.log(
            "Lock Active:",
            this.state.lock.locked
        );

        console.log(
            "Lock Level:",
            this.state.lock.level
        );

        console.log(
            "Restaurant Edit:",
            this.state.permissions.restaurantEdit
        );

        console.log(
            "Menu Management:",
            this.state.permissions.menuManagement
        );

        console.log(
            "Orders Management:",
            this.state.permissions.ordersManagement
        );

        console.log(
            "Bookings Management:",
            this.state.permissions.bookingsManagement
        );

        console.log(
            "Modal Ready:",
            this.state.accountModal.initialized
        );

        console.log(
            "BK OWNER ACCOUNT GUARD: UI SYNCHRONIZATION READY."
        );

        console.log(
            "=========================================="
        );

        return true;
    };


/* ------------------------------------------------------------
   UI SYNC STATE GETTER
------------------------------------------------------------ */

BKOwnerAccountGuard.getUISyncState =
    function () {

        return {

            initialized:
                this.state.uiSync.initialized,

            lastStatus:
                this.state.uiSync.lastStatus,

            lastControlled:
                this.state.uiSync.lastControlled,

            lastSyncedAt:
                this.state.uiSync.lastSyncedAt
        };
    };


/* ------------------------------------------------------------
   INITIAL ACCOUNT UI SYNCHRONIZATION
------------------------------------------------------------ */

BKOwnerAccountGuard.startAccountControlUISync =
    function () {

        if (!this.state.ready) {

            console.warn(
                "BK OWNER ACCOUNT GUARD: UI sync waiting for Guard readiness."
            );

            return false;
        }

        const synced =
            this.syncAccountControlUI();

        if (!synced) {

            console.warn(
                "BK OWNER ACCOUNT GUARD: Initial UI synchronization failed."
            );

            return false;
        }

        console.log(
            "BK OWNER ACCOUNT GUARD: INITIAL ACCOUNT UI SYNC COMPLETE."
        );

        return true;
    };


/* ------------------------------------------------------------
   START AFTER OWNER GUARD IS READY
------------------------------------------------------------ */

const originalGuardStartForPart9UISync =
    BKOwnerAccountGuard.start;

BKOwnerAccountGuard.start =
    function () {

        /*
         * Preserve all existing Guard startup behavior.
         */

        originalGuardStartForPart9UISync.call(
            this
        );


        /*
         * Guard may already have started the
         * realtime status listener above.
         *
         * Wait briefly so the first Firestore
         * snapshot can populate accountStatus.
         */

        setTimeout(
            function () {

                if (
                    BKOwnerAccountGuard.state.ready !== true
                ) {

                    console.warn(
                        "BK OWNER ACCOUNT GUARD: UI sync skipped. Guard not ready."
                    );

                    return;
                }

                BKOwnerAccountGuard
                    .startAccountControlUISync();

            },
            350
        );
    };


/* ============================================================
   PART 9 — PART 6 COMPLETE
============================================================ */

console.log(
    "BK OWNER ACCOUNT GUARD: PART 9 UI SYNCHRONIZATION LOADED."
);

console.log(
    "Account State → UI Sync: READY"
);

console.log(
    "Lock State → UI Sync: READY"
);

console.log(
    "Permission State → UI Sync: READY"
);

console.log(
    "Modal State → UI Sync: READY"
);

console.log(
    "Initial Account UI Synchronization: READY"
);
