
 // ============================================================
 // BK RESTAURANT PLATFORM
 // CENTRAL FIREBASE CORE
 // Version: 1.0.0
 // ============================================================

"use strict";

// ============================================================
// DEFAULT FIREBASE IMPORTS
// ============================================================

import {
    app as defaultApp,
    auth as defaultAuth,
    db as defaultDb,
    BK_CONFIG
} from "./firebase.js";

// ============================================================
// FIREBASE SESSION IMPORTS
// ============================================================

import {
    masterApp,
    masterAuth,
    masterDb,

    ownerApp,
    ownerAuth,
    ownerDb,

    masterProvisioningApp,
    masterProvisioningAuth,
    masterProvisioningDb

} from "./firebase-sessions.js";

// ============================================================
// CENTRAL SESSION REGISTRY
// ============================================================

const sessions = Object.freeze({

    default: Object.freeze({
        app: defaultApp,
        auth: defaultAuth,
        db: defaultDb
    }),

    master: Object.freeze({
        app: masterApp,
        auth: masterAuth,
        db: masterDb
    }),

    owner: Object.freeze({
        app: ownerApp,
        auth: ownerAuth,
        db: ownerDb
    }),

    masterProvisioning: Object.freeze({
        app: masterProvisioningApp,
        auth: masterProvisioningAuth,
        db: masterProvisioningDb
    })

});

// ============================================================
// SESSION VALIDATION
// ============================================================

function validateSession(name) {

    const session = sessions[name];

    if (!session) {
        throw new Error(
            `BK Firebase Core: Unknown session "${name}".`
        );
    }

    if (
        !session.app ||
        !session.auth ||
        !session.db
    ) {
        throw new Error(
            `BK Firebase Core: Incomplete session "${name}".`
        );
    }

    if (session.auth.app !== session.app) {
        throw new Error(
            `BK Firebase Core: Auth mismatch in "${name}".`
        );
    }

    if (session.db.app !== session.app) {
        throw new Error(
            `BK Firebase Core: Firestore mismatch in "${name}".`
        );
    }

    return true;
}

// ============================================================
// GET SESSION
// ============================================================

function getSession(name) {

    validateSession(name);

    return sessions[name];
}

// ============================================================
// GET ALL SESSION NAMES
// ============================================================

function getSessionNames() {

    return Object.keys(sessions);
}

// ============================================================
// DIAGNOSTICS
// ============================================================

function getDiagnostics() {

    const report = {};

    for (const name of getSessionNames()) {

        try {

            const session = getSession(name);

            report[name] = {
                status: "READY",
                appName: session.app.name,
                projectId: session.app.options.projectId
            };

        } catch (error) {

            report[name] = {
                status: "ERROR",
                message: error.message
            };

        }
    }

    return Object.freeze({

        version: "1.0.0",

        projectId:
            BK_CONFIG.firebaseProjectId,

        sessions: report

    });
}

// ============================================================
// INITIALIZATION CHECK
// ============================================================

function initializeCore() {

    const diagnostics = getDiagnostics();

    console.log(
        "[BK FIREBASE CORE] Diagnostics:",
        diagnostics
    );

    const failedSessions = Object.entries(
        diagnostics.sessions
    ).filter(
        ([, result]) =>
            result.status !== "READY"
    );

    if (failedSessions.length > 0) {

        throw new Error(
            "BK Firebase Core: Session validation failed."
        );

    }

    return true;
}

// ============================================================
// EXPORT
// ============================================================

export {

    sessions,

    getSession,

    getSessionNames,

    validateSession,

    getDiagnostics,

    initializeCore

};
