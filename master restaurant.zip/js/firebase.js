// ============================================================
// BK RESTAURANT PLATFORM
// FIREBASE CORE CONFIGURATION
// Version: 1.0.0
// ============================================================

"use strict";


// ============================================================
// FIREBASE SDK IMPORTS
// ============================================================

import {
    initializeApp
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-app.js";

import {
    getAuth
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-auth.js";

import {
    getFirestore
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";


// ============================================================
// FIREBASE PROJECT CONFIGURATION
// ============================================================

const firebaseConfig = {

    apiKey:
        "AIzaSyDdCsWuGbqBX4B9X0Ar2M1W3XcnE05yPw4",

    authDomain:
        "master-restaurant-platform.firebaseapp.com",

    projectId:
        "master-restaurant-platform",

    storageBucket:
        "master-restaurant-platform.firebasestorage.app",

    messagingSenderId:
        "211224186237",

    appId:
        "1:211224186237:web:1383de1c1631c4bc0f1014"
};


// ============================================================
// INITIALIZE FIREBASE
// ============================================================

const app = initializeApp(firebaseConfig);


// ============================================================
// FIREBASE AUTHENTICATION
// ============================================================

const auth = getAuth(app);


// ============================================================
// CLOUD FIRESTORE DATABASE
// ============================================================

const db = getFirestore(app);


// ============================================================
// BK PLATFORM CONSTANTS
// ============================================================

const BK_CONFIG = {

    platformName: "BK Restaurant Platform",

    platformVersion: "1.0.0",

    firebaseProjectId:
        firebaseConfig.projectId,

    collections: {

        users: "users",

        restaurants: "restaurants"

    },

    storagePaths: {

        restaurants: "restaurants",

        branding: "branding",

        logo: "logo",

        cover: "cover",

        menu: "menu",

        gallery: "gallery"

    }

};


// ============================================================
// FIREBASE CONNECTION CHECK
// ============================================================

console.log(
    "=========================================="
);

console.log(
    "BK Restaurant Platform"
);

console.log(
    "Firebase initialized successfully."
);

console.log(
    "Project:",
    firebaseConfig.projectId
);

console.log(
    "Authentication: Ready"
);

console.log(
    "Firestore: Ready"
);

console.log(
    "Storage Architecture: Prepared"
);

console.log(
    "=========================================="
);


// ============================================================
// EXPORT
// ============================================================

export {

    app,

    auth,

    db,

    BK_CONFIG

};

