// ============================================================
// BK RESTAURANT PLATFORM
// FIREBASE SESSION ISOLATION
// Version: 1.0.0
// ============================================================

"use strict";


// ============================================================
// DEFAULT FIREBASE APP
// ============================================================

import {
    app
} from "./firebase.js";


// ============================================================
// FIREBASE APP IMPORTS
// ============================================================

import {
    initializeApp,
    getApps
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-app.js";


// ============================================================
// FIREBASE AUTH / FIRESTORE
// ============================================================

import {
    getAuth
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-auth.js";

import {
    getFirestore
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";


// ============================================================
// APP NAMES
// ============================================================

const MASTER_APP_NAME =
    "BK_MASTER_APP";

const OWNER_APP_NAME =
    "BK_OWNER_APP";
    
const MASTER_PROVISIONING_APP_NAME =
    "BK_MASTER_PROVISIONING_APP";

// ============================================================
// GET OR CREATE NAMED FIREBASE APP
// ============================================================

function getOrCreateApp(name) {

    const existingApp =
        getApps().find(
            firebaseApp =>
                firebaseApp.name === name
        );


    if (existingApp) {

        return existingApp;

    }


    return initializeApp(
        app.options,
        name
    );

}


// ============================================================
// MASTER FIREBASE APP
// ============================================================

const masterApp =
    getOrCreateApp(
        MASTER_APP_NAME
    );


// ============================================================
// OWNER FIREBASE APP
// ============================================================

const ownerApp =
    getOrCreateApp(
        OWNER_APP_NAME
    );


// ============================================================
// MASTER PROVISIONING FIREBASE APP
// ============================================================

const masterProvisioningApp =
    getOrCreateApp(
        MASTER_PROVISIONING_APP_NAME
    );

// ============================================================
// MASTER AUTH / FIRESTORE
// ============================================================

const masterAuth =
    getAuth(
        masterApp
    );

const masterDb =
    getFirestore(
        masterApp
    );


// ============================================================
// OWNER AUTH / FIRESTORE
// ============================================================

const ownerAuth =
    getAuth(
        ownerApp
    );

const ownerDb =
    getFirestore(
        ownerApp
    );


// ============================================================
// MASTER PROVISIONING AUTH
// ============================================================

const masterProvisioningAuth =
    getAuth(
        masterProvisioningApp
    );
    
    // ============================================================
// MASTER PROVISIONING FIRESTORE
// ============================================================

const masterProvisioningDb =
    getFirestore(
        masterProvisioningApp
    );

// ============================================================
// DIAGNOSTIC
// ============================================================

console.log(
    "=========================================="
);

console.log(
    "BK FIREBASE SESSION ISOLATION"
);

console.log(
    "Default App:",
    app.name
);

console.log(
    "Master App:",
    masterApp.name
);

console.log(
    "Owner App:",
    ownerApp.name
);

console.log(
    "Master Auth: READY"
);

console.log(
    "Master Firestore: READY"
);

console.log(
    "Owner Auth: READY"
);

console.log(
    "Owner Firestore: READY"
);

console.log(
    "=========================================="
);


// ============================================================
// EXPORT
// ============================================================

export {

    masterApp,
    masterAuth,
    masterDb,

    ownerApp,
    ownerAuth,
    ownerDb,

    masterProvisioningApp,
    masterProvisioningAuth,
    masterProvisioningDb

};