 // ============================================================
// BK RESTAURANT PLATFORM
// REGISTRATION SYSTEM
// Part 1 of 2
// ============================================================

"use strict";


import {
    auth,
    db
} from "./firebase.js";
import {
    createUserWithEmailAndPassword,
    deleteUser
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-auth.js";

import {
    collection,
    doc,
    serverTimestamp,
    writeBatch,
    getDocs,
    query,
    where
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";


// ============================================================
// BK REGISTRATION CONTROLLER
// ============================================================

const BKRegistration = {

    currentStep: 1,

    totalSteps: 5,

    form: null,

    steps: [],

    indicators: [],

    backButton: null,

    continueButton: null,

    createAccountButton: null,

    currentStepDisplay: null,

    successSection: null,

    dashboardButton: null,


    // ========================================================
    // SUBSCRIPTION PLAN STATE
    // ========================================================

    activePlans: [],

    selectedPlan: null,

    planList: null,

    planLoading: null,

    planError: null,


    // ========================================================
    // INITIALIZE
    // ========================================================

    init: async function () {

        this.form =
            document.querySelector(
                "#registrationForm"
            );

        this.steps =
            document.querySelectorAll(
                ".form-step"
            );

        this.indicators =
            document.querySelectorAll(
                ".step"
            );

        this.backButton =
            document.querySelector(
                "#backButton"
            );

        this.continueButton =
            document.querySelector(
                "#continueButton"
            );

        this.createAccountButton =
            document.querySelector(
                "#createAccountButton"
            );

        this.currentStepDisplay =
            document.querySelector(
                "#currentStep"
            );

        this.successSection =
            document.querySelector(
                "#registrationSuccess"
            );

        this.dashboardButton =
            document.querySelector(
                "#dashboardButton"
            );


        // ----------------------------------------------------
        // PLAN ELEMENTS
        // ----------------------------------------------------

        this.planList =
            document.querySelector(
                "#registrationPlanList"
            );

        this.planLoading =
            document.querySelector(
                "#registrationPlanLoading"
            );

        this.planError =
            document.querySelector(
                "#registrationPlanError"
            );


        if (!this.form) {

            console.error(
                "BK Registration form not found."
            );

            return;
        }


        this.setupEvents();

        this.setupImagePreviews();

        this.showStep(1);


        // ----------------------------------------------------
        // LOAD ACTIVE SUBSCRIPTION PLANS
        // ----------------------------------------------------

        await this.loadActivePlans();


        console.log(
            "BK Registration System initialized."
        );

    },


    // ========================================================
    // EVENTS
    // ========================================================

    setupEvents: function () {

        const self = this;


        // ----------------------------------------------------
        // CONTINUE
        // ----------------------------------------------------

        if (this.continueButton) {

            this.continueButton.addEventListener(
                "click",
                function () {

                    if (
                        self.validateStep(
                            self.currentStep
                        )
                    ) {

                        self.goToNextStep();

                    }

                }
            );

        }


        // ----------------------------------------------------
        // BACK
        // ----------------------------------------------------

        if (this.backButton) {

            this.backButton.addEventListener(
                "click",
                function () {

                    self.goToPreviousStep();

                }
            );

        }


        // ----------------------------------------------------
        // FORM SUBMIT
        // ----------------------------------------------------

        this.form.addEventListener(
            "submit",
            function (event) {

                event.preventDefault();

                self.handleRegistration();

            }
        );


        // ----------------------------------------------------
        // DASHBOARD
        // ----------------------------------------------------

        if (this.dashboardButton) {

            this.dashboardButton.addEventListener(
                "click",
                function () {

                    window.location.href =
                        "owner.html";

                }
            );

        }

    },


    // ========================================================
    // LOAD ACTIVE SUBSCRIPTION PLANS
    // ========================================================

    loadActivePlans: async function () {

        if (!this.planList) {

            console.warn(
                "BK Registration plan list not found."
            );

            return;

        }


        this.showPlanLoading();


        try {

            console.log(
                "BK Registration: Loading active subscription plans..."
            );


            const plansQuery =
                query(
                    collection(
                        db,
                        "subscriptionPlans"
                    ),
                    where(
                        "status",
                        "==",
                        "ACTIVE"
                    )
                );


            const snapshot =
                await getDocs(
                    plansQuery
                );


            this.activePlans = [];


            snapshot.forEach(
                function (planDocument) {

                    const planData =
                        planDocument.data();


                    if (
                        !planData ||
                        !planData.planId
                    ) {

                        return;

                    }


                    BKRegistration.activePlans.push({

                        planId:
                            String(
                                planData.planId
                            ),

                        name:
                            String(
                                planData.name || ""
                            ),

                        description:
                            String(
                                planData.description || ""
                            ),

                        baseAmount:
                            Number(
                                planData.baseAmount || 0
                            ),

                        minimumAmount:
                            Number(
                                planData.minimumAmount || 0
                            ),

                        maximumAmount:
                            Number(
                                planData.maximumAmount || 0
                            ),

                        currency:
                            String(
                                planData.currency || "INR"
                            ),

                        billingCycle:
                            String(
                                planData.billingCycle || "MONTHLY"
                            ),

                        usagePricingEnabled:
                            planData.usagePricingEnabled === true,

                        entitlementKey:
                            String(
                                planData.entitlementKey || ""
                            ),

                        status:
                            String(
                                planData.status || ""
                            )

                    });

                }
            );


            // ------------------------------------------------
            // SORT BY BASE AMOUNT
            // ------------------------------------------------

            this.activePlans.sort(
                function (a, b) {

                    return (
                        a.baseAmount -
                        b.baseAmount
                    );

                }
            );


            console.log(
                "BK Registration: Active plans loaded:",
                this.activePlans.length
            );


            this.renderActivePlans();


        } catch (error) {

            console.error(
                "BK Registration: Failed to load subscription plans:",
                error
            );


            this.activePlans = [];


            this.showPlanError(
                "Unable to load subscription plans. Please refresh and try again."
            );

        }

    },


    // ========================================================
    // SHOW PLAN LOADING
    // ========================================================

    showPlanLoading: function () {

        if (this.planLoading) {

            this.planLoading.style.display =
                "block";

            this.planLoading.textContent =
                "Loading available plans...";

        }


        if (this.planError) {

            this.planError.textContent =
                "";

        }

    },


    // ========================================================
    // SHOW PLAN ERROR
    // ========================================================

    showPlanError: function (message) {

        if (this.planLoading) {

            this.planLoading.style.display =
                "none";

        }


        if (this.planError) {

            this.planError.textContent =
                message;

        }

    },


    // ========================================================
    // RENDER ACTIVE PLANS
    // ========================================================

    renderActivePlans: function () {

        if (!this.planList) {

            return;

        }


        this.planList.innerHTML =
            "";


        if (
            !this.activePlans.length
        ) {

            this.showPlanError(
                "No active subscription plans are currently available."
            );

            return;

        }


        if (this.planError) {

            this.planError.textContent =
                "";

        }


        const self =
            this;


        this.activePlans.forEach(
            function (plan) {

                const card =
                    document.createElement(
                        "button"
                    );


                card.type =
                    "button";


                card.className =
                    "registration-plan-card";


                card.dataset.planId =
                    plan.planId;


                card.setAttribute(
                    "aria-pressed",
                    "false"
                );


                const amount =
                    self.formatPlanAmount(
                        plan.baseAmount,
                        plan.currency
                    );


                const cycle =
                    self.formatBillingCycle(
                        plan.billingCycle
                    );


                card.innerHTML = `

                    <div class="registration-plan-card-header">

                        <div>

                            <span class="registration-plan-label">
                                BK PLAN
                            </span>

                            <h3>
                                ${self.escapeHTML(plan.name)}
                            </h3>

                        </div>

                        <span class="registration-plan-status">
                            ACTIVE
                        </span>

                    </div>


                    <div class="registration-plan-price">

                        <strong>
                            ${self.escapeHTML(amount)}
                        </strong>

                        <span>
                            / ${self.escapeHTML(cycle)}
                        </span>

                    </div>


                    <p class="registration-plan-description">
                        ${self.escapeHTML(
                            plan.description ||
                            "Premium BK restaurant platform access."
                        )}
                    </p>


                    <div class="registration-plan-meta">

                        <span>
                            Currency: ${self.escapeHTML(plan.currency)}
                        </span>

                        <span>
                            ${plan.usagePricingEnabled
                                ? "Usage pricing enabled"
                                : "Standard pricing"}
                        </span>

                    </div>


                    <div class="registration-plan-select-state">

                        <span>
                            Select Plan
                        </span>

                    </div>

                `;


                card.addEventListener(
                    "click",
                    function () {

                        self.selectPlan(
                            plan.planId
                        );

                    }
                );


                self.planList.appendChild(
                    card
                );

            }
        );


        if (this.planLoading) {

            this.planLoading.style.display =
                "none";

        }


        console.log(
            "BK Registration: Plan cards rendered."
        );

    },


    // ========================================================
    // SELECT PLAN
    // ========================================================

    selectPlan: function (planId) {

        const plan =
            this.activePlans.find(
                function (item) {

                    return (
                        item.planId ===
                        planId
                    );

                }
            );


        if (!plan) {

            this.showPlanError(
                "Selected plan could not be found."
            );

            return false;

        }


        this.selectedPlan =
            plan;


        const cards =
            document.querySelectorAll(
                ".registration-plan-card"
            );


        cards.forEach(
            function (card) {

                const isSelected =
                    card.dataset.planId ===
                    planId;


                card.classList.toggle(
                    "selected",
                    isSelected
                );


                card.setAttribute(
                    "aria-pressed",
                    String(
                        isSelected
                    )
                );

            }
        );


        if (this.planError) {

            this.planError.textContent =
                "";

        }


        console.log(
            "BK Registration: Plan selected:",
            plan.planId,
            plan.name,
            plan.baseAmount,
            plan.currency
        );


        return true;

    },


    // ========================================================
    // GET SELECTED PLAN
    // ========================================================

    getSelectedPlan: function () {

        return this.selectedPlan;

    },


    // ========================================================
    // PLAN VALIDATION
    // ========================================================

    validatePlanSelection: function () {

        if (
            !this.selectedPlan
        ) {

            this.showPlanError(
                "Please select a BK subscription plan before continuing."
            );


            return false;

        }


        if (
            !this.selectedPlan.planId
        ) {

            this.showPlanError(
                "The selected subscription plan is invalid."
            );


            return false;

        }


        if (
            String(
                this.selectedPlan.status
            ).toUpperCase() !==
            "ACTIVE"
        ) {

            this.showPlanError(
                "This subscription plan is no longer active. Please select another plan."
            );


            this.selectedPlan =
                null;


            this.renderActivePlans();


            return false;

        }


        return true;

    },


    // ========================================================
    // FORMAT PLAN AMOUNT
    // ========================================================

    formatPlanAmount: function (
        amount,
        currency
    ) {

        const numericAmount =
            Number(
                amount
            );


        if (
            !Number.isFinite(
                numericAmount
            )
        ) {

            return (
                String(
                    currency || "INR"
                ) +
                " 0"
            );

        }


        try {

            return new Intl.NumberFormat(
                "en-IN",
                {
                    style: "currency",
                    currency:
                        String(
                            currency || "INR"
                        ).toUpperCase(),
                    maximumFractionDigits: 2
                }
            ).format(
                numericAmount
            );

        } catch (error) {

            return (
                String(
                    currency || "INR"
                ) +
                " " +
                numericAmount.toFixed(2)
            );

        }

    },


    // ========================================================
    // FORMAT BILLING CYCLE
    // ========================================================

    formatBillingCycle: function (
        billingCycle
    ) {

        const value =
            String(
                billingCycle || ""
            ).toUpperCase();


        if (
            value === "MONTHLY"
        ) {

            return "month";

        }


        if (
            value === "QUARTERLY"
        ) {

            return "quarter";

        }


        if (
            value === "YEARLY"
        ) {

            return "year";

        }


        return (
            value.toLowerCase() ||
            "billing cycle"
        );

    },


    // ========================================================
    // ESCAPE HTML
    // ========================================================

    escapeHTML: function (value) {

        const element =
            document.createElement(
                "div"
            );


        element.textContent =
            String(
                value ?? ""
            );


        return element.innerHTML;

    },


    // ========================================================
    // SHOW STEP
    // ========================================================

showStep: function (stepNumber) {

        this.currentStep =
            stepNumber;


        this.steps.forEach(
            function (step) {

                const stepValue =
                    Number(
                        step.dataset.stepContent
                    );


                step.classList.toggle(
                    "active",
                    stepValue ===
                    stepNumber
                );

            }
        );


        this.indicators.forEach(
            function (indicator) {

                const indicatorValue =
                    Number(
                        indicator.dataset.step
                    );


                indicator.classList.toggle(
                    "active",
                    indicatorValue ===
                    stepNumber
                );


                indicator.classList.toggle(
                    "completed",
                    indicatorValue <
                    stepNumber
                );

            }
        );


        if (
            this.currentStepDisplay
        ) {

            this.currentStepDisplay.textContent =
                stepNumber;

        }


        if (
            this.backButton
        ) {

            this.backButton.style.visibility =
                stepNumber === 1
                    ? "hidden"
                    : "visible";

        }


        if (
            this.continueButton
        ) {

            this.continueButton.style.display =
                stepNumber ===
                this.totalSteps
                    ? "none"
                    : "block";

        }


        if (
            this.createAccountButton
        ) {

            this.createAccountButton.style.display =
                stepNumber ===
                this.totalSteps
                    ? "block"
                    : "none";

        }

    },


    // ========================================================
    // NEXT STEP
    // ========================================================

    goToNextStep: function () {

        if (
            this.currentStep <
            this.totalSteps
        ) {

            this.showStep(
                this.currentStep + 1
            );


            this.scrollToForm();

        }

    },


    // ========================================================
    // PREVIOUS STEP
    // ========================================================

    goToPreviousStep: function () {

        if (
            this.currentStep >
            1
        ) {

            this.showStep(
                this.currentStep - 1
            );


            this.scrollToForm();

        }

    },


    // ========================================================
    // SCROLL
    // ========================================================

    scrollToForm: function () {

        if (!this.form) {

            return;

        }


        const formTop =
            this.form.getBoundingClientRect().top
            + window.scrollY
            - 30;


        window.scrollTo({

            top:
                formTop,

            behavior:
                "smooth"

        });

    },


    // ========================================================
    // STEP VALIDATION
    // ========================================================

    validateStep: function (
        stepNumber
    ) {

        this.clearErrors();


        if (
            stepNumber === 1
        ) {

            return this.validateOwnerDetails();

        }


        if (
            stepNumber === 2
        ) {

            return this.validateRestaurantDetails();

        }


        if (
            stepNumber === 3
        ) {

            return this.validatePlanSelection();

        }


        if (
            stepNumber === 4
        ) {

            return true;

        }


        if (
            stepNumber === 5
        ) {

            return this.validatePolicy();

        }


        return true;

    },


    // ========================================================
    // OWNER VALIDATION
    // ========================================================

    validateOwnerDetails: function () {

        const ownerName =
            document.querySelector(
                "#ownerName"
            );

        const ownerEmail =
            document.querySelector(
                "#ownerEmail"
            );

        const password =
            document.querySelector(
                "#ownerPassword"
            );

        const confirmPassword =
            document.querySelector(
                "#confirmPassword"
            );


        let valid =
            true;


        if (
            !ownerName ||
            !ownerName.value.trim()
        ) {

            this.showError(
                "ownerNameError",
                "Please enter your full name."
            );


            valid =
                false;

        }


        if (
            !ownerEmail ||
            !ownerEmail.value.trim()
        ) {

            this.showError(
                "ownerEmailError",
                "Please enter your email address."
            );


            valid =
                false;

        } else if (
            !this.isValidEmail(
                ownerEmail.value.trim()
            )
        ) {

            this.showError(
                "ownerEmailError",
                "Please enter a valid email address."
            );


            valid =
                false;

        }


        if (
            !password ||
            password.value.length < 6
        ) {

            this.showError(
                "ownerPasswordError",
                "Password must contain at least 6 characters."
            );


            valid =
                false;

        }


        if (
            !confirmPassword ||
            !password ||
            confirmPassword.value !==
            password.value
        ) {

            this.showError(
                "confirmPasswordError",
                "Passwords do not match."
            );


            valid =
                false;

        }


        return valid;

    },


    // ========================================================
    // RESTAURANT VALIDATION
    // ========================================================

    validateRestaurantDetails: function () {

        const restaurantName =
            document.querySelector(
                "#restaurantName"
            );

        const restaurantType =
            document.querySelector(
                "#restaurantType"
            );

        const address =
            document.querySelector(
                "#restaurantAddress"
            );

        const city =
            document.querySelector(
                "#restaurantCity"
            );

        const state =
            document.querySelector(
                "#restaurantState"
            );


        let valid =
            true;


        if (
            !restaurantName ||
            !restaurantName.value.trim()
        ) {

            alert(
                "Please enter your restaurant name."
            );


            valid =
                false;

        }


        if (
            !restaurantType ||
            !restaurantType.value
        ) {

            alert(
                "Please select your restaurant type."
            );


            valid =
                false;

        }


        if (
            !address ||
            !address.value.trim()
        ) {

            alert(
                "Please enter your restaurant address."
            );


            valid =
                false;

        }


        if (
            !city ||
            !city.value.trim()
        ) {

            alert(
                "Please enter your city."
            );


            valid =
                false;

        }


        if (
            !state ||
            !state.value.trim()
        ) {

            alert(
                "Please enter your state."
            );


            valid =
                false;

        }


        return valid;

    },


    // ========================================================
    // POLICY VALIDATION
    // ========================================================

    validatePolicy: function () {

        const policyAgreement =
            document.querySelector(
                "#policyAgreement"
            );


        if (
            !policyAgreement ||
            !policyAgreement.checked
        ) {

            this.showError(
                "policyError",
                "Please accept the BK platform policies before creating your account."
            );


            return false;

        }


        return true;

    },


    // ========================================================
    // EMAIL VALIDATION
    // ========================================================

    isValidEmail: function (
        email
    ) {

        const pattern =
            /^[^\s@]+@[^\s@]+\.[^\s@]+$/;


        return pattern.test(
            email
        );

    },


    // ========================================================
    // ERROR HANDLING
    // ========================================================

    showError: function (
        elementId,
        message
    ) {

        const element =
            document.querySelector(
                "#" + elementId
            );


        if (element) {

            element.textContent =
                message;

        }

    },


    clearErrors: function () {

        const errors =
            document.querySelectorAll(
                ".field-error"
            );


        errors.forEach(
            function (error) {

                error.textContent =
                    "";

            }
        );

    },


    // ========================================================
    // IMAGE PREVIEW
    // ========================================================

    setupImagePreviews: function () {

        const logoInput =
            document.querySelector(
                "#restaurantLogo"
            );

        const coverInput =
            document.querySelector(
                "#restaurantCover"
            );


        if (logoInput) {

            logoInput.addEventListener(
                "change",
                function () {

                    BKRegistration.previewImage(
                        logoInput,
                        "#logoPreview"
                    );

                }
            );

        }


        if (coverInput) {

            coverInput.addEventListener(
                "change",
                function () {

                    BKRegistration.previewImage(
                        coverInput,
                        "#coverPreview"
                    );

                }
            );

        }

    },


    previewImage: function (
        input,
        previewSelector
    ) {

        const preview =
            document.querySelector(
                previewSelector
            );


        if (
            !preview ||
            !input.files ||
            !input.files[0]
        ) {

            return;

        }


        const file =
            input.files[0];


        if (
            !file.type.startsWith(
                "image/"
            )
        ) {

            alert(
                "Please select a valid image file."
            );


            input.value =
                "";


            return;

        }


        const imageURL =
            URL.createObjectURL(
                file
            );


        preview.innerHTML =
            "";


        const image =
            document.createElement(
                "img"
            );


        image.src =
            imageURL;


        image.alt =
            "Restaurant image preview";


        preview.appendChild(
            image
        );

    },


    // ========================================================
    // COLLECT FORM DATA
    // ========================================================

    collectFormData: function () {

        const selectedPlan =
            this.getSelectedPlan();


        return {

            owner: {

                name:
                    document.querySelector(
                        "#ownerName"
                    ).value.trim(),

                email:
                    document.querySelector(
                        "#ownerEmail"
                    ).value.trim(),

                phone:
                    document.querySelector(
                        "#ownerPhone"
                    ).value.trim()

            },


            restaurant: {

                name:
                    document.querySelector(
                        "#restaurantName"
                    ).value.trim(),

                description:
                    document.querySelector(
                        "#restaurantDescription"
                    ).value.trim(),

                type:
                    document.querySelector(
                        "#restaurantType"
                    ).value,

                cuisine:
                    document.querySelector(
                        "#cuisine"
                    ).value.trim(),

                address:
                    document.querySelector(
                        "#restaurantAddress"
                    ).value.trim(),

                city:
                    document.querySelector(
                        "#restaurantCity"
                    ).value.trim(),

                state:
                    document.querySelector(
                        "#restaurantState"
                    ).value.trim(),

                openingTime:
                    document.querySelector(
                        "#openingTime"
                    ).value,

                closingTime:
                    document.querySelector(
                        "#closingTime"
                    ).value,

                whatsapp:
                    document.querySelector(
                        "#whatsapp"
                    ).value.trim(),

                email:
                    document.querySelector(
                        "#restaurantEmail"
                    ).value.trim()

            },


            // ------------------------------------------------
            // SELECTED PLAN
            // ------------------------------------------------
            plan: selectedPlan
                ? {

                    planId:
                        selectedPlan.planId,

                    name:
                        selectedPlan.name,

                    baseAmount:
                        selectedPlan.baseAmount,

                    currency:
                        selectedPlan.currency,

                    billingCycle:
                        selectedPlan.billingCycle,

                    entitlementKey:
                        selectedPlan.entitlementKey

                }
                : null

        };

    },


    // ========================================================
    // REGISTRATION
    // ========================================================

    handleRegistration:
        async function () {

        console.log(
            "Starting BK account registration..."
        );


        // ----------------------------------------------------
        // FINAL PLAN VALIDATION
        // ----------------------------------------------------

        if (
            !this.validatePlanSelection()
        ) {

            this.showStep(3);

            return;

        }


        // ----------------------------------------------------
        // FINAL POLICY VALIDATION
        // ----------------------------------------------------

        if (
            !this.validatePolicy()
        ) {

            this.showStep(5);

            return;

        }


        const data =
            this.collectFormData();


        if (
            !data.plan ||
            !data.plan.planId
        ) {

            this.showStep(3);

            this.showPlanError(
                "Please select a subscription plan before creating your account."
            );

            return;

        }


        if (
            this.createAccountButton
        ) {

            this.createAccountButton.disabled =
                true;


            this.createAccountButton.textContent =
                "Creating Account...";

        }


        try {

            await this.createFirebaseAccount(
                data
            );


        } catch (error) {

            console.error(
                "Registration failed:",
                error
            );


            this.handleFirebaseError(
                error
            );


            this.resetCreateButton();

        }

    },


    // ========================================================
    // FIREBASE ACCOUNT CREATION
    // ========================================================

    createFirebaseAccount:
        async function (data) {

        const credential =
            await createUserWithEmailAndPassword(
                auth,
                data.owner.email,
                document.querySelector(
                    "#ownerPassword"
                ).value
            );


        const user =
            credential.user;


        console.log(
            "Firebase Auth account created:",
            user.uid
        );


        const restaurantReference =
            doc(
                collection(
                    db,
                    "restaurants"
                )
            );


        const restaurantId =
            restaurantReference.id;


        const userReference =
            doc(
                db,
                "users",
                user.uid
            );


        const userData = {

            ownerName:
                data.owner.name,

            email:
                data.owner.email,

            phone:
                data.owner.phone,

            role:
                "owner",

            restaurantId:
                restaurantId,

            createdAt:
                serverTimestamp()

        };


        const restaurantData = {

            ownerId:
                user.uid,

            name:
                data.restaurant.name,

            description:
                data.restaurant.description,

            type:
                data.restaurant.type,

            cuisine:
                data.restaurant.cuisine,

            contact: {

                email:
                    data.restaurant.email,

                whatsapp:
                    data.restaurant.whatsapp

            },

            address: {

                line1:
                    data.restaurant.address,

                city:
                    data.restaurant.city,

                state:
                    data.restaurant.state

            },

            timings: {

                opening:
                    data.restaurant.openingTime,

                closing:
                    data.restaurant.closingTime

            },

            branding: {

                logoUrl: "",

                logoPath: "",

                coverUrl: "",

                coverPath: ""

            },

            status:
                "active",

            createdAt:
                serverTimestamp(),

            updatedAt:
                serverTimestamp()

        };


        const batch =
            writeBatch(db);


        batch.set(
            userReference,
            userData
        );


        batch.set(
            restaurantReference,
            restaurantData
        );


        await batch.commit();


        console.log(
            "BK Firestore data saved successfully."
        );


        localStorage.setItem(
            "bkOwnerUid",
            user.uid
        );


        localStorage.setItem(
            "bkRestaurantId",
            restaurantId
        );


        this.showRegistrationSuccess();

    },


    // ========================================================
    // SUCCESS SCREEN
    // ========================================================

    showRegistrationSuccess:
        function () {

        if (this.form) {

            this.form.style.display =
                "none";

        }


        if (this.successSection) {

            this.successSection.hidden =
                false;

        }


        console.log(
            "================================"
        );


        console.log(
            "BK ACCOUNT CREATED SUCCESSFULLY"
        );


        console.log(
            "================================"
        );

    },


    // ========================================================
    // RESET CREATE BUTTON
    // ========================================================

    resetCreateButton:
        function () {

        if (
            this.createAccountButton
        ) {

            this.createAccountButton.disabled =
                false;


            this.createAccountButton.textContent =
                "Create Account";

        }

    },


    // ========================================================
    // FIREBASE ERROR HANDLING
    // ========================================================

    handleFirebaseError:
        function (error) {

        let message =
            "Something went wrong. Please try again.";


        switch (
            error.code
        ) {

            case "auth/email-already-in-use":

                message =
                    "This email is already registered.";

                break;


            case "auth/invalid-email":

                message =
                    "Please enter a valid email address.";

                break;


            case "auth/weak-password":

                message =
                    "Your password is too weak.";

                break;


            case "auth/network-request-failed":

                message =
                    "Network error. Please check your internet connection.";

                break;


            case "permission-denied":

                message =
                    "Firebase permission denied. Please check Firestore security rules.";

                break;

        }


        alert(
            "BK Registration\n\n" +
            message
        );

    }

};


// ============================================================
// PART 1 END
// ============================================================
// Part 2 continues directly below.
// ============================================================
// ============================================================
// BK RESTAURANT PLATFORM
// REGISTRATION SYSTEM
// Part 2 of 2
// ============================================================


// ============================================================
// FINAL FIREBASE ACCOUNT CREATION OVERRIDE
// ============================================================

BKRegistration.createFirebaseAccount =
    async function (data) {

    let createdUser = null;


    try {

        // ----------------------------------------------------
        // CREATE FIREBASE AUTH ACCOUNT
        // ----------------------------------------------------

        const credential =
            await createUserWithEmailAndPassword(
                auth,
                data.owner.email,
                document.querySelector(
                    "#ownerPassword"
                ).value
            );


        createdUser =
            credential.user;


        console.log(
            "Firebase Auth account created:",
            createdUser.uid
        );


        // ----------------------------------------------------
        // CREATE RESTAURANT ID
        // ----------------------------------------------------

        const restaurantReference =
            doc(
                collection(
                    db,
                    "restaurants"
                )
            );


        const restaurantId =
            restaurantReference.id;


        // ----------------------------------------------------
        // USER DOCUMENT
        // ----------------------------------------------------

        const userReference =
            doc(
                db,
                "users",
                createdUser.uid
            );


        const userData = {

            ownerName:
                data.owner.name,

            email:
                data.owner.email,

            phone:
                data.owner.phone,

            role:
                "owner",

            restaurantId:
                restaurantId,

            agreedToPolicies:
                true,

            policyVersion:
                "1.0",

            createdAt:
                serverTimestamp()

        };


        // ----------------------------------------------------
        // RESTAURANT DOCUMENT
        // ----------------------------------------------------

        const restaurantData = {

            ownerId:
                createdUser.uid,

            name:
                data.restaurant.name,

            description:
                data.restaurant.description,

            type:
                data.restaurant.type,

            cuisine:
                data.restaurant.cuisine,


            // ------------------------------------------------
            // SELECTED PLAN
            // ------------------------------------------------

            selectedPlanId:
                data.plan.planId,

            selectedPlanAt:
                serverTimestamp(),


            // ------------------------------------------------
            // MASTER-CONTROLLED ACCESS FOUNDATION
            // ------------------------------------------------
            // SECURITY RULE:
            // Every newly created restaurant starts with
            // PAYMENT_REQUIRED.
            //
            // Free access is NEVER granted automatically.
            // Master must explicitly grant free access later.
            // ------------------------------------------------

            accessControl: {

                mode:
                    "PAYMENT_REQUIRED",

                masterAccess:
                    "NOT_GRANTED",

                paymentStatus:
                    "NOT_SUBMITTED",

                freeGrantStatus:
                    "NOT_ACTIVE",

                freeGrantStart:
                    null,

                freeGrantExpiresAt:
                    null,

                freeGrantReason:
                    "",

                accessDecision:
                    "PENDING",

                accessDecisionReason:
                    "",

                accessDecisionAt:
                    null,

                accessDecisionBy:
                    null

            },


            contact: {

                email:
                    data.restaurant.email,

                whatsapp:
                    data.restaurant.whatsapp

            },


            address: {

                line1:
                    data.restaurant.address,

                city:
                    data.restaurant.city,

                state:
                    data.restaurant.state

            },


            timings: {

                opening:
                    data.restaurant.openingTime,

                closing:
                    data.restaurant.closingTime

            },


            branding: {

                logoUrl: "",

                logoPath: "",

                coverUrl: "",

                coverPath: ""

            },


            status:
                "active",


            policies: {

                agreed:
                    true,

                version:
                    "1.0",

                agreedAt:
                    serverTimestamp()

            },


            createdAt:
                serverTimestamp(),

            updatedAt:
                serverTimestamp()

        };
        
        
                // ----------------------------------------------------
        // PUBLIC RESTAURANT PROFILE
        // CUSTOMER WEBSITE DATA ONLY
        // ----------------------------------------------------

        const publicRestaurantReference =
            doc(
                db,
                "publicRestaurantProfiles",
                restaurantId
            );


        const publicRestaurantData = {

            restaurantId:
                restaurantId,

            name:
                data.restaurant.name,

            description:
                data.restaurant.description,

            type:
                data.restaurant.type,

            cuisine:
                data.restaurant.cuisine,

            contact: {

                email:
                    data.restaurant.email,

                whatsapp:
                    data.restaurant.whatsapp

            },

            address: {

                line1:
                    data.restaurant.address,

                city:
                    data.restaurant.city,

                state:
                    data.restaurant.state

            },

            timings: {

                opening:
                    data.restaurant.openingTime,

                closing:
                    data.restaurant.closingTime

            },

            branding: {

                logoUrl: "",

                coverUrl: ""

            },

            status:
                "active",

            createdAt:
                serverTimestamp(),

            updatedAt:
                serverTimestamp()

        };
 
 
        // ----------------------------------------------------
        // ATOMIC FIRESTORE WRITE
        // ----------------------------------------------------

        const batch =
            writeBatch(db);

        batch.set(
            userReference,
            userData
        );

        batch.set(
            restaurantReference,
            restaurantData
        );

        batch.set(
            publicRestaurantReference,
            publicRestaurantData
        );

        await batch.commit();

 
        console.log(
            "BK Registration: User + Restaurant created successfully."
        );


        console.log(
            "BK Registration: Selected Plan ID:",
            data.plan.planId
        );


        console.log(
            "BK Registration: Selected Plan:",
            data.plan.name
        );


        console.log(
            "BK Registration: Selected Plan Amount:",
            data.plan.baseAmount,
            data.plan.currency
        );


        // ----------------------------------------------------
        // LOCAL STORAGE
        // ----------------------------------------------------

        localStorage.setItem(
            "bkOwnerUid",
            createdUser.uid
        );


        localStorage.setItem(
            "bkRestaurantId",
            restaurantId
        );


        localStorage.setItem(
            "bkOwnerEmail",
            data.owner.email
        );


        // ----------------------------------------------------
        // REGISTRATION SUCCESS
        // ----------------------------------------------------

        this.showRegistrationSuccess();


    } catch (error) {

        console.error(
            "BK Registration: Account creation failed:",
            error
        );


        // ----------------------------------------------------
        // CLEANUP AUTH ACCOUNT
        // ----------------------------------------------------

        if (createdUser) {

            try {

                await deleteUser(
                    createdUser
                );


                console.log(
                    "BK Registration: Auth account cleanup completed."
                );


            } catch (cleanupError) {

                console.error(
                    "BK Registration: Auth cleanup failed:",
                    cleanupError
                );

            }

        }


        throw error;

    }

};


// ============================================================
// FINAL FIREBASE ERROR HANDLER
// ============================================================

BKRegistration.handleFirebaseError =
    function (error) {

    console.error(
        "BK Registration Error Code:",
        error?.code
    );


    let message =
        "Something went wrong. Please try again.";


    switch (
        error?.code
    ) {

        case "auth/email-already-in-use":

            message =
                "This email is already registered.";

            break;


        case "auth/invalid-email":

            message =
                "Please enter a valid email address.";

            break;


        case "auth/weak-password":

            message =
                "Your password is too weak.";

            break;


        case "auth/network-request-failed":

            message =
                "Network error. Please check your internet connection.";

            break;


        case "auth/too-many-requests":

            message =
                "Too many requests. Please wait and try again.";

            break;


        case "permission-denied":

            message =
                "Firebase permission denied. Please check Firestore security rules.";

            break;


        case "unavailable":

            message =
                "Firebase service is temporarily unavailable. Please try again.";

            break;


        default:

            if (
                error?.message &&
                String(
                    error.message
                ).toLowerCase().includes(
                    "permission"
                )
            ) {

                message =
                    "Firebase permission denied. Please check Firestore security rules.";

            }

            break;

    }


    alert(
        "BK Registration\n\n" +
        message
    );

};


// ============================================================
// FINAL STARTUP
// ============================================================

document.addEventListener(
    "DOMContentLoaded",
    function () {

        BKRegistration.init();

    }
);


// ============================================================
// GLOBAL ACCESS
// ============================================================

window.BKRegistration =
    BKRegistration;


// ============================================================
// BK REGISTRATION MODULE LOG
// ============================================================

console.log(
    "=========================================="
);

console.log(
    "BK Registration Module Loaded"
);

console.log(
    "Firebase Authentication: READY"
);

console.log(
    "Firestore Registration: READY"
);

console.log(
    "Restaurant ID Generation: READY"
);

console.log(
    "Subscription Plan Selection: READY"
);

console.log(
    "Policy Agreement: READY"
);

console.log(
    "Branding Preview: READY"
);

console.log(
    "=========================================="
);