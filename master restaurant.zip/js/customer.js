/* =========================================================
   BK CUSTOMER EXPERIENCE
   CUSTOMER JS — PART 1/6
   FOUNDATION + RESTAURANT / TABLE IDENTIFICATION
========================================================= */

"use strict";


/* =========================================================
   01. CUSTOMER APPLICATION STATE
========================================================= */

const CustomerState = {

    restaurantId: null,

    tableId: null,

    restaurant: null,

    categories: [],

    menuItems: [],

    cart: [],

    currentCategory: "all",

    searchText: "",

    activeService: null,

    isLoading: false

};


/* =========================================================
   02. CUSTOMER DOM REFERENCES
========================================================= */

const CustomerDOM = {

    app:
        document.getElementById("customerApp"),

    restaurantName:
        document.getElementById("customerRestaurantName"),

    heroRestaurantName:
        document.getElementById("customerHeroRestaurantName"),

    footerRestaurantName:
        document.getElementById("customerFooterRestaurantName"),

    restaurantDescription:
        document.getElementById("customerRestaurantDescription"),

    restaurantType:
        document.getElementById("customerRestaurantType"),

    restaurantCover:
        document.getElementById("customerRestaurantCover"),

    restaurantLogo:
        document.getElementById("customerRestaurantLogo"),

    searchButton:
        document.getElementById("customerSearchButton"),

    cartButton:
        document.getElementById("customerCartButton"),

    cartCount:
        document.getElementById("customerCartCount"),

    menuSearch:
        document.getElementById("customerMenuSearch"),

    categoryList:
        document.getElementById("customerCategoryList"),

    foodGrid:
        document.getElementById("customerFoodGrid"),

    menuEmpty:
        document.getElementById("customerMenuEmptyState"),

    loading:
        document.getElementById("customerLoading"),

    toast:
        document.getElementById("customerToast"),

    toastIcon:
        document.getElementById("customerToastIcon"),

    toastMessage:
        document.getElementById("customerToastMessage")

};


/* =========================================================
   03. READ QR / URL PARAMETERS
========================================================= */

function getCustomerParameters() {

    const params =
        new URLSearchParams(
            window.location.search
        );


    CustomerState.restaurantId =
        params.get("restaurant");


    CustomerState.tableId =
        params.get("table");


    console.log(
        "BK Customer Restaurant ID:",
        CustomerState.restaurantId
    );


    console.log(
        "BK Customer Table ID:",
        CustomerState.tableId
    );

}


/* =========================================================
   04. CHECK RESTAURANT IDENTIFICATION
========================================================= */

function validateCustomerParameters() {

    if (!CustomerState.restaurantId) {

        console.warn(
            "BK Customer: Restaurant ID missing."
        );

        showCustomerToast(
            "Restaurant information is missing.",
            "!"
        );

        return false;
    }


    if (!CustomerState.tableId) {

        console.info(
            "BK Customer: Table ID not provided."
        );

    }


    return true;

}


/* =========================================================
   05. BASIC PAGE INITIALIZATION
========================================================= */

function initializeCustomerPage() {

    console.log(
        "=========================================="
    );

    console.log(
        "BK CUSTOMER EXPERIENCE"
    );

    console.log(
        "Customer page initializing..."
    );


    getCustomerParameters();


    const valid =
        validateCustomerParameters();


    if (!valid) {

        console.warn(
            "Customer page stopped: invalid restaurant information."
        );

        return;

    }


    updateCustomerTableInformation();


    console.log(
        "Customer foundation ready."
    );

    console.log(
        "=========================================="
    );

}


/* =========================================================
   06. TABLE INFORMATION
========================================================= */

function updateCustomerTableInformation() {

    if (!CustomerState.tableId) {

        return;

    }


    document.body.dataset.restaurantId =
        CustomerState.restaurantId;


    document.body.dataset.tableId =
        CustomerState.tableId;


    console.log(
        "Customer Table:",
        CustomerState.tableId
    );

}


/* =========================================================
   07. LOADING CONTROL
========================================================= */

function showCustomerLoading() {

    CustomerState.isLoading =
        true;


    if (CustomerDOM.loading) {

        CustomerDOM.loading.hidden =
            false;

    }

}


function hideCustomerLoading() {

    CustomerState.isLoading =
        false;


    if (CustomerDOM.loading) {

        CustomerDOM.loading.hidden =
            true;

    }

}


/* =========================================================
   08. TOAST SYSTEM
========================================================= */

let customerToastTimer = null;


function showCustomerToast(
    message,
    icon = "✓"
) {

    if (
        !CustomerDOM.toast ||
        !CustomerDOM.toastMessage ||
        !CustomerDOM.toastIcon
    ) {

        return;

    }


    CustomerDOM.toastMessage.textContent =
        message;


    CustomerDOM.toastIcon.textContent =
        icon;


    CustomerDOM.toast.hidden =
        false;


    requestAnimationFrame(() => {

        CustomerDOM.toast.classList.add(
            "show"
        );

    });


    clearTimeout(
        customerToastTimer
    );


    customerToastTimer =
        setTimeout(() => {

            CustomerDOM.toast.classList.remove(
                "show"
            );


            setTimeout(() => {

                CustomerDOM.toast.hidden =
                    true;

            }, 250);


        }, 2800);

}


/* =========================================================
   09. BASIC SEARCH BUTTON
========================================================= */

function focusCustomerSearch() {

    if (!CustomerDOM.menuSearch) {

        return;

    }


    CustomerDOM.menuSearch.focus();


    CustomerDOM.menuSearch.scrollIntoView({
        behavior: "smooth",
        block: "center"
    });

}


/* =========================================================
   10. BASIC CART COUNT
========================================================= */

function updateCustomerCartCount() {

    if (!CustomerDOM.cartCount) {

        return;

    }


    const totalQuantity =
        CustomerState.cart.reduce(
            (total, item) => {

                return total +
                    Number(item.quantity || 0);

            },
            0
        );


    CustomerDOM.cartCount.textContent =
        totalQuantity;

}


/* =========================================================
   11. HEADER EVENTS
========================================================= */

function setupCustomerHeaderEvents() {

    if (CustomerDOM.searchButton) {

        CustomerDOM.searchButton.addEventListener(
            "click",
            focusCustomerSearch
        );

    }


    if (CustomerDOM.cartButton) {

        CustomerDOM.cartButton.addEventListener(
            "click",
            () => {

                showCustomerToast(
                    "Your cart will open here.",
                    "🛒"
                );

            }
        );

    }

}


/* =========================================================
   12. CUSTOMER START
========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    () => {

        setupCustomerHeaderEvents();

        initializeCustomerPage();

        updateCustomerCartCount();

    }
);


/* =========================================================
   END OF CUSTOMER JS — PART 1/6
========================================================= */
/* =========================================================
   BK CUSTOMER EXPERIENCE
   CUSTOMER JS — PART 2/6
   FIREBASE + RESTAURANT DATA
========================================================= */


/* =========================================================
   13. FIREBASE IMPORT
========================================================= */

import {
    db,
    auth
} from "./firebase.js";

import {
    doc,
    getDoc
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";


/* =========================================================
   14. LOAD RESTAURANT DATA
========================================================= */

async function loadCustomerRestaurant() {

    if (!CustomerState.restaurantId) {

        return;

    }


    try {

        showCustomerLoading();


        console.log(
            "Loading restaurant:",
            CustomerState.restaurantId
        );


        const restaurantRef =
    doc(
        db,
        "publicRestaurantProfiles",
        CustomerState.restaurantId
    );

        const restaurantSnapshot =
            await getDoc(
                restaurantRef
            );


        if (!restaurantSnapshot.exists()) {

            console.error(
                "Restaurant not found."
            );


            showCustomerToast(
                "Restaurant not found.",
                "!"
            );


            return;

        }


        CustomerState.restaurant =
            {
                id: restaurantSnapshot.id,
                ...restaurantSnapshot.data()
            };


        console.log(
            "Restaurant loaded:",
            CustomerState.restaurant
        );


        renderCustomerRestaurant();


    } catch (error) {

        console.error(
            "Customer restaurant loading error:",
            error
        );


        showCustomerToast(
            "Unable to load restaurant.",
            "!"
        );


    } finally {

        hideCustomerLoading();

    }

}


/* =========================================================
   15. RENDER RESTAURANT INFORMATION
========================================================= */

function renderCustomerRestaurant() {

    const restaurant =
        CustomerState.restaurant;


    if (!restaurant) {

        return;

    }


    const restaurantName =
        restaurant.name ||
        "BK Restaurant";


    const description =
        restaurant.description ||
        "Good Food • Great Vibes • Always";


    const type =
        restaurant.type ||
        "RESTAURANT";


    if (CustomerDOM.restaurantName) {

        CustomerDOM.restaurantName.textContent =
            restaurantName;

    }


    if (CustomerDOM.heroRestaurantName) {

        CustomerDOM.heroRestaurantName.textContent =
            restaurantName;

    }


    if (CustomerDOM.footerRestaurantName) {

        CustomerDOM.footerRestaurantName.textContent =
            restaurantName;

    }


    if (CustomerDOM.restaurantDescription) {

        CustomerDOM.restaurantDescription.textContent =
            description;

    }


    if (CustomerDOM.restaurantType) {

        CustomerDOM.restaurantType.textContent =
            String(type).toUpperCase();

    }


    renderCustomerBranding();

}


/* =========================================================
   16. RESTAURANT BRANDING
========================================================= */

function renderCustomerBranding() {

    const restaurant =
        CustomerState.restaurant;


    if (!restaurant) {

        return;

    }


    const branding =
        restaurant.branding ||
        {};


    const logoUrl =
        branding.logo ||
        restaurant.logo ||
        "";


    const coverUrl =
        branding.cover ||
        restaurant.cover ||
        "";


    if (
        CustomerDOM.restaurantLogo &&
        logoUrl
    ) {

        CustomerDOM.restaurantLogo.src =
            logoUrl;


        CustomerDOM.restaurantLogo.style.display =
            "block";

    }


    if (
        CustomerDOM.restaurantCover &&
        coverUrl
    ) {

        CustomerDOM.restaurantCover.src =
            coverUrl;


        CustomerDOM.restaurantCover.style.display =
            "block";

    }


    setupCustomerBrandingFallbacks();

}


/* =========================================================
   17. BRANDING IMAGE FALLBACK
========================================================= */

function setupCustomerBrandingFallbacks() {

    if (CustomerDOM.restaurantLogo) {

        CustomerDOM.restaurantLogo.onerror =
            () => {

                CustomerDOM.restaurantLogo.style.display =
                    "none";

            };

    }


    if (CustomerDOM.restaurantCover) {

        CustomerDOM.restaurantCover.onerror =
            () => {

                CustomerDOM.restaurantCover.style.display =
                    "none";

            };

    }

}


/* =========================================================
   18. CUSTOMER RESTAURANT LOAD START
========================================================= */

async function startCustomerRestaurantLoad() {

    if (
        !CustomerState.restaurantId
    ) {

        return;

    }


    await loadCustomerRestaurant();

}


/* =========================================================
   19. START RESTAURANT LOADING
========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    () => {

        startCustomerRestaurantLoad();

    }
);


/* =========================================================
   END OF CUSTOMER JS — PART 2/6
========================================================= */
/* =========================================================
   BK CUSTOMER EXPERIENCE
   CUSTOMER JS — PART 3/6
   CATEGORIES + MENU ITEMS
========================================================= */


/* =========================================================
   20. FIRESTORE QUERY IMPORTS
========================================================= */

import {
    addDoc,
    collection,
    getDocs,
    query,
    where,
    orderBy,
    runTransaction,
    serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";

/* =========================================================
   21. LOAD MENU CATEGORIES
========================================================= */

async function loadCustomerCategories() {

    if (!CustomerState.restaurantId) {

        return;

    }


    try {

        const categoriesRef =
            collection(
                db,
                "restaurants",
                CustomerState.restaurantId,
                "menuCategories"
            );


        const categoriesQuery =
            query(
                categoriesRef,
                where("isActive", "==", true),
                orderBy("name", "asc")
            );


        const snapshot =
            await getDocs(
                categoriesQuery
            );


        CustomerState.categories = [];


        snapshot.forEach((categoryDoc) => {

            CustomerState.categories.push({

                id: categoryDoc.id,

                ...categoryDoc.data()

            });

        });


        console.log(
            "Customer categories loaded:",
            CustomerState.categories
        );


        renderCustomerCategories();

    } catch (error) {

        console.error(
            "Category loading error:",
            error
        );


        showCustomerToast(
            "Unable to load categories.",
            "!"
        );

    }

}


/* =========================================================
   22. RENDER CATEGORY BUTTONS
========================================================= */

function renderCustomerCategories() {

    if (!CustomerDOM.categoryList) {

        return;

    }


    CustomerDOM.categoryList.innerHTML = "";


    const allButton =
        document.createElement("button");


    allButton.type =
        "button";


    allButton.className =
        "customer-category-button active";


    allButton.dataset.category =
        "all";


    allButton.textContent =
        "All";


    CustomerDOM.categoryList.appendChild(
        allButton
    );


    CustomerState.categories.forEach(
        (category) => {

            const button =
                document.createElement("button");


            button.type =
                "button";


            button.className =
                "customer-category-button";


            button.dataset.category =
                category.id;


            button.textContent =
                category.name ||
                "Category";


            CustomerDOM.categoryList.appendChild(
                button
            );

        }
    );


    setupCustomerCategoryEvents();

}


/* =========================================================
   23. CATEGORY EVENTS
========================================================= */

function setupCustomerCategoryEvents() {

    const buttons =
        CustomerDOM.categoryList.querySelectorAll(
            ".customer-category-button"
        );


    buttons.forEach((button) => {

        button.addEventListener(
            "click",
            () => {

                buttons.forEach(
                    (item) => {

                        item.classList.remove(
                            "active"
                        );

                    }
                );


                button.classList.add(
                    "active"
                );


                CustomerState.currentCategory =
                    button.dataset.category ||
                    "all";


                renderCustomerFoodItems();

            }
        );

    });

}


/* =========================================================
   24. LOAD MENU ITEMS
========================================================= */

async function loadCustomerMenuItems() {

    if (!CustomerState.restaurantId) {

        return;

    }


    try {

        const menuItemsRef =
            collection(
                db,
                "restaurants",
                CustomerState.restaurantId,
                "menuItems"
            );


        const menuItemsQuery =
            query(
                menuItemsRef,
                where("isAvailable", "==", true),
                orderBy("name", "asc")
            );


        const snapshot =
            await getDocs(
                menuItemsQuery
            );


        CustomerState.menuItems = [];


        snapshot.forEach((itemDoc) => {

            const data =
                itemDoc.data();


            CustomerState.menuItems.push({

                id: itemDoc.id,

                ...data

            });

        });


        console.log(
            "Customer menu items loaded:",
            CustomerState.menuItems
        );


        renderCustomerFoodItems();

    } catch (error) {

        console.error(
            "Menu item loading error:",
            error
        );


        showCustomerToast(
            "Unable to load menu.",
            "!"
        );

    }

}


/* =========================================================
   25. FILTER CUSTOMER FOOD ITEMS
========================================================= */

function getFilteredCustomerFoodItems() {

    let items =
        [...CustomerState.menuItems];


    if (
        CustomerState.currentCategory !==
        "all"
    ) {

        items =
            items.filter(
                (item) => {

                    return (
                        item.categoryId ===
                        CustomerState.currentCategory
                    );

                }
            );

    }


    const search =
        CustomerState.searchText
            .trim()
            .toLowerCase();


    if (search) {

        items =
            items.filter(
                (item) => {

                    const name =
                        String(
                            item.name || ""
                        ).toLowerCase();


                    const description =
                        String(
                            item.description || ""
                        ).toLowerCase();


                    const category =
                        String(
                            item.categoryName || ""
                        ).toLowerCase();


                    return (
                        name.includes(search) ||
                        description.includes(search) ||
                        category.includes(search)
                    );

                }
            );

    }


    return items;

}

/* =========================================================
   BK CUSTOMER FOOD VISUAL RESOLVER
   SAME IMAGE SYSTEM AS OWNER DASHBOARD
========================================================= */

async function resolveCustomerFoodVisual(item) {

    const manualImageUrl =
        String(item?.imageUrl || "").trim();

    /* -----------------------------------------------------
       1. MANUAL IMAGE URL
    ----------------------------------------------------- */

    if (manualImageUrl) {

        return {
            status: "manual",
            imageUrl: manualImageUrl
        };

    }


    /* -----------------------------------------------------
       2. BK FOOD IMAGE DATABASE RESOLVER
    ----------------------------------------------------- */

    if (
        window.BKFoodImageResolver &&
        typeof window.BKFoodImageResolver.resolve === "function"
    ) {

        try {

            const result =
                await window.BKFoodImageResolver.resolve(
                    item?.name || ""
                );


            if (
                result &&
                result.status === "matched" &&
                result.imageUrl
            ) {

                return {
                    status: "resolver",
                    imageUrl: result.imageUrl
                };

            }

        } catch (error) {

            console.warn(
                "BK Customer Food Resolver Error:",
                error
            );

        }

    }


    /* -----------------------------------------------------
       3. FINAL PREMIUM FALLBACK
    ----------------------------------------------------- */

    return {
        status: "fallback",
        imageUrl: null
    };

}

/* =========================================================
   26. RENDER CUSTOMER FOOD GRID
========================================================= */

async function renderCustomerFoodItems(){

    if(!CustomerDOM.foodGrid) return;

    CustomerDOM.foodGrid.innerHTML = "";

    const items = getFilteredCustomerFoodItems();

    if(!items.length){

        if(CustomerDOM.menuEmpty){
            CustomerDOM.menuEmpty.hidden = false;
        }

        return;
    }

    if(CustomerDOM.menuEmpty){
        CustomerDOM.menuEmpty.hidden = true;
    }


    /* -----------------------------------------------------
       RESOLVE ALL FOOD VISUALS
    ----------------------------------------------------- */

    const resolvedItems =
        await Promise.all(

            items.map(
                async (item) => {

                    const visual =
                        await resolveCustomerFoodVisual(item);

                    return {
                        item,
                        visual
                    };

                }
            )

        );


    /* -----------------------------------------------------
       CREATE CUSTOMER CARDS
    ----------------------------------------------------- */

    resolvedItems.forEach(
        ({ item, visual }) => {

            const card =
                createCustomerFoodCard(
                    item,
                    visual
                );

            CustomerDOM.foodGrid.appendChild(card);

        }
    );
    setupCustomerFoodImageFallbacks();

}
/* =========================================================
   27. CREATE CUSTOMER FOOD CARD
   BK PREMIUM DESIGN #7
========================================================= */

function createCustomerFoodCard(item, visual = null) {

    const card =
        document.createElement("article");

    card.className =
        "customer-food-card";

    card.dataset.itemId =
        item.id;


    const imageUrl =
        String(
            visual?.imageUrl ||
            ""
        ).trim();


    const name =
        item.name ||
        "Signature Dish";


    const description =
        item.description ||
        "Deliciously prepared for you.";


    const category =
        item.categoryName ||
        "SIGNATURE";


    const price =
        Number(
            item.price || 0
        );


    const fallbackHTML = `

        <div
            class="customer-food-fallback"
            data-customer-card-fallback
        >

            <div class="customer-fallback-scene">

                <div class="customer-fallback-glow"></div>

                <div class="customer-fallback-table"></div>


                <!-- BK ROYAL BRANDING -->
                <div class="customer-fallback-brand">

                    <div class="customer-fallback-crown">
                        ♛
                    </div>

                    <div class="customer-fallback-badge">
                        <span>BK</span>
                    </div>

                    <div class="customer-fallback-selection">
                        PREMIUM SELECTION
                    </div>

                </div>


                <!-- MAIN MESSAGE -->
                <div class="customer-fallback-message">

                    <div class="customer-fallback-script">
                        Delicious
                    </div>

                    <strong>
                        Food Awaits
                    </strong>

                    <span>
                        PREMIUM TASTE ALWAYS
                    </span>

                </div>


                <!-- CHEF LABEL -->
                <div class="customer-fallback-food">

                    <div class="customer-fallback-food-label">
                        CHEF'S SPECIAL
                    </div>

                </div>


                <!-- FALLBACK BADGE -->
                <div class="customer-fallback-tag">
                    FALLBACK IMAGE
                </div>

            </div>

        </div>

    `;


    card.innerHTML = `

        <div class="customer-food-card-image">

            ${
                imageUrl

                ?

                `
                <img
                    src="${escapeCustomerHTML(imageUrl)}"
                    alt="${escapeCustomerHTML(name)}"
                    loading="lazy"
                    data-customer-item-image
                >

                <div class="customer-food-image-overlay">

                    <span class="customer-food-premium-badge">
                        ✦ PREMIUM
                    </span>

                </div>
                `

                :

                fallbackHTML
            }

        </div>


        <div class="customer-food-card-content">

            <span class="customer-food-card-category">
                ${escapeCustomerHTML(category)}
            </span>


            <h3 class="customer-food-card-name">
                ${escapeCustomerHTML(name)}
            </h3>


            <p class="customer-food-card-description">
                ${escapeCustomerHTML(description)}
            </p>


            <div class="customer-food-card-bottom">

                <strong class="customer-food-card-price">
                    ₹${formatCustomerPrice(price)}
                </strong>


                <button
                    type="button"
                    class="customer-add-cart-button"
                    data-add-food="${escapeCustomerHTML(item.id)}"
                    aria-label="Order ${escapeCustomerHTML(name)}"
                >
                    ORDER NOW
                </button>

            </div>


            <div class="customer-food-card-tagline">
                Good Food • Great Moments
            </div>

        </div>

    `;


    setupCustomerFoodCardEvents(
        card,
        item
    );


    return card;
}


/* =========================================================
   28. FOOD CARD EVENTS
========================================================= */

function setupCustomerFoodCardEvents(card, item) {

    const addButton =
        card.querySelector("[data-add-food]");

    if (addButton) {

        addButton.addEventListener("click", (event) => {

            event.stopPropagation();

            /*
             * ORDER NOW
             * Directly opens the premium checkout popup.
             */

            openCustomerCheckout(item);

        });

    }


    card.addEventListener("click", (event) => {

        if (
            event.target.closest("[data-add-food]")
        ) {
            return;
        }


        openCustomerFoodDetail(item);

    });

}

/* =========================================================
   29. CUSTOMER FOOD DETAIL FOUNDATION
========================================================= */

function openCustomerFoodDetail(item) {

    if (!item) {

        return;

    }


    console.log(
        "Customer food selected:",
        item
    );


    showCustomerToast(
        `${item.name || "Dish"} selected.`,
        "✦"
    );

}


/* =========================================================
   30. CUSTOMER HTML ESCAPE
========================================================= */

function escapeCustomerHTML(value) {

    return String(value)
        .replace(
            /&/g,
            "&amp;"
        )
        .replace(
            /</g,
            "&lt;"
        )
        .replace(
            />/g,
            "&gt;"
        )
        .replace(
            /"/g,
            "&quot;"
        )
        .replace(
            /'/g,
            "&#039;"
        );

}


/* =========================================================
   31. CUSTOMER PRICE FORMAT
========================================================= */

function formatCustomerPrice(
    value
) {

    const number =
        Number(value || 0);


    return number.toLocaleString(
        "en-IN",
        {
            maximumFractionDigits: 2
        }
    );

}


/* =========================================================
   32. LOAD CUSTOMER MENU
========================================================= */

async function startCustomerMenuLoad() {

    if (!CustomerState.restaurantId) {

        return;

    }


    await loadCustomerCategories();

    await loadCustomerMenuItems();

}


/* =========================================================
   33. START MENU LOADING
========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    () => {

        startCustomerMenuLoad();

    }
);


/* =========================================================
   END OF CUSTOMER JS — PART 3/6
========================================================= */
/* =========================================================
   BK CUSTOMER EXPERIENCE
   CUSTOMER JS — PART 4/6
   SEARCH + FOOD DETAIL + PREMIUM FALLBACK
========================================================= */


/* =========================================================
   34. FOOD DETAIL DOM REFERENCES
========================================================= */

const CustomerFoodDetailDOM = {

    modal:
        document.getElementById("foodDetailModal"),

    closeButton:
        document.getElementById("closeFoodDetailButton"),

    image:
        document.getElementById("foodDetailImage"),

    category:
        document.getElementById("foodDetailCategory"),

    name:
        document.getElementById("foodDetailName"),

    description:
        document.getElementById("foodDetailDescription"),

    price:
        document.getElementById("foodDetailPrice"),

    addButton:
        document.getElementById("foodDetailAddButton")

};


/* =========================================================
   35. CURRENT FOOD DETAIL ITEM
========================================================= */

let currentCustomerFoodItem = null;


/* =========================================================
   36. CUSTOMER MENU SEARCH
========================================================= */

function setupCustomerMenuSearch() {

    if (!CustomerDOM.menuSearch) {

        return;

    }


    CustomerDOM.menuSearch.addEventListener(
        "input",
        () => {

            CustomerState.searchText =
                CustomerDOM.menuSearch.value || "";


            renderCustomerFoodItems();

        }
    );

}


/* =========================================================
   37. OPEN FOOD DETAIL MODAL
========================================================= */

async function openCustomerFoodDetailModal(item){

    if (
        !item ||
        !CustomerFoodDetailDOM.modal
    ) {

        return;

    }


    currentCustomerFoodItem =
        item;


    const name =
        item.name ||
        "Signature Dish";


    const description =
        item.description ||
        "Deliciously prepared for you.";


    const category =
        item.categoryName ||
        "SIGNATURE";


    const price =
        Number(item.price || 0);


    const visual =
    await resolveCustomerFoodVisual(item);

const imageUrl =
    String(
        visual?.imageUrl || ""
    ).trim();


    if (CustomerFoodDetailDOM.name) {

        CustomerFoodDetailDOM.name.textContent =
            name;

    }


    if (CustomerFoodDetailDOM.description) {

        CustomerFoodDetailDOM.description.textContent =
            description;

    }


    if (CustomerFoodDetailDOM.category) {

        CustomerFoodDetailDOM.category.textContent =
            String(category).toUpperCase();

    }


    if (CustomerFoodDetailDOM.price) {

        CustomerFoodDetailDOM.price.textContent =
            `₹${formatCustomerPrice(price)}`;

    }


    if (CustomerFoodDetailDOM.image) {

        if (imageUrl) {

            CustomerFoodDetailDOM.image.src =
                imageUrl;

            CustomerFoodDetailDOM.image.alt =
                name;

            CustomerFoodDetailDOM.image.style.display =
                "block";


            setupCustomerDetailImageFallback(
                item
            );

        } else {

            showCustomerDetailFallback(
                item
            );

        }

    }


    CustomerFoodDetailDOM.modal.hidden =
        false;


    document.body.classList.add(
        "customer-modal-open"
    );


    requestAnimationFrame(() => {

        CustomerFoodDetailDOM.modal.classList.add(
            "active"
        );

    });

}


/* =========================================================
   38. DETAIL IMAGE FALLBACK
========================================================= */

function setupCustomerDetailImageFallback(item) {

    if (!CustomerFoodDetailDOM.image) {

        return;

    }


    CustomerFoodDetailDOM.image.onerror =
        () => {

            showCustomerDetailFallback(
                item
            );

        };

}


/* =========================================================
   39. PREMIUM #7 DETAIL FALLBACK
   ROYAL GOLDEN TABLE
========================================================= */

function showCustomerDetailFallback(item) {

    if (!CustomerFoodDetailDOM.image) {
        return;
    }


    const imageBox =
        CustomerFoodDetailDOM.image.parentElement;


    if (!imageBox) {
        return;
    }


    CustomerFoodDetailDOM.image.style.display =
        "none";


    let fallback =
        imageBox.querySelector(
            "[data-customer-detail-fallback]"
        );


    if (!fallback) {

        fallback =
            document.createElement("div");


        fallback.dataset.customerDetailFallback =
            "true";


        fallback.className =
            "customer-food-fallback";


        imageBox.appendChild(
            fallback
        );

    }


    fallback.innerHTML = `

        <div class="customer-fallback-scene">

            <div class="customer-fallback-glow"></div>

            <div class="customer-fallback-table"></div>


            <!-- BK ROYAL BRANDING -->

            <div class="customer-fallback-brand">

                <div class="customer-fallback-crown">
                    ♛
                </div>

                <div class="customer-fallback-badge">
                    <span>BK</span>
                </div>

                <div class="customer-fallback-selection">
                    PREMIUM SELECTION
                </div>

            </div>


            <!-- MAIN MESSAGE -->

            <div class="customer-fallback-message">

                <div class="customer-fallback-script">
                    Delicious
                </div>

                <strong>
                    Food Awaits
                </strong>

                <span>
                    PREMIUM TASTE ALWAYS
                </span>

            </div>


            <!-- CHEF LABEL -->

            <div class="customer-fallback-food">

                <div class="customer-fallback-food-label">
                    CHEF'S SPECIAL
                </div>

            </div>


            <!-- FALLBACK BADGE -->

            <div class="customer-fallback-tag">
                FALLBACK IMAGE
            </div>

        </div>

    `;


    fallback.style.display =
        "block";

}

/* =========================================================
   40. CLOSE FOOD DETAIL MODAL
========================================================= */

function closeCustomerFoodDetailModal() {

    if (!CustomerFoodDetailDOM.modal) {

        return;

    }


    CustomerFoodDetailDOM.modal.classList.remove(
        "active"
    );


    setTimeout(() => {

        CustomerFoodDetailDOM.modal.hidden =
            true;


        document.body.classList.remove(
            "customer-modal-open"
        );


    }, 200);


    currentCustomerFoodItem =
        null;

}


/* =========================================================
   41. DETAIL MODAL EVENTS
========================================================= */

function setupCustomerFoodDetailEvents() {

    if (CustomerFoodDetailDOM.closeButton) {

        CustomerFoodDetailDOM.closeButton.addEventListener(
            "click",
            closeCustomerFoodDetailModal
        );

    }


    if (CustomerFoodDetailDOM.modal) {

        const backdrop =
            CustomerFoodDetailDOM.modal.querySelector(
                ".customer-modal-backdrop"
            );


        if (backdrop) {

            backdrop.addEventListener(
                "click",
                closeCustomerFoodDetailModal
            );

        }

    }


    document.addEventListener(
        "keydown",
        (event) => {

            if (
                event.key === "Escape" &&
                currentCustomerFoodItem
            ) {

                closeCustomerFoodDetailModal();

            }

        }
    );


    if (CustomerFoodDetailDOM.addButton) {

        CustomerFoodDetailDOM.addButton.addEventListener(
            "click",
            () => {

                if (
                    !currentCustomerFoodItem
                ) {

                    return;

                }


                addCustomerFoodToCartFoundation(
                    currentCustomerFoodItem
                );

            }
        );

    }

}


/* =========================================================
   42. ADD FOOD TO CART FOUNDATION
========================================================= */

async function addCustomerFoodToCartFoundation(item){

    if (!item) {

        return;

    }

const visual =
    await resolveCustomerFoodVisual(item);

const resolvedImageUrl =
    String(
        visual?.imageUrl || ""
    ).trim();
    
    const existingItem =
        CustomerState.cart.find(
            (cartItem) => {

                return cartItem.id === item.id;

            }
        );


    if (existingItem) {

        existingItem.quantity += 1;

    } else {

        CustomerState.cart.push({

            id: item.id,

            name: item.name ||
                "Signature Dish",

            description:
                item.description || "",

            price:
                Number(item.price || 0),

            categoryId:
                item.categoryId || "",

            categoryName:
                item.categoryName || "",

            imageUrl: resolvedImageUrl,

            quantity: 1

        });

    }


    updateCustomerCartCount();


    showCustomerToast(
        `${item.name || "Item"} added to cart.`,
        "✓"
    );


    closeCustomerFoodDetailModal();

}


/* =========================================================
   43. CUSTOMER FOOD CARD IMAGE ERRORS
========================================================= */

function setupCustomerFoodImageFallbacks(){

    if(!CustomerDOM.foodGrid) return;


    const images =
        CustomerDOM.foodGrid.querySelectorAll(
            ".customer-food-card-image img[data-customer-item-image]"
        );


    images.forEach(
        (image) => {

            image.addEventListener(
                "error",
                () => {

                    const card =
                        image.closest(
                            ".customer-food-card"
                        );


                    if(!card) return;


                    const itemId =
                        card.dataset.itemId;


                    const item =
                        CustomerState.menuItems.find(
                            menuItem =>
                                menuItem.id === itemId
                        );


                    if(!item) return;


                    image.style.display =
                        "none";


                    let fallback =
                        card.querySelector(
                            "[data-customer-card-fallback]"
                        );


                    if(!fallback){

                        fallback =
                            document.createElement(
                                "div"
                            );

                        fallback.dataset.customerCardFallback =
                            "true";

                        fallback.className =
                            "customer-food-fallback";


                        image.parentElement.appendChild(
                            fallback
                        );

                    }


                    fallback.innerHTML = `

                        <div class="customer-food-fallback-inner">

                            <div
                                class="customer-food-fallback-crown"
                                aria-hidden="true"
                            >
                                ♛
                            </div>

                            <div class="customer-food-fallback-mark">
                                BK
                            </div>

                            <span>
                                PREMIUM SELECTION
                            </span>

                            <strong>
                                ${escapeCustomerHTML(
                                    item.name ||
                                    "Signature Dish"
                                )}
                            </strong>

                            <small>
                                ₹${formatCustomerPrice(
                                    item.price || 0
                                )}
                            </small>

                        </div>

                    `;


                    fallback.style.display =
                        "flex";

                }
            );

        }
    );

}
/* =========================================================
   44. UPDATE FOOD GRID RENDER WITH IMAGE FALLBACK
========================================================= */



/* =========================================================
   45. REPLACE FOOD CARD DETAIL ACTION
========================================================= */

const originalCustomerDetailFunction =
    openCustomerFoodDetail;


openCustomerFoodDetail =
    function (item) {

        openCustomerFoodDetailModal(
            item
        );

    };


/* =========================================================
   46. CUSTOMER FOOD EXPERIENCE START
========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    () => {

        setupCustomerMenuSearch();

        setupCustomerFoodDetailEvents();

    }
);


/* =========================================================
   END OF CUSTOMER JS — PART 4/6
========================================================= */
/* =========================================================
   BK CUSTOMER EXPERIENCE
   CUSTOMER JS — PART 5/6
   COMPLETE CART SYSTEM
========================================================= */


/* =========================================================
   47. CUSTOMER CART DOM
========================================================= */

const CustomerCartDOM = {

    modal: null,

    content: null,

    total: null,

    closeButton: null,

    checkoutButton: null

};


/* =========================================================
   48. CREATE CART MODAL
========================================================= */

function createCustomerCartModal() {

    if (
        document.getElementById(
            "customerCartModal"
        )
    ) {

        return;

    }


    const modal =
        document.createElement("div");


    modal.className =
        "customer-modal";


    modal.id =
        "customerCartModal";


    modal.hidden =
        true;


    modal.innerHTML = `

        <div
            class="customer-modal-backdrop"
            data-close-cart
        ></div>


        <div
            class="customer-modal-card customer-cart-modal-card"
            role="dialog"
            aria-modal="true"
            aria-labelledby="customerCartTitle"
        >

            <button
                type="button"
                class="customer-modal-close"
                id="closeCustomerCartButton"
                aria-label="Close cart"
            >
                ×
            </button>


            <div class="customer-modal-icon">
                🛒
            </div>


            <p class="customer-modal-eyebrow">
                YOUR SELECTION
            </p>


            <h2 id="customerCartTitle">
                Your Cart
            </h2>


            <div
                id="customerCartContent"
                class="customer-cart-content"
            ></div>


            <div
                class="customer-cart-summary"
                id="customerCartSummary"
            >

                <div
                    class="customer-cart-total-row"
                >

                    <span>
                        Total
                    </span>

                    <strong
                        id="customerCartTotal"
                    >
                        ₹0
                    </strong>

                </div>


                <button
                    type="button"
                    class="customer-primary-button"
                    id="customerCartCheckoutButton"
                >
                    Continue to Checkout
                </button>

            </div>

        </div>

    `;


    document.body.appendChild(
        modal
    );


    CustomerCartDOM.modal =
        modal;


    CustomerCartDOM.content =
        document.getElementById(
            "customerCartContent"
        );


    CustomerCartDOM.total =
        document.getElementById(
            "customerCartTotal"
        );


    CustomerCartDOM.closeButton =
        document.getElementById(
            "closeCustomerCartButton"
        );


    CustomerCartDOM.checkoutButton =
        document.getElementById(
            "customerCartCheckoutButton"
        );


    setupCustomerCartEvents();


    renderCustomerCart();

}


/* =========================================================
   49. OPEN CART
========================================================= */

function openCustomerCart() {

    if (!CustomerCartDOM.modal) {

        createCustomerCartModal();

    }


    renderCustomerCart();


    CustomerCartDOM.modal.hidden =
        false;


    document.body.classList.add(
        "customer-modal-open"
    );


    requestAnimationFrame(() => {

        CustomerCartDOM.modal.classList.add(
            "active"
        );

    });

}


/* =========================================================
   50. CLOSE CART
========================================================= */

function closeCustomerCart() {

    if (!CustomerCartDOM.modal) {

        return;

    }


    CustomerCartDOM.modal.classList.remove(
        "active"
    );


    setTimeout(() => {

        CustomerCartDOM.modal.hidden =
            true;


        document.body.classList.remove(
            "customer-modal-open"
        );

    }, 200);

}


/* =========================================================
   51. RENDER CART
========================================================= */

function renderCustomerCart() {

    if (
        !CustomerCartDOM.content
    ) {

        return;

    }


    if (
        !CustomerState.cart.length
    ) {

        CustomerCartDOM.content.innerHTML = `

            <div class="customer-cart-empty">

                <div class="customer-empty-icon">
                    🛒
                </div>

                <h3>
                    Your cart is empty
                </h3>

                <p>
                    Discover something delicious
                    and add it to your selection.
                </p>

                <button
                    type="button"
                    class="customer-primary-button"
                    id="customerEmptyCartMenuButton"
                >
                    Explore Menu
                </button>

            </div>

        `;


        if (CustomerCartDOM.total) {

            CustomerCartDOM.total.textContent =
                "₹0";

        }


        if (
            CustomerCartDOM.checkoutButton
        ) {

            CustomerCartDOM.checkoutButton.disabled =
                true;

        }


        const menuButton =
            document.getElementById(
                "customerEmptyCartMenuButton"
            );


        if (menuButton) {

            menuButton.addEventListener(
                "click",
                () => {

                    closeCustomerCart();


                    if (CustomerDOM.foodGrid) {

                        CustomerDOM.foodGrid.scrollIntoView({
                            behavior: "smooth",
                            block: "start"
                        });

                    }

                }
            );

        }


        return;

    }


    if (
        CustomerCartDOM.checkoutButton
    ) {

        CustomerCartDOM.checkoutButton.disabled =
            false;

    }


    CustomerCartDOM.content.innerHTML =
        "";


    CustomerState.cart.forEach(
        (item) => {

            const cartItem =
                createCustomerCartItem(
                    item
                );


            CustomerCartDOM.content.appendChild(
                cartItem
            );

        }
    );


    updateCustomerCartTotal();

}


/* =========================================================
   52. CREATE CART ITEM
========================================================= */

function createCustomerCartItem(item) {

    const wrapper =
        document.createElement("div");


    wrapper.className =
        "customer-cart-item";


    wrapper.dataset.itemId =
        item.id;


    const imageUrl =
        String(
            item.imageUrl || ""
        ).trim();


    const imageHTML =
        imageUrl

            ? `
                <img
                    src="${escapeCustomerHTML(
                        imageUrl
                    )}"
                    alt="${escapeCustomerHTML(
                        item.name
                    )}"
                >
              `

            : `
                <div
                    class="customer-cart-item-fallback"
                >
                    BK
                </div>
              `;


    wrapper.innerHTML = `

        <div
            class="customer-cart-item-image"
        >
            ${imageHTML}
        </div>


        <div
            class="customer-cart-item-info"
        >

            <span>
                ${escapeCustomerHTML(
                    item.categoryName ||
                    "SIGNATURE"
                )}
            </span>


            <h3>
                ${escapeCustomerHTML(
                    item.name ||
                    "Signature Dish"
                )}
            </h3>


            <strong>
                ₹${formatCustomerPrice(
                    item.price
                )}
            </strong>


            <div
                class="customer-cart-quantity"
            >

                <button
                    type="button"
                    data-cart-minus
                    aria-label="Decrease quantity"
                >
                    −
                </button>


                <span>
                    ${item.quantity}
                </span>


                <button
                    type="button"
                    data-cart-plus
                    aria-label="Increase quantity"
                >
                    +
                </button>

            </div>


            <button
                type="button"
                class="customer-cart-remove"
                data-cart-remove
            >
                Remove
            </button>

        </div>

    `;


    setupCustomerCartItemEvents(
        wrapper,
        item
    );


    return wrapper;

}


/* =========================================================
   53. CART ITEM EVENTS
========================================================= */

function setupCustomerCartItemEvents(
    wrapper,
    item
) {

    const plusButton =
        wrapper.querySelector(
            "[data-cart-plus]"
        );


    const minusButton =
        wrapper.querySelector(
            "[data-cart-minus]"
        );


    const removeButton =
        wrapper.querySelector(
            "[data-cart-remove]"
        );


    if (plusButton) {

        plusButton.addEventListener(
            "click",
            () => {

                changeCustomerCartQuantity(
                    item.id,
                    1
                );

            }
        );

    }


    if (minusButton) {

        minusButton.addEventListener(
            "click",
            () => {

                changeCustomerCartQuantity(
                    item.id,
                    -1
                );

            }
        );

    }


    if (removeButton) {

        removeButton.addEventListener(
            "click",
            () => {

                removeCustomerCartItem(
                    item.id
                );

            }
        );

    }

}


/* =========================================================
   54. CHANGE CART QUANTITY
========================================================= */

function changeCustomerCartQuantity(
    itemId,
    change
) {

    const item =
        CustomerState.cart.find(
            (cartItem) => {

                return cartItem.id ===
                    itemId;

            }
        );


    if (!item) {

        return;

    }


    item.quantity +=
        Number(change);


    if (item.quantity <= 0) {

        CustomerState.cart =
            CustomerState.cart.filter(
                (cartItem) => {

                    return cartItem.id !==
                        itemId;

                }
            );

    }


    updateCustomerCartCount();

    renderCustomerCart();

}


/* =========================================================
   55. REMOVE CART ITEM
========================================================= */

function removeCustomerCartItem(
    itemId
) {

    const item =
        CustomerState.cart.find(
            (cartItem) => {

                return cartItem.id ===
                    itemId;

            }
        );


    CustomerState.cart =
        CustomerState.cart.filter(
            (cartItem) => {

                return cartItem.id !==
                    itemId;

            }
        );


    updateCustomerCartCount();

    renderCustomerCart();


    if (item) {

        showCustomerToast(
            `${item.name || "Item"} removed.`,
            "×"
        );

    }

}


/* =========================================================
   56. CART TOTAL
========================================================= */

function calculateCustomerCartTotal() {

    return CustomerState.cart.reduce(
        (total, item) => {

            return total +
                (
                    Number(item.price || 0) *
                    Number(item.quantity || 0)
                );

        },
        0
    );

}


/* =========================================================
   57. UPDATE CART TOTAL
========================================================= */

function updateCustomerCartTotal() {

    if (!CustomerCartDOM.total) {

        return;

    }


    const total =
        calculateCustomerCartTotal();


    CustomerCartDOM.total.textContent =
        `₹${formatCustomerPrice(total)}`;

}


/* =========================================================
   58. CART EVENTS
========================================================= */

function setupCustomerCartEvents() {

    if (CustomerCartDOM.closeButton) {

        CustomerCartDOM.closeButton.addEventListener(
            "click",
            closeCustomerCart
        );

    }


    if (CustomerCartDOM.modal) {

        const backdrop =
            CustomerCartDOM.modal.querySelector(
                "[data-close-cart]"
            );


        if (backdrop) {

            backdrop.addEventListener(
                "click",
                closeCustomerCart
            );

        }

    }


    if (
        CustomerCartDOM.checkoutButton
    ) {

        CustomerCartDOM.checkoutButton.addEventListener(
            "click",
            openCustomerCheckoutFoundation
        );

    }

}


/* =========================================================
   59. CONNECT HEADER CART BUTTON
========================================================= */

function setupCustomerCartHeaderButton() {

    if (!CustomerDOM.cartButton) {

        return;

    }


    CustomerDOM.cartButton.onclick =
        () => {

            openCustomerCart();

        };

}


/* =========================================================
   60. CART KEYBOARD CONTROL
========================================================= */

document.addEventListener(
    "keydown",
    (event) => {

        if (
            event.key === "Escape" &&
            CustomerCartDOM.modal &&
            !CustomerCartDOM.modal.hidden
        ) {

            closeCustomerCart();

        }

    }
);


/* =========================================================
   61. CHECKOUT FOUNDATION
========================================================= */

function openCustomerCheckoutFoundation() {

    if (
        !CustomerState.cart.length
    ) {

        showCustomerToast(
            "Your cart is empty.",
            "!"
        );

        return;

    }


    const total =
        calculateCustomerCartTotal();


    console.log(
        "Customer checkout foundation:",
        {
            restaurantId:
                CustomerState.restaurantId,

            tableId:
                CustomerState.tableId,

            items:
                CustomerState.cart,

            total:
                total
        }
    );


    showCustomerToast(
        "Checkout will open next.",
        "✓"
    );

}


/* =========================================================
   62. CART SYSTEM START
========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    () => {

        createCustomerCartModal();

        setupCustomerCartHeaderButton();

        updateCustomerCartCount();

    }
);


/* =========================================================
   END OF CUSTOMER JS — PART 5/6
========================================================= */
/* =========================================================
   BK CUSTOMER EXPERIENCE
   CUSTOMER JS — PART 6/6
   CHECKOUT + CUSTOMER SERVICES + FINAL CONTROLS
========================================================= */


/* =========================================================
   END OF CUSTOMER JS — PART 5/6
========================================================= */
/* =========================================================
   BK CUSTOMER EXPERIENCE
   CUSTOMER JS — PART 6/6
   DIRECT ORDER + DYNAMIC TABLE FOUNDATION
========================================================= */


/* =========================================================
   63. CUSTOMER DIRECT ORDER STATE
========================================================= */

let customerCheckoutModal = null;

let currentDirectOrderItem = null;


/* =========================================================
   64. DEFAULT TABLE FOUNDATION
   TEMPORARY: LATER LOAD FROM FIRESTORE
========================================================= */

function getCustomerActiveTables() {

    /*
       Future architecture:

       restaurants/{restaurantId}/tables/{tableId}

       For now we keep a premium default foundation
       so the customer order flow can be tested safely.
    */

    if (
        Array.isArray(CustomerState.tables) &&
        CustomerState.tables.length
    ) {

        return CustomerState.tables;

    }


    const tables = [];

    for (let number = 1; number <= 25; number++) {

        const tableNumber =
            `T${String(number).padStart(2, "0")}`;

        tables.push({

            id: tableNumber,

            tableNumber: tableNumber,

            displayName:
                `Table ${String(number).padStart(2, "0")}`,

            isActive: true

        });

    }


    CustomerState.tables = tables;

    return tables;

}


/* =========================================================
   65. CREATE CUSTOMER CHECKOUT MODAL
========================================================= */

function createCustomerCheckoutModal() {

    if (
        document.getElementById(
            "customerCheckoutModal"
        )
    ) {

        customerCheckoutModal =
            document.getElementById(
                "customerCheckoutModal"
            );

        return;

    }


    const modal =
        document.createElement("div");


    modal.className =
        "customer-modal";


    modal.id =
        "customerCheckoutModal";


    modal.hidden =
        true;


    modal.innerHTML = `

        <div
            class="customer-modal-backdrop"
            data-close-checkout
        ></div>


        <div
            class="customer-modal-card customer-direct-order-modal"
            role="dialog"
            aria-modal="true"
            aria-labelledby="customerCheckoutTitle"
        >

            <button
                type="button"
                class="customer-modal-close"
                id="closeCustomerCheckoutButton"
                aria-label="Close order"
            >
                ×
            </button>


            <div class="customer-modal-icon">
                ✦
            </div>


            <p class="customer-modal-eyebrow">
                BK DIRECT ORDER
            </p>


            <h2 id="customerCheckoutTitle">
                Complete Your Order
            </h2>


            <p class="customer-direct-order-subtitle">
                Just your name and table. Nothing unnecessary.
            </p>


            <!-- ORDER SUMMARY -->

            <div
                class="customer-direct-order-summary"
                id="customerDirectOrderSummary"
            ></div>


            <!-- CUSTOMER NAME -->

            <div class="customer-form-field">

                <label
                    for="checkoutCustomerName"
                >
                    Your Name
                </label>

                <input
                    type="text"
                    id="checkoutCustomerName"
                    placeholder="Enter your name"
                    autocomplete="name"
                    maxlength="60"
                    required
                >

            </div>


            <!-- TABLE SELECTION -->

            <div
                class="customer-table-selection"
            >

                <div
                    class="customer-table-selection-heading"
                >

                    <div>

                        <span>
                            SELECT YOUR TABLE
                        </span>

                        <small>
                            Choose the table where you are seated.
                        </small>

                    </div>

                    <strong
                        id="selectedCustomerTableLabel"
                    >
                        Select Table
                    </strong>

                </div>
                <div class="customer-table-search-wrap">

    <span class="customer-table-search-icon">
        🔎
    </span>

    <input
        type="search"
        id="customerTableSearchInput"
        class="customer-table-search-input"
        placeholder="Search table..."
        autocomplete="off"
        maxlength="20"
    >

    <button
        type="button"
        id="clearCustomerTableSearchButton"
        class="customer-table-search-clear"
        aria-label="Clear table search"
        hidden
    >
        ×
    </button>

</div>


                <div
                    class="customer-table-grid"
                    id="customerCheckoutTableGrid"
                ></div>

            </div>


            <!-- FINAL TOTAL -->

            <div
                class="customer-checkout-total"
            >

                <span>
                    Order Total
                </span>

                <strong
                    id="checkoutCustomerTotal"
                >
                    ₹0
                </strong>

            </div>


            <button
                type="button"
                class="customer-primary-button customer-direct-order-button"
                id="customerPlaceDirectOrderButton"
            >
                PLACE ORDER
            </button>


            <p class="customer-direct-order-privacy">
                Your dine-in order only requires your name and table.
            </p>

        </div>

    `;


    document.body.appendChild(
        modal
    );


    customerCheckoutModal =
        modal;


    setupCustomerCheckoutEvents();

}


/* =========================================================
   66. RENDER TABLES
   SCALABLE SEARCH + PREMIUM TABLE GRID
========================================================= */

function renderCustomerCheckoutTables() {

    const tableGrid =
        document.getElementById(
            "customerCheckoutTableGrid"
        );


    const searchInput =
        document.getElementById(
            "customerTableSearchInput"
        );


    const clearSearchButton =
        document.getElementById(
            "clearCustomerTableSearchButton"
        );


    if (!tableGrid) return;


    const allTables =
        getCustomerActiveTables()
            .filter((table) => {
                return table.isActive !== false;
            });


    /*
       ---------------------------------------------------------
       TABLE SEARCH
       ---------------------------------------------------------
    */

    const searchValue =
        searchInput
            ? searchInput.value.trim().toLowerCase()
            : "";


    const tables =
        allTables.filter((table) => {

            if (!searchValue) {
                return true;
            }


            const tableNumber =
                String(
                    table.tableNumber ||
                    table.id ||
                    ""
                ).toLowerCase();


            const displayName =
                String(
                    table.displayName ||
                    ""
                ).toLowerCase();


            return (
                tableNumber.includes(searchValue) ||
                displayName.includes(searchValue)
            );

        });


    /*
       ---------------------------------------------------------
       CLEAR SEARCH BUTTON
       ---------------------------------------------------------
    */

    if (clearSearchButton) {

        clearSearchButton.hidden =
            !searchValue;

    }


    /*
       ---------------------------------------------------------
       CLEAR OLD TABLE CARDS
       ---------------------------------------------------------
    */

    tableGrid.innerHTML = "";


    /*
       ---------------------------------------------------------
       NO ACTIVE TABLES
       ---------------------------------------------------------
    */

    if (!allTables.length) {

        tableGrid.innerHTML = `

            <div class="customer-table-empty">

                <strong>
                    No tables available
                </strong>

                <span>
                    Please ask the restaurant team for assistance.
                </span>

            </div>

        `;

        return;

    }


    /*
       ---------------------------------------------------------
       SEARCH RESULT EMPTY
       ---------------------------------------------------------
    */

    if (!tables.length) {

        tableGrid.innerHTML = `

            <div class="customer-table-empty">

                <strong>
                    No matching table
                </strong>

                <span>
                    Try another table number or name.
                </span>

            </div>

        `;

        return;

    }


    /*
       ---------------------------------------------------------
       RENDER ONLY MATCHING TABLES
       ---------------------------------------------------------
    */

    tables.forEach((table) => {

        const button =
            document.createElement("button");


        button.type =
            "button";


        button.className =
            "customer-table-card";


        button.dataset.tableId =
            table.id;


        button.innerHTML = `

            <span class="customer-table-card-mark">
                ◆
            </span>

            <strong>
                ${escapeCustomerHTML(
                    table.tableNumber ||
                    table.id
                )}
            </strong>

            <small>
                ${escapeCustomerHTML(
                    table.displayName ||
                    "Dining Table"
                )}
            </small>

        `;


        /*
           ------------------------------------------------------
           RESTORE SELECTED TABLE
           ------------------------------------------------------
        */

        if (
            CustomerState.tableId ===
            table.id
        ) {

            button.classList.add(
                "selected"
            );

        }


        /*
           ------------------------------------------------------
           TABLE SELECTION
           ------------------------------------------------------
        */

        button.addEventListener(
            "click",
            () => {

                selectCustomerCheckoutTable(
                    table
                );

            }
        );


        tableGrid.appendChild(
            button
        );

    });

}



/* =========================================================
   67. SELECT TABLE
========================================================= */

function selectCustomerCheckoutTable(
    table
) {

    if (!table) return;


    CustomerState.tableId =
        table.id;


    const buttons =
        document.querySelectorAll(
            ".customer-table-card"
        );


    buttons.forEach(
        (button) => {

            button.classList.toggle(
                "selected",
                button.dataset.tableId ===
                table.id
            );

        }
    );


    const selectedLabel =
        document.getElementById(
            "selectedCustomerTableLabel"
        );


    if (selectedLabel) {

        selectedLabel.textContent =
            table.tableNumber ||
            table.id;

    }


    showCustomerToast(
        `${table.displayName || "Table"} selected.`,
        "✓"
    );

}


/* =========================================================
   68. RENDER DIRECT ORDER SUMMARY
========================================================= */

function renderCustomerDirectOrderSummary(
    item
) {

    const summary =
        document.getElementById(
            "customerDirectOrderSummary"
        );


    if (!summary || !item) return;


    const quantity =
        Number(item.quantity || 1);


    const price =
        Number(item.price || 0);


    const total =
        price * quantity;


    summary.innerHTML = `

        <div class="customer-direct-order-summary-image">

            ${
                String(item.imageUrl || "").trim()

                ?

                `
                    <img
                        src="${escapeCustomerHTML(
                            item.imageUrl
                        )}"
                        alt="${escapeCustomerHTML(
                            item.name ||
                            "Signature Dish"
                        )}"
                    >
                `

                :

                `
                    <div
                        class="customer-direct-order-summary-fallback"
                    >
                        <span>♛</span>
                        <strong>BK</strong>
                    </div>
                `
            }

        </div>


        <div
            class="customer-direct-order-summary-info"
        >

            <span>
                ${escapeCustomerHTML(
                    item.categoryName ||
                    "SIGNATURE"
                )}
            </span>

            <h3>
                ${escapeCustomerHTML(
                    item.name ||
                    "Signature Dish"
                )}
            </h3>

            <small>
                Quantity × ${quantity}
            </small>

        </div>


        <strong
            class="customer-direct-order-summary-price"
        >
            ₹${formatCustomerPrice(total)}
        </strong>

    `;


    const totalElement =
        document.getElementById(
            "checkoutCustomerTotal"
        );


    if (totalElement) {

        totalElement.textContent =
            `₹${formatCustomerPrice(total)}`;

    }

}


/* =========================================================
   69. OPEN DIRECT ORDER
========================================================= */

function openCustomerCheckout(
    item = null
) {

    /*
       If an item is supplied, this is ORDER NOW.

       If no item is supplied, this can later support
       the combined cart checkout.
    */

    if (item) {

        currentDirectOrderItem = {

            ...item,

            quantity:
                Number(item.quantity || 1)

        };

    }


    if (
        !currentDirectOrderItem &&
        CustomerState.cart.length
    ) {

        currentDirectOrderItem = {

            ...CustomerState.cart[0],

            quantity:
                Number(
                    CustomerState.cart[0].quantity ||
                    1
                )

        };

    }


    if (!currentDirectOrderItem) {

        showCustomerToast(
            "Please select an item first.",
            "!"
        );

        return;

    }


    if (!customerCheckoutModal) {

        createCustomerCheckoutModal();

    }


    renderCustomerDirectOrderSummary(
        currentDirectOrderItem
    );


    renderCustomerCheckoutTables();


    customerCheckoutModal.hidden =
        false;


    document.body.classList.add(
        "customer-modal-open"
    );


    requestAnimationFrame(() => {

        customerCheckoutModal.classList.add(
            "active"
        );

    });

}


/* =========================================================
   70. CLOSE DIRECT ORDER
========================================================= */

function closeCustomerCheckout() {

    if (!customerCheckoutModal) {

        return;

    }


    customerCheckoutModal.classList.remove(
        "active"
    );


    setTimeout(() => {

        customerCheckoutModal.hidden =
            true;

        document.body.classList.remove(
            "customer-modal-open"
        );

    }, 200);


    currentDirectOrderItem =
        null;

}


/* =========================================================
   71. CHECKOUT EVENTS
========================================================= */

function setupCustomerCheckoutEvents() {

    const closeButton =
        document.getElementById(
            "closeCustomerCheckoutButton"
        );


    const backdrop =
        customerCheckoutModal.querySelector(
            "[data-close-checkout]"
        );


    const placeOrderButton =
        document.getElementById(
            "customerPlaceDirectOrderButton"
        );


    const tableSearchInput =
        document.getElementById(
            "customerTableSearchInput"
        );


    const clearTableSearchButton =
        document.getElementById(
            "clearCustomerTableSearchButton"
        );


    /* -----------------------------------------------------
       CLOSE CHECKOUT
    ----------------------------------------------------- */

    if (closeButton) {

        closeButton.addEventListener(
            "click",
            closeCustomerCheckout
        );

    }


    /* -----------------------------------------------------
       BACKDROP CLOSE
    ----------------------------------------------------- */

    if (backdrop) {

        backdrop.addEventListener(
            "click",
            closeCustomerCheckout
        );

    }


    /* -----------------------------------------------------
       PLACE ORDER
    ----------------------------------------------------- */

    if (placeOrderButton) {

        placeOrderButton.addEventListener(
            "click",
            handleCustomerCheckout
        );

    }


    /* -----------------------------------------------------
       TABLE SEARCH
    ----------------------------------------------------- */

    if (tableSearchInput) {

        tableSearchInput.addEventListener(
            "input",
            () => {

                renderCustomerCheckoutTables();

            }
        );

    }


    /* -----------------------------------------------------
       CLEAR TABLE SEARCH
    ----------------------------------------------------- */

    if (clearTableSearchButton) {

        clearTableSearchButton.addEventListener(
            "click",
            () => {

                if (tableSearchInput) {

                    tableSearchInput.value = "";

                    tableSearchInput.focus();

                }


                renderCustomerCheckoutTables();

            }
        );

    }

}

/* =========================================================
   72. DIRECT ORDER SUBMIT — FIREBASE
========================================================= */

async function handleCustomerCheckout() {

    const nameInput =
        document.getElementById(
            "checkoutCustomerName"
        );

    const name =
        nameInput?.value.trim();


    const tableId =
        CustomerState.tableId;


    /* -----------------------------------------------------
       BASIC VALIDATION
    ----------------------------------------------------- */

    if (!name) {

        showCustomerToast(
            "Please enter your name.",
            "!"
        );

        nameInput?.focus();

        return;

    }


    if (!tableId) {

        showCustomerToast(
            "Please select your table.",
            "!"
        );

        return;

    }


    if (!currentDirectOrderItem) {

        showCustomerToast(
            "No food item selected.",
            "!"
        );

        return;

    }


    /* -----------------------------------------------------
       SELECTED ITEM
    ----------------------------------------------------- */

    const item =
        currentDirectOrderItem;


    const quantity =
        Number(
            item.quantity || 1
        );


    const price =
        Number(
            item.price || 0
        );


    const total =
        price * quantity;


    /* -----------------------------------------------------
       FIRESTORE ORDER DATA
    ----------------------------------------------------- */

    const orderData = {

        restaurantId:
            CustomerState.restaurantId,

        tableId:
            tableId,

        customerName:
            name,

        items: [

            {

                id:
                    item.id,

                name:
                    item.name ||
                    "Signature Dish",

                price:
                    price,

                quantity:
                    quantity,

                categoryId:
                    item.categoryId ||
                    null,

                categoryName:
                    item.categoryName ||
                    null

            }

        ],

        total:
            total,

        status:
            "pending",

        createdAt:
            new Date().toISOString()

    };


    console.log(
        "BK: Sending order to Firebase...",
        orderData
    );


    /* -----------------------------------------------------
       FIRESTORE WRITE
    ----------------------------------------------------- */

    try {

        const ordersRef =
            collection(
                db,
                "restaurants",
                CustomerState.restaurantId,
                "orders"
            );


        const orderDocument =
            await addDoc(
                ordersRef,
                orderData
            );


        console.log(
            "BK: Order saved successfully.",
            orderDocument.id
        );
        
        
        /* -------------------------------------------------
   BK STORY CARD — REAL ORDER CONNECTION
------------------------------------------------- */

const storyCardUrl =
    "story-card.html" +
    "?restaurant=" +
    encodeURIComponent(
        CustomerState.restaurantId
    ) +
    "&order=" +
    encodeURIComponent(
        orderDocument.id
    );


console.log(
    "BK STORY CARD URL:",
    storyCardUrl
);


/*
   Open premium story card
   immediately after successful order
*/

window.open(
    storyCardUrl,
    "_blank"
);


        /* -------------------------------------------------
           SUCCESS
        ------------------------------------------------- */

        showCustomerOrderSuccessModal(
    orderDocument.id,
    tableId
);


        /* -------------------------------------------------
           CLOSE POPUP
        ------------------------------------------------- */

        closeCustomerCheckout();


        /* -------------------------------------------------
           CLEAR DIRECT ORDER
        ------------------------------------------------- */

        currentDirectOrderItem =
            null;


        console.log(
            "BK ORDER ID:",
            orderDocument.id
        );


    } catch (error) {

        console.error(
            "BK: Order submission failed:",
            error
        );


        showCustomerToast(
            "Unable to place your order. Please try again.",
            "!"
        );

    }

}


/* =========================================================
   END OF ORDER NOW FOUNDATION
========================================================= */
/* =========================================================
   73. CREATE ORDER SUCCESS MODAL
========================================================= */

function createCustomerOrderSuccessModal() {

    if (
        document.getElementById(
            "customerOrderSuccessModal"
        )
    ) {

        return;

    }


    const modal =
        document.createElement("div");


    modal.className =
        "customer-modal";


    modal.id =
        "customerOrderSuccessModal";


    modal.hidden =
        true;


    modal.innerHTML = `

        <div
            class="customer-modal-backdrop"
            data-close-order-success
        ></div>


        <div
            class="customer-modal-card customer-order-success-modal"
            role="dialog"
            aria-modal="true"
            aria-labelledby="customerOrderSuccessTitle"
        >

            <div class="customer-order-success-mark">
                ✓
            </div>


            <p class="customer-order-success-eyebrow">
                BK • ORDER DESK
            </p>


            <h2 id="customerOrderSuccessTitle">
                ORDER CONFIRMED
            </h2>


            <div class="customer-order-success-divider">
                <span>✦</span>
            </div>


            <p class="customer-order-success-message">
                Your order was received successfully.
            </p>


            <div class="customer-order-success-details">

                <div>

                    <span>
                        ORDER ID
                    </span>

                    <strong
                        id="customerSuccessOrderId"
                    >
                        —
                    </strong>

                </div>


                <div>

                    <span>
                        TABLE
                    </span>

                    <strong
                        id="customerSuccessTable"
                    >
                        —
                    </strong>

                </div>

            </div>


            <button
                type="button"
                class="customer-primary-button customer-order-success-done"
                id="customerOrderSuccessDoneButton"
            >
                DONE
            </button>

        </div>

    `;


    document.body.appendChild(
        modal
    );


    const doneButton =
        document.getElementById(
            "customerOrderSuccessDoneButton"
        );


    const backdrop =
        modal.querySelector(
            "[data-close-order-success]"
        );


    if (doneButton) {

        doneButton.addEventListener(
            "click",
            closeCustomerOrderSuccessModal
        );

    }


    if (backdrop) {

        backdrop.addEventListener(
            "click",
            closeCustomerOrderSuccessModal
        );

    }

}


/* =========================================================
   74. SHOW ORDER SUCCESS MODAL
========================================================= */

function showCustomerOrderSuccessModal(
    orderId,
    tableId
) {

    createCustomerOrderSuccessModal();


    const modal =
        document.getElementById(
            "customerOrderSuccessModal"
        );


    if (!modal) return;


    const orderIdElement =
        document.getElementById(
            "customerSuccessOrderId"
        );


    const tableElement =
        document.getElementById(
            "customerSuccessTable"
        );


    if (orderIdElement) {

        orderIdElement.textContent =
            String(orderId || "—");

    }


    if (tableElement) {

        tableElement.textContent =
            String(tableId || "—");

    }


    modal.hidden =
        false;


    document.body.classList.add(
        "customer-modal-open"
    );


    requestAnimationFrame(() => {

        modal.classList.add(
            "active"
        );

    });

}


/* =========================================================
   75. CLOSE ORDER SUCCESS MODAL
========================================================= */

function closeCustomerOrderSuccessModal() {

    const modal =
        document.getElementById(
            "customerOrderSuccessModal"
        );


    if (!modal) return;


    modal.classList.remove(
        "active"
    );


    setTimeout(() => {

        modal.hidden =
            true;

        document.body.classList.remove(
            "customer-modal-open"
        );

    }, 200);

}

/* =========================================================
   69. CUSTOMER SERVICE MODALS
========================================================= */

const customerServiceModalMap = {

    ticket:
        "ticketBookingModal",

    "home-order":
        "homeOrderModal",

    party:
        "partyBookingModal",

    birthday:
        "birthdayBookingModal",

    "table-date":
        "tableDateBookingModal"

};


/* =========================================================
   70. OPEN SERVICE MODAL
========================================================= */

function openCustomerServiceModal(
    modalId
) {

    const modal =
        document.getElementById(
            modalId
        );


    if (!modal) {

        return;

    }


    modal.hidden =
        false;


    document.body.classList.add(
        "customer-modal-open"
    );


    requestAnimationFrame(() => {

        modal.classList.add(
            "active"
        );

    });


    CustomerState.activeService =
        modalId;

}


/* =========================================================
   71. CLOSE SERVICE MODAL
========================================================= */

function closeCustomerServiceModal(
    modalId
) {

    const modal =
        document.getElementById(
            modalId
        );


    if (!modal) {

        return;

    }


    modal.classList.remove(
        "active"
    );


    setTimeout(() => {

        modal.hidden =
            true;


        document.body.classList.remove(
            "customer-modal-open"
        );

    }, 200);


    CustomerState.activeService =
        null;

}


/* =========================================================
   72. SETUP SERVICE BUTTONS
========================================================= */

function setupCustomerServiceButtons() {

    const serviceButtons =
        document.querySelectorAll(
            "[data-service]"
        );


    serviceButtons.forEach(
        (button) => {

            button.addEventListener(
                "click",
                () => {

                    const service =
                        button.dataset.service;


                    const modalId =
                        customerServiceModalMap[
                            service
                        ];


                    if (modalId) {

                        openCustomerServiceModal(
                            modalId
                        );

                    }

                }
            );

        }
    );

}


/* =========================================================
   73. SETUP SERVICE CLOSE BUTTONS
========================================================= */

function setupCustomerServiceCloseButtons() {

    const closeButtons =
        document.querySelectorAll(
            "[data-close-modal]"
        );


    closeButtons.forEach(
        (button) => {

            button.addEventListener(
                "click",
                () => {

                    const modalId =
                        button.dataset.closeModal;


                    if (modalId) {

                        closeCustomerServiceModal(
                            modalId
                        );

                    }

                }
            );

        }
    );

}

/* =========================================================
   BK BOOKING ENGINE
   TABLE / DATE BOOKING
   FIRESTORE + ATOMIC DUPLICATE PROTECTION
========================================================= */

async function createBKTableBooking(
    bookingData
) {

    const restaurantId =
        CustomerState.restaurantId;


    if (!restaurantId) {

        throw new Error(
            "BK_RESTAURANT_ID_MISSING"
        );

    }


    const date =
        String(
            bookingData.date || ""
        ).trim();


    const time =
        String(
            bookingData.time || ""
        ).trim();


    if (!date) {

        throw new Error(
            "BK_BOOKING_DATE_MISSING"
        );

    }


    if (!time) {

        throw new Error(
            "BK_BOOKING_TIME_MISSING"
        );

    }


    /*
       Example:

       2026-09-26
       19:30

       becomes:

       2026-09-26_19-30
    */

    const slotKey =
        `${date}_${time.replace(
            /:/g,
            "-"
        )}`;


    console.log(
        "BK BOOKING SLOT KEY:",
        slotKey
    );


    const slotRef =
        doc(
            db,
            "restaurants",
            restaurantId,
            "bookingSlots",
            slotKey
        );


    const bookingsCollection =
        collection(
            db,
            "restaurants",
            restaurantId,
            "bookings"
        );


    /*
       Create booking document reference
       before transaction so the booking ID
       is known inside the transaction.
    */

    const bookingRef =
        doc(
            bookingsCollection
        );


    await runTransaction(
        db,
        async (transaction) => {

            /*
             * ---------------------------------------------
             * CHECK SLOT
             * ---------------------------------------------
             */

            const slotSnapshot =
                await transaction.get(
                    slotRef
                );


            /*
             * ---------------------------------------------
             * DUPLICATE PROTECTION
             * ---------------------------------------------
             */

            if (
                slotSnapshot.exists()
            ) {

                throw new Error(
                    "BK_BOOKING_SLOT_ALREADY_BOOKED"
                );

            }


            /*
             * ---------------------------------------------
             * BOOKING RECORD
             * ---------------------------------------------
             */

            const bookingRecord = {

                bookingId:
                    bookingRef.id,

                restaurantId:
                    restaurantId,

                bookingType:
                    "table",

                customerName:
                    bookingData.name || "",

                mobile:
                    bookingData.mobile || "",

                date:
                    date,

                time:
                    time,

                guestCount:
                    Number(
                        bookingData.guests || 1
                    ),

                specialRequest:
                    bookingData.specialRequest || "",

                tableId:
                    CustomerState.tableId || null,

                status:
                    "pending",

                slotKey:
                    slotKey,

                createdAt:
                    serverTimestamp()

            };


            /*
             * ---------------------------------------------
             * CREATE BOOKING
             * ---------------------------------------------
             */

            transaction.set(
                bookingRef,
                bookingRecord
            );


            /*
             * ---------------------------------------------
             * LOCK THIS DATE + TIME SLOT
             * ---------------------------------------------
             */

            transaction.set(
                slotRef,
                {

                    restaurantId:
                        restaurantId,

                    bookingId:
                        bookingRef.id,

                    bookingType:
                        "table",

                    date:
                        date,

                    time:
                        time,

                    guestCount:
                        Number(
                            bookingData.guests || 1
                        ),

                    status:
                        "reserved",

                    createdAt:
                        serverTimestamp()

                }
            );

        }
    );


    console.log(
        "BK BOOKING CREATED:",
        bookingRef.id
    );


    return {

        bookingId:
            bookingRef.id,

        slotKey:
            slotKey

    };

}

/* =========================================================
   74. SERVICE FORM FOUNDATION
   REAL FIRESTORE BOOKING ENGINE
========================================================= */

function setupCustomerServiceForms() {

    const forms =
        document.querySelectorAll(
            ".customer-booking-form"
        );


    forms.forEach(
        (form) => {

            /*
             * Food checkout is handled separately.
             */

            if (
                form.id ===
                "customerCheckoutForm"
            ) {

                return;

            }


            form.addEventListener(
                "submit",
                async (event) => {

                    event.preventDefault();


                    /*
                     * TABLE / DATE BOOKING
                     */

                    if (
                        form.id ===
                        "tableDateBookingForm"
                    ) {

                        await handleTableDateBooking(
                            form
                        );

                        return;

                    }


                    /*
                     * Other service forms
                     * remain foundation-only for now.
                     */

                    const formData =
                        new FormData(
                            form
                        );


                    const data =
                        Object.fromEntries(
                            formData.entries()
                        );


                    console.log(
                        "BK Customer Service Request:",
                        {

                            restaurantId:
                                CustomerState.restaurantId,

                            tableId:
                                CustomerState.tableId,

                            service:
                                form.id,

                            customer:
                                data,

                            status:
                                "pending",

                            createdAt:
                                new Date().toISOString()

                        }
                    );


                    showCustomerToast(
                        "Request prepared successfully.",
                        "✓"
                    );


                    const modal =
                        form.closest(
                            ".customer-modal"
                        );


                    if (modal) {

                        closeCustomerServiceModal(
                            modal.id
                        );

                    }

                }
            );

        }
    );

}


/* =========================================================
   BK TABLE / DATE BOOKING SUBMIT
========================================================= */

async function handleTableDateBooking(
    form
) {

const formData =
    new FormData(
        form
    );


const data =
    Object.fromEntries(
        formData.entries()
    );


/* =====================================================
   BK BOOKING DATA
   Read critical values directly from DOM
===================================================== */

const dateInput =
    document.getElementById(
        "tableDateBookingDate"
    );


const timeInput =
    document.getElementById(
        "tableDateBookingTime"
    );


const guestInput =
    document.getElementById(
        "tableDateGuestCount"
    );


const nameInput =
    document.getElementById(
        "tableDateCustomerName"
    );


const mobileInput =
    document.getElementById(
        "tableDateCustomerMobile"
    );


const specialRequestInput =
    document.getElementById(
        "tableDateSpecialRequest"
    );


/* =====================================================
   FINAL VALUES
===================================================== */

const date =
    String(
        dateInput?.value ||
        data.date ||
        ""
    ).trim();


const time =
    String(
        timeInput?.value ||
        form.dataset.bookingTime ||
        data.time ||
        ""
    ).trim();


const guests =
    Number(
        guestInput?.value ||
        data.guests ||
        0
    );


const name =
    String(
        nameInput?.value ||
        data.name ||
        ""
    ).trim();


const mobile =
    String(
        mobileInput?.value ||
        data.mobile ||
        ""
    ).trim();


const specialRequest =
    String(
        specialRequestInput?.value ||
        data.specialRequest ||
        ""
    ).trim();


console.log(
    "BK TABLE BOOKING FINAL DATA:",
    {
        date,
        time,
        guests,
        name,
        mobile,
        specialRequest
    }
);

    if (!date) {

        showCustomerToast(
            "Please select a date.",
            "!"
        );

        return;

    }


    if (!time) {

        showCustomerToast(
            "Please select a time.",
            "!"
        );

        return;

    }


    if (
        !guests ||
        guests < 1
    ) {

        showCustomerToast(
            "Please select number of guests.",
            "!"
        );

        return;

    }


    if (!name) {

        showCustomerToast(
            "Please enter your full name.",
            "!"
        );

        return;

    }


    if (!mobile) {

        showCustomerToast(
            "Please enter your mobile number.",
            "!"
        );

        return;

    }


    /*
     * ---------------------------------------------
     * SUBMIT BUTTON
     * ---------------------------------------------
     */

    const submitButton =
        document.getElementById(
            "bkReservationSubmitButton"
        );


    if (submitButton) {

        submitButton.disabled =
            true;

    }


    try {

        /*
         * ---------------------------------------------
         * FIRESTORE TRANSACTION
         * ---------------------------------------------
         */

        const result =
            await createBKTableBooking({

                name:
                    name,

                mobile:
                    mobile,

                date:
                    date,

                time:
                    time,

                guests:
                    guests,

                specialRequest:
                    specialRequest

            });


        console.log(
            "BK TABLE BOOKING SUCCESS:",
            result
        );


        /*
         * ---------------------------------------------
         * SUCCESS MESSAGE
         * ---------------------------------------------
         */

        showCustomerToast(
            "Your table reservation has been requested successfully.",
            "✓"
        );


        /*
         * ---------------------------------------------
         * CLOSE MODAL
         * ---------------------------------------------
         */

        const modal =
            form.closest(
                ".customer-modal"
            );


        if (modal) {

            closeCustomerServiceModal(
                modal.id
            );

        }


        /*
         * ---------------------------------------------
         * RESET FORM
         * ---------------------------------------------
         */

        form.reset();


        /*
         * Restore default guest count.
         */

        const guestInput =
            document.getElementById(
                "tableDateGuestCount"
            );


        const guestDisplay =
            document.getElementById(
                "bkGuestCountDisplay"
            );


        if (guestInput) {

            guestInput.value =
                "2";

        }


        if (guestDisplay) {

            guestDisplay.textContent =
                "2";

        }


        console.log(
            "BK TABLE BOOKING ID:",
            result.bookingId
        );

    } catch (error) {

        console.error(
            "BK TABLE BOOKING FAILED:",
            error
        );


        /*
         * ---------------------------------------------
         * DUPLICATE SLOT
         * ---------------------------------------------
         */

        if (
            error &&
            error.message ===
                "BK_BOOKING_SLOT_ALREADY_BOOKED"
        ) {

            showCustomerToast(
                "This date & time is already booked. Please choose another time.",
                "!"
            );


            return;

        }


        /*
         * ---------------------------------------------
         * OTHER ERROR
         * ---------------------------------------------
         */

        showCustomerToast(
            "Unable to create your reservation. Please try again.",
            "!"
        );

    } finally {

        if (submitButton) {

            submitButton.disabled =
                false;

        }

    }

}
/* =========================================================
   75. GLOBAL CUSTOMER MODAL CONTROL
========================================================= */

function setupGlobalCustomerModalControl() {

    document.addEventListener(
        "keydown",
        (event) => {

            if (
                event.key !== "Escape"
            ) {

                return;

            }


            document
                .querySelectorAll(
                    ".customer-modal"
                )
                .forEach(
                    (modal) => {

                        if (!modal.hidden) {

                            modal.classList.remove(
                                "active"
                            );


                            setTimeout(() => {

                                modal.hidden =
                                    true;

                            }, 200);

                        }

                    }
                );


            document.body.classList.remove(
                "customer-modal-open"
            );

        }
    );

}


/* =========================================================
   76. CUSTOMER CART STATE SUMMARY
========================================================= */

function getCustomerCartSummary() {

    return {

        restaurantId:
            CustomerState.restaurantId,

        tableId:
            CustomerState.tableId,

        itemCount:
            CustomerState.cart.length,

        quantity:
            CustomerState.cart.reduce(
                (total, item) => {

                    return total +
                        Number(
                            item.quantity || 0
                        );

                },
                0
            ),

        total:
            calculateCustomerCartTotal()

    };

}


/* =========================================================
   77. CUSTOMER DEBUG INFORMATION
========================================================= */

function logCustomerSystemStatus() {

    console.log(
        "=========================================="
    );


    console.log(
        "BK CUSTOMER SYSTEM"
    );


    console.log(
        "Restaurant ID:",
        CustomerState.restaurantId
    );


    console.log(
        "Table ID:",
        CustomerState.tableId
    );


    console.log(
        "Restaurant:",
        CustomerState.restaurant
    );


    console.log(
        "Categories:",
        CustomerState.categories.length
    );


    console.log(
        "Menu Items:",
        CustomerState.menuItems.length
    );


    console.log(
        "Cart:",
        getCustomerCartSummary()
    );


    console.log(
        "Customer Dashboard Core Ready."
    );


    console.log(
        "=========================================="
    );

}


/* =========================================================
   78. FINAL CUSTOMER INITIALIZATION
========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    () => {

        createCustomerCartModal();

        createCustomerCheckoutModal();

        setupCustomerCartHeaderButton();

        setupCustomerMenuSearch();

        setupCustomerFoodDetailEvents();

        setupCustomerServiceButtons();

        setupCustomerServiceCloseButtons();

        setupCustomerServiceForms();

        setupGlobalCustomerModalControl();

        updateCustomerCartCount();

        logCustomerSystemStatus();

    }
);

/* =========================================================
   BK BOOKING ENGINE — STEP 3
   CALENDAR + TIME SLOTS + GUEST COUNTER
   APPEND ONLY
========================================================= */

(function BKReservationUI() {

    "use strict";

    let currentCalendarDate = new Date();

    let selectedDate = null;

    let selectedTime = null;

    let guestCount = 2;


    /* =====================================================
       ELEMENTS
    ===================================================== */

    function getElements() {

        return {

            calendarMonth:
                document.getElementById(
                    "bkCalendarMonth"
                ),

            calendarGrid:
                document.getElementById(
                    "bkCalendarGrid"
                ),

            previousMonth:
                document.getElementById(
                    "bkPreviousMonth"
                ),

            nextMonth:
                document.getElementById(
                    "bkNextMonth"
                ),

            dateInput:
                document.getElementById(
                    "tableDateBookingDate"
                ),

            timeInput:
                document.getElementById(
                    "tableDateBookingTime"
                ),

            timeSlots:
                document.getElementById(
                    "bkTimeSlots"
                ),

            guestMinus:
                document.getElementById(
                    "bkGuestMinus"
                ),

            guestPlus:
                document.getElementById(
                    "bkGuestPlus"
                ),

            guestDisplay:
                document.getElementById(
                    "bkGuestCountDisplay"
                ),

            guestInput:
                document.getElementById(
                    "tableDateGuestCount"
                ),

            request:
                document.getElementById(
                    "tableDateSpecialRequest"
                ),

            requestCount:
                document.getElementById(
                    "bkSpecialRequestCount"
                )

        };

    }


    /* =====================================================
       DATE HELPERS
    ===================================================== */

    function formatDateValue(date) {

        const year =
            date.getFullYear();

        const month =
            String(
                date.getMonth() + 1
            ).padStart(2, "0");

        const day =
            String(
                date.getDate()
            ).padStart(2, "0");

        return `${year}-${month}-${day}`;

    }


    function isSameDate(
        first,
        second
    ) {

        return (
            first.getFullYear() ===
                second.getFullYear()

            &&

            first.getMonth() ===
                second.getMonth()

            &&

            first.getDate() ===
                second.getDate()
        );

    }


    function isPastDate(date) {

        const today =
            new Date();

        today.setHours(
            0,
            0,
            0,
            0
        );

        const checkDate =
            new Date(date);

        checkDate.setHours(
            0,
            0,
            0,
            0
        );

        return checkDate < today;

    }


    /* =====================================================
       CALENDAR
    ===================================================== */

    function renderCalendar() {

        const elements =
            getElements();

        if (
            !elements.calendarGrid ||
            !elements.calendarMonth
        ) {

            return;

        }


        const year =
            currentCalendarDate.getFullYear();

        const month =
            currentCalendarDate.getMonth();


        const monthName =
            currentCalendarDate.toLocaleDateString(
                "en-IN",
                {
                    month: "long",
                    year: "numeric"
                }
            );


        elements.calendarMonth.textContent =
            monthName;


        elements.calendarGrid.innerHTML =
            "";


        const firstDay =
            new Date(
                year,
                month,
                1
            ).getDay();


        const daysInMonth =
            new Date(
                year,
                month + 1,
                0
            ).getDate();


        for (
            let blank = 0;
            blank < firstDay;
            blank++
        ) {

            const spacer =
                document.createElement(
                    "span"
                );

            spacer.setAttribute(
                "aria-hidden",
                "true"
            );

            elements.calendarGrid.appendChild(
                spacer
            );

        }


        for (
            let day = 1;
            day <= daysInMonth;
            day++
        ) {

            const date =
                new Date(
                    year,
                    month,
                    day
                );


            const button =
                document.createElement(
                    "button"
                );


            button.type =
                "button";


            button.textContent =
                String(day);


            button.dataset.date =
                formatDateValue(date);


            if (
                isPastDate(date)
            ) {

                button.classList.add(
                    "is-disabled"
                );

                button.disabled =
                    true;

            }


            if (
                selectedDate &&
                isSameDate(
                    date,
                    selectedDate
                )
            ) {

                button.classList.add(
                    "is-selected"
                );

            }


            const today =
                new Date();


            if (
                isSameDate(
                    date,
                    today
                )
            ) {

                button.classList.add(
                    "is-today"
                );

            }


            button.addEventListener(
                "click",
                function () {

                    selectDate(
                        date
                    );

                }
            );


            elements.calendarGrid.appendChild(
                button
            );

        }

    }


    function selectDate(date) {

        if (
            isPastDate(date)
        ) {

            return;

        }


        selectedDate =
            new Date(date);


        const elements =
            getElements();


        if (
            elements.dateInput
        ) {

            elements.dateInput.value =
                formatDateValue(
                    selectedDate
                );

        }


        renderCalendar();


        /*
         * Re-render available times
         * whenever date changes.
         */

        renderTimeSlots();

    }


    /* =====================================================
       MONTH NAVIGATION
    ===================================================== */

    function goToPreviousMonth() {

        const today =
            new Date();

        const currentMonthStart =
            new Date(
                today.getFullYear(),
                today.getMonth(),
                1
            );


        const targetMonth =
            new Date(
                currentCalendarDate.getFullYear(),
                currentCalendarDate.getMonth() - 1,
                1
            );


        /*
         * Never allow navigation
         * before current month.
         */

        if (
            targetMonth <
            currentMonthStart
        ) {

            return;

        }


        currentCalendarDate =
            targetMonth;


        renderCalendar();

    }


    function goToNextMonth() {

        currentCalendarDate =
            new Date(
                currentCalendarDate.getFullYear(),
                currentCalendarDate.getMonth() + 1,
                1
            );


        renderCalendar();

    }


    /* =====================================================
       TIME SLOTS
    ===================================================== */

    function getAvailableTimeSlots() {

        return [

            "12:00 PM",
            "12:30 PM",
            "01:00 PM",
            "01:30 PM",

            "02:00 PM",
            "02:30 PM",

            "07:00 PM",
            "07:30 PM",
            "08:00 PM",
            "08:30 PM",

            "09:00 PM",
            "09:30 PM"

        ];

    }


    function convertTimeToValue(
        time
    ) {

        const match =
            time.match(
                /^(\d+):(\d+)\s(AM|PM)$/
            );


        if (!match) {

            return "";

        }


        let hour =
            Number(
                match[1]
            );

        const minute =
            match[2];

        const period =
            match[3];


        if (
            period === "PM" &&
            hour !== 12
        ) {

            hour += 12;

        }


        if (
            period === "AM" &&
            hour === 12
        ) {

            hour = 0;

        }


        return (
            String(hour).padStart(2, "0") +
            ":" +
            minute
        );

    }


    function renderTimeSlots() {

        const elements =
            getElements();


        if (
            !elements.timeSlots
        ) {

            return;

        }


        elements.timeSlots.innerHTML =
            "";


        const slots =
            getAvailableTimeSlots();


        slots.forEach(
            function (time) {

                const button =
                    document.createElement(
                        "button"
                    );


                button.type =
                    "button";


                button.className =
                    "bk-time-slot";


                button.textContent =
                    time;


                button.dataset.time =
                    convertTimeToValue(
                        time
                    );


                if (
                    selectedTime ===
                    button.dataset.time
                ) {

                    button.classList.add(
                        "is-selected"
                    );

                }


                button.addEventListener(
                    "click",
                    function () {

                        selectTime(
                            button.dataset.time,
                            time
                        );

                    }
                );


                elements.timeSlots.appendChild(
                    button
                );

            }
        );

    }


    function selectTime(
        value,
        displayTime
    ) {

        selectedTime =
            value;


        const elements =
            getElements();


        if (
            elements.timeInput
        ) {

            elements.timeInput.value =
                value;

        }


        renderTimeSlots();


        console.log(
            "BK Reservation Time:",
            displayTime
        );

    }


    /* =====================================================
       GUEST COUNTER
    ===================================================== */

    function updateGuestDisplay() {

        const elements =
            getElements();


        if (
            elements.guestDisplay
        ) {

            elements.guestDisplay.textContent =
                guestCount;

        }


        if (
            elements.guestInput
        ) {

            elements.guestInput.value =
                guestCount;

        }

    }


    function decreaseGuests() {

        if (
            guestCount <= 1
        ) {

            return;

        }


        guestCount--;

        updateGuestDisplay();

    }


    function increaseGuests() {

        if (
            guestCount >= 50
        ) {

            return;

        }


        guestCount++;

        updateGuestDisplay();

    }


    /* =====================================================
       SPECIAL REQUEST COUNTER
    ===================================================== */

    function updateRequestCounter() {

        const elements =
            getElements();


        if (
            !elements.request ||
            !elements.requestCount
        ) {

            return;

        }


        elements.requestCount.textContent =
            String(
                elements.request.value.length
            );

    }


    /* =====================================================
       EVENTS
    ===================================================== */

    function setupEvents() {

        const elements =
            getElements();


        if (
            elements.previousMonth
        ) {

            elements.previousMonth.addEventListener(
                "click",
                goToPreviousMonth
            );

        }


        if (
            elements.nextMonth
        ) {

            elements.nextMonth.addEventListener(
                "click",
                goToNextMonth
            );

        }


        if (
            elements.guestMinus
        ) {

            elements.guestMinus.addEventListener(
                "click",
                decreaseGuests
            );

        }


        if (
            elements.guestPlus
        ) {

            elements.guestPlus.addEventListener(
                "click",
                increaseGuests
            );

        }


        if (
            elements.request
        ) {

            elements.request.addEventListener(
                "input",
                updateRequestCounter
            );

        }

    }


    /* =====================================================
       DEFAULT DATE
    ===================================================== */

    function initializeDefaults() {

        const today =
            new Date();


        selectedDate =
            new Date(today);


        currentCalendarDate =
            new Date(
                today.getFullYear(),
                today.getMonth(),
                1
            );


        guestCount =
            2;


        selectedTime =
            null;


        const elements =
            getElements();


        if (
            elements.dateInput
        ) {

            elements.dateInput.value =
                formatDateValue(
                    selectedDate
                );

        }


        updateGuestDisplay();

        updateRequestCounter();

        renderCalendar();

        renderTimeSlots();

    }


    /* =====================================================
       START
    ===================================================== */

    function start() {

        if (
            !document.getElementById(
                "tableDateBookingModal"
            )
        ) {

            return;

        }


        setupEvents();

        initializeDefaults();


        console.log(
            "BK RESERVATION UI: READY"
        );

    }


    document.addEventListener(
        "DOMContentLoaded",
        start
    );

})();

/* =========================================================
   END — BK BOOKING ENGINE STEP 3
========================================================= */
/* =========================================================
   BK PREMIUM CLOCK TIME PICKER
   FIXED — CLOCK → HIDDEN INPUT SYNC
========================================================= */

(function BKClockTimePicker() {

    "use strict";


    /* =====================================================
       STATE
    ===================================================== */

    let selectedHour = 12;

    let selectedMinute = "00";

    let selectedMeridiem = "AM";


    /* =====================================================
       DOM
    ===================================================== */

    function getElements() {

        return {

            hours:
                document.querySelectorAll(
                    ".bk-clock-number"
                ),

            minutes:
                document.querySelectorAll(
                    ".bk-minute-button"
                ),

            amButton:
                document.getElementById(
                    "bkAMButton"
                ),

            pmButton:
                document.getElementById(
                    "bkPMButton"
                ),

            selectedHour:
                document.getElementById(
                    "bkSelectedHour"
                ),

            selectedMinute:
                document.getElementById(
                    "bkSelectedMinute"
                ),

            preview:
                document.getElementById(
                    "bkSelectedTimePreview"
                ),

            hiddenInput:
                document.getElementById(
                    "tableDateBookingTime"
                ),

            form:
                document.getElementById(
                    "tableDateBookingForm"
                )

        };

    }


    /* =====================================================
       CONVERT 12-HOUR → 24-HOUR
    ===================================================== */

    function get24HourValue() {

        let hour =
            Number(
                selectedHour
            );


        if (
            selectedMeridiem === "AM"
            && hour === 12
        ) {

            hour = 0;

        }


        if (
            selectedMeridiem === "PM"
            && hour !== 12
        ) {

            hour += 12;

        }


        return String(
            hour
        ).padStart(
            2,
            "0"
        );

    }


    /* =====================================================
       GET FINAL BOOKING TIME
    ===================================================== */

    function getBookingTimeValue() {

        return (
            get24HourValue() +
            ":" +
            selectedMinute
        );

    }


    /* =====================================================
       UPDATE EVERYTHING
    ===================================================== */

    function updateClockDisplay() {

        const elements =
            getElements();


        const bookingTime =
            getBookingTimeValue();


        /* ---------------------------------------------
           VISIBLE CLOCK
        --------------------------------------------- */

        if (
            elements.selectedHour
        ) {

            elements.selectedHour.textContent =
                String(
                    selectedHour
                );

        }


        if (
            elements.selectedMinute
        ) {

            elements.selectedMinute.textContent =
                selectedMinute;

        }


        /* ---------------------------------------------
           VISIBLE SUMMARY
        --------------------------------------------- */

        if (
            elements.preview
        ) {

            elements.preview.textContent =
                `${selectedHour}:${selectedMinute} ${selectedMeridiem}`;

        }


        /* ---------------------------------------------
           CRITICAL:
           HIDDEN FORM VALUE
        --------------------------------------------- */

        if (
            elements.hiddenInput
        ) {

            elements.hiddenInput.value =
                bookingTime;


            /*
                Tell the browser/form system
                that the value has changed.
            */

            elements.hiddenInput.dispatchEvent(
                new Event(
                    "input",
                    {
                        bubbles: true
                    }
                )
            );


            elements.hiddenInput.dispatchEvent(
                new Event(
                    "change",
                    {
                        bubbles: true
                    }
                )
            );

        }


        /* ---------------------------------------------
           BACKUP FORM STATE
        --------------------------------------------- */

        if (
            elements.form
        ) {

            elements.form.dataset.bookingTime =
                bookingTime;

        }


        console.log(
            "BK CLOCK SYNC:",
            selectedHour +
            ":" +
            selectedMinute,
            selectedMeridiem,
            "→",
            bookingTime
        );

    }


    /* =====================================================
       HOUR BUTTON STATE
    ===================================================== */

    function updateHourButtons() {

        const elements =
            getElements();


        elements.hours.forEach(
            function (button) {

                const hour =
                    Number(
                        button.dataset.clockHour
                    );


                button.classList.toggle(
                    "active",
                    hour === selectedHour
                );

            }
        );

    }


    /* =====================================================
       MINUTE BUTTON STATE
    ===================================================== */

    function updateMinuteButtons() {

        const elements =
            getElements();


        elements.minutes.forEach(
            function (button) {

                const minute =
                    String(
                        button.dataset.minute
                    );


                button.classList.toggle(
                    "active",
                    minute === selectedMinute
                );

            }
        );

    }


    /* =====================================================
       AM / PM BUTTON STATE
    ===================================================== */

    function updateMeridiemButtons() {

        const elements =
            getElements();


        if (
            elements.amButton
        ) {

            elements.amButton.classList.toggle(
                "active",
                selectedMeridiem === "AM"
            );

        }


        if (
            elements.pmButton
        ) {

            elements.pmButton.classList.toggle(
                "active",
                selectedMeridiem === "PM"
            );

        }

    }


    /* =====================================================
       SELECT HOUR
    ===================================================== */

    function selectHour(
        hour
    ) {

        selectedHour =
            Number(
                hour
            );


        updateHourButtons();

        updateClockDisplay();

    }


    /* =====================================================
       SELECT MINUTE
    ===================================================== */

    function selectMinute(
        minute
    ) {

        selectedMinute =
            String(
                minute
            ).padStart(
                2,
                "0"
            );


        updateMinuteButtons();

        updateClockDisplay();

    }


    /* =====================================================
       SELECT AM / PM
    ===================================================== */

    function selectMeridiem(
        value
    ) {

        selectedMeridiem =
            value;


        updateMeridiemButtons();

        updateClockDisplay();

    }


    /* =====================================================
       EVENT SETUP
    ===================================================== */

    function setupEvents() {

        const elements =
            getElements();


        /* ---------------------------------------------
           HOURS
        --------------------------------------------- */

        elements.hours.forEach(
            function (button) {

                button.addEventListener(
                    "click",
                    function () {

                        selectHour(
                            this.dataset.clockHour
                        );

                    }
                );

            }
        );


        /* ---------------------------------------------
           MINUTES
        --------------------------------------------- */

        elements.minutes.forEach(
            function (button) {

                button.addEventListener(
                    "click",
                    function () {

                        selectMinute(
                            this.dataset.minute
                        );

                    }
                );

            }
        );


        /* ---------------------------------------------
           AM
        --------------------------------------------- */

        if (
            elements.amButton
        ) {

            elements.amButton.addEventListener(
                "click",
                function () {

                    selectMeridiem(
                        "AM"
                    );

                }
            );

        }


        /* ---------------------------------------------
           PM
        --------------------------------------------- */

        if (
            elements.pmButton
        ) {

            elements.pmButton.addEventListener(
                "click",
                function () {

                    selectMeridiem(
                        "PM"
                    );

                }
            );

        }

    }


    /* =====================================================
       INITIALIZE
    ===================================================== */

    function initializeClock() {

        selectedHour =
            12;

        selectedMinute =
            "00";

        selectedMeridiem =
            "AM";


        updateHourButtons();

        updateMinuteButtons();

        updateMeridiemButtons();

        updateClockDisplay();


        console.log(
            "BK CLOCK TIME PICKER: READY"
        );

    }


    /* =====================================================
       START
    ===================================================== */

    function startClock() {

        const clock =
            document.querySelector(
                ".bk-clock-picker"
            );


        if (!clock) {

            return;

        }


        setupEvents();

        initializeClock();

    }


    document.addEventListener(
        "DOMContentLoaded",
        startClock
    );


})();
/* =========================================================
   END OF CUSTOMER JS — PART 6/6
========================================================= */