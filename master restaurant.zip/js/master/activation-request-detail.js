"use strict";

(() => {

    /* =========================================================
       01. STATE
       ========================================================= */

    const state = {
        initialized: false,
        ready: false,
        open: false,
        selectedRequestId: null,
        decisionType: null
    };


    /* =========================================================
       02. ENGINE HELPERS
       ========================================================= */

    function getRequestEngine() {
        return window.BKMasterActivationRequests || null;
    }


    function getQueueEngine() {
        return window.BKMasterActivationRequestQueue || null;
    }


    /* =========================================================
       03. HTML ESCAPE HELPER
       ========================================================= */

    function escapeHTML(value) {

        const text = String(value ?? "");

        return text
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }


    /* =========================================================
       04. DATE FORMATTER
       ========================================================= */

    function formatDate(timestamp) {

        if (!timestamp) {
            return "Pending timestamp";
        }

        try {

            let date = null;

            if (typeof timestamp.toDate === "function") {
                date = timestamp.toDate();

            } else if (timestamp instanceof Date) {
                date = timestamp;

            } else if (typeof timestamp === "string") {
                date = new Date(timestamp);
            }

            if (!date || Number.isNaN(date.getTime())) {
                return "Pending timestamp";
            }

            return date.toLocaleString(undefined, {
                dateStyle: "medium",
                timeStyle: "short"
            });

        } catch (error) {

            return "Pending timestamp";
        }
    }


    /* =========================================================
       05. CREATE DETAIL MODAL
       ========================================================= */

    function createModal() {

        if (
            document.getElementById(
                "bkMasterActivationRequestModal"
            )
        ) {
            return true;
        }

        const modal =
            document.createElement("div");

        modal.id =
            "bkMasterActivationRequestModal";

        modal.className =
            "bk-master-request-modal";

        modal.setAttribute(
            "aria-hidden",
            "true"
        );

        modal.innerHTML = `

            <!-- =================================================
                 MAIN REQUEST MODAL
                 ================================================= -->

            <div
                class="bk-master-request-modal-backdrop"
                data-request-modal-close="true"
            ></div>


            <section
                class="bk-master-request-modal-dialog"
                role="dialog"
                aria-modal="true"
                aria-labelledby="bkMasterRequestModalTitle"
            >

                <div
                    class="bk-master-request-modal-header"
                >

                    <div>

                        <span
                            class="bk-master-request-modal-kicker"
                        >
                            ACCOUNT CONTROL
                        </span>

                        <h3
                            id="bkMasterRequestModalTitle"
                        >
                            Activation Request
                        </h3>

                        <p>
                            Review the complete owner activation request.
                        </p>

                    </div>


                    <button
                        type="button"
                        class="bk-master-request-modal-close"
                        id="bkMasterActivationRequestModalClose"
                        aria-label="Close activation request"
                    >
                        ×
                    </button>

                </div>


                <div
                    class="bk-master-request-modal-body"
                    id="bkMasterActivationRequestModalBody"
                ></div>


                <!-- =================================================
                     REQUEST DECISION FOOTER
                     ================================================= -->

                <div
                    class="bk-master-request-modal-footer"
                >

                    <div
                        class="bk-master-request-decision-actions"
                    >

                        <button
                            type="button"
                            class="bk-master-request-decision-button reject"
                            id="bkMasterActivationRequestReject"
                        >
                            Reject Request
                        </button>


                        <button
                            type="button"
                            class="bk-master-request-decision-button approve"
                            id="bkMasterActivationRequestApprove"
                        >
                            Approve Request
                        </button>

                    </div>


                    <button
                        type="button"
                        class="bk-master-request-modal-secondary"
                        id="bkMasterActivationRequestModalFooterClose"
                    >
                        Close
                    </button>

                </div>

            </section>


            <!-- =================================================
                 CONFIRMATION POPUP
                 ================================================= -->

            <div
                class="bk-master-request-confirm-overlay"
                id="bkMasterRequestConfirmOverlay"
                aria-hidden="true"
            >

                <div
                    class="bk-master-request-confirm-dialog"
                    role="alertdialog"
                    aria-modal="true"
                    aria-labelledby="bkMasterRequestConfirmTitle"
                >

                    <span
                        class="bk-master-request-confirm-kicker"
                    >
                        ACCOUNT CONTROL
                    </span>


                    <h3
                        id="bkMasterRequestConfirmTitle"
                    >
                        Confirm Decision
                    </h3>


                    <p
                        id="bkMasterRequestConfirmMessage"
                    >
                        Please confirm this request decision.
                    </p>


                    <div
                        class="bk-master-request-confirm-actions"
                    >

                        <button
                            type="button"
                            class="bk-master-request-confirm-cancel"
                            id="bkMasterRequestConfirmCancel"
                        >
                            Cancel
                        </button>


                        <button
                            type="button"
                            class="bk-master-request-confirm-submit"
                            id="bkMasterRequestConfirmSubmit"
                        >
                            Confirm
                        </button>

                    </div>

                </div>

            </div>


            <!-- =================================================
                 RESULT POPUP
                 ================================================= -->

            <div
                class="bk-master-request-result-overlay"
                id="bkMasterRequestResultOverlay"
                aria-hidden="true"
            >

                <div
                    class="bk-master-request-result-dialog"
                    role="alertdialog"
                    aria-modal="true"
                    aria-labelledby="bkMasterRequestResultTitle"
                >

                    <span
                        class="bk-master-request-result-kicker"
                        id="bkMasterRequestResultKicker"
                    >
                        ACCOUNT CONTROL
                    </span>


                    <div
                        class="bk-master-request-result-icon"
                        id="bkMasterRequestResultIcon"
                    >
                        ✓
                    </div>


                    <h3
                        id="bkMasterRequestResultTitle"
                    >
                        Operation Successful
                    </h3>


                    <p
                        id="bkMasterRequestResultMessage"
                    >
                        The operation was completed successfully.
                    </p>


                    <button
                        type="button"
                        class="bk-master-request-result-close"
                        id="bkMasterRequestResultClose"
                    >
                        Continue
                    </button>

                </div>

            </div>

        `;

        document.body.appendChild(modal);

        return true;
    }


    /* =========================================================
       06. CACHE DOM ELEMENTS
       ========================================================= */

    function cacheElements() {

        state.modal =
            document.getElementById(
                "bkMasterActivationRequestModal"
            );


        state.body =
            document.getElementById(
                "bkMasterActivationRequestModalBody"
            );


        state.closeButton =
            document.getElementById(
                "bkMasterActivationRequestModalClose"
            );


        state.footerCloseButton =
            document.getElementById(
                "bkMasterActivationRequestModalFooterClose"
            );


        state.approveButton =
            document.getElementById(
                "bkMasterActivationRequestApprove"
            );


        state.rejectButton =
            document.getElementById(
                "bkMasterActivationRequestReject"
            );


        state.confirmOverlay =
            document.getElementById(
                "bkMasterRequestConfirmOverlay"
            );


        state.confirmTitle =
            document.getElementById(
                "bkMasterRequestConfirmTitle"
            );


        state.confirmMessage =
            document.getElementById(
                "bkMasterRequestConfirmMessage"
            );


        state.confirmCancelButton =
            document.getElementById(
                "bkMasterRequestConfirmCancel"
            );


        state.confirmSubmitButton =
            document.getElementById(
                "bkMasterRequestConfirmSubmit"
            );


        state.resultOverlay =
            document.getElementById(
                "bkMasterRequestResultOverlay"
            );


        state.resultKicker =
            document.getElementById(
                "bkMasterRequestResultKicker"
            );


        state.resultIcon =
            document.getElementById(
                "bkMasterRequestResultIcon"
            );


        state.resultTitle =
            document.getElementById(
                "bkMasterRequestResultTitle"
            );


        state.resultMessage =
            document.getElementById(
                "bkMasterRequestResultMessage"
            );


        state.resultCloseButton =
            document.getElementById(
                "bkMasterRequestResultClose"
            );
    }


    /* =========================================================
       07. DETAIL ROW CREATOR
       ========================================================= */

    function createDetailRow(label, value) {

        return `
            <div class="bk-master-request-detail-row">

                <span
                    class="bk-master-request-detail-label"
                >
                    ${escapeHTML(label)}
                </span>

                <strong
                    class="bk-master-request-detail-value"
                >
                    ${escapeHTML(value || "Not available")}
                </strong>

            </div>
        `;
    }


    /* =========================================================
       08. REQUEST RENDERER
       ========================================================= */

    function renderRequest(request) {

        if (!state.body || !request) {
            return;
        }


        const restaurantName =
            request.restaurantName ||
            "Unknown Restaurant";


        const ownerName =
            request.ownerName ||
            "Unknown Owner";


        const ownerReason =
            request.ownerReason ||
            "No owner response provided.";


        const masterReason =
            request.masterReason ||
            "No Master reason recorded.";


        state.body.innerHTML = `

            <div
                class="bk-master-request-detail-summary"
            >

                <span
                    class="bk-master-request-detail-status"
                >
                    ${escapeHTML(
                        request.status || "PENDING"
                    )}
                </span>


                <span
                    class="bk-master-request-detail-date"
                >
                    ${escapeHTML(
                        formatDate(request.createdAt)
                    )}
                </span>

            </div>


            <div
                class="bk-master-request-detail-grid"
            >

                ${createDetailRow(
                    "Restaurant Name",
                    restaurantName
                )}


                ${createDetailRow(
                    "Restaurant ID",
                    request.restaurantId
                )}


                ${createDetailRow(
                    "Owner Name",
                    ownerName
                )}


                ${createDetailRow(
                    "Owner ID",
                    request.ownerId
                )}


                ${createDetailRow(
                    "Account Status",
                    request.accountStatus
                )}


                ${createDetailRow(
                    "Master Action",
                    request.masterAction
                )}


                ${createDetailRow(
                    "Request Status",
                    request.status
                )}


                ${createDetailRow(
                    "Request Type",
                    request.requestType
                )}

            </div>


            <div
                class="bk-master-request-detail-message"
            >

                <span>
                    OWNER RESPONSE
                </span>

                <p>
                    ${escapeHTML(ownerReason)}
                </p>

            </div>


            <div
                class="bk-master-request-detail-message master-reason"
            >

                <span>
                    ORIGINAL MASTER REASON
                </span>

                <p>
                    ${escapeHTML(masterReason)}
                </p>

            </div>

        `;
    }


    /* =========================================================
       09. OPEN REQUEST
       ========================================================= */

    function openRequest(requestId) {

        if (!requestId) {
            return;
        }


        const engine =
            getRequestEngine();


        if (!engine) {

            console.error(
                "BK MASTER: ACTIVATION REQUEST ENGINE NOT AVAILABLE."
            );

            return;
        }


        const request =
            engine.getRequest(requestId);


        if (!request) {

            console.warn(
                "BK MASTER: ACTIVATION REQUEST NOT FOUND:",
                requestId
            );

            return;
        }


        state.selectedRequestId =
            requestId;


        renderRequest(request);


        if (!state.modal) {
            return;
        }


        state.modal.classList.add(
            "is-open"
        );


        state.modal.setAttribute(
            "aria-hidden",
            "false"
        );


        document.body.classList.add(
            "bk-master-request-modal-open"
        );


        state.open = true;


        console.log(
            "BK MASTER: ACTIVATION REQUEST DETAIL OPENED.",
            requestId
        );
    }


    /* =========================================================
       10. CLOSE REQUEST MODAL
       ========================================================= */

    function closeModal() {

        if (!state.modal) {
            return;
        }


        state.modal.classList.remove(
            "is-open"
        );


        state.modal.setAttribute(
            "aria-hidden",
            "true"
        );


        document.body.classList.remove(
            "bk-master-request-modal-open"
        );


        state.open = false;
        state.selectedRequestId = null;


        console.log(
            "BK MASTER: ACTIVATION REQUEST DETAIL CLOSED."
        );
    }


    /* =========================================================
       11. QUEUE CLICK HANDLER
       ========================================================= */

    function handleQueueClick(event) {

        const button =
            event.target.closest(
                ".bk-master-view-request"
            );


        if (!button) {
            return;
        }


        const requestId =
            button.dataset.requestId;


        if (!requestId) {
            return;
        }


        openRequest(requestId);
    }


    /* =========================================================
       12. QUEUE EVENT BINDING
       ========================================================= */

    function bindQueueEvents() {

        const queue =
            document.getElementById(
                "bkMasterActivationRequestList"
            );


        if (!queue) {
            return false;
        }


        if (queue.__bkDetailBound) {
            return true;
        }


        queue.addEventListener(
            "click",
            handleQueueClick
        );


        queue.__bkDetailBound =
            true;


        console.log(
            "BK MASTER: ACTIVATION REQUEST DETAIL CLICK HANDLER BOUND."
        );


        return true;
    }


    /* =========================================================
       13. OPEN CONFIRMATION POPUP
       ========================================================= */

function openConfirmation(decisionType) {

        if (
            !state.confirmOverlay ||
            !state.confirmTitle ||
            !state.confirmMessage ||
            !state.confirmSubmitButton
        ) {
            return;
        }


        state.decisionType =
            decisionType;


        if (decisionType === "APPROVE") {

            state.confirmTitle.textContent =
                "Approve Activation Request?";


            state.confirmMessage.textContent =
                "Are you sure you want to approve this owner's activation request?";


            state.confirmSubmitButton.textContent =
                "Confirm Approve";


            state.confirmSubmitButton.classList.remove(
                "reject"
            );


            state.confirmSubmitButton.classList.add(
                "approve"
            );

        } else {

            state.confirmTitle.textContent =
                "Reject Activation Request?";


            state.confirmMessage.textContent =
                "Are you sure you want to reject this owner's activation request?";


            state.confirmSubmitButton.textContent =
                "Confirm Reject";


            state.confirmSubmitButton.classList.remove(
                "approve"
            );


            state.confirmSubmitButton.classList.add(
                "reject"
            );
        }


        state.confirmOverlay.classList.add(
            "is-open"
        );


        state.confirmOverlay.setAttribute(
            "aria-hidden",
            "false"
        );
    }


    /* =========================================================
       14. CLOSE CONFIRMATION POPUP
       ========================================================= */

    function closeConfirmation() {

        if (!state.confirmOverlay) {
            return;
        }


        state.confirmOverlay.classList.remove(
            "is-open"
        );


        state.confirmOverlay.setAttribute(
            "aria-hidden",
            "true"
        );


        state.decisionType = null;
    }


    /* =========================================================
       15. SHOW RESULT POPUP
       ========================================================= */

    function showResultPopup(
        type,
        title,
        message
    ) {

        if (
            !state.resultOverlay ||
            !state.resultTitle ||
            !state.resultMessage ||
            !state.resultIcon
        ) {
            return;
        }


        state.resultOverlay.classList.remove(
            "success",
            "failure"
        );


        if (type === "SUCCESS") {

            state.resultOverlay.classList.add(
                "success"
            );


            state.resultIcon.textContent =
                "✓";


            if (state.resultKicker) {

                state.resultKicker.textContent =
                    "BK MASTER • SUCCESS";
            }

        } else {

            state.resultOverlay.classList.add(
                "failure"
            );


            state.resultIcon.textContent =
                "×";


            if (state.resultKicker) {

                state.resultKicker.textContent =
                    "BK MASTER • ACTION FAILED";
            }
        }


        state.resultTitle.textContent =
            title;


        state.resultMessage.textContent =
            message;


        state.resultOverlay.classList.add(
            "is-open"
        );


        state.resultOverlay.setAttribute(
            "aria-hidden",
            "false"
        );
    }


    /* =========================================================
       16. CLOSE RESULT POPUP
       ========================================================= */

    function closeResultPopup() {

        if (!state.resultOverlay) {
            return;
        }


        state.resultOverlay.classList.remove(
            "is-open"
        );


        state.resultOverlay.setAttribute(
            "aria-hidden",
            "true"
        );
    }


    /* =========================================================
       17. CONFIRM DECISION ENGINE
       ========================================================= */

    async function confirmDecision() {

        if (
            !state.decisionType ||
            !state.selectedRequestId
        ) {
            return;
        }


        const decisionType =
            state.decisionType;


        const requestId =
            state.selectedRequestId;


        /* =====================================================
           MASTER AUTH CHECK
           ===================================================== */

        if (
            !window.BKMaster ||
            !window.BKMaster.state ||
            window.BKMaster.state.authorized !== true
        ) {

            console.error(
                "BK MASTER: AUTHORIZATION REQUIRED FOR REQUEST DECISION."
            );


            showResultPopup(
                "FAILURE",
                "Action Failed",
                "Master authorization is required to process this request."
            );


            return;
        }


        const masterUser =
            window.BKMaster.state.currentUser;


        const masterUid =
            masterUser
                ? masterUser.uid
                : null;


        if (!masterUid) {

            console.error(
                "BK MASTER: MASTER USER IDENTITY UNAVAILABLE."
            );


            showResultPopup(
                "FAILURE",
                "Action Failed",
                "Master user identity could not be verified."
            );


            return;
        }


        /* =====================================================
           PREVENT DOUBLE SUBMISSION
           ===================================================== */

        if (
            state.processingDecision === true
        ) {
            return;
        }


        state.processingDecision =
            true;


        if (state.confirmSubmitButton) {

            state.confirmSubmitButton.disabled =
                true;


            state.confirmSubmitButton.textContent =
                decisionType === "APPROVE"
                    ? "Approving..."
                    : "Rejecting...";
        }


        /* =====================================================
           OPERATION STEP
           Used for production failure message.
           ===================================================== */

        let operationStep =
            decisionType === "APPROVE"
                ? "Preparing approval"
                : "Preparing rejection";


        try {

            /* =================================================
               18. LOAD FIREBASE
               ================================================= */

            operationStep =
                "Loading Firebase";


            const firebaseCore =
                await import(
                    "../firebase.js"
                );


            const firestore =
                await import(
                    "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js"
                );


            const db =
                firebaseCore.db;


            const {
                doc,
                getDoc,
                updateDoc,
                serverTimestamp
            } = firestore;


            /* =================================================
               19. FRESH REQUEST READ
               ================================================= */

            operationStep =
                "Checking activation request";


            const requestRef =
                doc(
                    db,
                    "accountControlRequests",
                    requestId
                );


            const requestSnapshot =
                await getDoc(
                    requestRef
                );


            if (
                !requestSnapshot.exists()
            ) {

                throw new Error(
                    "Activation request no longer exists."
                );
            }


            const requestData =
                requestSnapshot.data() || {};


            /* =================================================
               20. REQUEST STATUS CHECK
               ================================================= */

            operationStep =
                "Checking request status";


            if (
                requestData.status !==
                "PENDING"
            ) {

                throw new Error(
                    `This request is already ${requestData.status || "processed"}.`
                );
            }


            /* =================================================
               21. RESTAURANT ID CHECK
               ================================================= */

            operationStep =
                "Checking restaurant information";


            const restaurantId =
                requestData.restaurantId;


            if (
                !restaurantId ||
                typeof restaurantId !== "string"
            ) {

                throw new Error(
                    "Restaurant ID is missing from activation request."
                );
            }


            /* =================================================
               22. APPROVE REQUEST
               ================================================= */

            if (
                decisionType === "APPROVE"
            ) {

                /* =============================================
                   EXISTING RESTAURANT CONTROL ENGINE
                   ============================================= */

                operationStep =
                    "Activating restaurant";


                const restaurantControl =
                    window.BKMasterRestaurantControl;


                if (
                    !restaurantControl ||
                    typeof restaurantControl.executeAction !==
                        "function"
                ) {

                    throw new Error(
                        "BK Master Restaurant Control engine is unavailable."
                    );
                }


                /* =============================================
                   APPROVAL REASON
                   ============================================= */

                const approvalReason =
                    requestData.masterReason ||
                    "Activation request approved by BK Master Control.";


                /* =============================================
                   EXECUTE EXISTING RESTAURANT ACTION
                   ============================================= */

                const actionResult =
                    await restaurantControl.executeAction(
                        restaurantId,
                        "ACTIVATE",
                        approvalReason
                    );


                if (
                    !actionResult ||
                    actionResult.success !== true
                ) {

                    throw new Error(
                        actionResult?.error ||
                        "Restaurant activation failed."
                    );
                }


                /* =============================================
                   MARK REQUEST APPROVED
                   ============================================= */

                operationStep =
                    "Finalizing activation request";


                await updateDoc(
                    requestRef,
                    {

                        status:
                            "APPROVED",

                        reviewedAt:
                            serverTimestamp(),

                        reviewedBy:
                            masterUid,

                        masterResponse:
                            "Activation request approved by BK Master Control."

                    }
                );


                /* =============================================
                   APPROVAL SUCCESS
                   ============================================= */

                closeConfirmation();

                closeModal();


                showResultPopup(
                    "SUCCESS",
                    "Approval Successful",
                    "The activation request was approved successfully. Restaurant status and Master Control records have been updated."
                );
            }


            /* =================================================
               23. REJECT REQUEST
               ================================================= */

            else if (
                decisionType === "REJECT"
            ) {

                operationStep =
                    "Finalizing rejection";


                await updateDoc(
                    requestRef,
                    {

                        status:
                            "REJECTED",

                        reviewedAt:
                            serverTimestamp(),

                        reviewedBy:
                            masterUid,

                        masterResponse:
                            "Activation request rejected by BK Master Control."

                    }
                );


                /* =============================================
                   REJECTION SUCCESS
                   ============================================= */

                closeConfirmation();

                closeModal();


                showResultPopup(
                    "SUCCESS",
                    "Request Rejected",
                    "The activation request was rejected successfully."
                );
            }


        } catch (error) {

            console.error(
                "BK MASTER: ACTIVATION REQUEST DECISION FAILED.",
                error
            );


            const errorMessage =
                error?.message ||
                String(error) ||
                "Unknown error";


            /* =============================================
               RESTORE CONFIRM BUTTON
               ============================================= */

            if (state.confirmSubmitButton) {

                state.confirmSubmitButton.disabled =
                    false;


                state.confirmSubmitButton.textContent =
                    decisionType === "APPROVE"
                        ? "Confirm Approve"
                        : "Confirm Reject";
            }


            /* =============================================
               SHOW PRODUCTION FAILURE POPUP
               ============================================= */

            closeConfirmation();


            showResultPopup(
                "FAILURE",
                decisionType === "APPROVE"
                    ? "Approval Failed"
                    : "Rejection Failed",
                `Failed at: ${operationStep}. ${errorMessage}`
            );


        } finally {

            state.processingDecision =
                false;
        }
    }


    /* =========================================================
       >>> PART 1 ENDS HERE
       ========================================================= */
           /* =========================================================
       24. EVENT BINDING
       ========================================================= */

    function bindEvents() {

        bindQueueEvents();


        /* =====================================================
           MAIN MODAL CLOSE BUTTON
           ===================================================== */

        if (
            state.closeButton &&
            !state.closeButton.__bkDetailBound
        ) {

            state.closeButton.addEventListener(
                "click",
                closeModal
            );


            state.closeButton.__bkDetailBound =
                true;
        }


        /* =====================================================
           FOOTER CLOSE BUTTON
           ===================================================== */

        if (
            state.footerCloseButton &&
            !state.footerCloseButton.__bkDetailBound
        ) {

            state.footerCloseButton.addEventListener(
                "click",
                closeModal
            );


            state.footerCloseButton.__bkDetailBound =
                true;
        }


        /* =====================================================
           APPROVE BUTTON
           ===================================================== */

        if (
            state.approveButton &&
            !state.approveButton.__bkDecisionBound
        ) {

            state.approveButton.addEventListener(
                "click",
                () => {

                    openConfirmation(
                        "APPROVE"
                    );

                }
            );


            state.approveButton.__bkDecisionBound =
                true;
        }


        /* =====================================================
           REJECT BUTTON
           ===================================================== */

        if (
            state.rejectButton &&
            !state.rejectButton.__bkDecisionBound
        ) {

            state.rejectButton.addEventListener(
                "click",
                () => {

                    openConfirmation(
                        "REJECT"
                    );

                }
            );


            state.rejectButton.__bkDecisionBound =
                true;
        }


        /* =====================================================
           CONFIRM CANCEL BUTTON
           ===================================================== */

        if (
            state.confirmCancelButton &&
            !state.confirmCancelButton.__bkConfirmCancelBound
        ) {

            state.confirmCancelButton.addEventListener(
                "click",
                closeConfirmation
            );


            state.confirmCancelButton.__bkConfirmCancelBound =
                true;
        }


        /* =====================================================
           CONFIRM SUBMIT BUTTON
           ===================================================== */

        if (
            state.confirmSubmitButton &&
            !state.confirmSubmitButton.__bkConfirmSubmitBound
        ) {

            state.confirmSubmitButton.addEventListener(
                "click",
                confirmDecision
            );


            state.confirmSubmitButton.__bkConfirmSubmitBound =
                true;
        }


        /* =====================================================
           RESULT POPUP CONTINUE BUTTON
           ===================================================== */

        if (
            state.resultCloseButton &&
            !state.resultCloseButton.__bkResultCloseBound
        ) {

            state.resultCloseButton.addEventListener(
                "click",
                closeResultPopup
            );


            state.resultCloseButton.__bkResultCloseBound =
                true;
        }


        /* =====================================================
           MODAL BACKDROP
           ===================================================== */

        if (
            state.modal &&
            !state.modal.__bkBackdropBound
        ) {

            state.modal.addEventListener(
                "click",
                event => {

                    if (
                        event.target.dataset
                            .requestModalClose === "true"
                    ) {

                        closeModal();
                    }
                }
            );


            state.modal.__bkBackdropBound =
                true;
        }


        /* =====================================================
           ESCAPE KEY
           ===================================================== */

        if (
            !document.__bkRequestModalEscapeBound
        ) {

            document.addEventListener(
                "keydown",
                event => {

                    if (
                        event.key === "Escape" &&
                        state.open
                    ) {

                        closeModal();
                    }
                }
            );


            document.__bkRequestModalEscapeBound =
                true;
        }


        /* =====================================================
           REALTIME QUEUE UPDATE
           ===================================================== */

        window.addEventListener(
            "bk:master:activationRequestsUpdated",
            () => {

                bindQueueEvents();
            }
        );
    }


    /* =========================================================
       25. INITIALIZATION
       ========================================================= */

    function init() {

        if (state.initialized) {
            return;
        }


        const created =
            createModal();


        if (!created) {

            console.error(
                "BK MASTER: ACTIVATION REQUEST DETAIL MODAL CREATION FAILED."
            );

            return;
        }


        cacheElements();

        bindEvents();


        state.initialized =
            true;


        state.ready =
            true;


        console.log(
            "=========================================="
        );


        console.log(
            "BK MASTER: ACTIVATION REQUEST DETAIL"
        );


        console.log(
            "Part 4A-1: READY"
        );


        console.log(
            "View Request Handler: READY"
        );


        console.log(
            "Detail Renderer: READY"
        );


        console.log(
            "Modal Controller: READY"
        );


        console.log(
            "Approve/Reject Engine: INCLUDED"
        );


        console.log(
            "=========================================="
        );
    }


    /* =========================================================
       26. PUBLIC API
       ========================================================= */

    window.BKMasterActivationRequestDetail = {

        state,

        init,

        openRequest,

        closeModal,


        getSelectedRequestId() {

            return state.selectedRequestId;
        },


        getState() {

            return {

                initialized:
                    state.initialized,

                ready:
                    state.ready,

                open:
                    state.open,

                selectedRequestId:
                    state.selectedRequestId
            };
        }
    };


    /* =========================================================
       27. DOM READY
       ========================================================= */

    if (
        document.readyState ===
        "loading"
    ) {

        document.addEventListener(
            "DOMContentLoaded",
            init,
            { once: true }
        );

    } else {

        init();
    }


    /* =========================================================
       END OF ACTIVATION REQUEST DETAIL ENGINE
       ========================================================= */

})();