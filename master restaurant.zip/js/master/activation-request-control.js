/* =====================================================
   BK MASTER CONTROL
   PART 1 — ACTIVATION REQUEST CONTROL ENGINE
   Version: 1.0.1
====================================================== */

"use strict";


/* =================================================
   1. FIREBASE
================================================= */

import {
    masterAuth as auth,
    masterDb as db
} from "../firebase-sessions.js";

import {
    doc,
    getDoc,
    collection,
    onSnapshot,
    query,
    where
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";


/* =================================================
   2. BK MASTER ACTIVATION REQUEST ENGINE
================================================= */

(() => {


    /* =================================================
       STATE
    ================================================= */

    const state = {

        initialized: false,

        ready: false,

        listening: false,

        loading: false,

        error: null,

        pendingCount: 0,

        requests: [],

        lastSyncedAt: null,

        unsubscribe: null

    };


    /* =================================================
       CONSTANTS
    ================================================= */

    const REQUEST_COLLECTION =
        "accountControlRequests";


    const REQUEST_TYPE =
        "ACTIVATION";


    const REQUEST_STATUS =
        "PENDING";


    /* =================================================
       NORMALIZE REQUEST
    ================================================= */

    function normalizeRequest(
        documentSnapshot
    ) {

        const data =
            documentSnapshot.data() || {};


        return {

            requestId:
                documentSnapshot.id,

            restaurantId:
                data.restaurantId || null,

            ownerId:
                data.ownerId || null,

            requestType:
                data.requestType || null,

            status:
                data.status || null,

            ownerReason:
                data.ownerReason || "",

            masterAction:
                data.masterAction || "NONE",

            masterReason:
                data.masterReason || null,

            masterActionAt:
                data.masterActionAt || null,

            accountStatus:
                data.accountStatus || null,

            createdAt:
                data.createdAt || null,

            reviewedAt:
                data.reviewedAt || null,

            reviewedBy:
                data.reviewedBy || null,

            masterResponse:
                data.masterResponse || null

        };

    }


    /* =================================================
       WAIT FOR MASTER AUTH
    ================================================= */

async function waitForMasterAuth(
    maxAttempts = 100
) {

    /* =========================================
       FIRST: CHECK CURRENT AUTH STATE
    ========================================= */

    if (auth.currentUser) {

        return auth.currentUser;

    }


    /* =========================================
       WAIT FOR FIREBASE AUTH STATE TO SETTLE
    ========================================= */

    return new Promise(
        (resolve, reject) => {

            let attempts = 0;

            let unsubscribe = null;


            const cleanup = () => {

                if (
                    typeof unsubscribe ===
                    "function"
                ) {

                    unsubscribe();

                }

            };


            unsubscribe =
                auth.onAuthStateChanged(
                    (user) => {

                        if (user) {

                            cleanup();

                            resolve(user);

                        }

                    }
                );


            const timer =
                setInterval(
                    () => {

                        attempts++;


                        if (
                            auth.currentUser
                        ) {

                            clearInterval(timer);

                            cleanup();

                            resolve(
                                auth.currentUser
                            );

                            return;

                        }


                        if (
                            attempts >=
                            maxAttempts
                        ) {

                            clearInterval(timer);

                            cleanup();

                            reject(
                                new Error(
                                    "MASTER_AUTH_TIMEOUT"
                                )
                            );

                        }

                    },
                    100
                );

        }
    );

}

    /* =================================================
       VERIFY MASTER ACCESS
    ================================================= */

    async function verifyMasterAccess() {

        const user =
            await waitForMasterAuth();
            console.log(
    "BK MASTER DEBUG: MASTER AUTH VERIFIED",
    {
        uid:
            user?.uid || null,

        email:
            user?.email || null
    }
);


        const masterRef =
            doc(
                db,
                "masterAdmins",
                user.uid
            );


        const masterSnapshot =
            await getDoc(
                masterRef
            );
            
console.log(
    "BK MASTER DEBUG: MASTER ADMIN READ",
    {
        exists:
            masterSnapshot.exists(),

        uid:
            user.uid
    }
);

        if (
            !masterSnapshot.exists()
        ) {

            throw new Error(
                "MASTER_ACCESS_DENIED"
            );

        }


        const masterData =
            masterSnapshot.data() || {};


        if (
            masterData.status !==
            "ACTIVE"
        ) {

            throw new Error(
                "MASTER_ACCOUNT_INACTIVE"
            );

        }


        return {

            success: true,

            uid:
                user.uid

        };

    }


    /* =================================================
       START REALTIME LISTENER
    ================================================= */
    

    async function startListener() {


        if (
            state.listening
        ) {

            return {

                success: true,

                alreadyListening: true

            };

        }


        if (
            state.loading
        ) {

            return {

                success: false,

                error:
                    "REQUEST_ENGINE_ALREADY_LOADING"

            };

        }


        state.loading =
            true;
            
console.log(
    "BK MASTER DEBUG: ACTIVATION LISTENER STARTING",
    {
        authUser: auth.currentUser
            ? auth.currentUser.uid
            : null,

        authReady:
            !!auth.currentUser
    }
);

        state.error =
            null;


        try {


            /* =========================================
               MASTER AUTH
            ========================================= */

            const master =
                await verifyMasterAccess();


            /* =========================================
               FIRESTORE QUERY
            ========================================= */

            const requestQuery =
                query(

                    collection(
                        db,
                        REQUEST_COLLECTION
                    ),

                    where(
                        "requestType",
                        "==",
                        REQUEST_TYPE
                    ),

                    where(
                        "status",
                        "==",
                        REQUEST_STATUS
                    )

                );


            /* =========================================
               REALTIME LISTENER
            ========================================= */
            console.log(
    "BK MASTER DEBUG: ATTACHING ACTIVATION REQUEST SNAPSHOT"
);

            state.unsubscribe =
                onSnapshot(

                    requestQuery,


                    /* =================================
                       SNAPSHOT SUCCESS
                    ================================= */

                    (snapshot) => {


                        const requests =
                            snapshot.docs.map(
                                normalizeRequest
                            );


                        state.requests =
                            requests;


                        state.pendingCount =
                            requests.length;


                        state.lastSyncedAt =
                            new Date();


                        state.loading =
                            false;


                        state.listening =
                            true;


                        state.ready =
                            true;


                        state.error =
                            null;


                        /* =============================
                           PUBLIC EVENT
                        ============================= */

                        window.dispatchEvent(

                            new CustomEvent(

                                "bk:master:activationRequestsUpdated",

                                {

                                    detail: {

                                        requests:
                                            requests,

                                        pendingCount:
                                            requests.length,

                                        masterUid:
                                            master.uid

                                    }

                                }

                            )

                        );


                        console.log(
                            "BK MASTER: ACTIVATION REQUESTS UPDATED.",
                            requests.length
                        );

                    },


                    /* =================================
                       SNAPSHOT ERROR
                    ================================= */

                    (error) => {
                        console.error(
    "BK MASTER DEBUG: SNAPSHOT ERROR DETAILS",
    {
        code:
            error?.code || null,

        message:
            error?.message || null,

        name:
            error?.name || null
    }
);


                        state.loading =
                            false;


                        state.listening =
                            false;


                        state.ready =
                            false;


                        state.error =
                            error?.message ||
                            "REQUEST_LISTENER_FAILED";


                        console.error(
                            "BK MASTER: ACTIVATION REQUEST LISTENER FAILED.",
                            error
                        );

                    }
                    

                );


            return {

                success: true

            };


        } catch (error) {


            state.loading =
                false;


            state.ready =
                false;


            state.listening =
                false;


            state.error =
                error?.message ||
                "MASTER_REQUEST_ENGINE_FAILED";


            console.error(
                "BK MASTER: ACTIVATION REQUEST ENGINE FAILED.",
                error
            );


            return {

                success: false,

                error:
                    state.error

            };

        }

    }


    /* =================================================
       GET REQUESTS
    ================================================= */

    function getRequests() {

        return [
            ...state.requests
        ];

    }


    /* =================================================
       GET PENDING COUNT
    ================================================= */

    function getPendingCount() {

        return state.pendingCount;

    }


    /* =================================================
       GET ENGINE STATE
    ================================================= */

    function getState() {

        return {

            initialized:
                state.initialized,

            ready:
                state.ready,

            listening:
                state.listening,

            loading:
                state.loading,

            error:
                state.error,

            pendingCount:
                state.pendingCount,

            requestCount:
                state.requests.length,

            lastSyncedAt:
                state.lastSyncedAt

        };

    }


    /* =================================================
       GET REQUEST BY ID
    ================================================= */

    function getRequest(
        requestId
    ) {


        if (!requestId) {

            return null;

        }


        return (

            state.requests.find(

                request =>

                    request.requestId ===
                    requestId

            ) || null

        );

    }


    /* =================================================
       STOP LISTENER
    ================================================= */

    function stopListener() {


        if (
            typeof state.unsubscribe ===
            "function"
        ) {

            state.unsubscribe();

        }


        state.unsubscribe =
            null;


        state.listening =
            false;


        state.ready =
            false;


        state.loading =
            false;

    }


    /* =================================================
       PUBLIC API
    ================================================= */

    window.BKMasterActivationRequests = {

        state,

        REQUEST_COLLECTION,

        REQUEST_TYPE,

        REQUEST_STATUS,

        startListener,

        stopListener,

        getRequests,

        getPendingCount,

        getRequest,

        getState

    };


    /* =================================================
       INITIALIZE
    ================================================= */

    state.initialized =
        true;


    console.log(
        "=========================================="
    );


    console.log(
        "BK MASTER: ACTIVATION REQUEST ENGINE"
    );


    console.log(
        "Part 1: READY"
    );


    console.log(
        "Collection:",
        REQUEST_COLLECTION
    );


    console.log(
        "Request Type:",
        REQUEST_TYPE
    );


    console.log(
        "Status Filter:",
        REQUEST_STATUS
    );


    console.log(
        "Firebase Bridge: READY"
    );


    console.log(
        "Master Auth Wait: READY"
    );


    console.log(
        "Realtime Listener: READY"
    );


    console.log(
        "=========================================="
    );


})();