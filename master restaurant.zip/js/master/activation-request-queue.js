/* =====================================================
   BK MASTER CONTROL
   PART 2 — ACTIVATION REQUEST QUEUE + SEARCH
   Version: 1.2.0
====================================================== */

import {
    masterDb as db
} from "../firebase-sessions.js";

import {
    doc,
    getDoc
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";

"use strict";


/* =====================================================
   BK MASTER ACTIVATION REQUEST QUEUE
====================================================== */

(() => {

    /* =================================================
       1. STATE
    ================================================= */

    const state = {

        initialized: false,

        ready: false,

        visible: false,

        starting: false,

        selectedRequestId: null,

        lastRenderedCount: 0,

        totalPendingCount: 0,

        searchQuery: "",

        profileCache: new Map(),

        panel: null,

        count: null,

        list: null,

        empty: null,

        searchInput: null,

        clearSearchButton: null,

        searchStatus: null

    };


    /* =================================================
       2. GET REQUEST ENGINE
    ================================================= */

    function getRequestEngine() {

        return (
            window.BKMasterActivationRequests ||
            null
        );

    }


    /* =================================================
       3. CREATE QUEUE PANEL
    ================================================= */

    function createQueuePanel() {

        const overviewSection =
            document.getElementById(
                "masterSectionOverview"
            );


        if (!overviewSection) {

            return false;

        }


        if (
            document.getElementById(
                "bkMasterActivationRequestPanel"
            )
        ) {

            return true;

        }


        const panel =
            document.createElement("div");


        panel.id =
            "bkMasterActivationRequestPanel";


        panel.className =
            "master-panel bk-master-activation-panel";


        panel.innerHTML = `

            <div class="master-panel-header">

                <div>

                    <span class="master-panel-kicker">
                        ACCOUNT CONTROL
                    </span>

                    <h3>
                        Activation Requests
                    </h3>

                    <p>
                        Review and search pending owner activation requests.
                    </p>

                </div>

                <div
                    class="bk-master-request-count"
                    id="bkMasterActivationRequestCount"
                >
                    0 Pending
                </div>

            </div>


            <div class="bk-master-request-search">

                <div class="bk-master-request-search-field">

                    <span
                        class="bk-master-search-icon"
                        aria-hidden="true"
                    >
                        🔎
                    </span>

                    <input
                        type="search"
                        id="bkMasterActivationRequestSearch"
                        placeholder="Search Restaurant ID, Owner ID, Request ID..."
                        autocomplete="off"
                        spellcheck="false"
                    >

                </div>


                <button
                    type="button"
                    id="bkMasterActivationRequestClearSearch"
                    class="bk-master-request-clear-search"
                    hidden
                >
                    Clear
                </button>

            </div>


            <div
                class="bk-master-request-search-status"
                id="bkMasterActivationRequestSearchStatus"
                aria-live="polite"
            >
                Showing all pending requests
            </div>


            <div
                class="bk-master-activation-request-list"
                id="bkMasterActivationRequestList"
            >

                <div
                    class="master-empty-state"
                    id="bkMasterActivationRequestEmpty"
                >

                    <strong>
                        No pending activation requests
                    </strong>

                    <span>
                        New owner activation requests will appear here.
                    </span>

                </div>

            </div>

        `;


        overviewSection.appendChild(
            panel
        );


        return true;

    }


    /* =================================================
       4. CACHE ELEMENTS
    ================================================= */

    function cacheElements() {

        state.panel =
            document.getElementById(
                "bkMasterActivationRequestPanel"
            );


        state.count =
            document.getElementById(
                "bkMasterActivationRequestCount"
            );


        state.list =
            document.getElementById(
                "bkMasterActivationRequestList"
            );


        state.empty =
            document.getElementById(
                "bkMasterActivationRequestEmpty"
            );


        state.searchInput =
            document.getElementById(
                "bkMasterActivationRequestSearch"
            );


        state.clearSearchButton =
            document.getElementById(
                "bkMasterActivationRequestClearSearch"
            );


        state.searchStatus =
            document.getElementById(
                "bkMasterActivationRequestSearchStatus"
            );

    }


    /* =================================================
       5. FORMAT DATE
    ================================================= */

    function formatRequestDate(timestamp) {

        if (!timestamp) {

            return "Pending timestamp";

        }


        try {

            let date = null;


            if (
                timestamp &&
                typeof timestamp.toDate ===
                "function"
            ) {

                date =
                    timestamp.toDate();

            } else if (
                timestamp instanceof Date
            ) {

                date =
                    timestamp;

            } else if (
                typeof timestamp === "string"
            ) {

                date =
                    new Date(timestamp);

            } else if (
                timestamp &&
                typeof timestamp.seconds === "number"
            ) {

                date =
                    new Date(
                        timestamp.seconds * 1000
                    );

            }


            if (
                !date ||
                Number.isNaN(
                    date.getTime()
                )
            ) {

                return "Pending timestamp";

            }


            return date.toLocaleString(
                undefined,
                {
                    dateStyle: "medium",
                    timeStyle: "short"
                }
            );

        } catch (error) {

            return "Pending timestamp";

        }

    }


    /* =================================================
       6. HTML ESCAPE
    ================================================= */

    function escapeHTML(value) {

        const text =
            String(
                value ?? ""
            );


        return text
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");

    }


    /* =================================================
       7. NORMALIZE SEARCH VALUE
    ================================================= */

    function normalizeSearchValue(value) {

        return String(
            value ?? ""
        )
            .trim()
            .toLowerCase();

    }


    /* =================================================
       8. MATCH REQUEST SEARCH
    ================================================= */

    function requestMatchesSearch(
        request,
        searchQuery
    ) {

        if (!searchQuery) {

            return true;

        }


        const fields = [

            request.requestId,

            request.restaurantId,

            request.restaurantName,

            request.ownerId,

            request.ownerName,

            request.masterAction,

            request.ownerReason,

            request.masterReason,

            request.accountStatus,

            request.status

        ];


        return fields.some(
            value =>
                normalizeSearchValue(
                    value
                ).includes(
                    searchQuery
                )
        );

    }


    /* =================================================
       9. FILTER REQUESTS
    ================================================= */

    function filterRequests(requests) {

        const safeRequests =
            Array.isArray(requests)
                ? requests
                : [];


        const searchQuery =
            normalizeSearchValue(
                state.searchQuery
            );


        if (!searchQuery) {

            return [
                ...safeRequests
            ];

        }


        return safeRequests.filter(
            request =>
                requestMatchesSearch(
                    request,
                    searchQuery
                )
        );

    }


    /* =================================================
       10. LOAD REQUEST PROFILE
    ================================================= */

    async function getRequestProfile(request) {

        const restaurantId =
            request?.restaurantId || "";

        const ownerId =
            request?.ownerId || "";


        const cacheKey =
            `${restaurantId}__${ownerId}`;


        if (
            state.profileCache.has(
                cacheKey
            )
        ) {

            const cached =
                state.profileCache.get(
                    cacheKey
                );


            request.restaurantName =
                cached.restaurantName;

            request.ownerName =
                cached.ownerName;


            return cached;

        }


        const profile = {

            restaurantName:
                "Unknown Restaurant",

            ownerName:
                "Unknown Owner"

        };


        /*
         * Restaurant profile
         */

        if (restaurantId) {

            try {

                const restaurantSnapshot =
                    await getDoc(
                        doc(
                            db,
                            "restaurants",
                            restaurantId
                        )
                    );


                if (
                    restaurantSnapshot.exists()
                ) {

                    const restaurantData =
                        restaurantSnapshot.data();


                    profile.restaurantName =
                        restaurantData.name ||
                        "Unknown Restaurant";

                }

            } catch (error) {

                console.error(
                    "BK MASTER: RESTAURANT PROFILE LOAD FAILED.",
                    error
                );

            }

        }


        /*
         * Owner profile
         */

        if (ownerId) {

            try {

                const ownerSnapshot =
                    await getDoc(
                        doc(
                            db,
                            "users",
                            ownerId
                        )
                    );


                if (
                    ownerSnapshot.exists()
                ) {

                    const ownerData =
                        ownerSnapshot.data();


                    profile.ownerName =
                        ownerData.ownerName ||
                        "Unknown Owner";

                }

            } catch (error) {

                console.error(
                    "BK MASTER: OWNER PROFILE LOAD FAILED.",
                    error
                );

            }

        }


        request.restaurantName =
            profile.restaurantName;


        request.ownerName =
            profile.ownerName;


        state.profileCache.set(
            cacheKey,
            profile
        );


        return profile;

    }


    /* =================================================
       11. CREATE REQUEST CARD
    ================================================= */

    async function createRequestCard(request) {

        const card =
            document.createElement("article");


        card.className =
            "bk-master-activation-request-card";


        card.dataset.requestId =
            request.requestId || "";


        const masterReason =
            request.masterReason ||
            "No Master reason recorded.";


        const ownerReason =
            request.ownerReason ||
            "No owner response provided.";


        const profile =
            await getRequestProfile(
                request
            );


        card.innerHTML = `

            <div class="bk-master-request-card-top">

                <div>

                    <span class="bk-master-request-badge">
                        PENDING
                    </span>

                    <h4>
                        Activation Request
                    </h4>

                </div>

                <span class="bk-master-request-date">
                    ${formatRequestDate(
                        request.createdAt
                    )}
                </span>

            </div>


            <div class="bk-master-request-details">


                <div class="bk-master-request-detail">

                    <span>
                        Restaurant Name
                    </span>

                    <strong>
                        ${escapeHTML(
                            profile.restaurantName
                        )}
                    </strong>

                </div>


                <div class="bk-master-request-detail">

                    <span>
                        Owner Name
                    </span>

                    <strong>
                        ${escapeHTML(
                            profile.ownerName
                        )}
                    </strong>

                </div>


                <div class="bk-master-request-detail">

                    <span>
                        Restaurant ID
                    </span>

                    <strong>
                        ${escapeHTML(
                            request.restaurantId ||
                            "Unknown"
                        )}
                    </strong>

                </div>


                <div class="bk-master-request-detail">

                    <span>
                        Owner ID
                    </span>

                    <strong>
                        ${escapeHTML(
                            request.ownerId ||
                            "Unknown"
                        )}
                    </strong>

                </div>


                <div class="bk-master-request-detail">

                    <span>
                        Account Status
                    </span>

                    <strong>
                        ${escapeHTML(
                            request.accountStatus ||
                            "UNKNOWN"
                        )}
                    </strong>

                </div>


                <div class="bk-master-request-detail">

                    <span>
                        Master Action
                    </span>

                    <strong>
                        ${escapeHTML(
                            request.masterAction ||
                            "NONE"
                        )}
                    </strong>

                </div>

            </div>


            <div class="bk-master-request-message">

                <span>
                    OWNER RESPONSE
                </span>

                <p>
                    ${escapeHTML(
                        ownerReason
                    )}
                </p>

            </div>


            <div class="bk-master-request-message master-reason">

                <span>
                    MASTER REASON
                </span>

                <p>
                    ${escapeHTML(
                        masterReason
                    )}
                </p>

            </div>


            <div class="bk-master-request-actions">

                <button
                    type="button"
                    class="master-restaurant-control-button primary bk-master-view-request"
                    data-request-id="${escapeHTML(
                        request.requestId || ""
                    )}"
                >
                    View Request
                </button>

            </div>

        `;


        return card;

    }


    /* =================================================
       12. UPDATE SEARCH UI
    ================================================= */

    function updateSearchUI(
        totalCount,
        visibleCount
    ) {

        if (state.clearSearchButton) {

            state.clearSearchButton.hidden =
                !state.searchQuery;

        }


        if (!state.searchStatus) {

            return;

        }


        if (!state.searchQuery) {

            state.searchStatus.textContent =
                `Showing all ${totalCount} pending request${
                    totalCount === 1
                        ? ""
                        : "s"
                }`;

            return;

        }


        state.searchStatus.textContent =
            `Showing ${visibleCount} of ${totalCount} pending request${
                totalCount === 1
                    ? ""
                    : "s"
            }`;

    }


    /* =================================================
       13. RENDER REQUESTS
    ================================================= */

async function renderRequests(requests) {

        if (!state.list) {

            return;

        }


        const safeRequests =
            Array.isArray(requests)
                ? requests
                : [];


        state.totalPendingCount =
            safeRequests.length;


        const filteredRequests =
            filterRequests(
                safeRequests
            );


        state.lastRenderedCount =
            filteredRequests.length;


        if (state.count) {

            state.count.textContent =
                `${safeRequests.length} Pending`;

        }


        updateSearchUI(
            safeRequests.length,
            filteredRequests.length
        );


        /*
         * Clear current cards first.
         */

        state.list.innerHTML = "";


        if (
            filteredRequests.length === 0
        ) {

            const empty =
                document.createElement("div");


            empty.className =
                "master-empty-state";


            if (
                state.searchQuery &&
                safeRequests.length > 0
            ) {

                empty.innerHTML = `

                    <strong>
                        No matching requests
                    </strong>

                    <span>
                        Try another Restaurant ID, Owner ID, or Request ID.
                    </span>

                `;

            } else {

                empty.innerHTML = `

                    <strong>
                        No pending activation requests
                    </strong>

                    <span>
                        New owner activation requests will appear here.
                    </span>

                `;

            }


            state.list.appendChild(
                empty
            );


            return;

        }


        /*
         * Build cards safely before adding them.
         */

        const cards = [];


        for (
            const request of filteredRequests
        ) {

            try {

                const card =
                    await createRequestCard(
                        request
                    );


                if (card) {

                    cards.push(card);

                }

            } catch (error) {

                console.error(
                    "BK MASTER: REQUEST CARD CREATION FAILED.",
                    error
                );

            }

        }


        /*
         * Prevent stale async render from
         * affecting an empty/replaced queue.
         */

        if (!state.list) {

            return;

        }


        cards.forEach(
            card => {

                state.list.appendChild(
                    card
                );

            }
        );

    }


    /* =================================================
       14. GET CURRENT REQUESTS
    ================================================= */

    function getCurrentRequests() {

        const engine =
            getRequestEngine();


        if (!engine) {

            return [];

        }


        if (
            typeof engine.getRequests !==
            "function"
        ) {

            return [];

        }


        return engine.getRequests();

    }


    /* =================================================
       15. APPLY SEARCH
    ================================================= */

    function applySearch() {

        state.searchQuery =
            state.searchInput
                ? state.searchInput.value
                : "";


        renderRequests(
            getCurrentRequests()
        );

    }


    /* =================================================
       16. CLEAR SEARCH
    ================================================= */

    function clearSearch() {

        state.searchQuery =
            "";


        if (state.searchInput) {

            state.searchInput.value =
                "";

        }


        renderRequests(
            getCurrentRequests()
        );


        if (state.searchInput) {

            state.searchInput.focus();

        }

    }
        /* =================================================
       17. UPDATE OVERVIEW PENDING STAT
    ================================================= */

    function updateOverviewPendingStat(count) {

        const element =
            document.getElementById(
                "masterPendingRequests"
            );


        if (!element) {

            return;

        }


        element.textContent =
            String(
                count || 0
            );

    }


    /* =================================================
       18. REQUEST UPDATE HANDLER
    ================================================= */

    function handleRequestsUpdated(event) {

        const detail =
            event?.detail || {};


        const requests =
            Array.isArray(
                detail.requests
            )
                ? detail.requests
                : [];


        const count =
            Number(
                detail.pendingCount ??
                requests.length
            );


        updateOverviewPendingStat(
            count
        );


        renderRequests(
            requests
        );


        state.ready =
            true;


        state.visible =
            true;

    }


    /* =================================================
       19. VIEW REQUEST
    ================================================= */

    function handleViewRequest(requestId) {

        if (!requestId) {

            return;

        }


        const engine =
            getRequestEngine();


        if (!engine) {

            console.error(
                "BK MASTER: ACTIVATION REQUEST ENGINE NOT AVAILABLE."
            );

            return;

        }


        if (
            typeof engine.getRequest !==
            "function"
        ) {

            console.error(
                "BK MASTER: REQUEST ENGINE API INVALID."
            );

            return;

        }


        const request =
            engine.getRequest(
                requestId
            );


        if (!request) {

            console.warn(
                "BK MASTER: REQUEST NOT FOUND:",
                requestId
            );

            return;

        }


        state.selectedRequestId =
            requestId;


        console.log(
            "BK MASTER: ACTIVATION REQUEST SELECTED.",
            request
        );


        /*
         * Detail module handles the actual modal.
         * This fallback keeps queue compatible with
         * the existing detail engine.
         */

        if (
            window.BKMasterActivationRequestDetail &&
            typeof
                window.BKMasterActivationRequestDetail
                    .openRequest ===
                "function"
        ) {

            window.BKMasterActivationRequestDetail
                .openRequest(
                    requestId
                );

        }

    }


    /* =================================================
       20. BIND SEARCH EVENTS
    ================================================= */

    function bindSearchEvents() {

        if (
            state.searchInput &&
            !state.searchInput.__bkSearchBound
        ) {

            state.searchInput.addEventListener(
                "input",
                applySearch
            );


            state.searchInput.__bkSearchBound =
                true;

        }


        if (
            state.clearSearchButton &&
            !state.clearSearchButton.__bkClearBound
        ) {

            state.clearSearchButton.addEventListener(
                "click",
                clearSearch
            );


            state.clearSearchButton.__bkClearBound =
                true;

        }

    }


    /* =================================================
       21. BIND QUEUE EVENTS
    ================================================= */

    function bindQueueEvents() {

        if (!state.list) {

            return;

        }


        if (
            state.list.__bkActivationQueueBound
        ) {

            return;

        }


        state.list.addEventListener(
            "click",
            event => {

                const button =
                    event.target.closest(
                        ".bk-master-view-request"
                    );


                if (!button) {

                    return;

                }


                handleViewRequest(
                    button.dataset.requestId
                );

            }
        );


        state.list.__bkActivationQueueBound =
            true;

    }


    /* =================================================
       22. START QUEUE
    ================================================= */

    async function start() {

        if (state.starting) {

            return;

        }


        if (state.initialized) {

            return;

        }


        state.starting =
            true;


        try {

            const created =
                createQueuePanel();


            if (!created) {

                throw new Error(
                    "ACTIVATION_REQUEST_QUEUE_PANEL_NOT_FOUND"
                );

            }


            cacheElements();


            bindSearchEvents();

            bindQueueEvents();


            /*
             * Listen for realtime updates BEFORE
             * starting the Firestore listener.
             */

            if (
                !window.__bkActivationQueueUpdateBound
            ) {

                window.addEventListener(
                    "bk:master:activationRequestsUpdated",
                    handleRequestsUpdated
                );


                window.__bkActivationQueueUpdateBound =
                    true;

            }


            /*
             * Wait briefly for Part 1 engine
             * to become available.
             *
             * This does NOT start another listener.
             */

            let engine = null;


            for (
                let attempt = 0;
                attempt < 100;
                attempt++
            ) {

                engine =
                    getRequestEngine();


                if (engine) {

                    break;

                }


                await new Promise(
                    resolve =>
                        setTimeout(
                            resolve,
                            100
                        )
                );

            }


            if (!engine) {

                throw new Error(
                    "ACTIVATION_REQUEST_ENGINE_NOT_AVAILABLE"
                );

            }


            /*
             * Start Firestore listener only when
             * Part 1 says it is not already listening.
             */

            if (
                !engine.state ||
                !engine.state.listening
            ) {

                if (
                    typeof engine.startListener !==
                    "function"
                ) {

                    throw new Error(
                        "ACTIVATION_REQUEST_START_LISTENER_NOT_AVAILABLE"
                    );

                }


                const listenerResult =
                    await engine.startListener();


                if (
                    !listenerResult ||
                    listenerResult.success !== true
                ) {

                    console.error(
                        "BK MASTER: ACTIVATION REQUEST LISTENER FAILED.",
                        listenerResult
                    );


                    state.starting =
                        false;


                    return;

                }

            }


            /*
             * Render current engine data.
             */

            const currentRequests =
                getCurrentRequests();


            await renderRequests(
                currentRequests
            );


            if (
                typeof engine.getPendingCount ===
                "function"
            ) {

                updateOverviewPendingStat(
                    engine.getPendingCount()
                );

            } else {

                updateOverviewPendingStat(
                    currentRequests.length
                );

            }


            state.initialized =
                true;


            state.ready =
                true;


            state.visible =
                true;


            console.log(
                "=========================================="
            );


            console.log(
                "BK MASTER: ACTIVATION REQUEST QUEUE"
            );


            console.log(
                "Part 2: READY"
            );


            console.log(
                "Pending Requests:",
                currentRequests.length
            );


            console.log(
                "Search Engine: READY"
            );


            console.log(
                "=========================================="
            );

        } catch (error) {

            console.error(
                "BK MASTER: ACTIVATION REQUEST QUEUE START FAILED.",
                error
            );


            state.ready =
                false;


            state.visible =
                false;

        } finally {

            state.starting =
                false;

        }

    }


    /* =================================================
       23. PUBLIC API
    ================================================= */

    window.BKMasterActivationRequestQueue = {

        state,

        start,

        renderRequests,

        applySearch,

        clearSearch,

        getSelectedRequestId() {

            return state.selectedRequestId;

        },

        getSearchQuery() {

            return state.searchQuery;

        },

        getState() {

            return {

                initialized:
                    state.initialized,

                ready:
                    state.ready,

                visible:
                    state.visible,

                starting:
                    state.starting,

                selectedRequestId:
                    state.selectedRequestId,

                lastRenderedCount:
                    state.lastRenderedCount,

                totalPendingCount:
                    state.totalPendingCount,

                searchQuery:
                    state.searchQuery

            };

        }

    };


    /* =================================================
       24. DOM START
    ================================================= */

    function initializeQueue() {

        start();

    }


    if (
        document.readyState ===
        "loading"
    ) {

        document.addEventListener(
            "DOMContentLoaded",
            initializeQueue,
            {
                once: true
            }
        );

    } else {

        initializeQueue();

    }


})();