/* ============================================================
   BK PREMIUM RESTAURANT PLATFORM
   MASTER DASHBOARD
   MODULE: PLATFORM COST & PRICING UI
   VERSION: 1.0.0

   RESPONSIBILITIES:
   - Load saved pricing
   - Render pricing table
   - Search and category filtering
   - Validate edited values
   - Save using revision protection
   - Prevent accidental stale overwrites

   IMPORTANT:
   This module does not publish bills or charge restaurants.
============================================================ */

(() => {
    "use strict";

    const MODULE_NAME = "BKPlatformPricingUI";
    const MODULE_VERSION = "1.0.0";

    const REQUIRED_IDS = [
        "bkPlatformPricingPanel",
        "bkPlatformPricingStatus",
        "bkPlatformPricingServiceCount",
        "bkPlatformPricingEnabledCount",
        "bkPlatformPricingRevision",
        "bkPlatformPricingSearch",
        "bkPlatformPricingCategory",
        "bkPlatformPricingTableBody",
        "bkPlatformPricingReload",
        "bkPlatformPricingSave",
        "bkPlatformPricingMessage"
    ];

    const state = {
        initialized: false,
        loading: false,
        saving: false,
        loaded: false,
        dirty: false,
        revision: null,
        catalog: [],
        draft: [],
        filteredIds: [],
        lastError: null
    };

    let elements = {};

    /* --------------------------------------------------------
       DOM HELPERS
    -------------------------------------------------------- */

    function getElement(id) {
        return document.getElementById(id);
    }

    function setMessage(message, type = "info") {
        if (!elements.message) return;

        elements.message.textContent = message;
        elements.message.dataset.type = type;
    }

    function setStatus(message, type = "info") {
        if (!elements.status) return;

        elements.status.textContent = message;
        elements.status.dataset.state = type;
    }

    function setBusy(busy) {
        state.loading = busy;

        if (elements.reload) {
            elements.reload.disabled = busy || state.saving;
        }

        if (elements.save) {
            elements.save.disabled =
                busy ||
                state.saving ||
                !state.loaded ||
                !state.dirty;
        }
    }

    function getController() {
        const controller = window.BKPlatformPricingControl;

        if (
            !controller ||
            typeof controller.loadPricing !== "function" ||
            typeof controller.savePricing !== "function" ||
            typeof controller.validateCatalog !== "function"
        ) {
            throw new Error(
                "Pricing controller is not ready. Please reload the Master Dashboard."
            );
        }

        return controller;
    }

    function getMasterState() {
        return window.BKMaster?.state || null;
    }

    function isMasterReady() {
        const masterState = getMasterState();
        const currentUser = masterState?.currentUser;

        return Boolean(
            masterState &&
            masterState.ready === true &&
            masterState.authorized === true &&
            currentUser?.uid &&
            masterState.masterData?.status === "ACTIVE"
        );
    }

    function waitForMasterAuthorization(timeoutMs = 10000) {
        return new Promise((resolve, reject) => {
            const startedAt = Date.now();

            function check() {
                if (isMasterReady()) {
                    resolve();
                    return;
                }

                if (Date.now() - startedAt >= timeoutMs) {
                    reject(
                        new Error(
                            "Master authorization is not ready. Wait for the dashboard to finish loading, then reload pricing."
                        )
                    );
                    return;
                }

                window.setTimeout(check, 150);
            }

            check();
        });
    }

    function getSafeCatalog(catalog) {
        if (!Array.isArray(catalog)) {
            throw new Error(
                "Saved pricing data has an invalid format."
            );
        }

        const controller = getController();

        const validation = controller.validateCatalog(catalog);

if (
    validation !== true &&
    validation?.valid !== true
) {
    const details = Array.isArray(validation?.errors)
        ? validation.errors.join("; ")
        : "";

    throw new Error(
        details || "Pricing validation failed."
    );
}
        
        return catalog.map(service => ({
            id: service.id,
            category: service.category,
            label: service.label,
            unit: service.unit,
            providerCostRate: service.providerCostRate,
            restaurantPriceRate: service.restaurantPriceRate,
            enabled: service.enabled
        }));
    }

    function formatMoney(value) {
        return Number(value).toLocaleString("en-IN", {
            minimumFractionDigits: 0,
            maximumFractionDigits: 4
        });
    }

    function createElement(tag, className, text) {
        const element = document.createElement(tag);

        if (className) {
            element.className = className;
        }

        if (text !== undefined && text !== null) {
            element.textContent = String(text);
        }

        return element;
    }

    /* --------------------------------------------------------
       SUMMARY
    -------------------------------------------------------- */

    function renderSummary() {
        if (elements.serviceCount) {
            elements.serviceCount.textContent =
                String(state.draft.length);
        }

        if (elements.enabledCount) {
            const enabledCount = state.draft.filter(
                service => service.enabled === true
            ).length;

            elements.enabledCount.textContent =
                String(enabledCount);
        }

        if (elements.revision) {
            elements.revision.textContent =
                state.revision === null
                    ? "—"
                    : String(state.revision);
        }
    }

    /* --------------------------------------------------------
       CATEGORY FILTER
    -------------------------------------------------------- */

    function renderCategoryOptions() {
        const select = elements.category;

        if (!select) return;

        const previousValue = select.value || "ALL";

        select.replaceChildren();

        select.appendChild(
            createElement("option", "", "All Categories")
        );

        select.options[0].value = "ALL";

        const categories = [
            ...new Set(
                state.draft.map(service => service.category)
            )
        ].sort((a, b) => a.localeCompare(b));

        for (const category of categories) {
            const option = createElement(
                "option",
                "",
                category
            );

            option.value = category;
            select.appendChild(option);
        }

        const optionExists = Array.from(select.options).some(
            option => option.value === previousValue
        );

        select.value = optionExists ? previousValue : "ALL";
    }

    /* --------------------------------------------------------
       INPUT HELPERS
    -------------------------------------------------------- */

    function createRateInput(service, field, label) {
        const input = document.createElement("input");

        input.type = "number";
        input.inputMode = "decimal";
        input.min = "0";
        input.step = "any";
        input.required = true;

        input.value = String(service[field]);

        input.dataset.serviceId = service.id;
        input.dataset.field = field;

        input.setAttribute(
            "aria-label",
            `${service.label}: ${label}`
        );

        input.autocomplete = "off";

        input.addEventListener("input", () => {
            handleRateChange(input);
        });

        return input;
    }

    function handleRateChange(input) {
        const serviceId = input.dataset.serviceId;
        const field = input.dataset.field;

        const service = state.draft.find(
            item => item.id === serviceId
        );

        if (!service) return;

        const rawValue = input.value.trim();

        if (rawValue === "") {
            input.setCustomValidity(
                "Enter a valid non-negative amount."
            );
            service[field] = NaN;
        } else {
            const value = Number(rawValue);

            if (
                !Number.isFinite(value) ||
                value < 0 ||
                value > Number.MAX_SAFE_INTEGER
            ) {
                input.setCustomValidity(
                    "Enter a valid non-negative amount."
                );
                service[field] = NaN;
            } else {
                input.setCustomValidity("");
                service[field] = value;
            }
        }

        state.dirty = true;

        setMessage(
            "Unsaved changes. Review the values before saving.",
            "warning"
        );

        setStatus("Unsaved Changes", "warning");

        renderSummary();
        updateSaveButton();
    }

    function createEnabledToggle(service) {
        const wrapper = createElement(
            "label",
            "bk-platform-pricing-toggle"
        );

        const input = document.createElement("input");

        input.type = "checkbox";
        input.checked = service.enabled === true;

        input.dataset.serviceId = service.id;
        input.dataset.field = "enabled";

        input.setAttribute(
            "aria-label",
            `Enable ${service.label}`
        );

        input.addEventListener("change", () => {
            const target = state.draft.find(
                item => item.id === service.id
            );

            if (!target) return;

            target.enabled = input.checked;

            state.dirty = true;

            setMessage(
                "Unsaved changes. Disabled services must not be billed.",
                "warning"
            );

            setStatus("Unsaved Changes", "warning");

            renderSummary();
            updateSaveButton();
        });

        const slider = createElement(
            "span",
            "bk-platform-pricing-toggle-slider"
        );

        wrapper.append(input, slider);

        return wrapper;
    }

    /* --------------------------------------------------------
       TABLE RENDERING
    -------------------------------------------------------- */

    function renderTable() {
        const tbody = elements.tableBody;

        if (!tbody) return;

        tbody.replaceChildren();

        const searchTerm = (
            elements.search?.value || ""
        ).trim().toLowerCase();

        const selectedCategory =
            elements.category?.value || "ALL";

        const visibleServices = state.draft.filter(service => {
            const matchesSearch =
                service.label.toLowerCase().includes(searchTerm) ||
                service.id.toLowerCase().includes(searchTerm) ||
                service.category.toLowerCase().includes(searchTerm) ||
                service.unit.toLowerCase().includes(searchTerm);

            const matchesCategory =
                selectedCategory === "ALL" ||
                service.category === selectedCategory;

            return matchesSearch && matchesCategory;
        });

        state.filteredIds = visibleServices.map(
            service => service.id
        );

        if (visibleServices.length === 0) {
            const row = document.createElement("tr");
            const cell = createElement(
                "td",
                "",
                "No matching services found."
            );

            cell.colSpan = 5;
            row.appendChild(cell);
            tbody.appendChild(row);

            return;
        }

        for (const service of visibleServices) {
            const row = document.createElement("tr");

            const serviceCell = document.createElement("td");

            serviceCell.appendChild(
                createElement(
                    "div",
                    "bk-platform-pricing-service-name",
                    service.label
                )
            );

            serviceCell.appendChild(
                createElement(
                    "div",
                    "bk-platform-pricing-service-id",
                    service.id
                )
            );

            const unitCell = createElement(
                "td",
                "",
                service.unit
            );

            const providerCell = document.createElement("td");

            providerCell.appendChild(
                createRateInput(
                    service,
                    "providerCostRate",
                    "Provider cost in rupees"
                )
            );

            const restaurantCell = document.createElement("td");

            restaurantCell.appendChild(
                createRateInput(
                    service,
                    "restaurantPriceRate",
                    "Restaurant price in rupees"
                )
            );

            const enabledCell = document.createElement("td");

            enabledCell.appendChild(
                createEnabledToggle(service)
            );

            row.append(
                serviceCell,
                unitCell,
                providerCell,
                restaurantCell,
                enabledCell
            );

            tbody.appendChild(row);
        }
    }

    function updateSaveButton() {
        if (!elements.save) return;

        elements.save.disabled =
            state.loading ||
            state.saving ||
            !state.loaded ||
            !state.dirty;
    }

    /* --------------------------------------------------------
       LOAD SAVED PRICING
    -------------------------------------------------------- */

    async function loadSavedPricing() {
        if (state.loading || state.saving) {
            return;
        }

        setBusy(true);

        setStatus("Loading Pricing…", "info");

        setMessage(
            "Loading saved pricing. No values are being changed.",
            "info"
        );

        try {
            await waitForMasterAuthorization();

            const controller = getController();

            const result = await controller.loadPricing();

            if (!result || result.success !== true) {
                throw new Error(
                    "Unable to load saved pricing."
                );
            }

            const safeCatalog = getSafeCatalog(result.catalog);

            if (
                !Number.isSafeInteger(result.revision) ||
                result.revision < 0
            ) {
                throw new Error(
                    "Saved pricing revision is invalid."
                );
            }

            state.catalog = safeCatalog.map(service => ({
                ...service
            }));

            state.draft = safeCatalog.map(service => ({
                ...service
            }));

            state.revision = result.revision;
            state.loaded = true;
            state.dirty = false;
            state.lastError = null;

            renderCategoryOptions();
            renderTable();
            renderSummary();

            if (result.exists === false) {
                setStatus("Defaults — Not Saved", "warning");

                setMessage(
                    "No saved pricing document was found. Default values are displayed only; nothing has been written to Firestore.",
                    "warning"
                );
            } else {
                setStatus("Saved Pricing Loaded", "success");

                setMessage(
                    `Saved pricing loaded successfully. Revision ${state.revision}. No billing record was created or published.`,
                    "success"
                );
            }
        } catch (error) {
            state.loaded = false;
            state.lastError = error;

            setStatus("Pricing Load Failed", "error");

            setMessage(
                error?.message ||
                "Could not load pricing. Check the Master session and console.",
                "error"
            );

            console.error(
                `[${MODULE_NAME}] Load failed:`,
                error
            );
        } finally {
            setBusy(false);
            updateSaveButton();
        }
    }

    /* --------------------------------------------------------
       SAVE VALIDATION
    -------------------------------------------------------- */

    function validateInputs() {
        const inputs = elements.tableBody.querySelectorAll(
            'input[type="number"]'
        );

        for (const input of inputs) {
            const rawValue = input.value.trim();

            if (rawValue === "") {
                input.setCustomValidity(
                    "Enter a valid non-negative amount."
                );

                input.reportValidity();

                return false;
            }

            const value = Number(rawValue);

            if (
                !Number.isFinite(value) ||
                value < 0 ||
                value > Number.MAX_SAFE_INTEGER
            ) {
                input.setCustomValidity(
                    "Enter a valid non-negative amount."
                );

                input.reportValidity();

                return false;
            }

            input.setCustomValidity("");
        }

        for (const service of state.draft) {
            for (const field of [
                "providerCostRate",
                "restaurantPriceRate"
            ]) {
                const value = service[field];

                if (
                    typeof value !== "number" ||
                    !Number.isFinite(value) ||
                    value < 0 ||
                    value > Number.MAX_SAFE_INTEGER
                ) {
                    setMessage(
                        `Invalid price detected for ${service.label}. Correct it before saving.`,
                        "error"
                    );

                    return false;
                }
            }

            if (typeof service.enabled !== "boolean") {
                setMessage(
                    `Invalid enabled setting for ${service.label}.`,
                    "error"
                );

                return false;
            }
        }

        try {
            const controller = getController();

const validation = controller.validateCatalog(
    state.draft
);

if (
    validation !== true &&
    validation?.valid !== true
) {
    const details = Array.isArray(validation?.errors)
        ? validation.errors.join("; ")
        : "";

    setMessage(
        details || "Pricing catalog validation failed.",
        "error"
    );

    return false;
}
            
        } catch (error) {
            setMessage(
                error?.message || "Pricing validation failed.",
                "error"
            );

            return false;
        }

        return true;
    }

    /* --------------------------------------------------------
       SAVE PRICING
    -------------------------------------------------------- */

async function savePricing() {
        if (state.loading || state.saving) {
            return;
        }

        if (!state.loaded || state.revision === null) {
            setMessage(
                "Load saved pricing before attempting to save.",
                "error"
            );

            return;
        }

        if (!state.dirty) {
            setMessage(
                "There are no changes to save.",
                "info"
            );

            return;
        }

        if (!validateInputs()) {
            return;
        }

        const confirmed = window.confirm(
            "Save these provider costs and restaurant prices?\n\n" +
            "This updates the pricing catalog only. It does not " +
            "create, publish, or collect a restaurant bill."
        );

        if (!confirmed) {
            return;
        }

        state.saving = true;

        if (elements.save) {
            elements.save.disabled = true;
        }

        if (elements.reload) {
            elements.reload.disabled = true;
        }

        setStatus("Saving Pricing…", "info");

        setMessage(
            "Saving with revision protection. Please wait.",
            "info"
        );

        try {
            await waitForMasterAuthorization();

            const controller = getController();

            const catalogToSave = state.draft.map(service => ({
                id: service.id,
                category: service.category,
                label: service.label,
                unit: service.unit,
                providerCostRate: service.providerCostRate,
                restaurantPriceRate: service.restaurantPriceRate,
                enabled: service.enabled
            }));

            const expectedRevision = state.revision;

            const result = await controller.savePricing(
                catalogToSave,
                {
                    expectedRevision
                }
            );

            if (
                !result ||
                result.success !== true ||
                !Number.isSafeInteger(result.revision)
            ) {
                throw new Error(
                    "Save result could not be verified."
                );
            }

            state.revision = result.revision;

            state.catalog = state.draft.map(service => ({
                ...service
            }));

            state.dirty = false;
            state.lastError = null;

            renderSummary();

            setStatus("Pricing Saved", "success");

            setMessage(
                `Pricing saved successfully. New revision: ${state.revision}. Existing historical bills have not been recalculated by this UI.`,
                "success"
            );

            renderTable();
        } catch (error) {
            state.lastError = error;

            if (error?.code === "REVISION_CONFLICT") {
                setStatus("Reload Required", "warning");

                setMessage(
                    "Another update changed the saved pricing. Your local edits were not automatically overwritten. Click Reload Saved Pricing, review the latest values, and reapply any needed changes.",
                    "warning"
                );
            } else {
                setStatus("Pricing Save Failed", "error");

                setMessage(
                    error?.message ||
                    "Pricing could not be saved. Your local edits have been retained where possible.",
                    "error"
                );
            }

            console.error(
                `[${MODULE_NAME}] Save failed:`,
                error
            );
        } finally {
            state.saving = false;

            if (elements.reload) {
                elements.reload.disabled = false;
            }

            updateSaveButton();
        }
    }

    /* --------------------------------------------------------
       INITIALIZATION
    -------------------------------------------------------- */

    function collectElements() {
        const missing = [];

        for (const id of REQUIRED_IDS) {
            const element = getElement(id);

            if (!element) {
                missing.push(id);
            }
        }

        if (missing.length > 0) {
            throw new Error(
                "Pricing UI elements are missing: " +
                missing.join(", ")
            );
        }

        elements = {
            panel: getElement("bkPlatformPricingPanel"),
            status: getElement("bkPlatformPricingStatus"),
            serviceCount: getElement("bkPlatformPricingServiceCount"),
            enabledCount: getElement("bkPlatformPricingEnabledCount"),
            revision: getElement("bkPlatformPricingRevision"),
            search: getElement("bkPlatformPricingSearch"),
            category: getElement("bkPlatformPricingCategory"),
            tableBody: getElement("bkPlatformPricingTableBody"),
            reload: getElement("bkPlatformPricingReload"),
            save: getElement("bkPlatformPricingSave"),
            message: getElement("bkPlatformPricingMessage")
        };
    }

    function bindEvents() {
        elements.search.addEventListener("input", () => {
            renderTable();
        });

        elements.category.addEventListener("change", () => {
            renderTable();
        });

        elements.reload.addEventListener("click", async () => {
            if (
                state.dirty &&
                !window.confirm(
                    "Reload saved pricing and discard your unsaved changes?"
                )
            ) {
                return;
            }

            await loadSavedPricing();
        });

        elements.save.addEventListener("click", savePricing);
    }

    async function initialize() {
        if (state.initialized) return;

        try {
            collectElements();
            bindEvents();

            state.initialized = true;

            setStatus("Pricing Initializing…", "info");

            setMessage(
                "Connecting to the saved pricing catalog…",
                "info"
            );

            await loadSavedPricing();

            console.info(
                `[${MODULE_NAME}] Initialized. Version ${MODULE_VERSION}.`
            );
        } catch (error) {
            console.error(
                `[${MODULE_NAME}] Initialization failed:`,
                error
            );

            const status = getElement(
                "bkPlatformPricingStatus"
            );

            const message = getElement(
                "bkPlatformPricingMessage"
            );

            if (status) {
                status.textContent = "Pricing UI Error";
                status.dataset.state = "error";
            }

            if (message) {
                message.textContent =
                    error?.message ||
                    "Pricing UI could not initialize.";

                message.dataset.type = "error";
            }
        }
    }

    function start() {
        if (document.readyState === "loading") {
            document.addEventListener(
                "DOMContentLoaded",
                initialize,
                { once: true }
            );
        } else {
            initialize();
        }
    }

    window.BKPlatformPricingUI = Object.freeze({
        version: MODULE_VERSION,
        reload: loadSavedPricing
    });

    start();
})();