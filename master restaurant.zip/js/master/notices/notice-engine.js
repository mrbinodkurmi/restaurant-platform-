/* ============================================================
   BK RESTAURANT PLATFORM
   MASTER CONTROL
   OWNER NOTICE ENGINE
   Version: 1.0.0
============================================================ */

"use strict";


const BKMasterNoticeEngine = {

    /* ========================================================
       ENGINE STATE
    ======================================================== */

    state: {

        initialized: false,

        ready: false

    },


    /* ========================================================
       NOTICE TYPES
    ======================================================== */

    TYPES: {

        ACTIVATED:
            "RESTAURANT_ACTIVATED",

        DEACTIVATED:
            "RESTAURANT_DEACTIVATED",

        SUSPENDED:
            "RESTAURANT_SUSPENDED",

        BLOCKED:
            "RESTAURANT_BLOCKED",

        GENERAL:
            "GENERAL"

    },


    /* ========================================================
       NOTICE PRIORITY
    ======================================================== */

    PRIORITY: {

        NORMAL:
            "NORMAL",

        IMPORTANT:
            "IMPORTANT",

        CRITICAL:
            "CRITICAL"

    },


    /* ========================================================
       INITIALIZATION
    ======================================================== */

    init() {

        console.log(
            "=========================================="
        );

        console.log(
            "BK OWNER NOTICE ENGINE: INITIALIZING"
        );

        console.log(
            "=========================================="
        );


        this.state.initialized =
            true;


        this.state.ready =
            true;


        console.log(
            "BK OWNER NOTICE ENGINE: READY"
        );

    },


    /* ========================================================
       GET NOTICE TYPE
    ======================================================== */

    getNoticeType(
        action
    ) {

        const normalizedAction =
            String(
                action || ""
            )
            .trim()
            .toUpperCase();


        switch (
            normalizedAction
        ) {

            case "ACTIVATE":

                return this.TYPES.ACTIVATED;


            case "DEACTIVATE":

                return this.TYPES.DEACTIVATED;


            case "SUSPEND":

                return this.TYPES.SUSPENDED;


            case "BLOCK":

                return this.TYPES.BLOCKED;


            default:

                return this.TYPES.GENERAL;

        }

    },


    /* ========================================================
       GET NOTICE PRIORITY
    ======================================================== */

    getPriority(
        action
    ) {

        const normalizedAction =
            String(
                action || ""
            )
            .trim()
            .toUpperCase();


        switch (
            normalizedAction
        ) {

            case "BLOCK":

                return this.PRIORITY.CRITICAL;


            case "SUSPEND":

                return this.PRIORITY.IMPORTANT;


            case "DEACTIVATE":

                return this.PRIORITY.IMPORTANT;


            case "ACTIVATE":

                return this.PRIORITY.NORMAL;


            default:

                return this.PRIORITY.NORMAL;

        }

    },


    /* ========================================================
       BUILD NOTICE TITLE
    ======================================================== */

    getTitle(
        action
    ) {

        const normalizedAction =
            String(
                action || ""
            )
            .trim()
            .toUpperCase();


        switch (
            normalizedAction
        ) {

            case "ACTIVATE":

                return "Restaurant Activated";


            case "DEACTIVATE":

                return "Restaurant Deactivated";


            case "SUSPEND":

                return "Restaurant Suspended";


            case "BLOCK":

                return "Restaurant Blocked";


            default:

                return "BK Platform Notice";

        }

    },


    /* ========================================================
       BUILD NOTICE MESSAGE
    ======================================================== */

    getMessage(
        action,
        reason
    ) {

        const normalizedAction =
            String(
                action || ""
            )
            .trim()
            .toUpperCase();


        const cleanReason =
            String(
                reason || ""
            ).trim();


        switch (
            normalizedAction
        ) {

            case "ACTIVATE":

                return (
                    "Your restaurant has been activated on the BK Platform."
                );


            case "DEACTIVATE":

                return (
                    "Your restaurant has been deactivated on the BK Platform."
                    +
                    (
                        cleanReason
                            ? ` Reason: ${cleanReason}`
                            : ""
                    )
                );


            case "SUSPEND":

                return (
                    "Your restaurant has been suspended on the BK Platform."
                    +
                    (
                        cleanReason
                            ? ` Reason: ${cleanReason}`
                            : ""
                    )
                );


            case "BLOCK":

                return (
                    "Your restaurant has been blocked on the BK Platform."
                    +
                    (
                        cleanReason
                            ? ` Reason: ${cleanReason}`
                            : ""
                    )
                );


            default:

                return (
                    cleanReason ||
                    "You have received a notice from the BK Platform."
                );

        }

    },


    /* ========================================================
       BUILD NOTICE PAYLOAD
    ======================================================== */

    buildNotice(
        data
    ) {

        if (
            !data
        ) {

            return {

                success: false,

                error:
                    "Notice data is required."

            };

        }


        const restaurantId =
            data.restaurantId;


        const ownerId =
            data.ownerId;


        const action =
            String(
                data.action || ""
            )
            .trim()
            .toUpperCase();


        const reason =
            String(
                data.reason || ""
            ).trim();


        if (
            !restaurantId
        ) {

            return {

                success: false,

                error:
                    "Restaurant ID is required."

            };

        }


        if (
            !ownerId
        ) {

            return {

                success: false,

                error:
                    "Owner ID is required."

            };

        }


        if (
            !action
        ) {

            return {

                success: false,

                error:
                    "Notice action is required."

            };

        }


        if (
            !reason
        ) {

            return {

                success: false,

                error:
                    "Notice reason is required."

            };

        }


        const notice = {

            restaurantId:
                restaurantId,

            ownerId:
                ownerId,

            type:
                this.getNoticeType(
                    action
                ),

            priority:
                this.getPriority(
                    action
                ),

            title:
                this.getTitle(
                    action
                ),

            message:
                this.getMessage(
                    action,
                    reason
                ),

            action:
                action,

            reason:
                reason,

            source:
                "BK_MASTER_CONTROL",

            mode:
                data.mode ||
                "MANUAL",

            read:
                false

        };


        return {

            success:
                true,

            notice:
                notice

        };

    },


    /* ========================================================
       ENGINE READY CHECK
    ======================================================== */

    isReady() {

        return (
            this.state.ready === true
        );

    }

};


/* ============================================================
   GLOBAL ACCESS
============================================================ */

window.BKMasterNoticeEngine =
    BKMasterNoticeEngine;


/* ============================================================
   START ENGINE
============================================================ */

if (
    document.readyState === "loading"
) {

    document.addEventListener(
        "DOMContentLoaded",
        () => {

            BKMasterNoticeEngine.init();

        }
    );

} else {

    BKMasterNoticeEngine.init();

}


/* ============================================================
   NOTICE ENGINE LOADED
============================================================ */

console.log(
    "BK OWNER NOTICE ENGINE: Loaded."
);
/* ============================================================
   FIRESTORE NOTICE STORAGE
============================================================ */

BKMasterNoticeEngine.createNotice = async function(data) {

    console.log(
        "BK OWNER NOTICE ENGINE: Creating notice..."
    );


    if (!this.isReady()) {

        return {

            success: false,

            error:
                "Notice Engine is not ready."

        };

    }


    if (
        !window.BKMaster ||
        !window.BKMaster.state ||
        window.BKMaster.state.authorized !== true
    ) {

        console.warn(
            "BK OWNER NOTICE ENGINE: Master authorization unavailable."
        );


        return {

            success: false,

            error:
                "Master authorization is required."

        };

    }


    try {

        const firebaseCore =
            await import("../firebase.js");


        const firestore =
            await import(
                "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js"
            );


        const db =
            firebaseCore.db;


        const {
            collection,
            addDoc,
            serverTimestamp
        } = firestore;


        const payloadResult =
            this.buildNotice(data);


        if (
            !payloadResult.success
        ) {

            return payloadResult;

        }


        const masterUid =
            window.BKMaster.state.currentUser
                ? window.BKMaster.state.currentUser.uid
                : null;


        const noticePayload = {

            ...payloadResult.notice,

            createdBy:
                masterUid,

            createdAt:
                serverTimestamp(),

            status:
                "UNREAD"

        };


        const noticesRef =
            collection(
                db,
                "notices"
            );


        const noticeDocument =
            await addDoc(
                noticesRef,
                noticePayload
            );


        console.log(
            "BK OWNER NOTICE ENGINE: Notice created."
        );


        console.log(
            "BK OWNER NOTICE ENGINE: Notice ID:",
            noticeDocument.id
        );


        return {

            success: true,

            noticeId:
                noticeDocument.id,

            notice:
                noticePayload

        };

    } catch (error) {

        console.error(
            "BK OWNER NOTICE ENGINE: Notice creation failed:",
            error
        );


        return {

            success: false,

            error:
                error.message ||
                "Notice creation failed."

        };

    }

};


console.log(
    "BK OWNER NOTICE ENGINE: Firestore storage loaded."
);


/* ============================================================
   SAFE NOTICE TEST
   ------------------------------------------------------------
   This test ONLY creates a notice.
   It does NOT change restaurant status.
============================================================ */

BKMasterNoticeEngine.testNotice = async function(
    restaurantId,
    ownerId
) {

    console.log(
        "=========================================="
    );

    console.log(
        "BK OWNER NOTICE ENGINE: TEST START"
    );

    console.log(
        "Restaurant Status: WILL NOT CHANGE"
    );

    console.log(
        "=========================================="
    );


    if (!restaurantId) {

        console.warn(
            "BK OWNER NOTICE ENGINE: Test restaurant ID missing."
        );

        return {

            success: false,

            error:
                "Restaurant ID is required."

        };

    }


    if (!ownerId) {

        console.warn(
            "BK OWNER NOTICE ENGINE: Test owner ID missing."
        );

        return {

            success: false,

            error:
                "Owner ID is required."

        };

    }


    const result =
        await this.createNotice({

            restaurantId:
                restaurantId,

            ownerId:
                ownerId,

            action:
                "DEACTIVATE",

            reason:
                "Controlled BK Notice Engine test.",

            mode:
                "MANUAL"

        });


    if (!result.success) {

        console.error(
            "BK OWNER NOTICE ENGINE: TEST FAILED:",
            result.error
        );

        return result;

    }


    console.log(
        "=========================================="
    );

    console.log(
        "BK OWNER NOTICE ENGINE: TEST PASSED"
    );

    console.log(
        "Notice ID:",
        result.noticeId
    );

    console.log(
        "Restaurant Status: UNCHANGED"
    );

    console.log(
        "=========================================="
    );


    return result;

};


console.log(
    "BK OWNER NOTICE ENGINE: Safe test loaded."
);


console.log(
    "BK RESTAURANT CONTROL: Real Execute Engine loaded."
);