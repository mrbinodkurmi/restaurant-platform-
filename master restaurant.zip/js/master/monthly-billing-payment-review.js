
/* ============================================================
   BK MASTER — MONTHLY BILLING PAYMENT REVIEW
   Version: 1.0.0

   PURPOSE:
   1. Load submitted monthly bill payments.
   2. Master-only payment verification.
   3. Master-only payment rejection with reason.
   4. Update billingRecords only after verification.
   5. Maintain master audit history.

   IMPORTANT:
   This module does NOT modify subscriptionPayments.
   ============================================================ */

import {
  masterAuth as auth,
  masterDb as db
} from "../firebase-sessions.js";


import {
  collection,
  doc,
  getDoc,
  getDocs,
  onSnapshot,
  query,
  where,
  runTransaction,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";



const BKMasterMonthlyBillingPaymentReview = {

  state: {
    initialized: false,
    ready: false,
    loading: false,
    pendingPayments: [],
    lastAction: null,
    unsubscribePayments: null,
    noticeEventsBound: false,
    noticeStarting: false,
    noticeObserver: null
  },

    

  /* ==========================================================
     INITIALIZE
     ========================================================== */

    init() {

    if (this.state.initialized) {
      return true;
    }

    this.state.initialized = true;
    this.state.ready = true;

    this.bindNoticeSectionObserver();

    console.info(
      "BK MASTER MONTHLY PAYMENT REVIEW: READY"
    );

    return true;

  },
  
  
    /* ==========================================================
     NOTICE SECTION VISIBILITY OBSERVER
     ========================================================== */

  bindNoticeSectionObserver() {

    const noticeSection = document.getElementById(
      "masterSectionNotices"
    );

    if (!noticeSection) {
      console.error(
        "BK MONTHLY NOTICE SECTION NOT FOUND."
      );
      return false;
    }

    if (this.state.noticeObserver) {
      return true;
    }

    this.state.noticeObserver = new MutationObserver(() => {

      const isVisible =
        !noticeSection.classList.contains(
          "hidden-master-section"
        );

      if (isVisible) {
        this.startNoticeListener();
      } else {
        this.stopNoticeListener();
      }

    });

    this.state.noticeObserver.observe(
      noticeSection,
      {
        attributes: true,
        attributeFilter: ["class"]
      }
    );

    if (
      !noticeSection.classList.contains(
        "hidden-master-section"
      )
    ) {
      this.startNoticeListener();
    }

    return true;

  },

  /* ==========================================================
     MASTER AUTHORIZATION
     ========================================================== */

  async requireMasterAuthorization() {

    const currentUser = auth.currentUser;

    if (!currentUser?.uid) {
      throw new Error(
        "Master authentication is required."
      );
    }

    if (
      !window.BKMaster?.state?.authorized
    ) {
      throw new Error(
        "Master authorization is unavailable."
      );
    }

    const masterRef = doc(
      db,
      "masterAdmins",
      currentUser.uid
    );

    const masterSnapshot = await runTransaction(
      db,
      async (transaction) => {

        const snapshot =
          await transaction.get(masterRef);

        if (!snapshot.exists()) {
          throw new Error(
            "Master authorization record was not found."
          );
        }

        if (
          snapshot.data().status !== "ACTIVE"
        ) {
          throw new Error(
            "Active Master authorization is required."
          );
        }

        return {
          uid: currentUser.uid
        };

      }
    );

    return masterSnapshot;

  },


  /* ==========================================================
     LOAD SUBMITTED MONTHLY PAYMENTS
     ========================================================== */

  async loadSubmittedPayments() {

    if (this.state.loading) {
      return this.state.pendingPayments;
    }

    this.state.loading = true;

    try {

      await this.requireMasterAuthorization();

      const paymentsQuery = query(
        collection(db, "billingPayments"),
        where("status", "==", "PAYMENT_SUBMITTED")
      );

      const snapshot = await getDocs(
        paymentsQuery
      );

      const payments = snapshot.docs.map(
        (paymentDoc) => ({
          paymentId: paymentDoc.id,
          ...paymentDoc.data()
        })
      );

      this.state.pendingPayments = payments;

      console.info(
        "BK MASTER MONTHLY PAYMENTS LOADED:",
        payments.length
      );

      return [...payments];

    } catch (error) {

      console.error(
        "BK MASTER MONTHLY PAYMENT LOAD FAILED:",
        error
      );

      throw error;

    } finally {

      this.state.loading = false;

    }

  },



  /* ==========================================================
     START — LIVE MONTHLY PAYMENT LISTENER
     ========================================================== */

  async startNoticeListener() {

    if (
      this.state.unsubscribePayments ||
      this.state.noticeStarting
    ) {
      return;
    }

    this.state.noticeStarting = true;

    const noticeList = document.getElementById(
      "bkMonthlyBillingNoticeList"
    );

    try {

      await this.requireMasterAuthorization();

      const paymentsQuery = query(
        collection(db, "billingPayments"),
        where("status", "==", "PAYMENT_SUBMITTED")
      );

      this.state.unsubscribePayments = onSnapshot(
        paymentsQuery,

        (snapshot) => {

          const payments = snapshot.docs.map(
            (paymentDoc) => ({
              paymentId: paymentDoc.id,
              ...paymentDoc.data()
            })
          );

          this.state.pendingPayments = payments;
          
        this.renderPendingPayments();  

          const counter = document.getElementById(
            "bkMonthlyBillingPendingCount"
          );

          if (counter) {
            counter.textContent = String(
              payments.length
            );
          }

          console.info(
            "BK MONTHLY BILLING LIVE PAYMENTS:",
            payments.length
          );

        },

        (error) => {

          console.error(
            "BK MONTHLY BILLING LIVE LISTENER FAILED:",
            error
          );

          this.stopNoticeListener();

          if (noticeList) {
            noticeList.textContent =
              "Monthly payment notifications could not be loaded.";
          }

        }
      );

    } catch (error) {

      console.error(
        "BK MONTHLY BILLING LISTENER START FAILED:",
        error
      );

      if (noticeList) {
        noticeList.textContent =
          "Master authorization or payment loading failed.";
      }

    } finally {

      this.state.noticeStarting = false;

    }

  },


  /* ==========================================================
     STOP — LIVE MONTHLY PAYMENT LISTENER
     ========================================================== */

  stopNoticeListener() {

    if (this.state.unsubscribePayments) {

      this.state.unsubscribePayments();

      this.state.unsubscribePayments = null;

      console.info(
        "BK MONTHLY BILLING LIVE LISTENER STOPPED."
      );

    }

  },

  /* ==========================================================
     LOAD RESTAURANT NAME
  ========================================================== */

  async loadRestaurantName(restaurantId) {

    if (!restaurantId) {
      return "Restaurant";
    }

    try {

      const restaurantRef = doc(
        db,
        "restaurants",
        restaurantId
      );

      const restaurantSnap = await getDoc(restaurantRef);

      if (!restaurantSnap.exists()) {
        return "Restaurant";
      }

      const data = restaurantSnap.data();

      return (
        data.restaurantName ||
        data.name ||
        data.businessName ||
        "Restaurant"
      );

    } catch (error) {

      console.error(
        "BK RESTAURANT NAME LOAD ERROR:",
        error
      );

      return "Restaurant";

    }
  },

  /* ==========================================================
     START — RENDER MONTHLY BILLING PAYMENT CARDS
     ========================================================== */

  async renderPendingPayments() {

    const noticeList = document.getElementById(
      "bkMonthlyBillingNoticeList"
    );

    if (!noticeList) return false;

    noticeList.replaceChildren();

    const payments = this.state.pendingPayments || [];

    if (payments.length === 0) {

      const empty = document.createElement("div");

      empty.className = "bk-monthly-notice-empty";

      empty.textContent =
        "No pending monthly billing payments.";

      noticeList.appendChild(empty);

      return true;
    }


    const restaurantNames = await Promise.all(
      payments.map((payment) =>
        this.loadRestaurantName(payment.restaurantId)
      )
    );
    payments.forEach((payment) => {

      const card = document.createElement("article");

      card.className = "bk-monthly-notice-card";

      const header = document.createElement("div");
      header.className = "bk-monthly-notice-card-header";

      const restaurant = document.createElement("div");

      const restaurantName = document.createElement("div");
      restaurantName.className = "bk-monthly-notice-restaurant";
      restaurantName.textContent =
  payment.restaurantName || restaurantNames[payments.indexOf(payment)];

      const restaurantId = document.createElement("div");
      restaurantId.className = "bk-monthly-notice-restaurant-id";
      restaurantId.textContent =
        payment.restaurantId || "Restaurant ID unavailable";

      restaurant.append(restaurantName, restaurantId);

      const status = document.createElement("span");
      status.className = "bk-monthly-notice-status";
      status.textContent = payment.status || "PENDING";

      header.append(restaurant, status);

      const details = document.createElement("div");
      details.className = "bk-monthly-notice-details";

      const addDetail = (label, value, extraClass = "") => {

        const item = document.createElement("div");
        item.className = "bk-monthly-notice-detail";

        const heading = document.createElement("div");
        heading.className = "bk-monthly-notice-label";
        heading.textContent = label;

        const content = document.createElement("div");
        content.className =
          `bk-monthly-notice-value ${extraClass}`.trim();

        content.textContent =
          value === undefined || value === null || value === ""
            ? "Not available"
            : String(value);

        item.append(heading, content);
        details.appendChild(item);
      };

      addDetail("Billing Month", payment.billingMonth);
      addDetail(
        "Payment Amount",
        `${payment.currency || "INR"} ${payment.amount ?? "—"}`,
        "bk-monthly-notice-amount"
      );
      addDetail("Payment Method", payment.paymentMethod);
      addDetail(
        "Payment Reference / UTR",
        payment.paymentReference,
        "bk-monthly-notice-reference"
      );
      addDetail("Owner ID", payment.ownerId);
      addDetail("Billing ID", payment.billingId);


      /* ======================================================
         PAYMENT REVIEW ACTION BUTTONS
      ====================================================== */

      const actions = document.createElement("div");

      actions.className = "bk-monthly-notice-actions";


      // VERIFY PAYMENT BUTTON

      const verifyButton = document.createElement("button");

      verifyButton.type = "button";
      verifyButton.className = "bk-monthly-notice-confirm";
      verifyButton.textContent = "Verify Payment";


      // REJECT PAYMENT BUTTON

      const rejectButton = document.createElement("button");

      rejectButton.type = "button";
      rejectButton.className = "bk-monthly-notice-reject";
      rejectButton.textContent = "Reject Payment";


      // VERIFY PAYMENT ACTION

      verifyButton.addEventListener("click", async () => {

        if (
          verifyButton.disabled ||
          rejectButton.disabled
        ) {
          return;
        }

        const confirmed = window.confirm(
          "Confirm that you have independently checked the actual bank/UPI transaction and received the payment."
        );

        if (!confirmed) return;

        verifyButton.disabled = true;
        rejectButton.disabled = true;

        try {

          await this.verifyPayment({
            billingId: payment.billingId,
            restaurantId: payment.restaurantId,
            ownerId: payment.ownerId
          });

          window.alert(
            "Monthly payment verification completed successfully."
          );

        } catch (error) {

          console.error(
            "BK MONTHLY PAYMENT VERIFICATION FAILED:",
            error
          );

          window.alert(
            error.message ||
            "Unable to verify monthly payment."
          );

        } finally {

          verifyButton.disabled = false;
          rejectButton.disabled = false;

        }

      });


      // REJECT PAYMENT ACTION

      rejectButton.addEventListener("click", async () => {

        if (
          verifyButton.disabled ||
          rejectButton.disabled
        ) {
          return;
        }

        const reason = window.prompt(
          "Enter the payment rejection reason (10–500 characters):"
        );

        if (reason === null) return;

        const cleanReason = reason.trim();

        if (
          cleanReason.length < 10 ||
          cleanReason.length > 500
        ) {

          window.alert(
            "Rejection reason must contain 10–500 characters."
          );

          return;
        }

        const confirmed = window.confirm(
          "Are you sure you want to reject this monthly payment?"
        );

        if (!confirmed) return;

        verifyButton.disabled = true;
        rejectButton.disabled = true;

        try {

          await this.rejectPayment({
            billingId: payment.billingId,
            restaurantId: payment.restaurantId,
            ownerId: payment.ownerId,
            reason: cleanReason
          });

          window.alert(
            "Monthly payment rejected successfully."
          );

        } catch (error) {

          console.error(
            "BK MONTHLY PAYMENT REJECTION FAILED:",
            error
          );

          window.alert(
            error.message ||
            "Unable to reject monthly payment."
          );

        } finally {

          verifyButton.disabled = false;
          rejectButton.disabled = false;

        }

      });


      // ATTACH ACTION BUTTONS

      actions.append(
        verifyButton,
        rejectButton
      );

      card.append(
        header,
        details,
        actions
      );

      noticeList.appendChild(card);

    });

    return true;

  },

  /* ==========================================================
     END — RENDER MONTHLY BILLING PAYMENT CARDS
     ========================================================== */

  /* ==========================================================
     VALIDATE PAYMENT REVIEW REQUEST
     ========================================================== */

  validateReviewRequest({
    billingId,
    restaurantId,
    ownerId
  }) {

    const errors = [];

    if (
      typeof billingId !== "string" ||
      !billingId.trim()
    ) {
      errors.push("Billing ID is required.");
    }

    if (
      typeof restaurantId !== "string" ||
      !restaurantId.trim()
    ) {
      errors.push("Restaurant ID is required.");
    }

    if (
      typeof ownerId !== "string" ||
      !ownerId.trim()
    ) {
      errors.push("Owner ID is required.");
    }

    return {
      valid: errors.length === 0,
      errors
    };

  },


  /* ==========================================================
     CONFIRM — VERIFY MONTHLY PAYMENT
     ========================================================== */

  async verifyPayment({
    billingId,
    restaurantId,
    ownerId
  }) {

    const validation =
      this.validateReviewRequest({
        billingId,
        restaurantId,
        ownerId
      });

    if (!validation.valid) {
      throw new Error(
        validation.errors.join(" ")
      );
    }

    const master =
      await this.requireMasterAuthorization();

    const paymentRef = doc(
      db,
      "billingPayments",
      billingId
    );

    const billRef = doc(
      db,
      "billingRecords",
      billingId
    );

    const restaurantRef = doc(
      db,
      "restaurants",
      restaurantId
    );

    const auditRef = doc(
      collection(db, "masterAuditLogs")
    );
    
    const noticeRef = doc(
  db,
  "notices",
  `${billingId}_PAYMENT_VERIFIED`
);
    

    const result = await runTransaction(
      db,
      async (transaction) => {

        // READ ALL DOCUMENTS BEFORE WRITES

        const paymentSnapshot =
          await transaction.get(paymentRef);

        const billSnapshot =
          await transaction.get(billRef);

        const restaurantSnapshot =
          await transaction.get(restaurantRef);

        const masterRef = doc(
          db,
          "masterAdmins",
          master.uid
        );

        const masterSnapshot =
          await transaction.get(masterRef);
          
          const existingNoticeSnapshot =
    await transaction.get(noticeRef);


        if (!masterSnapshot.exists()) {
          throw new Error(
            "Master authorization record is missing."
          );
        }

        if (
          masterSnapshot.data().status !== "ACTIVE"
        ) {
          throw new Error(
            "Master authorization is no longer active."
          );
        }

        if (!paymentSnapshot.exists()) {
          throw new Error(
            "Monthly payment record was not found."
          );
        }

        if (!billSnapshot.exists()) {
          throw new Error(
            "Monthly bill was not found."
          );
        }

        if (!restaurantSnapshot.exists()) {
          throw new Error(
            "Restaurant record was not found."
          );
        }


        const payment =
          paymentSnapshot.data();

        const bill =
          billSnapshot.data();

        const restaurant =
          restaurantSnapshot.data();


        // ID AND OWNERSHIP VALIDATION

        if (
          payment.billingId !== billingId ||
          payment.restaurantId !== restaurantId ||
          payment.ownerId !== ownerId
        ) {
          throw new Error(
            "Payment ownership or billing ID mismatch."
          );
        }

        if (
          bill.restaurantId !== restaurantId ||
          bill.ownerId !== ownerId
        ) {
          throw new Error(
            "Monthly bill ownership mismatch."
          );
        }

        if (
          restaurant.ownerId !== ownerId
        ) {
          throw new Error(
            "Restaurant ownership verification failed."
          );
        }


        // PAYMENT STATE VALIDATION

        if (
          payment.status !== "PAYMENT_SUBMITTED"
        ) {
          throw new Error(
            "Payment is no longer awaiting verification."
          );
        }

        if (
          payment.verificationStatus !== "PENDING"
        ) {
          throw new Error(
            "Payment verification is not pending."
          );
        }

        if (
          bill.status !== "PUBLISHED" ||
          bill.paymentStatus === "PAID"
        ) {
          throw new Error(
            "Monthly bill is not eligible for verification."
          );
        }


        // AMOUNT AND CURRENCY VALIDATION

        const paymentAmount =
          Number(payment.amount);

        const billAmount =
          Number(bill.finalAmount);

        if (
          !Number.isFinite(paymentAmount) ||
          !Number.isFinite(billAmount) ||
          paymentAmount <= 0 ||
          paymentAmount !== billAmount
        ) {
          throw new Error(
            "Payment amount does not match the published bill."
          );
        }

        if (
          payment.currency !== bill.currency ||
          payment.currency !== "INR"
        ) {
          throw new Error(
            "Payment currency does not match the bill."
          );
        }

        if (
          typeof payment.paymentReference !== "string" ||
          !payment.paymentReference.trim()
        ) {
          throw new Error(
            "Payment reference is missing."
          );
        }


// DUPLICATE NOTIFICATION PROTECTION

if (existingNoticeSnapshot.exists()) {
  throw new Error(
    "Payment verification notice already exists. Duplicate notification blocked."
  );
}

        // MASTER CONFIRMATION

        transaction.update(
          paymentRef,
          {
            status: "VERIFIED",
            verificationStatus: "VERIFIED",
            reviewedBy: master.uid,
            reviewedAt: serverTimestamp(),
            verifiedBy: master.uid,
            verifiedAt: serverTimestamp(),
            updatedAt: serverTimestamp()
          }
        );


        transaction.update(
          billRef,
          {
            paymentStatus: "PAID",
            paymentVerifiedBy: master.uid,
            paymentVerifiedAt: serverTimestamp(),
            updatedAt: serverTimestamp()
          }
        );


        transaction.set(
          auditRef,
          {
            action: "MONTHLY_BILL_PAYMENT_VERIFIED",
            billingId,
            restaurantId,
            ownerId,
            paymentReference:
              payment.paymentReference,
            amount: paymentAmount,
            currency: payment.currency,
            changedBy: master.uid,
            createdAt: serverTimestamp(),
            result: "VERIFIED"
          }
        );

// OWNER NOTIFICATION — PAYMENT VERIFIED

transaction.set(
  noticeRef,
  {
    noticeId: `${billingId}_PAYMENT_VERIFIED`,
    ownerId,
    restaurantId,
    source: "BK_MONTHLY_BILLING_PAYMENT_REVIEW",
    type: "PAYMENT_VERIFIED",
    priority: "NORMAL",
    title: "Monthly Payment Verified",
    message: `Your monthly bill payment for ${billingId} has been verified successfully. Your bill is now marked as PAID.`,
    billingId,
    amount: paymentAmount,
    currency: payment.currency,
    read: false,
    status: "UNREAD",
    createdBy: master.uid,
    createdAt: serverTimestamp()
  }
);


        return {
          success: true,
          billingId,
          restaurantId,
          ownerId,
          status: "VERIFIED",
          paymentStatus: "PAID"
        };

      }
    );

this.state.lastAction = result;

try {

  await this.loadSubmittedPayments();

} catch (refreshError) {

  console.error(
    "PAYMENT ACTION SUCCEEDED, BUT LIST REFRESH FAILED:",
    refreshError
  );

}

console.info(
  "BK MASTER MONTHLY PAYMENT VERIFIED:",
  result
);

return result;

  },


  /* ==========================================================
     REJECT — MONTHLY PAYMENT
     ========================================================== */

  async rejectPayment({
    billingId,
    restaurantId,
    ownerId,
    reason
  }) {

    const cleanReason =
      String(reason || "").trim();

    if (
      cleanReason.length < 10 ||
      cleanReason.length > 500
    ) {
      throw new Error(
        "Rejection reason must contain 10 to 500 characters."
      );
    }


    const validation =
      this.validateReviewRequest({
        billingId,
        restaurantId,
        ownerId
      });

    if (!validation.valid) {
      throw new Error(
        validation.errors.join(" ")
      );
    }


    const master =
      await this.requireMasterAuthorization();


    const paymentRef = doc(
      db,
      "billingPayments",
      billingId
    );

    const billRef = doc(
      db,
      "billingRecords",
      billingId
    );

    const restaurantRef = doc(
      db,
      "restaurants",
      restaurantId
    );

    const auditRef = doc(
      collection(db, "masterAuditLogs")
    );
    
    const noticeRef = doc(
  db,
  "notices",
  `${billingId}_PAYMENT_REJECTED`
);


    const result = await runTransaction(
      db,
      async (transaction) => {

        // READ ALL DOCUMENTS BEFORE WRITES

        const paymentSnapshot =
          await transaction.get(paymentRef);

        const billSnapshot =
          await transaction.get(billRef);

        const restaurantSnapshot =
          await transaction.get(restaurantRef);

        const masterRef = doc(
          db,
          "masterAdmins",
          master.uid
        );

        const masterSnapshot =
          await transaction.get(masterRef);
          
          const existingNoticeSnapshot =
  await transaction.get(noticeRef);


        if (!masterSnapshot.exists()) {
          throw new Error(
            "Master authorization record is missing."
          );
        }

        if (
          masterSnapshot.data().status !== "ACTIVE"
        ) {
          throw new Error(
            "Master authorization is no longer active."
          );
        }

        if (
          !paymentSnapshot.exists() ||
          !billSnapshot.exists() ||
          !restaurantSnapshot.exists()
        ) {
          throw new Error(
            "Payment, bill or restaurant record is missing."
          );
        }


        const payment =
          paymentSnapshot.data();

        const bill =
          billSnapshot.data();

        const restaurant =
          restaurantSnapshot.data();


        if (
          payment.billingId !== billingId ||
          payment.restaurantId !== restaurantId ||
          payment.ownerId !== ownerId ||
          bill.restaurantId !== restaurantId ||
          bill.ownerId !== ownerId ||
          restaurant.ownerId !== ownerId
        ) {
          throw new Error(
            "Payment ownership verification failed."
          );
        }


        if (
          payment.status !== "PAYMENT_SUBMITTED" ||
          payment.verificationStatus !== "PENDING"
        ) {
          throw new Error(
            "Payment is no longer awaiting review."
          );
        }


        if (
          bill.status !== "PUBLISHED" ||
          bill.paymentStatus === "PAID"
        ) {
          throw new Error(
            "This bill cannot be rejected in its current state."
          );
        }

// DUPLICATE NOTIFICATION PROTECTION

if (existingNoticeSnapshot.exists()) {
  throw new Error(
    "Payment rejection notice already exists. Duplicate notification blocked."
  );
}


        // REJECTION — BILL REMAINS UNPAID

        transaction.update(
          paymentRef,
          {
            status: "REJECTED",
            verificationStatus: "REJECTED",
            rejectionReason: cleanReason,
            reviewedBy: master.uid,
            reviewedAt: serverTimestamp(),
            rejectedBy: master.uid,
            rejectedAt: serverTimestamp(),
            updatedAt: serverTimestamp()
          }
        );


        transaction.update(
          billRef,
          {
            paymentStatus: "UNPAID",
            updatedAt: serverTimestamp()
          }
        );


        transaction.set(
          auditRef,
          {
            action: "MONTHLY_BILL_PAYMENT_REJECTED",
            billingId,
            restaurantId,
            ownerId,
            paymentReference:
              payment.paymentReference || "",
            amount: Number(payment.amount),
            currency: payment.currency || "INR",
            reason: cleanReason,
            changedBy: master.uid,
            createdAt: serverTimestamp(),
            result: "REJECTED"
          }
        );

// OWNER NOTIFICATION — PAYMENT REJECTED

transaction.set(
  noticeRef,
  {
    noticeId: `${billingId}_PAYMENT_REJECTED`,
    ownerId,
    restaurantId,
    source: "BK_MONTHLY_BILLING_PAYMENT_REVIEW",
    type: "PAYMENT_REJECTED",
    priority: "NORMAL",
    title: "Monthly Payment Rejected",
    message: `Your monthly bill payment for ${billingId} was rejected. Reason: ${cleanReason}`,
    billingId,
    amount: Number(payment.amount),
    currency: payment.currency || "INR",
    reason: cleanReason,
    read: false,
    status: "UNREAD",
    createdBy: master.uid,
    createdAt: serverTimestamp()
  }
);


        return {
          success: true,
          billingId,
          restaurantId,
          ownerId,
          status: "REJECTED",
          paymentStatus: "UNPAID",
          rejectionReason: cleanReason
        };

      }
    );

this.state.lastAction = result;

try {

  await this.loadSubmittedPayments();

} catch (refreshError) {

  console.error(
    "PAYMENT ACTION SUCCEEDED, BUT LIST REFRESH FAILED:",
    refreshError
  );

}

console.info(
  "BK MASTER MONTHLY PAYMENT REJECTED:",
  result
);

return result;

  },


  /* ==========================================================
     PUBLIC STATE
     ========================================================== */

  getPendingPayments() {

    return this.state.pendingPayments.map(
      (payment) => ({
        ...payment
      })
    );

  },


  isReady() {

    return this.state.ready;

  }

};


/* ============================================================
   GLOBAL EXPOSURE
   ============================================================ */

window.BKMasterMonthlyBillingPaymentReview =
  BKMasterMonthlyBillingPaymentReview;


/* ============================================================
   INITIALIZE
   ============================================================ */

BKMasterMonthlyBillingPaymentReview.init();
