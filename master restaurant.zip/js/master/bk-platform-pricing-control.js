/* ============================================================
   BK PLATFORM COST & PRICING CONTROL
   Production-Oriented Module
   Version: 1.2.0

   Responsibilities:
   1. Central platform pricing catalogue
   2. Provider cost and restaurant price separation
   3. Strict catalogue validation
   4. Authorized Master-session checks
   5. Firestore load and transactional save
   6. Revision conflict protection
   7. Consistent schema metadata
   8. Safe error reporting

   Important:
   - This module does not calculate or publish bills.
   - Existing billing/payment modules remain untouched.
   - Default pricing values are zero and services are disabled.
   - Actual billing integration requires a separate reviewed change.
   ============================================================ */

"use strict";

import {
    masterAuth as auth,
    masterDb as db
} from "../firebase-sessions.js";

import {
    doc,
    getDoc,
    runTransaction,
    serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";


/* ============================================================
   CONFIGURATION
   ============================================================ */

const VERSION = "1.2.0";
const SCHEMA_VERSION = 1;

const PRICING_COLLECTION = "platformPricing";
const PRICING_DOCUMENT = "bk-pricing-catalog";

const MAX_RATE = Number.MAX_SAFE_INTEGER;


/* ============================================================
   SUPPORTED SERVICE DEFINITIONS
   These are metadata, not actual provider rates.
   ============================================================ */

const SERVICE_DEFINITIONS = [

    // DATABASE
    {
        id: "database.read",
        category: "Database",
        label: "Database Reads",
        unit: "per_1000_reads"
    },
    {
        id: "database.write",
        category: "Database",
        label: "Database Writes",
        unit: "per_1000_writes"
    },
    {
        id: "database.update",
        category: "Database",
        label: "Database Updates",
        unit: "per_1000_updates"
    },
    {
        id: "database.delete",
        category: "Database",
        label: "Database Deletes",
        unit: "per_1000_deletes"
    },

    // BOOKINGS
    {
        id: "booking.table",
        category: "Bookings",
        label: "Table Booking",
        unit: "per_booking"
    },
    {
        id: "booking.advance",
        category: "Bookings",
        label: "Advance Booking",
        unit: "per_booking"
    },
    {
        id: "booking.party",
        category: "Bookings",
        label: "Party Booking",
        unit: "per_booking"
    },
    {
        id: "booking.event",
        category: "Bookings",
        label: "Event Booking",
        unit: "per_booking"
    },
    {
        id: "booking.reject",
        category: "Bookings",
        label: "Booking Rejection",
        unit: "per_operation"
    },
    {
        id: "booking.cancel",
        category: "Bookings",
        label: "Booking Cancellation",
        unit: "per_operation"
    },

    // ORDERS
    {
        id: "order.create",
        category: "Orders",
        label: "Order Creation",
        unit: "per_order"
    },
    {
        id: "order.update",
        category: "Orders",
        label: "Order Update",
        unit: "per_operation"
    },
    {
        id: "order.reject",
        category: "Orders",
        label: "Order Rejection",
        unit: "per_operation"
    },
    {
        id: "order.cancel",
        category: "Orders",
        label: "Order Cancellation",
        unit: "per_operation"
    },
    {
        id: "order.delete",
        category: "Orders",
        label: "Order Deletion",
        unit: "per_operation"
    },

    // WEBSITE
    {
        id: "website.visit",
        category: "Website",
        label: "Website Visits",
        unit: "per_1000_visits"
    },
    {
        id: "website.bandwidth",
        category: "Website",
        label: "Bandwidth",
        unit: "per_gb"
    },
    {
        id: "website.hosting",
        category: "Website",
        label: "Website Hosting",
        unit: "per_restaurant_month"
    },

    // STORAGE
    {
        id: "storage.gb_month",
        category: "Storage",
        label: "Storage Usage",
        unit: "per_gb_month"
    },
    {
        id: "storage.upload",
        category: "Storage",
        label: "Storage Upload",
        unit: "per_gb"
    },
    {
        id: "storage.download",
        category: "Storage",
        label: "Storage Download",
        unit: "per_gb"
    },

    // MENU AND IMAGES
    {
        id: "menu.item",
        category: "Menu & Images",
        label: "Menu Item",
        unit: "per_item_month"
    },
    {
        id: "image.upload",
        category: "Menu & Images",
        label: "Image Upload",
        unit: "per_upload"
    },

    // PLATFORM SERVICES
    {
        id: "notification.send",
        category: "Platform Services",
        label: "Notifications",
        unit: "per_1000_notifications"
    },
    {
        id: "email.send",
        category: "Platform Services",
        label: "Emails",
        unit: "per_1000_emails"
    },

    // FUTURE FEATURES
    {
        id: "future.ai",
        category: "Future Features",
        label: "AI Services",
        unit: "per_request"
    },
    {
        id: "future.analytics",
        category: "Future Features",
        label: "Advanced Analytics",
        unit: "per_report"
    },
    {
        id: "future.custom",
        category: "Future Features",
        label: "Future Custom Feature",
        unit: "per_operation"
    }

].map(function (definition) {

    return Object.freeze({ ...definition });

});


const DEFINITION_BY_ID = new Map(
    SERVICE_DEFINITIONS.map(function (definition) {
        return [definition.id, definition];
    })
);


/* ============================================================
   ERROR HELPER
   ============================================================ */

function createPricingError(code, message, details) {

    const error = new Error(message);

    error.name = "BKPlatformPricingError";
    error.code = code;

    if (Array.isArray(details)) {
        error.details = details.slice();
    }

    return error;

}


/* ============================================================
   DOCUMENT REFERENCE
   ============================================================ */

function getPricingDocumentReference() {

    return doc(
        db,
        PRICING_COLLECTION,
        PRICING_DOCUMENT
    );

}


/* ============================================================
   DEFAULT CATALOGUE
   Defaults are safe starting values, not configured billing rates.
   ============================================================ */

function getDefaultCatalog() {

    return SERVICE_DEFINITIONS.map(function (definition) {

        return {
            id: definition.id,
            category: definition.category,
            label: definition.label,
            unit: definition.unit,

            providerCostRate: 0,
            restaurantPriceRate: 0,

            enabled: false
        };

    });

}


/* ============================================================
   MASTER AUTHORIZATION
   This is a client-side session check.
   Firestore Security Rules remain authoritative.
   ============================================================ */

function requireAuthorizedMaster() {

    const master = window.BKMaster;

    if (!master || !master.state) {

        throw createPricingError(
            "MASTER_MODULE_UNAVAILABLE",
            "BK Master authorization module is unavailable."
        );

    }

    const state = master.state;

    if (
        state.ready !== true ||
        state.authorized !== true
    ) {

        throw createPricingError(
            "MASTER_NOT_AUTHORIZED",
            "A fully initialized, authorized Master session is required."
        );

    }

    const user = auth.currentUser;

    if (
        !user ||
        !state.currentUser ||
        user.uid !== state.currentUser.uid
    ) {

        throw createPricingError(
            "MASTER_SESSION_MISMATCH",
            "The Firebase user does not match the authorized Master session."
        );

    }

    if (
        !state.masterData ||
        state.masterData.status !== "ACTIVE"
    ) {

        throw createPricingError(
            "MASTER_NOT_ACTIVE",
            "The Master account is not confirmed as ACTIVE."
        );

    }

    return user;

}


/* ============================================================
   RATE VALIDATION
   ============================================================ */

function isValidRate(value) {

    return (
        typeof value === "number" &&
        Number.isFinite(value) &&
        value >= 0 &&
        value <= MAX_RATE
    );

}


/* ============================================================
   CATALOGUE VALIDATION
   ============================================================ */

function validateCatalog(catalog) {

    const errors = [];
    const seenIds = new Set();

    if (!Array.isArray(catalog)) {

        return {
            valid: false,
            errors: ["Catalogue must be an array."]
        };

    }

    if (
        catalog.length !== SERVICE_DEFINITIONS.length
    ) {

        errors.push(
            "Catalogue must contain exactly " +
            SERVICE_DEFINITIONS.length +
            " supported services."
        );

    }

    catalog.forEach(function (item, index) {

        const prefix = "Item " + index + ": ";

        if (
            !item ||
            typeof item !== "object" ||
            Array.isArray(item)
        ) {

            errors.push(prefix + "Invalid item.");
            return;

        }

        if (
            typeof item.id !== "string" ||
            item.id.length === 0 ||
            item.id.trim() !== item.id
        ) {

            errors.push(prefix + "Invalid service ID.");
            return;

        }

        if (seenIds.has(item.id)) {

            errors.push(
                prefix + "Duplicate service ID: " + item.id
            );

            return;

        }

        seenIds.add(item.id);

        const definition = DEFINITION_BY_ID.get(item.id);

        if (!definition) {

            errors.push(
                prefix + "Unsupported service ID: " + item.id
            );

            return;

        }

        ["category", "label", "unit"].forEach(function (key) {

            if (item[key] !== definition[key]) {

                errors.push(
                    prefix + "Unsupported " + key + "."
                );

            }

        });

        if (!isValidRate(item.providerCostRate)) {

            errors.push(
                prefix +
                "Provider cost must be a finite, non-negative number."
            );

        }

        if (!isValidRate(item.restaurantPriceRate)) {

            errors.push(
                prefix +
                "Restaurant price must be a finite, non-negative number."
            );

        }

        if (typeof item.enabled !== "boolean") {

            errors.push(
                prefix + "Enabled must be true or false."
            );

        }

    });

    for (const definition of SERVICE_DEFINITIONS) {

        if (!seenIds.has(definition.id)) {

            errors.push(
                "Missing supported service: " + definition.id
            );

        }

    }

    return {
        valid: errors.length === 0,
        errors: errors
    };

}


/* ============================================================
   NORMALIZE SAVED CATALOGUE
   Reject incomplete or unsupported data.
   Do not silently invent missing saved entries.
   ============================================================ */

function normalizeSavedCatalog(savedCatalog) {

    if (!Array.isArray(savedCatalog)) {

        throw createPricingError(
            "INVALID_SAVED_CATALOG",
            "Saved pricing catalogue is missing or invalid."
        );

    }

    const savedById = new Map();

    savedCatalog.forEach(function (item) {

        if (
            !item ||
            typeof item !== "object" ||
            Array.isArray(item) ||
            typeof item.id !== "string"
        ) {

            throw createPricingError(
                "INVALID_SAVED_ITEM",
                "Saved pricing contains an invalid service item."
            );

        }

        if (savedById.has(item.id)) {

            throw createPricingError(
                "DUPLICATE_SAVED_ID",
                "Saved pricing contains a duplicate service ID."
            );

        }

        savedById.set(item.id, item);

    });

    const normalized = getDefaultCatalog().map(function (definition) {

        const saved = savedById.get(definition.id);

        if (!saved) {

            throw createPricingError(
                "INCOMPLETE_SAVED_CATALOG",
                "Saved pricing is missing service: " + definition.id
            );

        }

        return {
            id: definition.id,
            category: definition.category,
            label: definition.label,
            unit: definition.unit,

            providerCostRate: saved.providerCostRate,
            restaurantPriceRate: saved.restaurantPriceRate,

            enabled: saved.enabled
        };

    });

    for (const savedId of savedById.keys()) {

        if (!DEFINITION_BY_ID.has(savedId)) {

            throw createPricingError(
                "UNKNOWN_SAVED_SERVICE",
                "Saved pricing contains an unsupported service: " +
                savedId
            );

        }

    }

    const validation = validateCatalog(normalized);

    if (!validation.valid) {

        throw createPricingError(
            "SAVED_CATALOG_VALIDATION_FAILED",
            "Saved pricing catalogue failed validation.",
            validation.errors
        );

    }

    return normalized;

}


/* ============================================================
   LOAD PRICING
   Read-only operation. Never creates a missing document.
   ============================================================ */

async function loadPricing() {

    requireAuthorizedMaster();

    try {

        const snapshot = await getDoc(
            getPricingDocumentReference()
        );

        if (!snapshot.exists()) {

            return {
                success: true,
                exists: false,
                version: VERSION,
                schemaVersion: SCHEMA_VERSION,
                revision: 0,
                updatedAt: null,
                updatedBy: null,
                catalog: getDefaultCatalog(),
                message: "Pricing has not been configured yet."
            };

        }

        const data = snapshot.data();

        if (data.schemaVersion !== SCHEMA_VERSION) {

            throw createPricingError(
                "UNSUPPORTED_SCHEMA_VERSION",
                "The saved pricing schema is unsupported. Migration or review is required."
            );

        }

        if (
            !Number.isSafeInteger(data.revision) ||
            data.revision < 1
        ) {

            throw createPricingError(
                "INVALID_SAVED_REVISION",
                "Saved pricing contains an invalid revision number."
            );

        }

        if (
            typeof data.updatedBy !== "string" ||
            data.updatedBy.length === 0
        ) {

            throw createPricingError(
                "INVALID_SAVED_METADATA",
                "Saved pricing is missing its Master audit identifier."
            );

        }

        const catalog = normalizeSavedCatalog(data.catalog);

        return {
            success: true,
            exists: true,
            version: VERSION,
            schemaVersion: data.schemaVersion,
            revision: data.revision,
            updatedAt: data.updatedAt || null,
            updatedBy: data.updatedBy,
            catalog: catalog
        };

    } catch (error) {

        console.error(
            "BK PLATFORM PRICING: LOAD FAILED",
            {
                code: error.code || "LOAD_FAILED",
                message: error.message
            }
        );

        throw error;

    }

}


/* ============================================================
   SAFE CATALOGUE COPY
   Whitelist supported fields only.
   ============================================================ */

function createSafeCatalog(catalog) {

    return catalog.map(function (item) {

        return {
            id: item.id,
            category: item.category,
            label: item.label,
            unit: item.unit,

            providerCostRate: item.providerCostRate,
            restaurantPriceRate: item.restaurantPriceRate,

            enabled: item.enabled
        };

    });

}


/* ============================================================
   SAVE PRICING
   Uses a Firestore transaction to serialize revision changes.

   expectedRevision:
     - 0 when creating the first catalogue
     - Existing loaded revision when updating

   This prevents a stale editor from silently overwriting a
   newer catalogue revision.
   ============================================================ */

async function savePricing(catalog, options) {

    const masterUser = requireAuthorizedMaster();

    const settings = options || {};

    const expectedRevision = settings.expectedRevision;

    if (
        !Number.isSafeInteger(expectedRevision) ||
        expectedRevision < 0
    ) {

        throw createPricingError(
            "EXPECTED_REVISION_REQUIRED",
            "Provide the revision returned by loadPricing(). " +
            "Use 0 only when creating the first pricing catalogue."
        );

    }

    const validation = validateCatalog(catalog);

    if (!validation.valid) {

        throw createPricingError(
            "PRICING_VALIDATION_FAILED",
            "Pricing validation failed.",
            validation.errors
        );

    }

    const safeCatalog = createSafeCatalog(catalog);

    const reference = getPricingDocumentReference();

    try {

        const result = await runTransaction(
            db,
            async function (transaction) {

                /*
                 * Recheck the Master session immediately before
                 * the transaction writes.
                 */
                const currentUser = requireAuthorizedMaster();

                if (currentUser.uid !== masterUser.uid) {

                    throw createPricingError(
                        "MASTER_SESSION_CHANGED",
                        "The Master session changed during the save."
                    );

                }

                const snapshot = await transaction.get(reference);

                let currentRevision = 0;

                if (snapshot.exists()) {

                    const existingData = snapshot.data();

                    if (
                        existingData.schemaVersion !== SCHEMA_VERSION
                    ) {

                        throw createPricingError(
                            "UNSUPPORTED_SCHEMA_VERSION",
                            "Existing pricing requires a schema review before it can be updated."
                        );

                    }

                    if (
                        !Number.isSafeInteger(existingData.revision) ||
                        existingData.revision < 1
                    ) {

                        throw createPricingError(
                            "INVALID_SAVED_REVISION",
                            "Existing pricing has an invalid revision."
                        );

                    }

                    currentRevision = existingData.revision;

                }

                if (currentRevision !== expectedRevision) {

                    throw createPricingError(
                        "REVISION_CONFLICT",
                        "Pricing changed since it was loaded. Reload the latest catalogue before saving."
                    );

                }

                const nextRevision = currentRevision + 1;

                if (!Number.isSafeInteger(nextRevision)) {

                    throw createPricingError(
                        "REVISION_OVERFLOW",
                        "The pricing revision limit has been reached."
                    );

                }

                transaction.set(reference, {

                    schemaVersion: SCHEMA_VERSION,
                    version: VERSION,

                    catalog: safeCatalog,

                    revision: nextRevision,

                    updatedAt: serverTimestamp(),
                    updatedBy: currentUser.uid

                });

                return {
                    revision: nextRevision,
                    updatedBy: currentUser.uid
                };

            }
        );

        console.log(
            "BK PLATFORM PRICING: SAVE SUCCEEDED",
            {
                revision: result.revision,
                itemCount: safeCatalog.length
            }
        );

        return {
            success: true,
            version: VERSION,
            schemaVersion: SCHEMA_VERSION,
            revision: result.revision,
            updatedBy: result.updatedBy
        };

    } catch (error) {

        console.error(
            "BK PLATFORM PRICING: SAVE FAILED",
            {
                code: error.code || "SAVE_FAILED",
                message: error.message
            }
        );

        throw error;

    }

}


/* ============================================================
   PUBLIC API
   ============================================================ */

const BKPlatformPricingControl = Object.freeze({

    version: VERSION,
    schemaVersion: SCHEMA_VERSION,

    getDefaultCatalog: getDefaultCatalog,

    validateCatalog: validateCatalog,

    loadPricing: loadPricing,

    savePricing: savePricing

});


window.BKPlatformPricingControl = BKPlatformPricingControl;


console.log(
    "BK PLATFORM PRICING CONTROL: MODULE LOADED",
    VERSION
);