/* =========================================================
   BK MASTER — SUBSCRIPTION CONTROL
   Part 1 — Subscription Plan Readiness & Loader
   UI Integration Fix — Part 1 + Part 2
   UI Management Controls — Version 1.1.0
   ========================================================= */

import {
  masterAuth as auth,
  masterDb as db
} from "../firebase-sessions.js";

import {
  collection,
  getDocs,
  query,
  orderBy
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";


window.BKMasterSubscriptionControl = (() => {

  const COLLECTION_NAME = "subscriptionPlans";

  const state = {
    initialized: false,
    ready: false,
    loading: false,
    loaded: false,
    plans: [],
    error: null
  };


  /* =======================================================
     LOGGING
     ======================================================= */

  function log(...args) {
    console.log(
      "BK MASTER SUBSCRIPTION CONTROL:",
      ...args
    );
  }


  function warn(...args) {
    console.warn(
      "BK MASTER SUBSCRIPTION CONTROL:",
      ...args
    );
  }


  function error(...args) {
    console.error(
      "BK MASTER SUBSCRIPTION CONTROL:",
      ...args
    );
  }


  /* =======================================================
     SECURITY — HTML ESCAPE
     ======================================================= */

  function escapeHTML(value) {

    return String(value ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");

  }


  /* =======================================================
     DOM HELPERS
     ======================================================= */

  function getSubscriptionSection() {

    return document.getElementById(
      "masterSectionSubscription"
    );

  }


  function getPlansContainer() {

    const section =
      getSubscriptionSection();


    if (!section) {

      warn(
        "Subscription section not found"
      );

      return null;

    }


    let container =
      document.getElementById(
        "bkMasterSubscriptionPlansContainer"
      );


    if (container) {

      return container;

    }


    container =
      document.createElement("div");


    container.id =
      "bkMasterSubscriptionPlansContainer";


    container.className =
      "bk-master-subscription-plans-container";


    section.appendChild(
      container
    );


    log(
      "Plans display container created."
    );


    return container;

  }


  /* =======================================================
     MASTER AUTHORIZATION
     ======================================================= */

  async function verifyMasterAccess() {

    try {

      const currentUser =
        auth.currentUser;


      if (!currentUser) {

        warn(
          "MASTER USER NOT READY"
        );

        return false;

      }


      if (
        window.BKMaster &&
        window.BKMaster.state &&
        window.BKMaster.state.authorized === true
      ) {

        return true;

      }


      warn(
        "MASTER CORE AUTHORIZATION NOT READY"
      );


      return false;

    } catch (err) {

      error(
        "MASTER ACCESS CHECK FAILED:",
        err
      );


      return false;

    }

  }


  /* =======================================================
     EMPTY STATE
     ======================================================= */

  function renderEmptyState() {

    const container =
      getPlansContainer();


    if (!container) {

      return;

    }


    container.innerHTML = `

      <div class="bk-master-subscription-panel">

        <div class="bk-master-subscription-empty">

          <div class="bk-master-subscription-empty-icon">
            ◈
          </div>

          <h3>
            No Subscription Plans Yet
          </h3>

          <p>
            Subscription plans will appear here once they are
            created from BK Master Control.
          </p>

        </div>

      </div>

    `;

  }


  /* =======================================================
     PLAN CARD
     ======================================================= */

  function renderPlanCard(plan) {

  const name =
    plan.name ||
    plan.planName ||
    "Unnamed Plan";


  const description =
    plan.description ||
    "No description available.";


  const amount =
    plan.baseAmount !== undefined &&
    plan.baseAmount !== null
      ? `₹${plan.baseAmount}`
      : "Activation amount not configured";


  const status =
    plan.status ||
    "UNKNOWN";


  const planId =
    plan.planId ||
    "ID NOT AVAILABLE";


  const entitlementKey =
    plan.entitlementKey ||
    "NOT CONFIGURED";


  const isActive =
    String(status).toUpperCase() === "ACTIVE";


  return `

    <div
      class="bk-master-subscription-card"
      data-plan-id="${escapeHTML(planId)}"
    >

      <!-- CARD HEADER -->

      <div class="bk-master-subscription-card-head">

        <div>

          <h3>
            ${escapeHTML(name)}
          </h3>

          <span
            class="bk-master-subscription-cycle"
          >
            ONE-TIME ACTIVATION
          </span>

        </div>


        <span
          class="bk-master-subscription-status"
        >
          ${escapeHTML(status)}

        </span>

      </div>


      <!-- PLAN ID -->

      <div
        class="bk-master-subscription-plan-id"
      >

        <span
          class="bk-master-subscription-plan-id-label"
        >
          Plan ID
        </span>

        <code>
          ${escapeHTML(planId)}
        </code>

      </div>


      <!-- ENTITLEMENT -->

      <div
        class="bk-master-subscription-plan-id"
      >

        <span
          class="bk-master-subscription-plan-id-label"
        >
          Entitlement
        </span>

        <code>
          ${escapeHTML(entitlementKey)}
        </code>

      </div>


      <!-- CARD BODY -->

      <div class="bk-master-subscription-card-body">

        <p>
          ${escapeHTML(description)}
        </p>


        <div
          class="bk-master-subscription-price"
        >
          ${escapeHTML(amount)}
        </div>


        <small>
          One-time activation / plan-change payment
        </small>

      </div>


      <!-- MANAGEMENT ACTIONS -->

      <div
        class="bk-master-subscription-card-actions"
      >

        <button
          type="button"
          class="bk-master-subscription-edit-button"
          data-subscription-action="edit"
          data-plan-id="${escapeHTML(planId)}"
        >
          Edit Plan
        </button>


        ${
          isActive
            ? `
              <button
                type="button"
                class="bk-master-subscription-disable-button"
                data-subscription-action="disable"
                data-plan-id="${escapeHTML(planId)}"
              >
                Disable Plan
              </button>
            `
            : `
              <button
                type="button"
                class="bk-master-subscription-enable-button"
                data-subscription-action="enable"
                data-plan-id="${escapeHTML(planId)}"
              >
                Enable Plan
              </button>

              <button
                type="button"
                class="bk-master-subscription-delete-button"
                data-subscription-action="delete"
                data-plan-id="${escapeHTML(planId)}"
              >
                Delete Plan
              </button>
            `
        }

      </div>

    </div>

  `;

}

  /* =======================================================
     PLAN LIST
     ======================================================= */

  function renderPlans() {

    const container =
      getPlansContainer();


    if (!container) {

      return;

    }


    if (!state.plans.length) {

      renderEmptyState();

      return;

    }


    const cards =
      state.plans
        .map(
          plan =>
            renderPlanCard(plan)
        )
        .join("");


    container.innerHTML = `

      <div class="bk-master-subscription-panel">


        <div
          class="bk-master-subscription-header"
        >

          <div>

            <h2>
              Subscription Plans
            </h2>

            <p>
              Manage configurable subscription plans
              for BK restaurants.
            </p>

          </div>


          <div
            class="bk-master-subscription-count"
          >

            ${state.plans.length}
            Plan${state.plans.length === 1 ? "" : "s"}

          </div>

        </div>


        <div
          class="bk-master-subscription-grid"
        >

          ${cards}

        </div>


      </div>

    `;


    bindPlanActionButtons();


    log(
      "Plan cards rendered:",
      state.plans.length
    );

  }


  /* =======================================================
     PLAN ACTION BUTTONS
     UI ONLY — REAL ACTIONS COME NEXT
     ======================================================= */

  function bindPlanActionButtons() {

    const container =
      getPlansContainer();


    if (!container) {

      return;

    }


    const buttons =
      container.querySelectorAll(
        "[data-subscription-action]"
      );


    buttons.forEach(button => {

      button.addEventListener(
        "click",
        () => {

          const action =
            button.dataset.subscriptionAction;


          const planId =
            button.dataset.planId;


          const plan =
            state.plans.find(
              item =>
                item.planId === planId
            );


          if (!plan) {

            warn(
              "Plan not found for action:",
              planId
            );

            return;

          }


          if (action === "edit") {

            handleEditPlan(plan);

            return;

          }


          if (action === "disable") {

            handleDisablePlan(plan);

            return;

          }


          if (action === "enable") {

            handleEnablePlan(plan);

            return;

          }
          
          if (action === "delete") {

  handleDeletePlan(plan);

  return;

}

        }
      );

    });


    log(
      "Plan action buttons:",
      buttons.length
    );

  }


  /* =======================================================
     EDIT — PREPARATION ONLY
     ======================================================= */

  function handleEditPlan(plan) {

    log(
      "EDIT PLAN REQUEST:",
      plan.planId
    );


    if (
      window.BKMasterSubscriptionPlanManagement &&
      typeof
        window.BKMasterSubscriptionPlanManagement.editPlan ===
        "function"
    ) {

      const opened =
        window.BKMasterSubscriptionPlanManagement
          .editPlan(plan);


      if (opened) {

        log(
          "EDIT PLAN FORM OPENED:",
          plan.planId
        );

      }


      return;

    }


    warn(
      "Plan Management module not available."
    );

  }


  /* =======================================================
     DISABLE / ENABLE — REAL MANAGEMENT ENGINE CONNECTION
     ======================================================= */

  async function handleDisablePlan(plan) {

    log(
      "DISABLE PLAN REQUEST:",
      plan.planId
    );


    if (
      !window.BKMasterSubscriptionPlanManagement ||
      typeof
        window.BKMasterSubscriptionPlanManagement
          .setPlanStatus !== "function"
    ) {

      warn(
        "Subscription Plan Management status engine not available."
      );

      window.alert(
        "Subscription Plan Management is not ready yet."
      );

      return;
    }


    const result =
      await
        window
          .BKMasterSubscriptionPlanManagement
          .setPlanStatus(
            plan,
            "INACTIVE"
          );


    if (
      result &&
      result.success
    ) {

      log(
        "DISABLE PLAN: SUCCESS",
        plan.planId
      );

      return;
    }


    if (
      result &&
      result.cancelled
    ) {

      log(
        "DISABLE PLAN: CANCELLED",
        plan.planId
      );

      return;
    }


    warn(
      "DISABLE PLAN: FAILED",
      result?.error
    );

  }
  /* =======================================================
     ENABLE — PREPARATION ONLY
     ======================================================= */

  async function handleEnablePlan(plan) {

    log(
      "ENABLE PLAN REQUEST:",
      plan.planId
    );


    if (
      !window.BKMasterSubscriptionPlanManagement ||
      typeof
        window.BKMasterSubscriptionPlanManagement
          .enablePlan !== "function"
    ) {

      warn(
        "Subscription Plan Management enable engine not available."
      );

      window.alert(
        "Subscription Plan Management is not ready yet."
      );

      return;
    }


    const result =
      await
        window
          .BKMasterSubscriptionPlanManagement
          .enablePlan(
            plan
          );


    if (
      result &&
      result.success
    ) {

      log(
        "ENABLE PLAN: SUCCESS",
        plan.planId
      );

      return;
    }


    if (
      result &&
      result.cancelled
    ) {

      log(
        "ENABLE PLAN: CANCELLED",
        plan.planId
      );

      return;
    }


    warn(
      "ENABLE PLAN: FAILED",
      result?.error
    );

  }
  
/* =======================================================
   DELETE — REAL MANAGEMENT ENGINE CONNECTION
   ======================================================= */

async function handleDeletePlan(plan) {

  log(
    "DELETE PLAN REQUEST:",
    plan.planId
  );


  if (
    !window.BKMasterSubscriptionPlanManagement ||
    typeof
      window.BKMasterSubscriptionPlanManagement
        .deletePlan !== "function"
  ) {

    warn(
      "Subscription Plan Management delete engine not available."
    );

    window.alert(
      "Subscription Plan Management delete engine is not ready yet."
    );

    return;

  }


  const result =
    await
      window
        .BKMasterSubscriptionPlanManagement
        .deletePlan(
          plan
        );


  if (
    result &&
    result.success
  ) {

    log(
      "DELETE PLAN: SUCCESS",
      plan.planId
    );

    return;

  }


  if (
    result &&
    result.cancelled
  ) {

    log(
      "DELETE PLAN: CANCELLED",
      plan.planId
    );

    return;

  }


  warn(
    "DELETE PLAN: FAILED",
    result?.error
  );

}

  /* =======================================================
     LOAD PLANS
     ======================================================= */

  async function loadPlans() {

    if (state.loading) {

      return;

    }


    state.loading =
      true;

    state.error =
      null;


    try {

      const authorized =
        await verifyMasterAccess();


      if (!authorized) {

        state.error =
          "Master authorization not ready.";

        return;

      }


      log(
        "Loading subscription plans..."
      );


      const plansRef =
        collection(
          db,
          COLLECTION_NAME
        );


      let snapshot;


      try {

        const plansQuery =
          query(
            plansRef,
            orderBy(
              "createdAt",
              "desc"
            )
          );


        snapshot =
          await getDocs(
            plansQuery
          );


      } catch (orderError) {

        warn(
          "createdAt ordering unavailable. Loading without order."
        );


        snapshot =
          await getDocs(
            plansRef
          );

      }


state.plans =
  snapshot.docs.map(
    docSnap => ({

      ...docSnap.data(),

      planId:
        docSnap.id

    })
  );

      state.loaded =
        true;


      log(
        `Subscription plans loaded: ${state.plans.length}`
      );


      renderPlans();


    } catch (err) {

      state.error =
        err;


      error(
        "SUBSCRIPTION PLAN LOAD FAILED:",
        err
      );


    } finally {

      state.loading =
        false;

    }

  }


  /* =======================================================
     INITIALIZATION
     ======================================================= */

  async function init() {

    if (
      state.initialized &&
      state.ready
    ) {

      return true;

    }


    log(
      "INITIALIZING..."
    );


    const authorized =
      await verifyMasterAccess();


    if (!authorized) {

      warn(
        "Waiting for BK Master authorization."
      );


      return false;

    }


    state.initialized =
      true;

    state.ready =
      true;


    log(
      "AUTHORIZATION: READY"
    );


    log(
      `Collection: ${COLLECTION_NAME}`
    );


    getPlansContainer();


    await loadPlans();


    log(
      "PART 1 READY"
    );


    return true;

  }


  /* =======================================================
     PUBLIC API
     ======================================================= */

  return {

    state,

    init,

    loadPlans,

    renderPlans,

    getPlans() {

      return [
        ...state.plans
      ];

    }

  };

})();


/* =========================================================
   AUTO START
   ========================================================= */

(async () => {

  try {

    const initialized =
      await
        window
          .BKMasterSubscriptionControl
          .init();


    if (!initialized) {

      const waitForMaster =
        setInterval(
          async () => {

            const masterReady =
              window.BKMaster &&
              window.BKMaster.state &&
              window.BKMaster.state.authorized === true;


            if (!masterReady) {

              return;

            }


            clearInterval(
              waitForMaster
            );


            console.log(
              "BK MASTER SUBSCRIPTION CONTROL: MASTER AUTHORIZATION DETECTED"
            );


            await
              window
                .BKMasterSubscriptionControl
                .init();

          },
          500
        );

    }

  } catch (err) {

    console.error(
      "BK MASTER SUBSCRIPTION CONTROL: AUTO START FAILED:",
      err
    );

  }

})();