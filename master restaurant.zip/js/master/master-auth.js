
"use strict";

import {
    masterAuth,
    masterDb
} from "../firebase-sessions.js";

import {
    onAuthStateChanged,
    setPersistence,
    browserLocalPersistence,
    signInWithEmailAndPassword,
    signOut
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-auth.js";

import {
    doc,
    getDoc
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";


const BKMaster = {

    state: {
        currentUser: null,
        masterData: null,
        authChecked: false,
        authorized: false,
        ready: false
    },


    async init() {

        console.log("==========================================");
        console.log("BK MASTER AUTH: INITIALIZING");
        console.log("==========================================");

        try {

            await setPersistence(
                masterAuth,
                browserLocalPersistence
            );

            console.log(
                "BK MASTER AUTH: Persistence = browserLocalPersistence"
            );

        } catch (error) {

            console.warn(
                "BK Master persistence setup failed:",
                error
            );
        }

        await this.setupAuthListener();
    },


    setupAuthListener() {

        return new Promise((resolve, reject) => {

            onAuthStateChanged(
                masterAuth,
                async (user) => {

                    try {

                        this.state.authChecked = true;

                        if (!user) {

                            this.state.currentUser = null;
                            this.state.masterData = null;
                            this.state.authorized = false;
                            this.state.ready = false;

                            console.log(
                                "BK MASTER AUTH: No authenticated user."
                            );

                            resolve();
                            return;
                        }


                        this.state.currentUser = user;

                        console.log(
                            "BK MASTER AUTH: User detected:",
                            user.uid
                        );

                        console.log(
                            "BK MASTER AUTH: Email:",
                            user.email || "(no email)"
                        );


                        const authorized =
                            await this.checkMasterAuthorization(
                                user.uid
                            );


                        if (!authorized) {

                            console.warn(
                                "BK MASTER AUTH: Access denied."
                            );

                            this.state.authorized = false;
                            this.state.ready = false;

                            this.state.currentUser = null;
                            this.state.masterData = null;

                            try {

                                await signOut(masterAuth);

                            } catch (signOutError) {

                                console.error(
                                    "BK MASTER AUTH: Sign-out after access denial failed:",
                                    signOutError
                                );
                            }

                            resolve();
                            return;
                        }


                        this.state.authorized = true;
                        this.state.ready = true;

                        console.log(
                            "=========================================="
                        );

                        console.log(
                            "BK MASTER AUTH: ACCESS GRANTED"
                        );

                        console.log(
                            "BK MASTER AUTH: READY"
                        );

                        console.log(
                            "Master UID:",
                            user.uid
                        );

                        console.log(
                            "=========================================="
                        );

                        resolve();

                    } catch (error) {

                        this.state.authorized = false;
                        this.state.ready = false;

                        console.error(
                            "BK MASTER AUTH ERROR:",
                            error
                        );

                        reject(error);
                    }
                }
            );
        });
    },


    async login(email, password) {

        try {

            const cleanEmail =
                String(email || "").trim();

            const cleanPassword =
                String(password || "");


            if (!cleanEmail) {

                throw new Error(
                    "Master email is required."
                );
            }

            if (!cleanPassword) {

                throw new Error(
                    "Master password is required."
                );
            }


            console.log(
                "=========================================="
            );

            console.log(
                "BK MASTER AUTH: SIGN-IN STARTING"
            );

            console.log(
                "Email:",
                cleanEmail
            );

            console.log(
                "=========================================="
            );


            await setPersistence(
                masterAuth,
                browserLocalPersistence
            );


            const credential =
                await signInWithEmailAndPassword(
                    masterAuth,
                    cleanEmail,
                    cleanPassword
                );


            const user =
                credential.user;


            console.log(
                "=========================================="
            );

            console.log(
                "BK MASTER AUTH: SIGN-IN SUCCESS"
            );

            console.log(
                "Firebase UID:",
                user.uid
            );

            console.log(
                "Firebase Email:",
                user.email || "(no email)"
            );

            console.log(
                "=========================================="
            );


            return user;

        } catch (error) {

            console.error(
                "=========================================="
            );

            console.error(
                "BK MASTER AUTH: SIGN-IN FAILED"
            );

            console.error(
                "Error code:",
                error?.code || "(unknown)"
            );

            console.error(
                "Error message:",
                error?.message || "(unknown)"
            );

            console.error(
                "=========================================="
            );

            throw error;
        }
    },


    async checkMasterAuthorization(uid) {

        if (!uid) {
            return false;
        }


        console.log(
            "BK MASTER AUTH: Checking masterAdmins record..."
        );


        const masterRef =
            doc(
                masterDb,
                "masterAdmins",
                uid
            );


        const masterSnapshot =
            await getDoc(masterRef);


        if (!masterSnapshot.exists()) {

            console.warn(
                "BK MASTER AUTH: Master record not found."
            );

            return false;
        }


        const masterData =
            masterSnapshot.data();

        this.state.masterData =
            masterData;


        console.log(
            "BK MASTER AUTH: Master record found."
        );

        console.log(
            "Master status:",
            masterData.status
        );


        if (masterData.status !== "ACTIVE") {

            console.warn(
                "BK MASTER AUTH: Master account is not ACTIVE."
            );

            return false;
        }

        return true;
    },


    async logout() {

        try {

            await signOut(masterAuth);

            this.state.currentUser = null;
            this.state.masterData = null;
            this.state.authorized = false;
            this.state.ready = false;

            console.log(
                "BK MASTER AUTH: Logged out."
            );

        } catch (error) {

            console.error(
                "BK MASTER LOGOUT ERROR:",
                error
            );

            throw error;
        }
    }
};


window.BKMaster =
    BKMaster;


document.addEventListener(
    "DOMContentLoaded",
    async function() {

        try {

            await BKMaster.init();

        } catch (error) {

            console.error(
                "BK Master initialization failed:",
                error
            );
        }
    }
);
