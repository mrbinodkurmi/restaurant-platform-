"use strict";

/*
========================================================
BK MASTER — SUBSCRIPTION & BILLING CONTROL
PART 1 — ENGINE FOUNDATION + CARD RENDERER
PART 2 — PAYMENT ARCHITECTURE FOUNDATION
PART 2B — FIRESTORE PAYMENT SUBMISSION LAYER
========================================================
*/

const BKMasterSubscriptionBillingControl = {

    /*
    ========================================================
    STATE
    ========================================================
    */

    state: {

        initialized: false,

        ready: false,

        loading: false,

        saving: false,

        error: null,

        selectedRestaurantId: null,

        paymentArchitectureReady: false,

        paymentWriteReady: false,

        paymentStatuses: [

            "PAYMENT_INITIATED",

            "PAYMENT_SUBMITTED",

            "VERIFICATION_PENDING",

            "VERIFIED",

            "REJECTED",

            "REFUND_PENDING",

            "REFUNDED"

        ]

    },


    /*
    ========================================================
    INITIALIZATION
    ========================================================
    */

    init() {

        if (this.state.initialized) {

            console.log(
                "BK MASTER SUBSCRIPTION BILLING: ALREADY INITIALIZED"
            );

            return;
        }


        console.log(
            "BK MASTER SUBSCRIPTION BILLING: INITIALIZING..."
        );


        this.state.initialized = true;


        /*
        ====================================================
        PAYMENT ARCHITECTURE
        ====================================================
        */

        this.initializePaymentArchitecture();


        /*
        ====================================================
        PAYMENT WRITE FOUNDATION
        ====================================================
        */

        this.initializePaymentWriteLayer();


        this.state.ready = true;


        console.log(
            "BK MASTER SUBSCRIPTION BILLING: PART 1 READY"
        );


        console.log(
            "BK MASTER SUBSCRIPTION BILLING: PAYMENT ARCHITECTURE READY:",
            this.state.paymentArchitectureReady
        );


        console.log(
            "BK MASTER SUBSCRIPTION BILLING: PAYMENT WRITE READY:",
            this.state.paymentWriteReady
        );


        console.log(
            "BK MASTER SUBSCRIPTION BILLING: FREE ACCESS LOGIC NOT CONNECTED YET"
        );

    },


    /*
    ========================================================
    READY CHECK
    ========================================================
    */

    isReady() {

        return (
            this.state.ready === true
        );

    },


    /*
    ========================================================
    RESTAURANT SELECTION
    ========================================================
    */

    setSelectedRestaurant(restaurantId) {

        if (!restaurantId) {

            this.state.selectedRestaurantId = null;


            console.log(
                "BK MASTER SUBSCRIPTION BILLING: RESTAURANT SELECTION CLEARED"
            );


            return;
        }


        this.state.selectedRestaurantId =
            restaurantId;


        console.log(
            "BK MASTER SUBSCRIPTION BILLING: SELECTED RESTAURANT:",
            restaurantId
        );

    },


    /*
    ========================================================
    PAYMENT SYSTEM
    PART 2 — ARCHITECTURE FOUNDATION
    ========================================================
    */

    initializePaymentArchitecture() {

        console.log(
            "BK MASTER PAYMENT: ARCHITECTURE INITIALIZING..."
        );


        this.paymentSchema = {

            collection:
                "subscriptionPayments",


            requiredFields: [

                "paymentId",

                "restaurantId",

                "ownerId",

                "planId",

                "amount",

                "currency",

                "paymentReference",

                "paymentMethod",

                "status",

                "createdAt",

                "updatedAt"

            ],


            optionalFields: [

                "submittedAt",

                "verifiedAt",

                "rejectedAt",

                "refundedAt",

                "receiptUrl",

                "receiptPath",

                "verificationMode",

                "verificationReason",

                "reviewedBy",

                "masterResponse"

            ]

        };


        console.log(
            "BK MASTER PAYMENT: COLLECTION:",
            this.paymentSchema.collection
        );


        console.log(
            "BK MASTER PAYMENT: REQUIRED FIELDS:",
            this.paymentSchema.requiredFields
        );


        console.log(
            "BK MASTER PAYMENT: OPTIONAL FIELDS:",
            this.paymentSchema.optionalFields
        );


        console.log(
            "BK MASTER PAYMENT: STATUS ENGINE READY"
        );


        this.state.paymentArchitectureReady =
            true;


        console.log(
            "BK MASTER PAYMENT: PART 2 READY"
        );

    },


    /*
    ========================================================
    PAYMENT ARCHITECTURE READY CHECK
    ========================================================
    */

    isPaymentArchitectureReady() {

        return (
            this.state.paymentArchitectureReady === true
        );

    },


    /*
    ========================================================
    PAYMENT STATUS VALIDATION
    ========================================================
    */

    isValidPaymentStatus(status) {

        return (

            typeof status === "string" &&

            this.state.paymentStatuses.includes(
                status
            )

        );

    },


    /*
    ========================================================
    BUILD PAYMENT DRAFT
    ========================================================
    */

    buildPaymentDraft(data = {}) {

        const paymentId =
            this.getSafeValue(
                data,
                ["paymentId"],
                ""
            );


        const restaurantId =
            this.getSafeValue(
                data,
                ["restaurantId"],
                ""
            );


        const ownerId =
            this.getSafeValue(
                data,
                ["ownerId"],
                ""
            );


        const planId =
            this.getSafeValue(
                data,
                ["planId"],
                ""
            );


        const paymentReference =
            this.getSafeValue(
                data,
                ["paymentReference"],
                ""
            );


        const paymentMethod =
            this.getSafeValue(
                data,
                ["paymentMethod"],
                ""
            );


        const currency =
            this.getSafeValue(
                data,
                ["currency"],
                "INR"
            );


        const amount =
            Number(
                data.amount
            );


        const status =
            this.getSafeValue(
                data,
                ["status"],
                "PAYMENT_INITIATED"
            );


        return {

            paymentId,

            restaurantId,

            ownerId,

            planId,

            amount,

            currency,

            paymentReference,

            paymentMethod,

            status

        };

    },


    /*
    ========================================================
    VALIDATE PAYMENT DRAFT
    ========================================================
    */

    validatePaymentDraft(data = {}) {

        const errors = [];


        const draft =
            this.buildPaymentDraft(
                data
            );


        if (!draft.paymentId) {

            errors.push(
                "paymentId is required"
            );

        }


        if (!draft.restaurantId) {

            errors.push(
                "restaurantId is required"
            );

        }


        if (!draft.ownerId) {

            errors.push(
                "ownerId is required"
            );

        }


        if (!draft.planId) {

            errors.push(
                "planId is required"
            );

        }


        if (

            !Number.isFinite(
                draft.amount
            ) ||

            draft.amount <= 0

        ) {

            errors.push(
                "amount must be greater than 0"
            );

        }


        if (!draft.paymentMethod) {

            errors.push(
                "paymentMethod is required"
            );

        }


        if (

            !this.isValidPaymentStatus(
                draft.status
            )

        ) {

            errors.push(
                "Invalid payment status"
            );

        }


        return {

            valid:
                errors.length === 0,

            errors,

            data:
                draft

        };

    },


    /*
    ========================================================
    PAYMENT WRITE LAYER
    PART 2B
    ========================================================
    */

    initializePaymentWriteLayer() {

        console.log(
            "BK MASTER PAYMENT: WRITE LAYER INITIALIZING..."
        );


        /*
        ----------------------------------------------------
        Firebase module is intentionally loaded dynamically.
        Existing firebase.js remains LOCKED.
        ----------------------------------------------------
        */

        this.state.paymentWriteReady =
            true;


        console.log(
            "BK MASTER PAYMENT: WRITE LAYER READY"
        );

    },


    /*
    ========================================================
    FIREBASE MODULE
    ========================================================
    */


async getFirebaseModules() {

    const firebase =
        await import(
            "../firebase-sessions.js"
        );

    if (!firebase.masterDb) {

        throw new Error(
            "BK MASTER PAYMENT: Master Firestore not found."
        );

    }

    if (!firebase.masterAuth) {

        throw new Error(
            "BK MASTER PAYMENT: Master Auth not found."
        );

    }

    const firestore =
        await import(
            "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js"
        );

    return {

        db:
            firebase.masterDb,

        auth:
            firebase.masterAuth,

        doc:
            firestore.doc,

        getDoc:
            firestore.getDoc,

        setDoc:
            firestore.setDoc,

        getDocs:
            firestore.getDocs,

        collection:
            firestore.collection,

        query:
            firestore.query,

        where:
            firestore.where,

        serverTimestamp:
            firestore.serverTimestamp,

        writeBatch:
            firestore.writeBatch,

        runTransaction:
            firestore.runTransaction,

        Timestamp:
            firestore.Timestamp

    };

},

    /*
    ========================================================
    CREATE PAYMENT ID
    ========================================================
    */

    createPaymentId() {

        return (

            "PAY-" +

            Date.now().toString(36) +

            "-" +

            Math.random()
                .toString(36)
                .slice(2, 8)
                .toUpperCase()

        );

    },


    /*
    ========================================================
    SUBMIT PAYMENT
    ========================================================
    */

    async submitPayment(data = {}) {

        if (!this.state.paymentWriteReady) {

            throw new Error(
                "Payment write layer is not ready."
            );

        }


        this.state.loading = true;

        this.state.saving = true;

        this.state.error = null;


        try {

const {
    db,
    auth,
    doc,
    getDoc,
    runTransaction,
    serverTimestamp
} = await this.getFirebaseModules();

            /*
            ==================================================
            AUTHENTICATION
            ==================================================
            */

            const currentUser =
                auth.currentUser;


            if (!currentUser) {

                throw new Error(
                    "Authentication required."
                );

            }


            /*
            ==================================================
            PAYMENT INPUT
            ==================================================
            */

const paymentId =
    String(
        data.paymentId ||
        this.createPaymentId()
    ).trim();

if (!paymentId) {
    throw new Error(
        "A valid paymentId is required."
    );
}

            const restaurantId =
                String(
                    data.restaurantId || ""
                ).trim();


            const ownerId =
                String(
                    data.ownerId || currentUser.uid
                ).trim();


            const planId =
                String(
                    data.planId || ""
                ).trim();


            const paymentReference =
    String(
        data.paymentReference || ""
    ).trim();

const normalizedPaymentReference =
    paymentReference
        .replace(/\s+/g, "")
        .toUpperCase();

if (!normalizedPaymentReference) {
    throw new Error(
        "A valid payment reference is required."
    );
}

const paymentReferenceIndexRef =
    doc(
        db,
        "paymentReferenceIndex",
        encodeURIComponent(
            normalizedPaymentReference
        )
    );

            const paymentMethod =
                String(
                    data.paymentMethod || ""
                ).trim();


            if (!restaurantId) {

                throw new Error(
                    "restaurantId is required."
                );

            }


            if (!planId) {

                throw new Error(
                    "planId is required."
                );

            }


            if (!paymentReference) {

                throw new Error(
                    "paymentReference is required."
                );

            }


            if (!paymentMethod) {

                throw new Error(
                    "paymentMethod is required."
                );

            }


            /*
            ==================================================
            OWNER CHECK
            ==================================================
            */

            if (
                ownerId !==
                currentUser.uid
            ) {

                throw new Error(
                    "Payment owner does not match authenticated user."
                );

            }


            /*
            ==================================================
            RESTAURANT READ
            ==================================================
            */

            const restaurantRef =
                doc(
                    db,
                    "restaurants",
                    restaurantId
                );


            const restaurantSnap =
                await getDoc(
                    restaurantRef
                );


            if (!restaurantSnap.exists()) {

                throw new Error(
                    "Restaurant not found."
                );

            }


            const restaurantData =
                restaurantSnap.data();


            if (
                restaurantData.ownerId !==
                currentUser.uid
            ) {

                throw new Error(
                    "Restaurant ownership validation failed."
                );

            }


            /*
            ==================================================
            PLAN READ
            ==================================================
            */

            const planRef =
                doc(
                    db,
                    "subscriptionPlans",
                    planId
                );


            const planSnap =
                await getDoc(
                    planRef
                );


            if (!planSnap.exists()) {

                throw new Error(
                    "Subscription plan not found."
                );

            }


            const planData =
                planSnap.data();


            /*
            ==================================================
            ACTIVE PLAN CHECK
            ==================================================
            */

            if (
                planData.status !==
                "ACTIVE"
            ) {

                throw new Error(
                    "Selected subscription plan is not ACTIVE."
                );

            }


            /*
            ==================================================
            PLAN AMOUNT
            ==================================================
            */

const planAmount =
    Number(
        planData.baseAmount
    );

if (
    !Number.isSafeInteger(planAmount) ||
    planAmount <= 0
) {
    throw new Error(
        "Plan amount must be a positive whole-rupee amount."
    );
}



            /*
            ==================================================
            PLAN CURRENCY
            ==================================================
            */

            const planCurrency =
                String(
                    planData.currency || ""
                ).trim();


            if (!planCurrency) {

                throw new Error(
                    "Active plan has no currency."
                );

            }


            /*
            ==================================================
            PAYMENT AMOUNT
            ==================================================
            */

            const paymentAmount =
    Number(
        data.amount
    );

if (
    !Number.isSafeInteger(paymentAmount) ||
    paymentAmount <= 0
) {
    throw new Error(
        "Payment amount must be a positive whole-rupee amount."
    );
}



            /*
            ==================================================
            EXACT PLAN AMOUNT MATCH
            ==================================================
            */

            if (
                paymentAmount !==
                planAmount
            ) {

                throw new Error(
                    `Payment amount ₹${paymentAmount} does not match active plan amount ₹${planAmount}.`
                );

            }


            /*
            ==================================================
            CURRENCY MATCH
            ==================================================
            */

            const suppliedCurrency =
                String(
                    data.currency ||
                    planCurrency
                ).trim();


            if (
                suppliedCurrency !==
                planCurrency
            ) {

                throw new Error(
                    "Payment currency does not match active plan currency."
                );

            }


                        /*
            ==================================================
            FINAL FIRESTORE PAYMENT RECORD
            ==================================================
            */

            const paymentData = {

                paymentId,

                restaurantId,

                ownerId,

                planId,

                amount:
                    planAmount,

                currency:
                    planCurrency,

                paymentReference,

                paymentMethod,

                status:
                    "PAYMENT_SUBMITTED",

                createdAt:
                    serverTimestamp(),

                updatedAt:
                    serverTimestamp(),

                submittedAt:
                    serverTimestamp()

            };


    const paymentRef =
                doc(
                    db,
                    "subscriptionPayments",
                    paymentId
                );
                


await runTransaction(
    db,
    async (transaction) => {

        // READ 1: Check whether payment ID already exists
        const existingPayment =
            await transaction.get(
                paymentRef
            );

        if (existingPayment.exists()) {
            throw new Error(
                "This paymentId already exists. Duplicate payment submission blocked."
            );
        }

        // READ 2: Check whether payment reference already exists
        const existingReference =
            await transaction.get(
                paymentReferenceIndexRef
            );

        if (existingReference.exists()) {
            throw new Error(
                "This payment reference has already been used. Duplicate payment submission blocked."
            );
        }

        // WRITE 1: Save payment record
        transaction.set(
            paymentRef,
            paymentData
        );

        // WRITE 2: Reserve unique payment reference
        transaction.set(
            paymentReferenceIndexRef,
            {
                normalizedPaymentReference,
                paymentId,
                restaurantId,
                ownerId,
                createdAt: serverTimestamp()
            }
        );

    }
);

            console.log(
                "BK MASTER PAYMENT: PAYMENT SUBMITTED:",
                paymentId
            );


            console.log(
                "BK MASTER PAYMENT: RESTAURANT:",
                restaurantId
            );


            console.log(
                "BK MASTER PAYMENT: PLAN:",
                planId
            );


            console.log(
                "BK MASTER PAYMENT: AMOUNT:",
                planAmount
            );


            console.log(
                "BK MASTER PAYMENT: STATUS:",
                "PAYMENT_SUBMITTED"
            );


            return {

                success: true,

                paymentId,

                restaurantId,

                ownerId,

                planId,

                amount:
                    planAmount,

                currency:
                    planCurrency,

                status:
                    "PAYMENT_SUBMITTED"

            };

        } catch (error) {

            this.state.error =
                error?.message ||
                "Payment submission failed.";


            console.error(
                "BK MASTER PAYMENT: PAYMENT SUBMISSION FAILED:",
                error
            );


            throw error;

        } finally {

            this.state.loading = false;

            this.state.saving = false;

        }

    },

    /*
    ========================================================
    PAYMENT REVIEW READ LAYER
    PART 2C — STEP 2
    ========================================================
    */

    async loadLatestPayment(restaurantId) {

        if (!restaurantId) {

            console.warn(
                "BK MASTER PAYMENT: Cannot load payment without restaurantId."
            );

            return null;
        }


        try {

            const {

                db,

                collection,

                query,

                where,

                getDocs

            } =
                await this.getFirebaseModules();


            /*
            ==================================================
            PAYMENT COLLECTION
            ==================================================
            */

            const paymentsRef =
                collection(
                    db,
                    "subscriptionPayments"
                );


            /*
            ==================================================
            RESTAURANT FILTER
            ==================================================
            */

            const paymentQuery =
                query(
                    paymentsRef,
                    where(
                        "restaurantId",
                        "==",
                        restaurantId
                    )
                );


            /*
            ==================================================
            READ PAYMENTS
            ==================================================
            */

            const snapshot =
                await getDocs(
                    paymentQuery
                );


            if (snapshot.empty) {

                console.log(
                    "BK MASTER PAYMENT: No payment found for restaurant:",
                    restaurantId
                );

                return null;
            }


            /*
            ==================================================
            BUILD PAYMENT LIST
            ==================================================
            */

            const payments =
                snapshot.docs.map(
                    paymentDoc => ({

                        id:
                            paymentDoc.id,

                        ...paymentDoc.data()

                    })
                );


            /*
            ==================================================
            LATEST PAYMENT
            ==================================================
            */

            payments.sort(
                (a, b) => {

                    const aTime =
                        a.submittedAt?.toMillis?.() ||
                        a.createdAt?.toMillis?.() ||
                        0;


                    const bTime =
                        b.submittedAt?.toMillis?.() ||
                        b.createdAt?.toMillis?.() ||
                        0;


                    return (
                        bTime - aTime
                    );

                }
            );


            const latestPayment =
                payments[0];


            console.log(
                "BK MASTER PAYMENT: LATEST PAYMENT LOADED:",
                latestPayment
            );


            return latestPayment;

        } catch (error) {

            console.error(
                "BK MASTER PAYMENT: PAYMENT READ FAILED:",
                error
            );


            return null;

        }

    },
    
    /*
========================================================
CONNECT LATEST PAYMENT TO BILLING CARD
PART 2C — STEP 3B
========================================================
*/

async connectLatestPaymentToCard(
    card,
    restaurantId
) {

    if (!card || !restaurantId) {

        console.warn(
            "BK MASTER PAYMENT: Cannot connect payment to card."
        );

        return;
    }


    try {

        const paymentData =
            await this.loadLatestPayment(
                restaurantId
            );


        if (!paymentData) {

            console.log(
                "BK MASTER PAYMENT: NO PAYMENT TO CONNECT:",
                restaurantId
            );

            return;
        }


        const infoItems =
            card.querySelectorAll(
                ".bk-master-card-info-item"
            );


        infoItems.forEach(
            item => {

                const label =
                    item.querySelector(
                        ".bk-master-card-info-label"
                    );


                const value =
                    item.querySelector(
                        ".bk-master-card-info-value"
                    );


                if (!label || !value) {

                    return;

                }


                const labelText =
                    label.textContent.trim();


                if (
                    labelText ===
                    "PAYMENT STATUS"
                ) {

                    value.textContent =
                        paymentData.status ||
                        "—";

                }


                if (
                    labelText ===
                    "PAYMENT REFERENCE"
                ) {

                    value.textContent =
                        paymentData.paymentReference ||
                        "—";

                }

            }
        );


        console.log(
            "BK MASTER PAYMENT: CARD PAYMENT CONNECTED:",
            {
                restaurantId,
                paymentId:
                    paymentData.paymentId ||
                    paymentData.id,
                status:
                    paymentData.status,
                paymentReference:
                    paymentData.paymentReference
            }
        );

    } catch (error) {

        console.error(
            "BK MASTER PAYMENT: CARD PAYMENT CONNECTION FAILED:",
            error
        );

    }

},

/*
========================================================
PAYMENT REVIEW STATUS LAYER
PART 2C — STEP 4A
========================================================
*/

getPaymentReviewState(paymentData = {}) {

    const status =
        String(
            paymentData.status || ""
        ).trim();


    if (
        !this.isValidPaymentStatus(
            status
        )
    ) {

        return {

            status: "UNKNOWN",

            label: "PAYMENT STATUS UNKNOWN",

            reviewable: false

        };

    }


    const reviewableStatuses = [

        "PAYMENT_SUBMITTED",

        "VERIFICATION_PENDING"

    ];


    const reviewable =
        reviewableStatuses.includes(
            status
        );


    return {

        status,

        label:
            status.replace(
                /_/g,
                " "
            ),

        reviewable

    };

},

/*
========================================================
PAYMENT REVIEW ACTION LAYER
PART 2C — STEP 4B
========================================================
*/

getPaymentReviewActions(paymentData = {}) {

    const reviewState =
        this.getPaymentReviewState(
            paymentData
        );

    if (!reviewState.reviewable) {

        return [];

    }

    if (
        reviewState.status ===
        "PAYMENT_SUBMITTED"
    ) {

        return [
            "VERIFY",
            "REJECT"
        ];

    }

    if (
        reviewState.status ===
        "VERIFICATION_PENDING"
    ) {

        return [
            "VERIFY",
            "REJECT"
        ];

    }

    return [];

},

/*
========================================================
PAYMENT REVIEW ACTION PREPARATION
PART 2C — STEP 4D
========================================================
*/

preparePaymentReviewAction(
    paymentData = {},
    action = ""
) {

    const normalizedAction =
        String(action || "")
            .trim()
            .toUpperCase();

    const reviewState =
        this.getPaymentReviewState(
            paymentData
        );

    const allowedActions =
        this.getPaymentReviewActions(
            paymentData
        );

    if (
        !reviewState.reviewable
    ) {

        return {

            ready: false,

            action: normalizedAction,

            status:
                reviewState.status,

            reason:
                "Payment is not reviewable."

        };

    }

    if (
        !allowedActions.includes(
            normalizedAction
        )
    ) {

        return {

            ready: false,

            action: normalizedAction,

            status:
                reviewState.status,

            reason:
                "Review action is not allowed."

        };

    }

    const paymentId = String(
    paymentData.paymentId ??
    paymentData.id ??
    ""
).trim();

const restaurantId = String(
    paymentData.restaurantId ?? ""
).trim();

const ownerId = String(
    paymentData.ownerId ?? ""
).trim();

    if (
        !paymentId ||
        !restaurantId ||
        !ownerId
    ) {

        return {

            ready: false,

            action: normalizedAction,

            status:
                reviewState.status,

            reason:
                "Payment identity data is incomplete."

        };

    }

    return {

        ready: true,

        action: normalizedAction,

        status:
            reviewState.status,

        paymentId,

        restaurantId,

        ownerId,

        paymentReference:
            paymentData.paymentReference ||
            "—",

        amount:
            paymentData.amount ?? null,

        currency:
            paymentData.currency ||
            "INR"

    };

},

/*
========================================================
PAYMENT REVIEW WRITE ENGINE
PART 2C — STEP 4E
ATOMIC SUBSCRIPTION ACTIVATION
========================================================
*/

async reviewPayment(
    paymentData = {},
    action = "",
    reviewReason = ""
) {

    try {

        /*
        ------------------------------------------------
        STEP 1 — FIREBASE MODULES & AUTHENTICATION
        ------------------------------------------------
        */

        const authModules =
            await this.getFirebaseModules();

        const {
            db,
            auth,
            doc,
            getDoc,
            setDoc,
            collection,
            query,
            where,
            getDocs,
            runTransaction,
            serverTimestamp,
            Timestamp
        } = authModules;

        const currentUser =
            auth.currentUser;

        if (!currentUser) {

            throw new Error(
                "Master authentication is required."
            );

        }

        if (typeof runTransaction !== "function") {

            throw new Error(
                "Firestore runTransaction is unavailable."
            );

        }


        /*
        ------------------------------------------------
        STEP 2 — PREPARE ACTION
        ------------------------------------------------
        */

        const prepared =
            this.preparePaymentReviewAction(
                paymentData,
                action
            );

        if (!prepared.ready) {

            throw new Error(
                prepared.reason ||
                "Payment review action is not ready."
            );

        }

        const cleanReason =
            String(reviewReason || "")
                .trim()
                .slice(0, 1000);

        if (!cleanReason) {

            throw new Error(
                "Payment review reason is required."
            );

        }

        if (
            prepared.action !== "VERIFY" &&
            prepared.action !== "REJECT"
        ) {

            throw new Error(
                "Unsupported payment review action."
            );

        }

        const targetStatus =
            prepared.action === "VERIFY"
                ? "VERIFIED"
                : "REJECTED";


        /*
        ------------------------------------------------
        STEP 3 — PAYMENT REFERENCE
        ------------------------------------------------
        */

        const paymentRef =
            doc(
                db,
                "subscriptionPayments",
                prepared.paymentId
            );


        /*
        ------------------------------------------------
        STEP 4 — ATOMIC REVIEW TRANSACTION
        ------------------------------------------------
        */

        const result =
            await runTransaction(
                db,
                async (transaction) => {

                    /*
                    ------------------------------------
                    READ 1 — CURRENT PAYMENT
                    ------------------------------------
                    */

                    const paymentSnapshot =
                        await transaction.get(
                            paymentRef
                        );

                    if (!paymentSnapshot.exists()) {

                        throw new Error(
                            "Payment record no longer exists."
                        );

                    }

                    const freshPaymentData =
                        paymentSnapshot.data();
                        
                                            if (
                        !freshPaymentData ||
                        typeof freshPaymentData !== "object"
                    ) {
                        throw new Error(
                            "Payment data is invalid."
                        );
                    }

                    /*
                    ------------------------------------
                    REVALIDATE REVIEW STATE
                    ------------------------------------
                    */

                    const freshReviewState =
                        this.getPaymentReviewState(
                            freshPaymentData
                        );

                    if (!freshReviewState.reviewable) {

                        throw new Error(
                            "Payment is no longer reviewable."
                        );

                    }

                    const freshAllowedActions =
                        this.getPaymentReviewActions(
                            freshPaymentData
                        );

                    if (
                        !freshAllowedActions.includes(
                            prepared.action
                        )
                    ) {

                        throw new Error(
                            "Payment review action is no longer allowed."
                        );

                    }

                    /*
                    ------------------------------------
                    REJECT PATH
                    ------------------------------------
                    */

                    if (
                        prepared.action === "REJECT"
                    ) {

                        transaction.set(
                            paymentRef,
                            {

                                status: "REJECTED",

                                reviewedBy:
                                    currentUser.uid,

                                masterResponse:
                                    cleanReason,

                                rejectedAt:
                                    serverTimestamp(),

                                updatedAt:
                                    serverTimestamp()

                            },
                            {
                                merge: true
                            }
                        );

                        return {

                            paymentId:
                                prepared.paymentId,

                            restaurantId:
                                freshPaymentData.restaurantId,

                            ownerId:
                                freshPaymentData.ownerId,

                            action: "REJECT",

                            previousStatus:
                                freshReviewState.status,

                            newStatus: "REJECTED",

                            reviewedBy:
                                currentUser.uid

                        };

                    }


                    /*
                    ------------------------------------
                    VALIDATE PAYMENT IDENTITY
                    ------------------------------------
                    */

                    if (
                        !freshPaymentData.restaurantId ||
                        !freshPaymentData.ownerId ||
                        !freshPaymentData.planId
                    ) {

                        throw new Error(
                            "Payment is missing required ownership or plan information."
                        );

                    }

                    if (
                        freshPaymentData.paymentId &&
                        freshPaymentData.paymentId !==
                            prepared.paymentId
                    ) {

                        throw new Error(
                            "Payment ID does not match the payment record."
                        );

                    }


if (
    String(freshPaymentData.restaurantId).trim() !==
        prepared.restaurantId ||
    String(freshPaymentData.ownerId).trim() !==
        prepared.ownerId
) {
    throw new Error(
        "Payment ownership does not match the prepared review action."
    );
}

                    /*
                    ------------------------------------
                    READ 2 — SELECTED PLAN
                    ------------------------------------
                    */
                                        const planRef =
                        doc(
                            db,
                            "subscriptionPlans",
                            freshPaymentData.planId
                        );

                    const planSnapshot =
                        await transaction.get(
                            planRef
                        );

                    if (!planSnapshot.exists()) {

                        throw new Error(
                            "Selected subscription plan no longer exists."
                        );

                    }

                    const planData =
                        planSnapshot.data();

                    if (
                        String(planData.status || "")
                            .toUpperCase() !== "ACTIVE"
                    ) {

                        throw new Error(
                            "Selected subscription plan is not active."
                        );

                    }


                    /*
                    ------------------------------------
                    VALIDATE AMOUNT & CURRENCY
                    ------------------------------------
                    */

                  const paymentAmount =
    freshPaymentData.amount;

const planAmount =
    planData.baseAmount;  
                    if (
                        !Number.isFinite(paymentAmount) ||
                        paymentAmount <= 0 ||
                        !Number.isFinite(planAmount) ||
                        planAmount <= 0
                    ) {

                        throw new Error(
                            "Payment or plan amount is invalid."
                        );

                    }

                    if (
                        paymentAmount !== planAmount
                    ) {

                        throw new Error(
                            "Payment amount does not match the selected plan."
                        );

                    }

                    const paymentCurrency =
                        String(
                            freshPaymentData.currency || ""
                        )
                        .trim()
                        .toUpperCase();

                    const planCurrency =
                        String(
                            planData.currency || ""
                        )
                        .trim()
                        .toUpperCase();

                    if (
                        !paymentCurrency ||
                        !planCurrency ||
                        paymentCurrency !== planCurrency
                    ) {

                        throw new Error(
                            "Payment currency does not match the selected plan."
                        );

                    }


                    /*
                    ------------------------------------
                    READ 3 — RESTAURANT SUBSCRIPTIONS
                    ALL TRANSACTION READS BEFORE WRITES
                    ------------------------------------
                    */

                    const subscriptionsCollection =
                        collection(
                            db,
                            "subscriptions"
                        );

                    const subscriptionsQuery =
                        query(
                            subscriptionsCollection,
                            where(
                                "restaurantId",
                                "==",
                                freshPaymentData.restaurantId
                            )
                        );

                    const subscriptionsSnapshot =
                        await transaction.get(
                            subscriptionsQuery
                        );


                    /*
                    ------------------------------------
                    CHECK EXISTING SUBSCRIPTION
                    ------------------------------------
                    */

                    const existingActiveSubscriptions = [];

                    subscriptionsSnapshot.forEach(
                        (subscriptionSnapshot) => {

                            const existingData =
                                subscriptionSnapshot.data();

                            if (
                                existingData.ownerId ===
                                    freshPaymentData.ownerId &&
                                existingData.status === "ACTIVE"
                            ) {

                                existingActiveSubscriptions.push({
                                    ref: subscriptionSnapshot.ref,
                                    data: existingData
                                });

                            }

                        }
                    );


                    /*
                    ------------------------------------
                    PREPARE NEW SUBSCRIPTION
                    ------------------------------------
                    */

                    const subscriptionId =
                        `SUB-${prepared.paymentId}`;

                    const subscriptionRef =
                        doc(
                            db,
                            "subscriptions",
                            subscriptionId
                        );
                        
                        const subscriptionSnapshot =
    await transaction.get(
        subscriptionRef
    );

if (subscriptionSnapshot.exists()) {

    const existingSubscriptionData =
        subscriptionSnapshot.data();

    if (
        !existingSubscriptionData ||
        existingSubscriptionData.subscriptionId !==
            subscriptionId ||
        existingSubscriptionData.paymentId !==
            prepared.paymentId ||
        existingSubscriptionData.restaurantId !==
            freshPaymentData.restaurantId ||
        existingSubscriptionData.ownerId !==
            freshPaymentData.ownerId ||
        existingSubscriptionData.planId !==
            freshPaymentData.planId
    ) {
        throw new Error(
            "Existing subscription identity mismatch. Activation blocked."
        );
    }

    throw new Error(
        "A subscription already exists for this payment. Manual review is required."
    );
}

                    const startedAt =
                        Timestamp.fromDate(
                            new Date()
                        );

/*
------------------------------------
READ 4 — RESTAURANT BILLING STATE
------------------------------------
*/

const restaurantRef = doc(
    db,
    "restaurants",
    freshPaymentData.restaurantId
);

const restaurantSnapshot =
    await transaction.get(restaurantRef);

if (!restaurantSnapshot.exists()) {
    throw new Error(
        "Restaurant record does not exist."
    );
}

const restaurantData =
    restaurantSnapshot.data();

if (
    restaurantData.ownerId !==
    freshPaymentData.ownerId
) {
    throw new Error(
        "Restaurant owner does not match payment owner."
    );
}



                    /*
                    ------------------------------------
                    WRITE 1 — DEACTIVATE OLD PLANS
                    ------------------------------------
                    */

                    existingActiveSubscriptions.forEach(
                        (existingSubscription) => {

                            if (
                                existingSubscription.ref.id !==
                                subscriptionId
                            ) {

                                transaction.set(
                                    existingSubscription.ref,
                                    {

                                        status: "INACTIVE",

                                        deactivatedAt:
                                            serverTimestamp(),

                                        deactivatedBy:
                                            currentUser.uid,

                                        deactivationReason:
                                            "PLAN_SWITCH_AFTER_PAYMENT_VERIFICATION",

                                        updatedAt:
                                            serverTimestamp()

                                    },
                                    {
                                        merge: true
                                    }
                                );

                            }

                        }
                    );


                    /*
                    ------------------------------------
                    WRITE 2 — ACTIVATE SELECTED PLAN
                    ------------------------------------
                    */

                    transaction.set(
                        subscriptionRef,
                        {

                            subscriptionId,

                            ownerId:
                                freshPaymentData.ownerId,

                            restaurantId:
                                freshPaymentData.restaurantId,

                            planId:
                                freshPaymentData.planId,

                            amount:
                                paymentAmount,

                            currency:
                                paymentCurrency,

                            status: "ACTIVE",

                            startedAt,

                            expiresAt: null,

                            paymentId:
                                prepared.paymentId,

                            updatedAt:
                                serverTimestamp(),

                            activatedBy:
                                currentUser.uid,

                            activationMode:
                                "MASTER_PAYMENT_VERIFICATION"

                        },
                        {
                            merge: true
                        }
                    );


/*
------------------------------------
WRITE 2B — ACTIVATE BILLING
------------------------------------
*/

const billingWasActive =
    String(
        restaurantData.billingStatus || ""
    ).toUpperCase() === "ACTIVE";

const billingStartedAt =
    billingWasActive &&
    restaurantData.billingStartedAt
        ? restaurantData.billingStartedAt
        : startedAt;

transaction.set(
    restaurantRef,
    {
        billingStatus: "ACTIVE",

        billingStartedAt,

        billingPlanId:
            freshPaymentData.planId,

        billingUpdatedAt:
            serverTimestamp(),

        billingActivatedBy:
            currentUser.uid,

        billingActivationSource:
            "MASTER_PAYMENT_VERIFICATION"
    },
    {
        merge: true
    }
);

                    /*
                    ------------------------------------
                    WRITE 3 — VERIFY PAYMENT
                    ------------------------------------
                    */

                    transaction.set(
                        paymentRef,
                        {
                            status: "VERIFIED",
                            verificationStatus: "VERIFIED",

                            reviewedBy: currentUser.uid,
                            verifiedBy: currentUser.uid,

                            masterResponse: cleanReason,

                            ownerNotice: {
                                status: "VERIFIED",
                                message:
                                    "Thank you! Your subscription payment has been verified and your restaurant subscription is active."
                            },

                            verifiedAt: serverTimestamp(),
                            updatedAt: serverTimestamp()
                        },
                        {
                            merge: true
                        }
                    );

                    /*
                    ------------------------------------
                    TRANSACTION RESULT
                    ------------------------------------
                    */

                    return {

                        paymentId:
                            prepared.paymentId,

                        restaurantId:
                            freshPaymentData.restaurantId,

                        ownerId:
                            freshPaymentData.ownerId,

                        subscriptionId,

                        planId:
                            freshPaymentData.planId,

                        amount:
                            paymentAmount,

                        currency:
                            paymentCurrency,

                        action: "VERIFY",

                        previousStatus:
                            freshReviewState.status,

                        newStatus: "VERIFIED",

                        reviewedBy:
                            currentUser.uid,

                        deactivatedCount:
                            existingActiveSubscriptions.filter(
                                (subscription) =>
                                    subscription.ref.id !==
                                    subscriptionId
                            ).length

                    };

                }
            );


        /*
        ------------------------------------------------
        STEP 5 — SUCCESS LOG
        ------------------------------------------------
        */

        console.log(
            "BK MASTER PAYMENT: REVIEW WRITE SUCCESS:",
            result
        );

        return {

            success: true,

            ...result

        };


    } catch (error) {

        console.error(
            "BK MASTER PAYMENT: REVIEW WRITE FAILED:",
            error
        );

        throw error;

    }

},
    /*
    ========================================================
    SUBSCRIPTION & BILLING CARD
    ========================================================
    */
    createBillingCard(

        restaurantId,

        restaurantData = {},

        ownerData = {}

    ) {

        const restaurantName =
            restaurantData?.name ||
            "—";


        const ownerName =
            ownerData?.ownerName ||
            "—";


        const ownerEmail =
            ownerData?.email ||
            "—";


        const ownerMobile =
            this.getSafeValue(
                ownerData,
                [
                    "phone",
                    "mobile",
                    "phoneNumber",
                    "ownerMobile"
                ],
                "—"
            );


        const accountStatus =
            restaurantData?.status ||
            "—";


        const card =
            document.createElement(
                "article"
            );


        card.className =
            "master-restaurant-card bk-master-subscription-billing-card";


        card.dataset.restaurantId =
            restaurantId;
card.dataset.ownerId =
    String(
        ownerData?.ownerId ||
        restaurantData?.ownerId ||
        ""
    ).trim();

        card.innerHTML = `

            <div class="bk-master-card-header">

                <div>

                    <div class="bk-master-card-kicker">
                        SUBSCRIPTION & BILLING CONTROL
                    </div>

                    <h3 class="bk-master-card-title">
                        ${this.escapeHTML(restaurantName)}
                    </h3>

                </div>

                <span class="bk-master-card-status">
                    BILLING NOT LOADED
                </span>

            </div>


            <div class="bk-master-card-info-grid">

                <div class="bk-master-card-info-item">
                    <span class="bk-master-card-info-label">
                        RESTAURANT ID
                    </span>
                    <span class="bk-master-card-info-value">
                        ${this.escapeHTML(restaurantId)}
                    </span>
                </div>


                <div class="bk-master-card-info-item">
                    <span class="bk-master-card-info-label">
                        RESTAURANT NAME
                    </span>
                    <span class="bk-master-card-info-value">
                        ${this.escapeHTML(restaurantName)}
                    </span>
                </div>


                <div class="bk-master-card-info-item">
                    <span class="bk-master-card-info-label">
                        OWNER NAME
                    </span>
                    <span class="bk-master-card-info-value">
                        ${this.escapeHTML(ownerName)}
                    </span>
                </div>


                <div class="bk-master-card-info-item">
                    <span class="bk-master-card-info-label">
                        OWNER MOBILE
                    </span>
                    <span class="bk-master-card-info-value">
                        ${this.escapeHTML(ownerMobile)}
                    </span>
                </div>


                <div class="bk-master-card-info-item">
                    <span class="bk-master-card-info-label">
                        OWNER EMAIL
                    </span>
                    <span class="bk-master-card-info-value">
                        ${this.escapeHTML(ownerEmail)}
                    </span>
                </div>


                <div class="bk-master-card-info-item">
                    <span class="bk-master-card-info-label">
                        ACCOUNT STATUS
                    </span>
                    <span class="bk-master-card-info-value">
                        ${this.escapeHTML(accountStatus)}
                    </span>
                </div>


                <div class="bk-master-card-info-item">
                    <span class="bk-master-card-info-label">
                        CURRENT PLAN
                    </span>
                    <span class="bk-master-card-info-value">
                        NOT LOADED
                    </span>
                </div>


                <div class="bk-master-card-info-item">
                    <span class="bk-master-card-info-label">
                        SUBSCRIPTION STATUS
                    </span>
                    <span class="bk-master-card-info-value">
                        NOT LOADED
                    </span>
                </div>


                <div class="bk-master-card-info-item">
                    <span class="bk-master-card-info-label">
                        START DATE
                    </span>
                    <span class="bk-master-card-info-value">
                        —
                    </span>
                </div>


                <div class="bk-master-card-info-item">
                    <span class="bk-master-card-info-label">
                        EXPIRY DATE
                    </span>
                    <span class="bk-master-card-info-value">
                        —
                    </span>
                </div>


                <div class="bk-master-card-info-item">
                    <span class="bk-master-card-info-label">
                        PAYMENT STATUS
                    </span>
                    <span class="bk-master-card-info-value">
                        NOT LOADED
                    </span>
                </div>


                <div class="bk-master-card-info-item">
                    <span class="bk-master-card-info-label">
                        CURRENT BILL
                    </span>
                    <span class="bk-master-card-info-value">
                        —
                    </span>
                </div>


                <div class="bk-master-card-info-item">
                    <span class="bk-master-card-info-label">
                        PAYMENT REFERENCE
                    </span>
                    <span class="bk-master-card-info-value">
                        —
                    </span>
                </div>


                <div class="bk-master-card-info-item">
                    <span class="bk-master-card-info-label">
                        MASTER FREE ACCESS
                    </span>
                    <span class="bk-master-card-info-value">
                        NOT GRANTED
                    </span>
                </div>


                <div class="bk-master-card-info-item">
                    <span class="bk-master-card-info-label">
                        FREE ACCESS EXPIRY
                    </span>
                    <span class="bk-master-card-info-value">
                        —
                    </span>
                </div>


                <div class="bk-master-card-info-item">
                    <span class="bk-master-card-info-label">
                        FREE ACCESS REASON
                    </span>
                    <span class="bk-master-card-info-value">
                        —
                    </span>
                </div>

            </div>



<div class="bk-master-card-billing-summary">

    <strong>
        BILLING SUMMARY
    </strong>

    <span>
        No subscription or billing record loaded yet.
    </span>

</div>


<div
    class="bk-master-billing-breakdown"
    data-billing-breakdown="true"
>

    <div class="bk-master-billing-breakdown-header">

        <div>

            <strong>
                MONTHLY BILLING BREAKDOWN
            </strong>

            <span>
                Restaurant activity and current payable calculation
            </span>

        </div>

        <span
            class="bk-master-billing-breakdown-period"
            data-billing-period
        >
            —
        </span>

    </div>


    <div class="bk-master-billing-breakdown-grid">

        <div class="bk-master-billing-breakdown-item">
            <span>BOOKINGS</span>
            <strong data-billing-bookings>0</strong>
        </div>

        <div class="bk-master-billing-breakdown-item">
            <span>ORDERS</span>
            <strong data-billing-orders>0</strong>
        </div>

        <div class="bk-master-billing-breakdown-item">
            <span>WEBSITE VISITS</span>
            <strong data-billing-website-visits>0</strong>
        </div>

        <div class="bk-master-billing-breakdown-item">
            <span>MENU ITEMS</span>
            <strong data-billing-menu-items>0</strong>
        </div>

        <div class="bk-master-billing-breakdown-item">
            <span>STORAGE</span>
            <strong data-billing-storage>0 GB</strong>
        </div>

        <div class="bk-master-billing-breakdown-item">
            <span>USAGE COST</span>
            <strong data-billing-usage-cost>₹0.00</strong>
        </div>

    </div>


    <div class="bk-master-billing-breakdown-total">

        <span>
            CURRENT PAYABLE BILL
        </span>

        <strong data-billing-final-amount>
            ₹0.00
        </strong>

    </div>

</div>

<div
    class="bk-master-billing-adjustment"
    data-billing-adjustment="true"
>

    <div class="bk-master-billing-adjustment-header">

        <div>

            <strong>MASTER BILLING ADJUSTMENT</strong>

            <span>
                Add your service / profit margin before publishing the bill.
            </span>

        </div>

    </div>


    <div class="bk-master-billing-adjustment-controls">

        <div class="bk-master-billing-adjustment-field">

            <label for="bkBillingAdjustmentType">
                MARGIN TYPE
            </label>

            <select
                id="bkBillingAdjustmentType"
                data-billing-adjustment-type
            >
                <option value="FIXED">FIXED AMOUNT</option>
                <option value="PERCENTAGE">PERCENTAGE</option>
            </select>

        </div>


        <div class="bk-master-billing-adjustment-field">

            <label for="bkBillingAdjustmentValue">
                MARGIN VALUE
            </label>

            <input
                id="bkBillingAdjustmentValue"
                type="number"
                min="0"
                step="0.01"
                value="0"
                inputmode="decimal"
                data-billing-adjustment-value
                placeholder="Enter margin"
            >

        </div>

    </div>


    <div
        class="bk-master-billing-adjustment-preview"
        aria-live="polite"
    >

        <div>
            <span>USAGE COST</span>
            <strong data-adjustment-usage-cost>₹0.00</strong>
        </div>

        <div>
            <span>MASTER MARGIN</span>
            <strong data-adjustment-margin>₹0.00</strong>
        </div>

        <div class="bk-master-billing-adjustment-final">
            <span>PREVIEW PAYABLE BILL</span>
            <strong data-adjustment-final>₹0.00</strong>
        </div>

    </div>

</div>

          <div class="bk-master-card-actions">
          
          <button
    type="button"
    class="bk-master-card-action publish-bill"
    data-billing-action="publish-bill"
    data-restaurant-id="${this.escapeHTML(restaurantId)}"
>
    ✓ CONFIRM &amp; PUBLISH BILL
</button>

    <button
        type="button"
        class="bk-master-card-action plan"
        data-billing-action="verify-payment"
        data-restaurant-id="${this.escapeHTML(restaurantId)}"
        disabled
    >
        VERIFY PAYMENT
    </button>


    <button
        type="button"
        class="bk-master-card-action details"
        data-billing-action="reject-payment"
        data-restaurant-id="${this.escapeHTML(restaurantId)}"
        disabled
    >
        REJECT PAYMENT
    </button>


    <button
        type="button"
        class="bk-master-card-action plan"
        data-billing-action="allow-subscription"
        data-restaurant-id="${this.escapeHTML(restaurantId)}"
        disabled
    >
        ALLOW SUBSCRIPTION
    </button>


    <button
        type="button"
        class="bk-master-card-action plan"
        data-billing-action="grant-free-access"
        data-restaurant-id="${this.escapeHTML(restaurantId)}"
        disabled
    >
        GRANT FREE ACCESS
    </button>


    <button
        type="button"
        class="bk-master-card-action details"
        data-billing-action="end-free-access"
        data-restaurant-id="${this.escapeHTML(restaurantId)}"
        disabled
    >
        END FREE ACCESS
    </button>

</div>
        `;

this.connectLatestPaymentToCard(
    card,
    restaurantId
);

this.connectPaymentReviewActions(
    card,
    restaurantId
);

this.connectCurrentSubscriptionToCard(
    card,
    restaurantId,
    ownerData?.ownerId ||
    restaurantData?.ownerId ||
    null
);

this.connectCurrentBillingToCard(
    card,
    restaurantId,
    ownerData?.ownerId ||
    restaurantData?.ownerId ||
    null
);

this.connectMonthlyUsageBreakdownToCard(
    card,
    restaurantId,
    ownerData?.ownerId ||
        restaurantData?.ownerId ||
        null
);

this.connectBillingAdjustmentToCard(
    card,
    restaurantId,
    ownerData?.ownerId ||
        restaurantData?.ownerId ||
        null
);

this.connectFreeAccessToCard(
    card,
    restaurantId,
    ownerData?.ownerId ||
        restaurantData?.ownerId ||
        null
);

        console.log(
            "BK MASTER SUBSCRIPTION BILLING: CARD CREATED:",
            restaurantId
        );


        return card;

    },
    
    /*
========================================================
PAYMENT REVIEW ACTION UI
PART 2C — STEP 4C
========================================================
*/

async connectPaymentReviewActions(
    card,
    restaurantId
) {

    if (!card || !restaurantId) {

        console.warn(
            "BK MASTER PAYMENT: REVIEW ACTION UI CANNOT CONNECT."
        );

        return;
    }

    try {

        const paymentData =
            await this.loadLatestPayment(
                restaurantId
            );

        if (!paymentData) {

            console.log(
                "BK MASTER PAYMENT: NO PAYMENT FOR REVIEW ACTIONS:",
                restaurantId
            );

            return;
        }

        const actions =
            this.getPaymentReviewActions(
                paymentData
            );

        const reviewable =
            actions.length > 0;

        const verifyButton =
            card.querySelector(
                '[data-billing-action="verify-payment"]'
            );

        const rejectButton =
            card.querySelector(
                '[data-billing-action="reject-payment"]'
            );

        if (verifyButton) {

            verifyButton.disabled =
                !reviewable;

        }

        if (rejectButton) {

            rejectButton.disabled =
                !reviewable;

        }

        console.log(
            "BK MASTER PAYMENT: REVIEW ACTION UI CONNECTED:",
            {
                restaurantId,
                paymentStatus:
                    paymentData.status,
                actions
            }
        );

    } catch (error) {

        console.error(
            "BK MASTER PAYMENT: REVIEW ACTION UI FAILED:",
            error
        );

    }

},

    /*
    ========================================================
    STEP 1 — CURRENT SUBSCRIPTION + PLAN LOADER
    ========================================================
    */

    async loadCurrentSubscription(
        restaurantId,
        ownerId = null
    ) {

        if (!restaurantId) {

            throw new Error(
                "Restaurant ID is required."
            );

        }

        try {

const {
    db,
    collection,
    query,
    where,
    getDocs,
    doc,
    getDoc
} = await this.getFirebaseModules();


const subscriptionsRef =
    collection(
        db,
        "subscriptions"
    );


const subscriptionQuery =
    query(
        subscriptionsRef,
        where(
            "restaurantId",
            "==",
            restaurantId
        )
    );


const snapshot =
    await getDocs(
        subscriptionQuery
    );

            if (snapshot.empty) {

                console.log(
                    "BK MASTER SUBSCRIPTION BILLING: NO SUBSCRIPTION FOUND:",
                    restaurantId
                );

                return {
                    subscription: null,
                    plan: null
                };

            }


            const subscriptions = [];


            snapshot.forEach(
                (subscriptionDoc) => {

                    const data =
                        subscriptionDoc.data();


                    if (
                        ownerId &&
                        data.ownerId &&
                        data.ownerId !== ownerId
                    ) {

                        return;

                    }


                    subscriptions.push({

                        id:
                            subscriptionDoc.id,

                        ...data

                    });

                }
            );


            if (!subscriptions.length) {

                return {
                    subscription: null,
                    plan: null
                };

            }


            /*
            ----------------------------------------
            PREFER ACTIVE SUBSCRIPTION
            ----------------------------------------
            */

            const activeSubscriptions =
                subscriptions.filter(
                    (item) =>
                        item.status === "ACTIVE"
                );


            const candidates =
                activeSubscriptions.length
                    ? activeSubscriptions
                    : subscriptions;


            /*
            ----------------------------------------
            NEWEST SUBSCRIPTION
            ----------------------------------------
            */

            candidates.sort(
                (a, b) => {

                    const aTime =
                        a.updatedAt?.toMillis?.() ||
                        a.startedAt?.toMillis?.() ||
                        0;


                    const bTime =
                        b.updatedAt?.toMillis?.() ||
                        b.startedAt?.toMillis?.() ||
                        0;


                    return bTime - aTime;

                }
            );


            const subscription =
                candidates[0];


            let plan = null;


            /*
            ----------------------------------------
            LOAD EXACT PLAN DOCUMENT
            ----------------------------------------
            */

            if (subscription.planId) {

const planRef =
    doc(
        db,
        "subscriptionPlans",
        subscription.planId
    );


const planSnapshot =
    await getDoc(
        planRef
    );

                if (
                    planSnapshot.exists()
                ) {

                    plan = {

                        id:
                            planSnapshot.id,

                        ...planSnapshot.data()

                    };

                }

            }


            console.log(
                "BK MASTER SUBSCRIPTION BILLING: CURRENT SUBSCRIPTION LOADED:",
                {
                    restaurantId,
                    subscriptionId:
                        subscription.subscriptionId,
                    planId:
                        subscription.planId,
                    status:
                        subscription.status,
                    amount:
                        subscription.amount,
                    currency:
                        subscription.currency
                }
            );


            return {

                subscription,

                plan

            };

        } catch (error) {

            console.error(
                "BK MASTER SUBSCRIPTION BILLING: CURRENT SUBSCRIPTION LOAD FAILED:",
                error
            );

            throw error;

        }

    },
/*
========================================================
CURRENT BILLING RECORD LOADER
STEP 2G — CURRENT BILL
========================================================
*/

async loadCurrentBillingRecord(
    restaurantId,
    ownerId = null
) {

    if (!restaurantId) {

        throw new Error(
            "Restaurant ID is required."
        );

    }


    try {

        const {
            db,
            doc,
            getDoc
        } = await this.getFirebaseModules();


        /*
        ------------------------------------------------
        CURRENT BILL DOCUMENT
        billingRecords/{restaurantId}
        ------------------------------------------------
        */

        const billingRef = doc(
    db,
    "billingRecords",
    `${restaurantId}_${this.validateBillingMonth(
        new Date(
            new Date().getUTCFullYear(),
            new Date().getUTCMonth(),
            0
        ).toISOString().slice(0, 7)
    )}`
);

const billingSnapshot = await getDoc(billingRef);

        if (!billingSnapshot.exists()) {

            console.log(
                "BK MASTER BILLING: NO CURRENT BILL FOUND:",
                restaurantId
            );

            return null;

        }


        const billingData =
            billingSnapshot.data();


        /*
        ------------------------------------------------
        OWNER SAFETY CHECK
        ------------------------------------------------
        */


const recordOwnerId = String(
    billingData.ownerId ?? ""
).trim();

const expectedOwnerId = String(
    ownerId ?? ""
).trim();

if (
    !recordOwnerId ||
    !expectedOwnerId ||
    recordOwnerId !== expectedOwnerId
) {
    console.warn(
        "BK MASTER BILLING: BILL OWNER VALIDATION FAILED:",
        restaurantId
    );

    return null;
}


        console.log(
            "BK MASTER BILLING: CURRENT BILL LOADED:",
            {
                restaurantId,

                billingId:
                    billingData.billingId,

                billingMonth:
                    billingData.billingMonth,

                billingPeriod:
                    billingData.billingPeriod,

                baseAmount:
                    billingData.baseAmount,

                usageAdjustment:
                    billingData.usageAdjustment,

                finalAmount:
                    billingData.finalAmount,

                currency:
                    billingData.currency,

                status:
                    billingData.status

            }
        );


        return {

            ...billingData,

            billingId:
                billingData.billingId ||
                restaurantId

        };


    } catch (error) {

        console.error(
            "BK MASTER BILLING: CURRENT BILL LOAD FAILED:",
            error
        );

        throw error;

    }

},

/*
========================================================
CONNECT CURRENT BILLING DATA TO BILLING CARD
STEP 2G-2 — CURRENT BILL
========================================================
*/

async connectCurrentBillingToCard(
    card,
    restaurantId,
    ownerId = null
) {

    if (
        !card ||
        !restaurantId
    ) {

        return;

    }

    try {

        const billingData =
            await this.loadCurrentBillingRecord(
                restaurantId,
                ownerId
            );


        if (!billingData) {

            return;

        }


        /*
        ------------------------------------------------
        FIND CURRENT BILL FIELD
        ------------------------------------------------
        */

        const infoItems =
            card.querySelectorAll(
                ".bk-master-card-info-item"
            );


        let currentBillValue = null;


        infoItems.forEach(
            (item) => {

                const label =
                    item.querySelector(
                        ".bk-master-card-info-label"
                    );


                const value =
                    item.querySelector(
                        ".bk-master-card-info-value"
                    );


                if (
                    label &&
                    value &&
                    label.textContent
                        .trim()
                        .toUpperCase() ===
                    "CURRENT BILL"
                ) {

                    currentBillValue =
                        value;

                }

            }
        );


        /*
        ------------------------------------------------
        RENDER CURRENT BILL
        ------------------------------------------------
        */

        if (currentBillValue) {

            currentBillValue.textContent =
                this.formatBillingAmount(
                    billingData.finalAmount,
                    billingData.currency || "INR"
                );

        }


        console.log(
            "BK MASTER BILLING: CARD CURRENT BILL CONNECTED:",
            {
                restaurantId,

                billingPeriod:
                    billingData.billingPeriod ||
                    billingData.billingMonth,

                baseAmount:
                    billingData.baseAmount,

                usageAdjustment:
                    billingData.usageAdjustment,

                finalAmount:
                    billingData.finalAmount,

                currency:
                    billingData.currency
            }
        );


    } catch (error) {

        console.error(
            "BK MASTER BILLING: CARD CURRENT BILL CONNECTION FAILED:",
            error
        );

    }

},

async connectMonthlyUsageBreakdownToCard(
    card,
    restaurantId,
    ownerId = null
) {

    if (!card || !restaurantId) {
        console.warn(
            "BK MASTER BILLING: USAGE BREAKDOWN SKIPPED: INVALID CONTEXT"
        );
        return;
    }

    try {

        const breakdown = card.querySelector(
            "[data-billing-breakdown='true']"
        );

        if (!breakdown) {
            console.warn(
                "BK MASTER BILLING: USAGE BREAKDOWN CONTAINER NOT FOUND:",
                restaurantId
            );
            return;
        }

        /*
         * First use the current billing record's billing month.
         * This keeps the usage period synchronized with the
         * restaurant's current billing record.
         */
        const billingData =
            await this.loadCurrentBillingRecord(
                restaurantId,
                ownerId
            );

        const now = new Date();

        const currentMonth =
            `${now.getFullYear()}-${String(
                now.getMonth() + 1
            ).padStart(2, "0")}`;

        const billingMonth =
            billingData?.billingMonth ||
            billingData?.billingPeriod ||
            currentMonth;

        /*
         * Load the restaurant's monthly usage record.
         */
        const usageData =
            await this.loadMonthlyUsageRecord(
                restaurantId,
                billingMonth
            );

        const periodElement =
            breakdown.querySelector(
                "[data-billing-period]"
            );

        const bookingsElement =
            breakdown.querySelector(
                "[data-billing-bookings]"
            );

        const ordersElement =
            breakdown.querySelector(
                "[data-billing-orders]"
            );

        const websiteVisitsElement =
            breakdown.querySelector(
                "[data-billing-website-visits]"
            );

        const menuItemsElement =
            breakdown.querySelector(
                "[data-billing-menu-items]"
            );

        const storageElement =
            breakdown.querySelector(
                "[data-billing-storage]"
            );

        const usageCostElement =
            breakdown.querySelector(
                "[data-billing-usage-cost]"
            );

        const finalAmountElement =
            breakdown.querySelector(
                "[data-billing-final-amount]"
            );


        if (periodElement) {
            periodElement.textContent = billingMonth;
        }


        /*
         * No usage record yet.
         */
        if (!usageData) {

            if (bookingsElement) {
                bookingsElement.textContent = "0";
            }

            if (ordersElement) {
                ordersElement.textContent = "0";
            }

            if (websiteVisitsElement) {
                websiteVisitsElement.textContent = "0";
            }

            if (menuItemsElement) {
                menuItemsElement.textContent = "0";
            }

            if (storageElement) {
                storageElement.textContent = "0 GB";
            }

            if (usageCostElement) {
                usageCostElement.textContent = "—";
            }

            if (finalAmountElement) {
                finalAmountElement.textContent =
                    billingData
                        ? this.formatBillingAmount(
                              billingData.finalAmount,
                              billingData.currency || "INR"
                          )
                        : "—";
            }

            console.log(
                "BK MASTER BILLING: NO USAGE RECORD:",
                {
                    restaurantId,
                    billingMonth
                }
            );

            return;
        }


        /*
         * Tenant safety check.
         */
        if (
            ownerId &&
            usageData.ownerId &&
            usageData.ownerId !== ownerId
        ) {

            throw new Error(
                "Usage owner mismatch."
            );
        }


        const bookings =
            Number(usageData.bookings) || 0;

        const orders =
            Number(usageData.orders) || 0;

        const websiteVisits =
            Number(usageData.websiteVisits) || 0;

        const menuItems =
            Number(usageData.menuItems) || 0;

        const storageGB =
            Number(usageData.storageUsedGB) || 0;


        /*
         * For the current usage cost, prefer the
         * current billing record's calculated baseAmount.
         *
         * We intentionally do NOT use usageData.estimatedCost
         * when a current billing record exists because the
         * billing record is the authoritative calculated value.
         */
        let usageCost = null;

        if (
            billingData &&
            Number.isFinite(
                Number(billingData.baseAmount)
            )
        ) {

            usageCost =
                Number(billingData.baseAmount);

        } else if (
            Number.isFinite(
                Number(usageData.estimatedCost)
            ) &&
            Number(usageData.estimatedCost) > 0
        ) {

            usageCost =
                Number(usageData.estimatedCost);
        }


        if (bookingsElement) {
            bookingsElement.textContent =
                bookings.toLocaleString("en-IN");
        }

        if (ordersElement) {
            ordersElement.textContent =
                orders.toLocaleString("en-IN");
        }

        if (websiteVisitsElement) {
            websiteVisitsElement.textContent =
                websiteVisits.toLocaleString("en-IN");
        }

        if (menuItemsElement) {
            menuItemsElement.textContent =
                menuItems.toLocaleString("en-IN");
        }

        if (storageElement) {
            storageElement.textContent =
                `${storageGB.toFixed(2)} GB`;
        }

        if (usageCostElement) {

            usageCostElement.textContent =
                usageCost !== null
                    ? this.formatBillingAmount(
                          usageCost,
                          billingData?.currency || "INR"
                      )
                    : "—";
        }

        if (finalAmountElement) {

            const finalAmount =
                Number(billingData?.finalAmount);

            finalAmountElement.textContent =
                Number.isFinite(finalAmount)
                    ? this.formatBillingAmount(
                          finalAmount,
                          billingData?.currency || "INR"
                      )
                    : "—";
        }


        console.log(
            "BK MASTER BILLING: MONTHLY USAGE BREAKDOWN CONNECTED:",
            {
                restaurantId,
                ownerId,
                billingMonth,
                bookings,
                orders,
                websiteVisits,
                menuItems,
                storageGB,
                usageCost,
                finalAmount:
                    billingData?.finalAmount ?? null
            }
        );

    } catch (error) {

        console.error(
            "BK MASTER BILLING: USAGE BREAKDOWN FAILED:",
            error
        );

    }
},


/*
========================================================
MASTER BILLING ADJUSTMENT PREVIEW
STEP 2B — UI CALCULATION CONNECTION
========================================================
*/
connectBillingAdjustmentToCard(
    card,
    restaurantId,
    ownerId = null
) { 

    if (
        !card ||
        !restaurantId
    ) {

        console.warn(
            "BK MASTER BILLING: ADJUSTMENT PREVIEW SKIPPED — INVALID CONTEXT."
        );

        return;

    }


    const adjustmentPanel =
        card.querySelector(
            "[data-billing-adjustment='true']"
        );


    if (!adjustmentPanel) {

        console.warn(
            "BK MASTER BILLING: ADJUSTMENT PANEL NOT FOUND:",
            restaurantId
        );

        return;

    }


    const typeElement =
        adjustmentPanel.querySelector(
            "[data-billing-adjustment-type]"
        );


    const valueElement =
        adjustmentPanel.querySelector(
            "[data-billing-adjustment-value]"
        );


    const usageCostElement =
        adjustmentPanel.querySelector(
            "[data-adjustment-usage-cost]"
        );


    const marginElement =
        adjustmentPanel.querySelector(
            "[data-adjustment-margin]"
        );


    const finalElement =
        adjustmentPanel.querySelector(
            "[data-adjustment-final]"
        );


    if (
        !typeElement ||
        !valueElement ||
        !usageCostElement ||
        !marginElement ||
        !finalElement
    ) {

        console.warn(
            "BK MASTER BILLING: ADJUSTMENT UI ELEMENTS MISSING:",
            restaurantId
        );

        return;

    }


    /*
    --------------------------------------------------------
    LOAD CURRENT BILLING COST
    --------------------------------------------------------
    */

    this.loadCurrentBillingRecord(
        restaurantId
    )
    .then(
        (billingData) => {

            const usageCost =
                Number(
                    billingData?.baseAmount || 0
                );


            if (
                !Number.isFinite(usageCost) ||
                usageCost < 0
            ) {

                console.warn(
                    "BK MASTER BILLING: INVALID USAGE COST:",
                    restaurantId
                );

                return;

            }


            /*
            ------------------------------------------------
            RENDER ORIGINAL USAGE COST
            ------------------------------------------------
            */
            usageCostElement.textContent =
                this.formatBillingAmount(
                    usageCost,
                    billingData?.currency || "INR"
                );


            /*
            ------------------------------------------------
            PREVIEW CALCULATOR
            ------------------------------------------------
            */

            const updatePreview =
                () => {

                    const chargeType =
                        typeElement.value ===
                        "PERCENTAGE"
                            ? "PERCENTAGE"
                            : "FIXED";


                    const marginValue =
                        Math.max(
                            0,
                            Number(
                                valueElement.value || 0
                            )
                        );


                    const calculation =
                        this.calculateMasterCharge(
                            usageCost,
                            {
                                type:
                                    chargeType,

                                fixedAmount:
                                    chargeType === "FIXED"
                                        ? marginValue
                                        : 0,

                                percentage:
                                    chargeType === "PERCENTAGE"
                                        ? marginValue
                                        : 0
                            }
                        );
                        
                        

                    /*
                    ----------------------------------------
                    MASTER MARGIN
                    ----------------------------------------
                    */

                    marginElement.textContent =
                        this.formatBillingAmount(
                            calculation.masterCharge,
                            billingData?.currency || "INR"
                        );


                    /*
                    ----------------------------------------
                    FINAL PREVIEW BILL
                    ----------------------------------------
                    */

                    finalElement.textContent =
                        this.formatBillingAmount(
                            calculation.finalBill,
                            billingData?.currency || "INR"
                        );


                    console.log(
                        "BK MASTER BILLING: ADJUSTMENT PREVIEW UPDATED:",
                        {
                            restaurantId,
                            chargeType,
                            marginValue,
                            usageCost,
                            masterCharge:
                                calculation.masterCharge,
                            finalBill:
                                calculation.finalBill
                        }
                    );

                };


            /*
            ------------------------------------------------
            LIVE PREVIEW EVENTS
            ------------------------------------------------
            */

            typeElement.addEventListener(
                "change",
                updatePreview
            );


            valueElement.addEventListener(
                "input",
                updatePreview
            );


            valueElement.addEventListener(
                "change",
                updatePreview
            );


            /*
            ------------------------------------------------
            INITIAL PREVIEW
            ------------------------------------------------
            */

            updatePreview();

        }
    )
    .catch(
        (error) => {

            console.error(
                "BK MASTER BILLING: ADJUSTMENT PREVIEW LOAD FAILED:",
                error
            );

        }
    );

},


/*
========================================================
FREE ACCESS — BILLING CARD CONNECTION
STEP 2 — GRANT / END BUTTON ACTIONS
========================================================
*/

async connectFreeAccessToCard(
    card,
    restaurantId,
    ownerId = null
) {
    if (!card || !restaurantId) {
        return;
    }

    const controller = window.BKFreeAccessControl;

    const grantButton = card.querySelector(
        '[data-billing-action="grant-free-access"]'
    );

    const endButton = card.querySelector(
        '[data-billing-action="end-free-access"]'
    );

    const findInfoValue = (labelText) => {
        for (const item of card.querySelectorAll(
            ".bk-master-card-info-item"
        )) {
            const label = item.querySelector(
                ".bk-master-card-info-label"
            );

            if (label?.textContent.trim() === labelText) {
                return item.querySelector(
                    ".bk-master-card-info-value"
                );
            }
        }

        return null;
    };

    const statusValue = findInfoValue("MASTER FREE ACCESS");
    const expiryValue = findInfoValue("FREE ACCESS EXPIRY");
    const reasonValue = findInfoValue("FREE ACCESS REASON");

    if (
        !controller ||
        typeof controller.loadFreeAccess !== "function" ||
        typeof controller.grantFreeAccess !== "function" ||
        typeof controller.endFreeAccess !== "function"
    ) {
        console.error(
            "BK FREE ACCESS: REQUIRED METHODS UNAVAILABLE."
        );
        return;
    }

    const refreshCard = async () => {
        const record = await controller.loadFreeAccess(
            restaurantId
        );

        const status =
            record.effectiveStatus ||
            record.freeAccessStatus ||
            controller.STATUS.NOT_GRANTED;

        if (statusValue) {
            statusValue.textContent = status;
        }

        if (expiryValue) {
            const rawExpiry = record.freeAccessExpiresAt;

            const expiry =
                rawExpiry?.toDate instanceof Function
                    ? rawExpiry.toDate()
                    : rawExpiry
                        ? new Date(rawExpiry)
                        : null;

            expiryValue.textContent =
                expiry && !Number.isNaN(expiry.getTime())
                    ? expiry.toLocaleString("en-IN")
                    : "—";
        }

        if (reasonValue) {
            reasonValue.textContent =
                record.freeAccessReason || "—";
        }

        if (grantButton) {
            grantButton.disabled = false;
        }

        if (endButton) {
            endButton.disabled =
                status !== controller.STATUS.ACTIVE;
        }

        console.log(
            "BK FREE ACCESS: CARD CONNECTED",
            {
                restaurantId,
                ownerId,
                status
            }
        );
    };

    if (grantButton && !grantButton.dataset.freeAccessBound) {
        grantButton.dataset.freeAccessBound = "true";

        grantButton.addEventListener("click", async () => {
            const durationInput = window.prompt(
                "Free Access duration in months (1–12):",
                "1"
            );

            if (durationInput === null) {
                return;
            }

            const durationMonths = Number(durationInput.trim());

            if (
                !Number.isInteger(durationMonths) ||
                durationMonths < 1 ||
                durationMonths > 12
            ) {
                window.alert(
                    "Enter a whole number from 1 to 12."
                );
                return;
            }

            const reason = window.prompt(
                "Enter the reason for granting Free Access:"
            );

            if (reason === null || !reason.trim()) {
                window.alert(
                    "A reason is required. Free Access was not granted."
                );
                return;
            }

            if (!window.confirm(
                `Grant ${durationMonths} month(s) of Free Access to restaurant ${restaurantId}?`
            )) {
                return;
            }

            grantButton.disabled = true;

            if (endButton) {
                endButton.disabled = true;
            }

            try {
                const result = await controller.grantFreeAccess({
                    restaurantId,
                    durationMonths,
                    reason: reason.trim()
                });

                if (!result?.success) {
                    throw new Error(
                        "The Free Access grant was not confirmed."
                    );
                }

                await refreshCard();

                window.alert(
                    "Free Access was saved successfully."
                );

            } catch (error) {
                console.error(
                    "BK FREE ACCESS: GRANT FAILED",
                    error
                );

                window.alert(
                    `Free Access could not be granted: ${error.message || error}`
                );

                try {
                    await refreshCard();
                } catch (refreshError) {
                    console.error(
                        "BK FREE ACCESS: REFRESH FAILED",
                        refreshError
                    );
                }
            }
        });
    }

    if (endButton && !endButton.dataset.freeAccessBound) {
        endButton.dataset.freeAccessBound = "true";

        endButton.addEventListener("click", async () => {
            if (!window.confirm(
                `End Free Access for restaurant ${restaurantId}?`
            )) {
                return;
            }

            endButton.disabled = true;

            if (grantButton) {
                grantButton.disabled = true;
            }

            try {
                const result = await controller.endFreeAccess(
                    restaurantId
                );

                if (!result?.success) {
                    throw new Error(
                        "The Free Access ending was not confirmed."
                    );
                }

                await refreshCard();

                window.alert(
                    "Free Access has been ended."
                );

            } catch (error) {
                console.error(
                    "BK FREE ACCESS: END FAILED",
                    error
                );

                window.alert(
                    `Free Access could not be ended: ${error.message || error}`
                );

                try {
                    await refreshCard();
                } catch (refreshError) {
                    console.error(
                        "BK FREE ACCESS: REFRESH FAILED",
                        refreshError
                    );
                }
            }
        });
    }

    if (grantButton) {
        grantButton.disabled = true;
    }

    if (endButton) {
        endButton.disabled = true;
    }

    try {
        await refreshCard();
    } catch (error) {
        console.error(
            "BK FREE ACCESS: CARD CONNECTION FAILED",
            error
        );

        if (statusValue) {
            statusValue.textContent = "LOAD FAILED";
        }

        if (grantButton) {
            grantButton.disabled = true;
        }

        if (endButton) {
            endButton.disabled = true;
        }
    }
},



    /*
    ========================================================
    BILLING DATE FORMATTER
    ========================================================
    */

    formatBillingDate(value) {

        if (!value) {

            return "—";

        }


        let date = null;


        if (
            value?.toDate
        ) {

            date =
                value.toDate();

        } else if (
            value instanceof Date
        ) {

            date =
                value;

        } else {

            date =
                new Date(value);

        }


        if (
            !date ||
            Number.isNaN(
                date.getTime()
            )
        ) {

            return "—";

        }


        return new Intl.DateTimeFormat(
            "en-IN",
            {
                day: "2-digit",
                month: "short",
                year: "numeric"
            }
        ).format(date);

    },


    /*
    ========================================================
    BILLING AMOUNT FORMATTER
    ========================================================
    */
        formatBillingAmount(
        amount,
        currency = "INR"
    ) {

        const numericAmount =
            Number(amount);


        if (
            !Number.isFinite(
                numericAmount
            )
        ) {

            return "—";

        }


        try {

            return new Intl.NumberFormat(
                "en-IN",
                {
                    style: "currency",
                    currency:
                        currency || "INR",
                    maximumFractionDigits: 2
                }
            ).format(
                numericAmount
            );

        } catch (error) {

            return `${currency || "INR"} ${numericAmount}`;

        }

    },


    /*
    ========================================================
    CONNECT SUBSCRIPTION DATA TO BILLING CARD
    ========================================================
    */

    async connectCurrentSubscriptionToCard(
        card,
        restaurantId,
        ownerId = null
    ) {

        if (
            !card ||
            !restaurantId
        ) {

            return;

        }


        try {

            const result =
                await this.loadCurrentSubscription(
                    restaurantId,
                    ownerId
                );


            const subscription =
                result.subscription;


            const plan =
                result.plan;


            const findInfoValue =
                (label) => {

                    const items =
                        card.querySelectorAll(
                            ".bk-master-card-info-item"
                        );


                    for (
                        const item of items
                    ) {

                        const labelElement =
                            item.querySelector(
                                ".bk-master-card-info-label"
                            );


                        if (
                            labelElement &&
                            labelElement.textContent.trim() ===
                                label
                        ) {

                            return item.querySelector(
                                ".bk-master-card-info-value"
                            );

                        }

                    }


                    return null;

                };


            const currentPlanValue =
                findInfoValue(
                    "CURRENT PLAN"
                );


            const subscriptionStatusValue =
                findInfoValue(
                    "SUBSCRIPTION STATUS"
                );


            const startDateValue =
                findInfoValue(
                    "START DATE"
                );


            const expiryDateValue =
                findInfoValue(
                    "EXPIRY DATE"
                );


            const currentBillValue =
                findInfoValue(
                    "CURRENT BILL"
                );


            if (!subscription) {

                if (currentPlanValue) {

                    currentPlanValue.textContent =
                        "NO ACTIVE PLAN";

                }


                if (subscriptionStatusValue) {

                    subscriptionStatusValue.textContent =
                        "NO SUBSCRIPTION";

                }


                if (startDateValue) {

                    startDateValue.textContent =
                        "—";

                }


                if (expiryDateValue) {

                    expiryDateValue.textContent =
                        "—";

                }


                if (currentBillValue) {

                    currentBillValue.textContent =
                        "—";

                }


                return;

            }


            const planName =
                plan?.name ||
                subscription.planId ||
                "PLAN";


            const subscriptionStatus =
                subscription.status ||
                "UNKNOWN";


            const currency =
                subscription.currency ||
                plan?.currency ||
                "INR";


            if (currentPlanValue) {

                currentPlanValue.textContent =
                    planName;

            }


            if (subscriptionStatusValue) {

                subscriptionStatusValue.textContent =
                    subscriptionStatus;

            }


            if (startDateValue) {

                startDateValue.textContent =
                    this.formatBillingDate(
                        subscription.startedAt
                    );

            }


            if (expiryDateValue) {

                expiryDateValue.textContent =
                    this.formatBillingDate(
                        subscription.expiresAt
                    );

            }


            if (currentBillValue) {

                currentBillValue.textContent =
                    this.formatBillingAmount(
                        subscription.amount,
                        currency
                    );

            }


            console.log(
                "BK MASTER SUBSCRIPTION BILLING: CARD SUBSCRIPTION CONNECTED:",
                {
                    restaurantId,
                    planName,
                    subscriptionStatus,
                    startDate:
                        this.formatBillingDate(
                            subscription.startedAt
                        ),
                    expiryDate:
                        this.formatBillingDate(
                            subscription.expiresAt
                        ),
                    currentBill:
                        this.formatBillingAmount(
                            subscription.amount,
                            currency
                        )
                }
            );

        } catch (error) {

            console.error(
                "BK MASTER SUBSCRIPTION BILLING: CARD SUBSCRIPTION CONNECTION FAILED:",
                error
            );

        }

    },

    /*
    ========================================================
    SAFE VALUE HELPER
    ========================================================
    */
    getSafeValue(

        data,

        keys,

        fallback = "—"

    ) {

        if (

            !data ||

            !Array.isArray(keys)

        ) {

            return fallback;

        }


        for (const key of keys) {

            const value =
                data[key];


            if (

                value !== undefined &&

                value !== null &&

                String(value).trim() !== ""

            ) {

                return String(value);

            }

        }


        return fallback;

    },


    /*
    ========================================================
    HTML ESCAPE HELPER
    ========================================================
    */

    escapeHTML(value) {

        return String(
            value ?? ""
        )

        .replace(
            /&/g,
            "&amp;"
        )

        .replace(
            /</g,
            "&lt;"
        )

        .replace(
            />/g,
            "&gt;"
        )

        .replace(
            /"/g,
            "&quot;"
        )

        .replace(
            /'/g,
            "&#039;"
        );

    },
    
   /*
========================================================
CREATE MONTHLY USAGE RECORD
STEP 2A — VERIFIED, DATA-SAFE USAGE STORAGE
========================================================
*/

async createMonthlyUsageRecord(
    restaurantId,
    ownerId,
    billingMonth,
    usageData = {}
) {
    if (
        typeof restaurantId !== "string" ||
        !restaurantId.trim()
    ) {
        throw new Error(
            "Valid restaurant ID is required."
        );
    }

    if (
        typeof ownerId !== "string" ||
        !ownerId.trim()
    ) {
        throw new Error(
            "Valid owner ID is required."
        );
    }

    if (
        typeof billingMonth !== "string" ||
        !/^\d{4}-(0[1-9]|1[0-2])$/.test(billingMonth)
    ) {
        throw new Error(
            "Valid billing month in YYYY-MM format is required."
        );
    }

    if (
        !usageData ||
        typeof usageData !== "object" ||
        Array.isArray(usageData)
    ) {
        throw new Error(
            "Usage data must be a valid object."
        );
    }

    const {
        db,
        doc,
        getDoc,
        setDoc,
        serverTimestamp
    } = await this.getFirebaseModules();

    const trustedRestaurantRef = doc(
        db,
        "restaurants",
        restaurantId
    );

    const trustedRestaurantSnapshot = await getDoc(
        trustedRestaurantRef
    );

    if (!trustedRestaurantSnapshot.exists()) {
        throw new Error(
            "Restaurant not found. Usage save blocked."
        );
    }

    const trustedRestaurant =
        trustedRestaurantSnapshot.data();

    const trustedOwnerId =
        trustedRestaurant?.ownerId;

    if (
        typeof trustedOwnerId !== "string" ||
        !trustedOwnerId.trim() ||
        trustedOwnerId !== ownerId
    ) {
        throw new Error(
            "Restaurant ownership verification failed. Usage save blocked."
        );
    }

    const usageId =
        `${restaurantId}-${billingMonth}`;

    const usageRef = doc(
        db,
        "restaurantUsage",
        usageId
    );

    const existingSnapshot = await getDoc(
        usageRef
    );

    const existingData = existingSnapshot.exists()
        ? existingSnapshot.data()
        : {};

    if (
        existingData.ownerId !== undefined &&
        existingData.ownerId !== trustedOwnerId
    ) {
        throw new Error(
            "Existing usage record owner mismatch. Save blocked."
        );
    }

    if (
        existingData.restaurantId !== undefined &&
        existingData.restaurantId !== restaurantId
    ) {
        throw new Error(
            "Existing usage record restaurant mismatch. Save blocked."
        );
    }

    const numericFields = [
    // Existing usage metrics
    "bookings",
    "websiteVisits",
    "menuItems",
// Database service metrics
"databaseReads",
"databaseWrites",
"databaseUpdates",
"databaseDeletes",
    // Booking service metrics
    "tableBookings",
    "advanceBookings",
    "partyBookings",
    "eventBookings",
    "bookingRejections",
    "bookingCancellations",

    // Order service metrics
    "orders",
    "orderUpdates",
    "orderRejections",
    "orderCancellations",
    "orderDeletions",


    // Website service metrics
    "bandwidthGB",
    "hostingMonths",

    // Storage service metrics
    "storageUsedBytes",
    "storageUsedMB",
    "storageUsedGB",
    "storageGBMonths",
    "storageUploadGB",
    "storageDownloadGB",

    // Menu and media metrics
    "imageUploads",

    // Communication metrics
    "notificationsSent",
    "emailsSent",

    // Future service metrics
    "aiRequests",
    "analyticsReports",
    "customOperations"
        
    ];
    const allowedUsageFields = new Set([
    ...numericFields,
    "activeFeatures"
]);

for (const field of Object.keys(usageData)) {
    if (!allowedUsageFields.has(field)) {
        throw new Error(
            `Unsupported usage field: ${field}. Save blocked.`
        );
    }
}
    const usageRecord = {
        usageId,
        restaurantId,
        ownerId: trustedOwnerId,
        billingMonth
    };

    for (const field of numericFields) {
        if (
            Object.prototype.hasOwnProperty.call(
                usageData,
                field
            )
        ) {
            const value = Number(usageData[field]);

            if (
                usageData[field] === null ||
                usageData[field] === "" ||
                !Number.isFinite(value) ||
                value < 0
            ) {
                throw new Error(
                    `Invalid usage value for ${field}. Save blocked.`
                );
            }

            usageRecord[field] = value;

        } else if (
            existingSnapshot.exists() &&
            typeof existingData[field] === "number" &&
            Number.isFinite(existingData[field]) &&
            existingData[field] >= 0
        ) {
            // Preserve previously saved verified values.
            usageRecord[field] = existingData[field];
        }

        // If a metric is missing and no verified previous
        // value exists, leave it absent.
        // Missing usage must never be silently treated as zero.
    }

    if (
        Object.prototype.hasOwnProperty.call(
            usageData,
            "activeFeatures"
        )
    ) {
        if (!Array.isArray(usageData.activeFeatures)) {
            throw new Error(
                "activeFeatures must be an array."
            );
        }

        usageRecord.activeFeatures =
            usageData.activeFeatures;
    } else {
        usageRecord.activeFeatures =
            Array.isArray(existingData.activeFeatures)
                ? existingData.activeFeatures
                : [];
    }

    usageRecord.calculatedAt =
        serverTimestamp();

    usageRecord.updatedAt =
        serverTimestamp();

    await setDoc(
        usageRef,
        usageRecord,
        {
            merge: true
        }
    );

    console.log(
        "BK MASTER BILLING: VERIFIED MONTHLY USAGE SAVED:",
        {
            usageId,
            restaurantId,
            billingMonth
        }
    );

    return {
        usageId,
        restaurantId,
        ownerId: trustedOwnerId,
        billingMonth
    };
}, 

/*
========================================================
SYNC ACTUAL MONTHLY ORDER USAGE
Counts existing orders for the selected billing month.
Does not publish a bill.
========================================================
*/

async syncActualMonthlyOrderUsage(
    restaurantId,
    ownerId,
    billingMonth
) {
    if (
        typeof restaurantId !== "string" ||
        !restaurantId.trim() ||
        typeof ownerId !== "string" ||
        !ownerId.trim() ||
        typeof billingMonth !== "string" ||
        !/^\d{4}-(0[1-9]|1[0-2])$/.test(billingMonth)
    ) {
        throw new Error(
            "Valid restaurant, owner, and billing month are required."
        );
    }
const {
    db,
    doc,
    getDoc,
    setDoc,
    serverTimestamp,
    collection,
    getDocs,
    query,
    where
} = await this.getFirebaseModules();

    // Verify trusted restaurant ownership.
    const restaurantRef = doc(
        db,
        "restaurants",
        restaurantId
    );

    const restaurantSnapshot = await getDoc(
        restaurantRef
    );

    if (!restaurantSnapshot.exists()) {
        throw new Error(
            "Restaurant not found. Usage sync blocked."
        );
    }

    const trustedOwnerId =
        restaurantSnapshot.data()?.ownerId;

    if (
        typeof trustedOwnerId !== "string" ||
        trustedOwnerId !== ownerId
    ) {
        throw new Error(
            "Owner verification failed. Usage sync blocked."
        );
    }

    // Count existing order documents for the selected month.
    const [year, month] = billingMonth
        .split("-")
        .map(Number);

    const monthStart =
        `${billingMonth}-01T00:00:00.000Z`;

    const nextMonthStart = new Date(
        Date.UTC(year, month, 1)
    ).toISOString();

    const ordersRef = collection(
        db,
        "restaurants",
        restaurantId,
        "orders"
    );

    const ordersQuery = query(
        ordersRef,
        where("createdAt", ">=", monthStart),
        where("createdAt", "<", nextMonthStart)
    );

    const ordersSnapshot = await getDocs(
        ordersQuery
    );

    const actualOrders = ordersSnapshot.size;
    if (
    !Number.isSafeInteger(actualOrders) ||
    actualOrders < 0
) {
    throw new Error(
        "Actual monthly order count is invalid."
    );
}

    // Never silently create a zero-usage record.
    const usageRef = doc(
        db,
        "restaurantUsage",
        `${restaurantId}-${billingMonth}`
    );

    const usageSnapshot = await getDoc(usageRef);

    if (!usageSnapshot.exists()) {
        throw new Error(
            "Monthly usage record is missing. Create a verified usage record before syncing orders."
        );
    }

    const existingUsage = usageSnapshot.data();

    if (
        existingUsage.restaurantId !== restaurantId ||
        existingUsage.ownerId !== trustedOwnerId ||
        existingUsage.billingMonth !== billingMonth
    ) {
        throw new Error(
            "Monthly usage identity mismatch. Usage sync blocked."
        );
    }

    // Preserve other metrics and update only the verified order count.

    await setDoc(
        usageRef,
        {
            orders: actualOrders,
            updatedAt: serverTimestamp()
        },
        { merge: true }
    );

    console.log(
        "BK BILLING: ACTUAL MONTHLY ORDER USAGE SYNCED",
        {
            restaurantId,
            billingMonth,
            orders: actualOrders
        }
    );

    return {
        success: true,
        restaurantId,
        ownerId: trustedOwnerId,
        billingMonth,
        orders: actualOrders,
        published: false
    };
},


/*
========================================================
INITIALIZE MONTHLY USAGE SAFELY
STEP 2B — VERIFIED ORDER USAGE
========================================================
*/

async initializeMonthlyUsageSafely(
    restaurantId,
    ownerId,
    billingMonth,
    verifiedMetrics = {}
) {
    if (
        typeof restaurantId !== "string" ||
        !restaurantId.trim() ||
        typeof ownerId !== "string" ||
        !ownerId.trim() ||
        typeof billingMonth !== "string" ||
        !/^\d{4}-(0[1-9]|1[0-2])$/.test(billingMonth)
    ) {
        throw new Error(
            "Valid restaurant, owner, and billing month are required."
        );
    }

    if (
        !verifiedMetrics ||
        typeof verifiedMetrics !== "object" ||
        Array.isArray(verifiedMetrics)
    ) {
        throw new Error(
            "Verified usage metrics must be a valid object."
        );
    }

    
    
    for (const field of Object.keys(verifiedMetrics)) {
    if (!allowedMetrics.includes(field)) {
        throw new Error(
            `Unsupported verified usage metric: ${field}.`
        );
    }
}

    for (const field of allowedMetrics) {
        if (
            Object.prototype.hasOwnProperty.call(
                verifiedMetrics,
                field
            )
        ) {
            const value = verifiedMetrics[field];

            if (
                typeof value !== "number" ||
                !Number.isFinite(value) ||
                value < 0
            ) {
                throw new Error(
                    `Invalid verified metric: ${field}.`
                );
            }
        }
    }

    // Verify the trusted restaurant and owner first.
    const {
        db,
        doc,
        getDoc,
        collection,
        getDocs,
        query,
        where
    } = await this.getFirebaseModules();

    const restaurantRef = doc(
        db,
        "restaurants",
        restaurantId
    );

    const restaurantSnapshot = await getDoc(
        restaurantRef
    );

    if (!restaurantSnapshot.exists()) {
        throw new Error(
            "Restaurant not found. Initialization blocked."
        );
    }

    const trustedOwnerId =
        restaurantSnapshot.data()?.ownerId;

    if (
        typeof trustedOwnerId !== "string" ||
        trustedOwnerId !== ownerId
    ) {
        throw new Error(
            "Restaurant ownership verification failed."
        );
    }

    // Count actual orders for this billing month.
    const [year, month] = billingMonth
        .split("-")
        .map(Number);

    const monthStart =
        `${billingMonth}-01T00:00:00.000Z`;

    const nextMonthStart = new Date(
        Date.UTC(year, month, 1)
    ).toISOString();

    const ordersRef = collection(
        db,
        "restaurants",
        restaurantId,
        "orders"
    );

    const ordersQuery = query(
        ordersRef,
        where("createdAt", ">=", monthStart),
        where("createdAt", "<", nextMonthStart)
    );

    const ordersSnapshot = await getDocs(
        ordersQuery
    );

    const actualOrders = ordersSnapshot.size;
    
if (
    !Number.isSafeInteger(actualOrders) ||
    actualOrders < 0
) {
    throw new Error(
        "Actual monthly order count is invalid."
    );
}
    // Check the existing usage record.
    const usageId =
        `${restaurantId}-${billingMonth}`;

    const usageRef = doc(
        db,
        "restaurantUsage",
        usageId
    );

    const usageSnapshot = await getDoc(
        usageRef
    );

    if (usageSnapshot.exists()) {
        const existingUsage = usageSnapshot.data();

        if (
            existingUsage.restaurantId !== restaurantId ||
            existingUsage.ownerId !== trustedOwnerId ||
            existingUsage.billingMonth !== billingMonth
        ) {
            throw new Error(
                "Existing usage identity mismatch. Initialization blocked."
            );
        }
// Existing record: verify identity, then retry actual order sync.
const orderSyncResult =
    await this.syncActualMonthlyOrderUsage(
        restaurantId,
        trustedOwnerId,
        billingMonth
    );

if (
    !orderSyncResult ||
    orderSyncResult.success !== true
) {
    throw new Error(
        "Existing monthly usage record found, but order sync failed."
    );
}

return {
    success: true,
    created: false,
    restaurantId,
    ownerId: trustedOwnerId,
    billingMonth,
    orders: orderSyncResult.orders,
    usageId,
    published: false,
    message:
        "Existing usage record verified and actual order usage synced."
};

    }

// Build a new record without inventing missing metrics.
// Actual order count must never be overridden by caller input.
// Caller metrics only.
// Actual order count is synced separately.
const usageData = {
    ...verifiedMetrics
};

const result =
    await this.createMonthlyUsageRecord(
        restaurantId,
        trustedOwnerId,
        billingMonth,
        usageData
    );

// Sync the actual order count using the dedicated method.
const orderSyncResult =
    await this.syncActualMonthlyOrderUsage(
        restaurantId,
        trustedOwnerId,
        billingMonth
    );
if (
    !orderSyncResult ||
    orderSyncResult.success !== true ||
    !Number.isSafeInteger(orderSyncResult.orders) ||
    orderSyncResult.orders < 0
) {
    throw new Error(
        "Actual monthly order usage sync failed verification."
    );
}

    console.log(
        "BK BILLING: MONTHLY USAGE INITIALIZED",
        {
            usageId: result.usageId,
            restaurantId,
            billingMonth,
            orders: orderSyncResult.orders
        }
    );

    return {
        success: true,
        created: true,
        restaurantId,
        ownerId: trustedOwnerId,
        billingMonth,
        orders: orderSyncResult.orders,
        usageId: result.usageId,
        published: false
    };
},

    


    /*
========================================================
MONTHLY USAGE DATA LOADER
STEP 2B — TRUSTED IDENTITY VALIDATION
========================================================
*/

  async loadMonthlyUsageRecord(restaurantId, billingMonth) {
    if (
        typeof restaurantId !== "string" ||
        !restaurantId.trim()
    ) {
        throw new Error("Restaurant ID is required.");
    }

    if (
        typeof billingMonth !== "string" ||
        !/^\d{4}-(0[1-9]|1[0-2])$/.test(billingMonth)
    ) {
        throw new Error(
            "A valid billing month in YYYY-MM format is required."
        );
    }

    const {
        db,
        doc,
        getDoc,
        collection,
        getDocs,
        query,
        where
    } = await this.getFirebaseModules();

    // 1. Verify the trusted restaurant record first.
    const restaurantRef = doc(
        db,
        "restaurants",
        restaurantId
    );

    const restaurantSnapshot = await getDoc(restaurantRef);

    if (!restaurantSnapshot.exists()) {
        throw new Error(
            "Restaurant record not found. Billing blocked."
        );
    }

    const restaurantData = restaurantSnapshot.data();
    const trustedOwnerId = restaurantData?.ownerId;

    if (
        typeof trustedOwnerId !== "string" ||
        !trustedOwnerId.trim()
    ) {
        throw new Error(
            "Trusted restaurant owner ID is missing. Billing blocked."
        );
    }

    // 2. Load the monthly usage record.
    const usageId = `${restaurantId}-${billingMonth}`;

    const usageRef = doc(
        db,
        "restaurantUsage",
        usageId
    );

    const usageSnapshot = await getDoc(usageRef);

    if (!usageSnapshot.exists()) {
        console.warn(
            "BK MASTER BILLING: Monthly usage record missing.",
            { restaurantId, billingMonth, usageId }
        );

        // Keep billing blocked if the monthly usage record is missing.
        return null;
    }

    const usageData = usageSnapshot.data();

    if (
        !usageData ||
        typeof usageData !== "object" ||
        Array.isArray(usageData)
    ) {
        throw new Error(
            "Monthly usage record is invalid. Billing blocked."
        );
    }


if (
    typeof usageData.restaurantId !== "string" ||
    usageData.restaurantId.trim() !== restaurantId
) {
    throw new Error(
        "Usage record restaurant ID is missing or mismatched. Billing blocked."
    );
}

if (
    typeof usageData.ownerId !== "string" ||
    usageData.ownerId.trim() !== trustedOwnerId.trim()
) {
    throw new Error(
        "Usage record owner ID is missing or mismatched. Billing blocked."
    );
}

if (
    usageData.billingMonth !== billingMonth
) {
    throw new Error(
        "Usage record billing month is missing or mismatched. Billing blocked."
    );
}


    // 3. Count existing orders created during the selected month.
    // Order documents use ISO-format createdAt strings.
    const [year, month] = billingMonth
        .split("-")
        .map(Number);

    const monthStart =
        `${billingMonth}-01T00:00:00.000Z`;

    const nextMonthStart = new Date(
        Date.UTC(year, month, 1)
    ).toISOString();

    const ordersRef = collection(
        db,
        "restaurants",
        restaurantId,
        "orders"
    );

    const monthlyOrdersQuery = query(
        ordersRef,
        where("createdAt", ">=", monthStart),
        where("createdAt", "<", nextMonthStart)
    );

    // If this query fails, throw an error. Never silently bill zero.
    const ordersSnapshot = await getDocs(
        monthlyOrdersQuery
    );

    const actualMonthlyOrders = ordersSnapshot.size;

    // 4. Return verified data with the actual order-document count.
    const verifiedUsageData = {
        ...usageData,
        restaurantId,
        ownerId: trustedOwnerId,
        usageId,
        billingMonth,
        orders: actualMonthlyOrders
    };

    console.log(
        "BK MASTER BILLING: MONTHLY USAGE VERIFIED",
        {
            usageId,
            restaurantId,
            ownerId: trustedOwnerId,
            billingMonth,
            existingMonthlyOrderDocuments: actualMonthlyOrders
        }
    );

    return verifiedUsageData;
},  
        /*
    ========================================================
    USAGE COST CALCULATOR
    STEP 2C — FOUNDATION
    ========================================================
    */
        calculateUsageCost(
        usageData = {},
        pricing = {}
    ) {


        if (
            !usageData ||
            typeof usageData !== "object" ||
            Array.isArray(usageData) ||
            !pricing ||
            typeof pricing !== "object" ||
            Array.isArray(pricing)
        ) {
            throw new Error(
                "Invalid usage or pricing data. Cost calculation blocked."
            );
        }

        const metricKeys = [
            "bookings",
            "orders",
            "websiteVisits",
            "menuItems",
            "storageUsedGB"
        ];

        const rateKeys = [
            "bookingRate",
            "orderRate",
            "websiteVisitRate",
            "menuItemRate",
            "storageGBRate"
        ];

        for (const key of metricKeys) {
            const value = usageData[key];

            if (
                typeof value !== "number" ||
                !Number.isFinite(value) ||
                value < 0
            ) {
                throw new Error(
                    `Invalid usage metric: ${key}.`
                );
            }
        }

        for (const key of rateKeys) {
            const value = pricing[key];

            if (
                typeof value !== "number" ||
                !Number.isFinite(value) ||
                value < 0
            ) {
                throw new Error(
                    `Invalid pricing rate: ${key}.`
                );
            }
        }


        const bookings =
            Number(usageData.bookings || 0);

        const orders =
            Number(usageData.orders || 0);

        const websiteVisits =
            Number(usageData.websiteVisits || 0);

        const menuItems =
            Number(usageData.menuItems || 0);

        const storageUsedGB =
            Number(usageData.storageUsedGB || 0);


        const bookingRate =
            Number(pricing.bookingRate || 0);

        const orderRate =
            Number(pricing.orderRate || 0);

        const websiteVisitRate =
            Number(pricing.websiteVisitRate || 0);

        const menuItemRate =
            Number(pricing.menuItemRate || 0);

        const storageGBRate =
            Number(pricing.storageGBRate || 0);


        const bookingCost =
            bookings * bookingRate;

        const orderCost =
            orders * orderRate;

        const websiteVisitCost =
            websiteVisits * websiteVisitRate;

        const menuItemCost =
            menuItems * menuItemRate;

        const storageCost =
            storageUsedGB * storageGBRate;


        const estimatedCost =
            bookingCost +
            orderCost +
            websiteVisitCost +
            menuItemCost +
            storageCost;


        const costComponents = [
            bookingCost,
            orderCost,
            websiteVisitCost,
            menuItemCost,
            storageCost
        ];
        
        if (
    Math.abs(
        estimatedCost -
        costComponents.reduce((total, value) => total + value, 0)
    ) > 0.000001
) {
    throw new Error(
        "Usage cost component total mismatch."
    );
}

        if (
            !costComponents.every(
                value =>
                    Number.isFinite(value) &&
                    value >= 0 &&
                    Number.isSafeInteger(
                        Math.round(value * 100)
                    ) &&
                    Math.abs(
                        value * 100 -
                        Math.round(value * 100)
                    ) < 0.000001
            ) ||
            !Number.isFinite(estimatedCost) ||
            !Number.isSafeInteger(
                Math.round(estimatedCost * 100)
            )
        ) {
            throw new Error(
                "Calculated usage cost exceeds safe billing limits."
            );
        }

const roundedEstimatedCost = Number(estimatedCost.toFixed(2));

if (
    !Number.isFinite(roundedEstimatedCost) ||
    roundedEstimatedCost < 0 ||
    !Number.isSafeInteger(
        Math.round(roundedEstimatedCost * 100)
    )
) {
    throw new Error(
        "Rounded usage cost exceeds safe billing limits."
    );
}

        const result = {

            bookings,
            orders,
            websiteVisits,
            menuItems,
            storageUsedGB,

            bookingRate,
            orderRate,
            websiteVisitRate,
            menuItemRate,
            storageGBRate,

            bookingCost,
            orderCost,
            websiteVisitCost,
            menuItemCost,
            storageCost,
estimatedCost: roundedEstimatedCost

        };


        console.log(
            "BK MASTER BILLING: USAGE COST CALCULATED:",
            result
        );


        return result;

    },
    
        /*
    ========================================================
    MASTER CHARGE / PROFIT CALCULATOR
    STEP 2D — FOUNDATION
    ========================================================
    */

    calculateMasterCharge(
        estimatedCost = 0,
        chargeSettings = {}
    ) {

        const baseCost =
            Number(estimatedCost || 0);

        if (!Number.isFinite(baseCost) || baseCost < 0) {
            throw new Error(
                "Estimated cost must be a valid non-negative number."
            );
        }

        const chargeType =
            chargeSettings.type === "PERCENTAGE"
                ? "PERCENTAGE"
                : "FIXED";

        const fixedCharge =
            Number(
                chargeSettings.fixedAmount || 0
            );

        const percentage =
            Number(
                chargeSettings.percentage || 0
            );

        if (
            !Number.isFinite(fixedCharge) ||
            fixedCharge < 0
        ) {
            throw new Error(
                "Fixed charge must be a valid non-negative number."
            );
        }

        if (
            !Number.isFinite(percentage) ||
            percentage < 0
        ) {
            throw new Error(
                "Percentage must be a valid non-negative number."
            );
        }

        let masterCharge = 0;

        if (chargeType === "PERCENTAGE") {

            masterCharge =
                baseCost *
                (percentage / 100);

        } else {

            masterCharge =
                fixedCharge;

        }

        const finalBill =
            baseCost +
            masterCharge;

        const result = {

            estimatedCost:
                Number(
                    baseCost.toFixed(2)
                ),

            chargeType,

            fixedCharge:
                Number(
                    fixedCharge.toFixed(2)
                ),

            percentage:
                Number(
                    percentage.toFixed(2)
                ),

            masterCharge:
                Number(
                    masterCharge.toFixed(2)
                ),

            finalBill:
                Number(
                    finalBill.toFixed(2)
                )

        };

        console.log(
            "BK MASTER BILLING: MASTER CHARGE CALCULATED:",
            result
        );

        return result;

    },
 
 
/*
========================================================
BILLING MONTH VALIDATION
========================================================
*/

validateBillingMonth(billingMonth) {

    const month = String(
        billingMonth ?? ""
    ).trim();

    if (
        !/^\d{4}-(0[1-9]|1[0-2])$/.test(month)
    ) {
        throw new Error(
            "Billing month must be in YYYY-MM format."
        );
    }

    return month;

},

    
    /*
========================================================
PREPARE BILLING CALCULATION RESULT
STEP 2C — PUBLISH PREPARATION
========================================================
*/

prepareBillingCalculation(
    restaurantId,
    ownerId,
    billingData = {}
) {
    if (
        typeof restaurantId !== "string" ||
        !restaurantId.trim() ||
        typeof ownerId !== "string" ||
        !ownerId.trim()
    ) {
        throw new Error(
            "Restaurant ID and Owner ID are required."
        );
    }
    
    const billingMonth =
    this.validateBillingMonth(
        billingData.billingMonth
    );

    const hasUsagePricing =
        Object.prototype.hasOwnProperty.call(
            billingData,
            "restaurantCharge"
        );

    const estimatedCost = Number(
        billingData.estimatedCost
    );

    if (
        !Number.isFinite(estimatedCost) ||
        estimatedCost < 0
    ) {
        throw new Error(
            "Estimated provider cost must be a valid non-negative amount."
        );
    }

    let masterCharge;
    let finalBill;
    let chargeType;
    let fixedCharge;
    let percentage;

    
if (hasUsagePricing) {
    const restaurantCharge = Number(
        billingData.restaurantCharge
    );

    if (
        !Number.isFinite(restaurantCharge) ||
        restaurantCharge < 0
    ) {
        throw new Error(
            "Restaurant charge must be a valid non-negative amount."
        );
    }

    if (restaurantCharge < estimatedCost) {
        throw new Error(
            "Restaurant pricing is below provider cost. Billing is blocked."
        );
    }

    chargeType =
        billingData.chargeType === "PERCENTAGE"
            ? "PERCENTAGE"
            : "FIXED";

    fixedCharge = Number(
        billingData.fixedAmount ?? 0
    );

    percentage = Number(
        billingData.percentage ?? 0
    );

    if (
        !Number.isFinite(fixedCharge) ||
        fixedCharge < 0 ||
        !Number.isFinite(percentage) ||
        percentage < 0
    ) {
        throw new Error(
            "Master margin must be a valid non-negative amount."
        );
    }

    if (
        chargeType === "PERCENTAGE" &&
        percentage > 100
    ) {
        throw new Error(
            "Master margin percentage cannot exceed 100."
        );
    }

    const usageMargin = Number(
        (restaurantCharge - estimatedCost).toFixed(2)
    );

    const extraMargin =
        chargeType === "PERCENTAGE"
            ? Number(
                (restaurantCharge * percentage / 100).toFixed(2)
            )
            : Number(fixedCharge.toFixed(2));

    masterCharge = Number(
        (usageMargin + extraMargin).toFixed(2)
    );

    finalBill = Number(
        (estimatedCost + masterCharge).toFixed(2)
    );
} else {
    chargeType =
        billingData.chargeType === "PERCENTAGE"
            ? "PERCENTAGE"
            : "FIXED";

    fixedCharge = Number(
        billingData.fixedAmount || 0
    );

    percentage = Number(
        billingData.percentage || 0
    );

    const legacyCalculation =
        this.calculateMasterCharge(
            estimatedCost,
            {
                type: chargeType,
                fixedAmount: fixedCharge,
                percentage
            }
        );

    masterCharge =
        legacyCalculation.masterCharge;

    finalBill =
        legacyCalculation.finalBill;
}

    return {
        restaurantId,
        ownerId,
        billingMonth,
        estimatedCost,
        chargeType,
        fixedCharge,
        percentage,
        masterCharge,
        finalBill,
        currency: String(
    billingData.currency || "INR"
).trim().toUpperCase()
    };
},

  
/*
========================================================
VALIDATE BILLING PUBLISH DATA
STEP 2D — PUBLISH VALIDATION
========================================================
*/

validateBillingPublishData(billingData = {}) {
    if (
        typeof billingData.restaurantId !== "string" ||
        !billingData.restaurantId.trim()
    ) {
        throw new Error(
            "Restaurant ID is required before publishing."
        );
    }

    if (
        typeof billingData.ownerId !== "string" ||
        !billingData.ownerId.trim()
    ) {
        throw new Error(
            "Owner ID is required before publishing."
        );
    }

    const billingMonth = String(
        billingData.billingMonth ||
        billingData.billingPeriod ||
        ""
    ).trim();

    if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(billingMonth)) {
        throw new Error(
            "Invalid billing month. Use YYYY-MM with a valid month from 01 to 12."
        );
    }

    const estimatedCost = Number(
        billingData.estimatedCost
    );

    const masterCharge = Number(
        billingData.masterCharge
    );

    const finalBill = Number(
        billingData.finalBill
    );

    const isValidMoney = (value) =>
        Number.isFinite(value) &&
        value >= 0 &&
        Math.abs(value * 100 - Math.round(value * 100)) < 0.000001;

    if (!isValidMoney(estimatedCost)) {
        throw new Error(
            "Usage cost must be a valid non-negative amount with no more than two decimal places."
        );
    }

    if (!isValidMoney(masterCharge)) {
        throw new Error(
            "Master margin must be a valid non-negative amount with no more than two decimal places."
        );
    }
    
    if (masterCharge < 0) {
    throw new Error(
        "Negative Master margin is not allowed. Billing is blocked."
    );
}

    if (!isValidMoney(finalBill)) {
        throw new Error(
            "Final payable bill must be a valid non-negative amount with no more than two decimal places."
        );
    }

    
const expectedFinalBill = Number(
    (estimatedCost + masterCharge).toFixed(2)
);

    if (finalBill !== expectedFinalBill) {
        throw new Error(
            "Final bill does not match usage cost plus Master margin."
        );
    }

if (billingData.currency !== undefined) {
    if (
        typeof billingData.currency !== "string" ||
        billingData.currency.trim() !== "INR"
    ) {
        throw new Error(
            "Unsupported billing currency. Only INR is allowed."
        );
    }
}

    const currency = billingData.currency || "INR";
    const status = billingData.status || "CALCULATED";

    const result = {
        restaurantId: billingData.restaurantId,
        ownerId: billingData.ownerId,
        billingMonth,
        estimatedCost,
        masterCharge,
        finalBill,
        currency,
        status
    };

    console.log(
        "BK MASTER BILLING: PUBLISH DATA VALIDATED:",
        result
    );

    return result;
},
  
    
        /*
    ========================================================
    MONTHLY BILLING RECORD
    STEP 2E — FINAL BILL + HISTORY FOUNDATION
    ========================================================
    */
async createMonthlyBillingRecord(
    restaurantId,
    ownerId,
    billingMonth,
    billingData = {}
) {
    restaurantId = String(restaurantId || "").trim();
    ownerId = String(ownerId || "").trim();
    billingMonth = String(billingMonth || "").trim();

    if (!restaurantId) {
        throw new Error("Restaurant ID is required.");
    }

    if (!ownerId) {
        throw new Error("Owner ID is required.");
    }

    if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(billingMonth)) {
        throw new Error(
            "Invalid billing month. Use YYYY-MM."
        );
    }

    const estimatedCost = Number(billingData.estimatedCost ?? 0);
    const masterCharge = Number(billingData.masterCharge ?? 0);
    const expectedFinalBill = Number(
        (estimatedCost + masterCharge).toFixed(2)
    );

    const finalBill = Number(
        billingData.finalBill ?? expectedFinalBill
    );
    
    const currency = String(
    billingData.currency ?? "INR"
).trim().toUpperCase();

if (currency !== "INR") {
    throw new Error(
        "Unsupported billing currency. Only INR is allowed."
    );
}

    const isValidMoney = (amount) =>
        typeof amount === "number" &&
        Number.isFinite(amount) &&
        amount >= 0 &&
        Number.isSafeInteger(
            Math.round(amount * 100)
        ) &&
        Math.abs(
            amount * 100 -
            Math.round(amount * 100)
        ) < 0.000001;

    if (
        !isValidMoney(estimatedCost) ||
        !isValidMoney(masterCharge) ||
        !isValidMoney(finalBill)
    ) {
        throw new Error(
            "Billing amounts must be valid non-negative amounts with up to 2 decimal places."
        );
    }

    if (
        !Number.isSafeInteger(
            Math.round((estimatedCost + masterCharge) * 100)
        ) ||
        finalBill !== expectedFinalBill
    ) {
        throw new Error(
            "Final bill calculation mismatch or amount exceeds the safe limit."
        );
    }

    const {
        db,
        doc,
        runTransaction,
        serverTimestamp
    } = await this.getFirebaseModules();

    if (typeof runTransaction !== "function") {
        throw new Error("Firestore transaction is unavailable.");
    }

    const billingId =
    `${restaurantId}_${billingMonth}`;

const billingRef = doc(
    db,
    "billingRecords",
    billingId
);

    const result = await runTransaction(
        db,
        async (transaction) => {
            const snapshot = await transaction.get(billingRef);

            let createdAt = serverTimestamp();

            if (snapshot.exists()) {
                const existing = snapshot.data();

                if (
                    existing.restaurantId &&
                    existing.restaurantId !== restaurantId
                ) {
                    throw new Error("Restaurant ID mismatch.");
                }

                if (
                    existing.ownerId &&
                    existing.ownerId !== ownerId
                ) {
                    throw new Error("Owner ID mismatch.");
                }

                const oldMonth = String(
                    existing.billingMonth ||
                    existing.billingPeriod ||
                    ""
                );

                const status = String(
                    existing.status || ""
                ).toUpperCase();

                const paymentStatus = String(
                    existing.paymentStatus || ""
                ).toUpperCase();

                const isPaid =
                    status === "PAID" ||
                    paymentStatus === "PAID";

                const unresolvedStatuses = [
                    "PUBLISHED",
                    "UNPAID",
                    "PAYMENT_SUBMITTED",
                    "VERIFICATION_PENDING",
                    "REJECTED"
                ];

                const unresolved =
                    unresolvedStatuses.includes(status) ||
                    unresolvedStatuses.includes(paymentStatus);

                if (oldMonth !== billingMonth && unresolved) {
                    throw new Error(
                        "Previous bill is unresolved. Resolve it before saving the next month's bill."
                    );
                }

                if (oldMonth === billingMonth && isPaid) {
                    throw new Error(
                        "This month's bill is already paid. It cannot be overwritten."
                    );
                }

                if (oldMonth === billingMonth && unresolved) {
                    throw new Error(
                        "This month's bill is already published or has an unresolved payment. It cannot be overwritten."
                    );
                }

                if (
                    oldMonth === billingMonth &&
                    status !== "CALCULATED"
                ) {
                    throw new Error(
                        "Only an existing CALCULATED draft can be updated."
                    );
                }

                if (
                    oldMonth !== billingMonth &&
                    !isPaid &&
                    status !== "CALCULATED" &&
                    status !== ""
                ) {
                    throw new Error(
                        "Previous billing record is not safely settled. Manual review is required."
                    );
                }

                if (existing.createdAt) {
                    createdAt = existing.createdAt;
                }
            }

            const record = {
                billingId,
                restaurantId,
                ownerId,
                billingMonth,
                billingPeriod: billingMonth,
                baseAmount: Number(estimatedCost.toFixed(2)),
                usageAdjustment: Number(masterCharge.toFixed(2)),
                finalAmount: Number(finalBill.toFixed(2)),
currency,

                status: "CALCULATED",
                createdAt,
                updatedAt: serverTimestamp()
            };

            transaction.set(billingRef, record);

            return {
                billingId,
                restaurantId,
                ownerId,
                billingMonth,
                estimatedCost: record.baseAmount,
                masterCharge: record.usageAdjustment,
                finalBill: record.finalAmount,
                currency: record.currency,
                status: record.status
            };
        }
    );

    console.log(
        "BK MASTER BILLING: MONTHLY BILL SAVED SAFELY:",
        result
    );

    return result;
},
};


/*
========================================================
GLOBAL EXPOSURE
========================================================
*/

window.BKMasterSubscriptionBillingControl =
    BKMasterSubscriptionBillingControl;
/*
========================================================
PAYMENT REVIEW ACTION BINDING
PART 2C — STEP 4F
========================================================
*/

let bkMasterPaymentReviewActionsBound = false;

function bindBKMasterPaymentReviewActions() {

    if (bkMasterPaymentReviewActionsBound) {

        return;

    }

    bkMasterPaymentReviewActionsBound = true;


    document.addEventListener(
        "click",
        async (event) => {

            const button =
                event.target.closest(
                    "[data-billing-action]"
                );


            if (!button) {

                return;

            }


            const actionType =
                String(
                    button.dataset.billingAction || ""
                )
                .trim()
                .toLowerCase();


            if (
                actionType !== "verify-payment" &&
                actionType !== "reject-payment"
            ) {

                return;

            }


            const restaurantId =
                String(
                    button.dataset.restaurantId || ""
                )
                .trim();


            if (!restaurantId) {

                console.error(
                    "BK MASTER PAYMENT: REVIEW ACTION MISSING RESTAURANT ID."
                );

                return;

            }


            const control =
                window.BKMasterSubscriptionBillingControl;


            if (!control) {

                console.error(
                    "BK MASTER PAYMENT: CONTROL ENGINE NOT AVAILABLE."
                );

                return;

            }


            const reviewAction =
                actionType === "verify-payment"
                    ? "VERIFY"
                    : "REJECT";


            try {

                button.disabled = true;


                /*
                ----------------------------------------
                LOAD LATEST PAYMENT
                ----------------------------------------
                */

                const paymentData =
                    await control.loadLatestPayment(
                        restaurantId
                    );


                if (!paymentData) {

                    throw new Error(
                        "No payment record found."
                    );

                }


                /*
                ----------------------------------------
                CONFIRM CURRENT REVIEW STATE
                ----------------------------------------
                */

                const reviewState =
                    control.getPaymentReviewState(
                        paymentData
                    );


                if (!reviewState.reviewable) {

                    throw new Error(
                        "Payment is no longer reviewable."
                    );

                }


                /*
                ----------------------------------------
                REVIEW REASON
                ----------------------------------------
                */
                
                                const reviewReason =
                    window.prompt(
                        reviewAction === "VERIFY"
                            ? "Enter the reason for verifying this payment:"
                            : "Enter the reason for rejecting this payment:"
                    );


                if (
                    reviewReason === null ||
                    !String(reviewReason).trim()
                ) {

                    console.warn(
                        "BK MASTER PAYMENT: REVIEW ACTION CANCELLED — REASON REQUIRED."
                    );

                    button.disabled = false;

                    return;

                }


                /*
                ----------------------------------------
                EXECUTE TESTED REVIEW ENGINE
                ----------------------------------------
                */

                const result =
                    await control.reviewPayment(
                        paymentData,
                        reviewAction,
                        reviewReason
                    );


                console.log(
                    "BK MASTER PAYMENT: UI REVIEW ACTION SUCCESS:",
                    result
                );


                /*
                ----------------------------------------
                UPDATE CARD BUTTON STATE
                ----------------------------------------
                */

                const card =
                    button.closest(
                        ".bk-master-subscription-billing-card"
                    );


                if (card) {

                    const verifyButton =
                        card.querySelector(
                            '[data-billing-action="verify-payment"]'
                        );

                    const rejectButton =
                        card.querySelector(
                            '[data-billing-action="reject-payment"]'
                        );


                    if (verifyButton) {

                        verifyButton.disabled = true;

                    }


                    if (rejectButton) {

                        rejectButton.disabled = true;

                    }


                    const infoItems =
                        card.querySelectorAll(
                            ".bk-master-card-info-item"
                        );


                    infoItems.forEach(
                        (item) => {

                            const label =
                                item.querySelector(
                                    ".bk-master-card-info-label"
                                );

                            const value =
                                item.querySelector(
                                    ".bk-master-card-info-value"
                                );


                            if (
                                !label ||
                                !value
                            ) {

                                return;

                            }


                            if (
                                label.textContent.trim() ===
                                "PAYMENT STATUS"
                            ) {

                                value.textContent =
                                    result.newStatus || "—";

                            }

                        }
                    );

                }


            } catch (error) {

                console.error(
                    "BK MASTER PAYMENT: UI REVIEW ACTION FAILED:",
                    error
                );


                button.disabled = false;


                window.alert(
                    error?.message ||
                    "Payment review action failed."
                );

            }

        }
    );


    console.log(
        "BK MASTER PAYMENT: REVIEW ACTION BINDING: READY"
    );

}


/*
========================================================
STEP 4F — INITIALIZE UI BINDING
========================================================
*/

bindBKMasterPaymentReviewActions();

/*
========================================================
BILLING PUBLISH ACTION BINDING
STEP 2D — PART 5
========================================================
*/

let bkMasterBillingPublishActionBound = false;


/*
========================================================
FIRESTORE BILL PUBLISH WRITE
========================================================
*/

async function publishBKMasterBillingRecord(
    billingData,
    control
) {

    if (!billingData) {

        throw new Error(
            "Billing publish data is missing."
        );

    }


    const firebase =
        await control.getFirebaseModules();


    const {
        db,
        auth,
        doc,
        runTransaction,
        serverTimestamp
    } = firebase;


    const masterUser =
        auth?.currentUser;


    if (!masterUser?.uid) {

        throw new Error(
            "Master authentication is required."
        );

    }
/*
----------------------------------------
MASTER AUTHORIZATION GUARD
----------------------------------------
*/

const masterState = window.BKMaster?.state;

if (
    !masterState ||
    masterState.ready !== true ||
    masterState.authorized !== true ||
    !masterState.currentUser ||
    masterState.currentUser.uid !== masterUser.uid ||
    !masterState.masterData ||
    masterState.masterData.status !== "ACTIVE"
) {
    throw new Error(
        "Authorized ACTIVE Master session required. Bill publication blocked."
    );
}

    const restaurantId =
        String(
            billingData.restaurantId || ""
        ).trim();


    const ownerId =
        String(
            billingData.ownerId || ""
        ).trim();


    const billingMonth =
    String(
        billingData.billingMonth ||
        billingData.billingPeriod ||
        ""
    ).trim();


    if (!restaurantId) {

        throw new Error(
            "Restaurant ID is missing."
        );

    }


    if (!ownerId) {

        throw new Error(
            "Owner ID is missing."
        );

    }


    if (!billingMonth) {

        throw new Error(
            "Billing month is missing."
        );

    }
    
/*
----------------------------------------
BILL DUE DATE VALIDATION
IST CALENDAR DATE
----------------------------------------
*/

const dueDate = String(
    billingData.dueDate || ""
).trim();

if (!/^\d{4}-\d{2}-\d{2}$/.test(dueDate)) {
    throw new Error(
        "A valid bill due date is required. Use YYYY-MM-DD."
    );
}

const [dueYear, dueMonth, dueDay] =
    dueDate.split("-").map(Number);

const dueDateCheck = new Date(
    Date.UTC(dueYear, dueMonth - 1, dueDay)
);

if (
    dueDateCheck.getUTCFullYear() !== dueYear ||
    dueDateCheck.getUTCMonth() !== dueMonth - 1 ||
    dueDateCheck.getUTCDate() !== dueDay
) {
    throw new Error(
        "Invalid calendar due date."
    );
}

const todayISTDate = new Intl.DateTimeFormat(
    "en-CA",
    {
        timeZone: "Asia/Kolkata",
        year: "numeric",
        month: "2-digit",
        day: "2-digit"
    }
).format(new Date());
if (dueDate < todayISTDate) {
    throw new Error(
        "Bill due date cannot be in the past."
    );
}
    
    
    if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(billingMonth)) {

    throw new Error(
        "Invalid billing month. Use YYYY-MM with a valid month from 01 to 12."
    );

}
/*
----------------------------------------
COMPLETED BILLING MONTH GUARD
----------------------------------------
*/

// Use UTC calendar boundaries for monthly billing.
const [billingYear, billingMonthNumber] =
    billingMonth.split("-").map(Number);

const billingPeriodEnd = Date.UTC(
    billingYear,
    billingMonthNumber,
    1
);

if (Date.now() < billingPeriodEnd) {
    throw new Error(
        "Billing month is not complete. Publication blocked until the month ends."
    );
}

/*
----------------------------------------
BILLING INPUT VALIDATION
----------------------------------------
*/

if (
    !billingData ||
    typeof billingData !== "object" ||
    Array.isArray(billingData)
) {
    throw new Error(
        "Invalid billing data. Publication blocked."
    );
}

if (
    typeof billingData.estimatedCost !== "number" ||
    !Number.isFinite(billingData.estimatedCost) ||
    billingData.estimatedCost < 0 ||
    typeof billingData.masterCharge !== "number" ||
    !Number.isFinite(billingData.masterCharge) ||
    billingData.masterCharge < 0 ||
    typeof billingData.finalBill !== "number" ||
    !Number.isFinite(billingData.finalBill) ||
    billingData.finalBill < 0
) {
    throw new Error(
        "Billing amounts must be valid non-negative numbers."
    );
}

    const estimatedCost =
        Number(
            billingData.estimatedCost || 0
        );


    const masterCharge =
        Number(
            billingData.masterCharge || 0
        );


    const finalBill =
        Number(
            billingData.finalBill || 0
        );


const currency = String(
    billingData.currency ?? "INR"
).trim().toUpperCase();

if (currency !== "INR") {
    throw new Error(
        "Unsupported billing currency. Only INR is allowed."
    );
}


    if (
        !Number.isFinite(estimatedCost) ||
        estimatedCost < 0
    ) {

        throw new Error(
            "Usage cost is invalid."
        );

    }


    if (
        !Number.isFinite(masterCharge) ||
        masterCharge < 0
    ) {

        throw new Error(
            "Master margin is invalid."
        );

    }


    if (
        !Number.isFinite(finalBill) ||
        finalBill < 0
    ) {

        throw new Error(
            "Final payable bill is invalid."
        );

    }



/*
----------------------------------------
BILLING MODE & USAGE VERIFICATION GUARD
----------------------------------------
*/

const billingMode = String(
    billingData.billingMode || ""
).trim().toUpperCase();

const usageStatus = String(
    billingData.usageStatus || ""
).trim().toUpperCase();

const usageVerified = billingData.usageVerified;

if (
    billingMode !== "USAGE_BASED" &&
    billingMode !== "MASTER_MARGIN_ONLY"
) {
    throw new Error(
        "Invalid billing mode. Publication blocked."
    );
}

if (billingMode === "USAGE_BASED") {
    if (
        usageStatus !== "VERIFIED" ||
        usageVerified !== true
    ) {
        throw new Error(
            "Verified usage data is required for usage-based billing."
        );
    }
}

if (billingMode === "MASTER_MARGIN_ONLY") {
    if (
        usageStatus !== "MISSING" ||
        usageVerified !== false ||
        estimatedCost !== 0
    ) {
        throw new Error(
            "Margin-only billing requires explicitly missing usage and zero usage cost."
        );
    }
}

/*
----------------------------------------
BILLING AMOUNT CONSISTENCY GUARD
----------------------------------------
*/

const isValidMoney = (value) =>
    typeof value === "number" &&
    Number.isFinite(value) &&
    value >= 0 &&
    Number.isSafeInteger(
        Math.round(value * 100)
    ) &&
    Math.abs(
        value * 100 -
        Math.round(value * 100)
    ) < 0.000001;

if (
    !isValidMoney(estimatedCost) ||
    !isValidMoney(masterCharge) ||
    !isValidMoney(finalBill)
) {
    throw new Error(
        "Billing amounts must be non-negative, have no more than two decimal places, and remain within safe calculation limits."
    );
}

const expectedFinalBill = Number(
    (estimatedCost + masterCharge).toFixed(2)
);

if (
    !Number.isSafeInteger(
        Math.round(estimatedCost * 100)
    ) ||
    !Number.isSafeInteger(
        Math.round(masterCharge * 100)
    ) ||
    !Number.isSafeInteger(
        Math.round(finalBill * 100)
    )
) {
    throw new Error(
        "Billing amount exceeds safe calculation limits."
    );
}

if (finalBill !== expectedFinalBill) {
    throw new Error(
        "Final bill calculation mismatch."
    );
}



    /*
    ----------------------------------------
    ATOMIC CURRENT BILL CHECK
    ----------------------------------------
    */

    const billingRef = doc(
    db,
    "billingRecords",
    `${restaurantId}_${billingMonth}`
);


const noticeRef = doc(
    db,
    "notices",
    `${restaurantId}_${billingMonth}_BILL_PUBLISHED`
);


    const publishedBillingRecord =
        await runTransaction(
            db,
            async (transaction) => {

                const existingSnapshot =
                    await transaction.get(
                        billingRef
                    );
                    
                    const existingNoticeSnapshot =
    await transaction.get(
        noticeRef
    );


                if (
                    existingSnapshot.exists()
                ) {

                    const existingBilling =
                        existingSnapshot.data();

                    if (
                        existingBilling.restaurantId &&
                        existingBilling.restaurantId !==
                            restaurantId
                    ) {
                        throw new Error(
                            "Billing record restaurant mismatch."
                        );
                    }

                    if (
                        existingBilling.ownerId &&
                        existingBilling.ownerId !==
                            ownerId
                    ) {
                        throw new Error(
                            "Billing record owner mismatch."
                        );
                    }

                    const existingMonth =
                        String(
                            existingBilling.billingMonth ||
                            existingBilling.billingPeriod ||
                            ""
                        );

                    const existingStatus =
                        String(
                            existingBilling.status || ""
                        ).toUpperCase();

                    const existingPaymentStatus =
                        String(
                            existingBilling.paymentStatus || ""
                        ).toUpperCase();

                    const requestedMonth =
                        String(billingMonth);

                    const isDifferentMonth =
                        existingMonth !== requestedMonth;

                    const isPaid =
                        existingStatus === "PAID" ||
                        existingPaymentStatus === "PAID";

const unresolvedStatuses = [
    "PUBLISHED",
    "UNPAID",
    "PAYMENT_SUBMITTED",
    "VERIFICATION_PENDING",
    "REJECTED"
];

const isUnresolvedOldBill =
    unresolvedStatuses.includes(existingStatus) ||
    unresolvedStatuses.includes(existingPaymentStatus);

const allowedExistingStatuses = [
    "CALCULATED",
    "PUBLISHED",
    "UNPAID",
    "PAYMENT_SUBMITTED",
    "VERIFICATION_PENDING",
    "REJECTED",
    "PAID"
];

if (
    existingStatus &&
    !allowedExistingStatuses.includes(existingStatus)
) {
    throw new Error(
        "Unknown billing status. Manual review is required."
    );
}

if (
    existingPaymentStatus &&
    ![
        "CALCULATED",
        "UNPAID",
        "PAYMENT_SUBMITTED",
        "VERIFICATION_PENDING",
        "REJECTED",
        "PAID"
    ].includes(existingPaymentStatus)
) {
    throw new Error(
        "Unknown payment status. Manual review is required."
    );
}

if (
    existingMonth === requestedMonth &&
    (
        existingStatus === "REJECTED" ||
        existingPaymentStatus === "REJECTED" ||
        existingStatus === "VERIFICATION_PENDING" ||
        existingPaymentStatus === "VERIFICATION_PENDING"
    )
) {
    throw new Error(
        "This month's payment requires review before republishing."
    );
}


if (isDifferentMonth) {
    throw new Error(
        "An existing billing record belongs to another month. Publishing is blocked to protect billing history."
    );
}

if (
    existingMonth === requestedMonth &&
    (
        existingStatus === "CALCULATED" ||
        existingPaymentStatus === "CALCULATED"
    )
) {
    throw new Error(
        "An existing calculated bill requires review before republishing."
    );
}


                    if (
                        existingMonth === requestedMonth &&
                        isPaid
                    ) {
                        throw new Error(
                            "This month's bill is already paid. Republish blocked."
                        );
                    }

                    if (
                        existingMonth === requestedMonth &&
                        (
                            existingStatus === "PAYMENT_SUBMITTED" ||
                            existingPaymentStatus === "PAYMENT_SUBMITTED"
                        )
                    ) {
                        throw new Error(
                            "Payment has already been submitted for this month. Verify it before republishing."
                        );
                    }

                    if (
                        existingMonth === requestedMonth &&
                        (
                            existingStatus === "PUBLISHED" ||
                            existingStatus === "UNPAID" ||
                            existingPaymentStatus === "UNPAID"
                        )
                    ) {
                        throw new Error(
                            "This month's bill already exists. Duplicate publishing is blocked."
                        );
                    }
                }

                /*
                ----------------------------------------
                CREATE PUBLISHED BILL
                ----------------------------------------
                */

                const record = {
               billingId: `${restaurantId}_${billingMonth}`,
               billingSchemaVersion: 2,
restaurantId,
ownerId,
billingMonth,
dueDate,

billingMode,
usageStatus,
usageVerified,

                    billingPeriod: billingMonth,
                    baseAmount: Number(
                        estimatedCost.toFixed(2)
                    ),
                    usageAdjustment: Number(
                        masterCharge.toFixed(2)
                    ),
                    finalAmount: Number(
                        finalBill.toFixed(2)
                    ),
                    currency,
                    status: "PUBLISHED",
                    paymentStatus: "UNPAID",
                    publishedBy: masterUser.uid,
                    publishedAt: serverTimestamp(),
                    updatedAt: serverTimestamp()
                };

                transaction.set(
                    billingRef,
                    record
                );
                
if (!existingNoticeSnapshot.exists()) {

    transaction.set(
        noticeRef,
        {
            noticeId: `${restaurantId}_${billingMonth}_BILL_PUBLISHED`,
            ownerId,
            restaurantId,

            source: "BK_MASTER_BILLING",
            type: "BILL_PUBLISHED",
            priority: "NORMAL",

            title: "Monthly Bill Published",
            message: `Your ${billingMonth} monthly restaurant bill has been published. Please review your billing details.`,

            billingId: `${restaurantId}_${billingMonth}`,
            billingMonth,
            amount: Number(finalBill.toFixed(2)),
            currency,

            read: false,
            status: "UNREAD",
            createdBy: masterUser.uid,
            createdAt: serverTimestamp()
        }
    );

}
                return record;
            }
        );


    console.log(
        "BK MASTER BILLING: BILL PUBLISHED SUCCESSFULLY:",
        {
            restaurantId,
            ownerId,
            billingMonth,
            dueDate:
    publishedBillingRecord.dueDate,
            baseAmount:
                publishedBillingRecord.baseAmount,
            usageAdjustment:
                publishedBillingRecord.usageAdjustment,
            finalAmount:
                publishedBillingRecord.finalAmount,
            currency:
                publishedBillingRecord.currency,
            status:
                publishedBillingRecord.status,
            publishedBy:
                masterUser.uid
        }
    );


    return {
        ...publishedBillingRecord,
        restaurantId,
        ownerId,
        billingMonth,
        publishedBy:
            masterUser.uid
    };

}


/*
========================================================
PREMIUM PUBLISH CONFIRMATION MODAL
========================================================
*/

function openBKMasterBillingPublishModal(
    billingData,
    control,
    sourceButton
) {

    const existingModal =
        document.getElementById(
            "bkMasterBillingPublishModal"
        );


    if (existingModal) {

        existingModal.remove();

    }


    const modal =
        document.createElement("div");


    modal.id =
        "bkMasterBillingPublishModal";


    modal.className =
        "bk-master-billing-publish-modal";


    modal.innerHTML = `
        <div
            class="bk-master-billing-publish-modal-overlay"
            data-billing-publish-close="true"
        ></div>

        <div
            class="bk-master-billing-publish-modal-panel"
            role="dialog"
            aria-modal="true"
            aria-labelledby="bkMasterBillingPublishTitle"
        >

            <div
                class="bk-master-billing-publish-modal-header"
            >

                <div>

                    <span
                        class="bk-master-billing-publish-eyebrow"
                    >
                        BK MASTER BILLING
                    </span>


                    <h3
                        id="bkMasterBillingPublishTitle"
                    >
                        CONFIRM &amp; PUBLISH BILL
                    </h3>


                    <p>
                        Review the final payable amount
                        before publishing this bill.
                    </p>

                </div>


                <button
                    type="button"
                    class="bk-master-billing-publish-close"
                    data-billing-publish-close="true"
                    aria-label="Close"
                >
                    ×
                </button>

            </div>


            <div
                class="bk-master-billing-publish-period"
            >
                <span>
                    BILLING MODE
                </span>

                <strong>
                    ${control.escapeHTML(
                        billingData.billingMode === "MASTER_MARGIN_ONLY"
                            ? "MASTER MARGIN ONLY"
                            : "USAGE-BASED BILLING"
                    )}
                </strong>
            </div>

            ${
                billingData.usageVerified === false
                    ? `
                        <div
                            class="bk-master-billing-publish-period"
                            role="status"
                        >
                            <span>
                                USAGE STATUS
                            </span>

                            <strong>
                                USAGE MISSING — NOT VERIFIED
                            </strong>
                        </div>
                    `
                    : ""
            }

            <div
                class="bk-master-billing-publish-period"
            >

                <span>
                    BILLING MONTH
                </span>


                <strong>
                    ${control.escapeHTML(
                        billingData.billingMonth || "—"
                    )}
                </strong>

            </div>


            <div
                class="bk-master-billing-publish-summary"
            >

                <div
                    class="bk-master-billing-publish-summary-item"
                >

                    <span>
                        USAGE COST
                    </span>


                    <strong>
                        ${control.escapeHTML(
                            control.formatBillingAmount(
                                billingData.estimatedCost,
                                billingData.currency
                            )
                        )}
                    </strong>

                </div>


                <div
                    class="bk-master-billing-publish-summary-item"
                >

                    <span>
                        MASTER MARGIN
                    </span>


                    <strong>
                        ${control.escapeHTML(
                            control.formatBillingAmount(
                                billingData.masterCharge,
                                billingData.currency
                            )
                        )}
                    </strong>

                </div>

            </div>
<div
    class="bk-master-billing-publish-period"
>
    <label
        for="bkMasterBillingDueDate"
    >
        PAYMENT DUE DATE
    </label>

    <input
        type="date"
        id="bkMasterBillingDueDate"
        required
        min="${new Intl.DateTimeFormat("en-CA", {
            timeZone: "Asia/Kolkata",
            year: "numeric",
            month: "2-digit",
            day: "2-digit"
        }).format(new Date())}"
    />
</div>

            <div
                class="bk-master-billing-publish-total"
            >

                <span>
                    FINAL PAYABLE BILL
                </span>


                <strong>
                    ${control.escapeHTML(
                        control.formatBillingAmount(
                            billingData.finalBill,
                            billingData.currency
                        )
                    )}
                </strong>

            </div>


            <div
                class="bk-master-billing-publish-actions"
            >

                <button
                    type="button"
                    class="bk-master-billing-publish-cancel"
                    data-billing-publish-close="true"
                >
                    CANCEL
                </button>


                <button
                    type="button"
                    class="bk-master-billing-publish-confirm"
                    data-billing-publish-confirm="true"
                >
                    ✓ CONFIRM &amp; PUBLISH
                </button>

            </div>

        </div>
    `;


    document.body.appendChild(modal);


    const closeModal = () => {

        document.removeEventListener(
            "keydown",
            escapeHandler
        );


        modal.remove();


        if (sourceButton) {

            sourceButton.disabled = false;

        }

    };


    const escapeHandler =
        (event) => {

            if (event.key !== "Escape") {

                return;

            }


            closeModal();

        };


    modal.addEventListener(
        "click",
        async (event) => {

            const closeButton =
                event.target.closest(
                    '[data-billing-publish-close="true"]'
                );


            if (closeButton) {

                console.warn(
                    "BK MASTER BILLING: PUBLISH CANCELLED BY MASTER."
                );


                closeModal();

                return;

            }


            const confirmButton =
                event.target.closest(
                    '[data-billing-publish-confirm="true"]'
                );


            if (!confirmButton) {

                return;

            }


            /*
            ----------------------------------------
            PREVENT DOUBLE SUBMISSION
            ----------------------------------------
            */

            if (
                confirmButton.disabled
            ) {

                return;

            }


            confirmButton.disabled =
                true;


            confirmButton.textContent =
                "PUBLISHING BILL...";


            if (sourceButton) {

                sourceButton.disabled =
                    true;

            }


            try {
                
                /*
----------------------------------------
VALIDATE MASTER SELECTED DUE DATE
----------------------------------------
*/

const dueDateInput =
    modal.querySelector(
        "#bkMasterBillingDueDate"
    );

const dueDate =
    String(
        dueDateInput?.value || ""
    ).trim();

if (
    !/^\d{4}-\d{2}-\d{2}$/.test(dueDate)
) {
    throw new Error(
        "Please select a valid payment due date."
    );
}

const [year, month, day] =
    dueDate.split("-").map(Number);

const dateCheck = new Date(
    Date.UTC(year, month - 1, day)
);

if (
    dateCheck.getUTCFullYear() !== year ||
    dateCheck.getUTCMonth() !== month - 1 ||
    dateCheck.getUTCDate() !== day
) {
    throw new Error(
        "Selected payment due date is invalid."
    );
}

billingData.dueDate = dueDate;

                console.log(
                    "BK MASTER BILLING: PUBLISH CONFIRMATION PASSED:",
                    billingData
                );


                /*
                ----------------------------------------
                ACTUAL FIRESTORE WRITE
                ----------------------------------------
                */

                const published =
                    await publishBKMasterBillingRecord(
                        billingData,
                        control
                    );


                console.log(
                    "BK MASTER BILLING: FIRESTORE PUBLISH COMPLETE:",
                    published
                );


                /*
                ----------------------------------------
                SUCCESS
                ----------------------------------------
                */

                window.alert(
                    "Billing bill published successfully."
                );


                closeModal();


            } catch (error) {

                console.error(
                    "BK MASTER BILLING: FIRESTORE PUBLISH FAILED:",
                    error
                );


                confirmButton.disabled =
                    false;


                confirmButton.textContent =
                    "✓ CONFIRM & PUBLISH";


                if (sourceButton) {

                    sourceButton.disabled =
                        false;

                }


                window.alert(
                    error?.message ||
                    "Billing publish failed."
                );

            }

        }
    );


    document.addEventListener(
        "keydown",
        escapeHandler
    );


    console.log(
        "BK MASTER BILLING: PUBLISH MODAL OPENED:",
        billingData
    );

}


/*
========================================================
PUBLISH BUTTON BINDING
========================================================
*/

function bindBKMasterBillingPublishAction() {

    if (
        bkMasterBillingPublishActionBound
    ) {

        return;

    }


    bkMasterBillingPublishActionBound = true;


    document.addEventListener(
        "click",
        async (event) => {

            const button =
                event.target.closest(
                    '[data-billing-action="publish-bill"]'
                );


            if (!button) {

                return;

            }


            const restaurantId =
                String(
                    button.dataset.restaurantId || ""
                ).trim();


            if (!restaurantId) {

                console.error(
                    "BK MASTER BILLING: PUBLISH ACTION MISSING RESTAURANT ID."
                );

                return;

            }


            const control =
                window.BKMasterSubscriptionBillingControl;


            if (!control) {

                console.error(
                    "BK MASTER BILLING: CONTROL ENGINE NOT AVAILABLE."
                );

                return;

            }


            try {

                button.disabled =
                    true;


                const card =
                    button.closest(
                        ".bk-master-subscription-billing-card"
                    );


                if (!card) {

                    throw new Error(
                        "Billing card could not be found."
                    );

                }


const ownerId = String(
    card.dataset.ownerId || ""
).trim();

if (!ownerId) {
    throw new Error(
        "Owner ID is missing from the restaurant card. Publication blocked."
    );
}

const billingData =
    await control.loadCurrentBillingRecord(
        restaurantId,
        ownerId
    );


                /*
                ----------------------------------------
                READ CURRENT LIVE BILLING ADJUSTMENT
                ----------------------------------------
                */

                const adjustmentType =
                    card.querySelector(
                        "[data-billing-adjustment-type]"
                    );


                const adjustmentValue =
                    card.querySelector(
                        "[data-billing-adjustment-value]"
                    );


                const chargeType =
                    String(
                        adjustmentType?.value || "FIXED"
                    ).toUpperCase() === "PERCENTAGE"
                        ? "PERCENTAGE"
                        : "FIXED";


                const marginValue =
                    Math.max(
                        0,
                        Number(
                            adjustmentValue?.value || 0
                        )
                    );


                if (
                    !Number.isFinite(
                        marginValue
                    )
                ) {

                    throw new Error(
                        "Billing margin value is invalid."
                    );

                }


/*
----------------------------------------
PREPARE VERIFIED USAGE CALCULATION
----------------------------------------
*/


const now = new Date();

const previousMonthDate = new Date(
    now.getFullYear(),
    now.getMonth() - 1,
    1
);

const billingMonth = [
    previousMonthDate.getFullYear(),
    String(previousMonthDate.getMonth() + 1).padStart(2, "0")
].join("-");

if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(billingMonth)) {
    throw new Error("Valid completed billing month is required.");
}

if (
    billingData &&
    String(billingData.billingMonth || billingData.billingPeriod || "").trim() !== billingMonth
) {
    throw new Error(
        "Existing billing record belongs to a different month. Publication blocked."
    );
}

if (typeof control.prepareUsageBasedBillingPreview !== "function") {
    throw new Error(
        "Usage billing integration is unavailable. Publication blocked."
    );
}

const usagePreview =
    await control.prepareUsageBasedBillingPreview(
        restaurantId,
        billingMonth
    );

let validated;

const usageMissing =
    usagePreview?.reason === "USAGE_NOT_FOUND" ||
    usagePreview?.blockers?.includes("USAGE_NOT_FOUND") === true;
    
if (usageMissing) {
    if (chargeType !== "FIXED") {
        throw new Error(
            "Usage data is missing. Select a fixed Master margin; percentage margin requires a verified usage base."
        );
    }

    const calculation =
        control.prepareBillingCalculation(
            restaurantId,
            ownerId,
            {
                billingMonth,
                estimatedCost: 0,
                chargeType: "FIXED",
                fixedAmount: marginValue,
                percentage: 0,
                currency: "INR"
            }
        );

    validated =
        control.validateBillingPublishData(calculation);

    validated.billingMode = "MASTER_MARGIN_ONLY";
    validated.usageStatus = "MISSING";
    validated.usageVerified = false;
} else {
    if (
        !usagePreview ||
        usagePreview.success !== true ||
        usagePreview.previewOnly !== true ||
        usagePreview.published !== false
    ) {
        throw new Error(
            usagePreview?.message ||
            "Verified usage calculation unavailable. Publication blocked."
        );
    }

    if (
        typeof usagePreview.providerCost !== "number" ||
        !Number.isFinite(usagePreview.providerCost) ||
        usagePreview.providerCost < 0
    ) {
        throw new Error(
            "Verified provider cost is invalid. Publication blocked."
        );
    }

    if (
        typeof usagePreview.baseAmount !== "number" ||
        !Number.isFinite(usagePreview.baseAmount) ||
        usagePreview.baseAmount < 0
    ) {
        throw new Error(
            "Verified restaurant charge is invalid. Publication blocked."
        );
    }

    if (
        usagePreview.restaurantId !== restaurantId ||
        usagePreview.ownerId !== ownerId ||
        usagePreview.billingMonth !== billingMonth
    ) {
        throw new Error(
            "Billing identity mismatch. Publication blocked."
        );
    }

    const calculation =
        control.prepareBillingCalculation(
            restaurantId,
            ownerId,
            {
                billingMonth,
                estimatedCost: usagePreview.providerCost,
                restaurantCharge: usagePreview.baseAmount,
                chargeType,
                fixedAmount:
                    chargeType === "FIXED" ? marginValue : 0,
                percentage:
                    chargeType === "PERCENTAGE" ? marginValue : 0,
                currency: billingData?.currency || "INR"
            }
        );

    validated =
        control.validateBillingPublishData(calculation);

    validated.billingMode = "USAGE_BASED";
    validated.usageStatus = "VERIFIED";
    validated.usageVerified = true;
}

console.log(
    "BK MASTER BILLING: PREVIEW READY:",
    validated
);

openBKMasterBillingPublishModal(
    validated,
    control,
    button
);



            } catch (error) {

                console.error(
                    "BK MASTER BILLING: PUBLISH ACTION FAILED:",
                    error
                );


                button.disabled =
                    false;


                window.alert(
                    error?.message ||
                    "Billing publish action failed."
                );

            }

        }
    );


    console.log(
        "BK MASTER BILLING: PUBLISH ACTION BINDING: READY"
    );

}


bindBKMasterBillingPublishAction();
/*
========================================================
STARTUP
========================================================
*/

if (
    document.readyState ===
    "loading"
) {

    document.addEventListener(

        "DOMContentLoaded",

        () => {

            BKMasterSubscriptionBillingControl.init();

        },

        {
            once: true
        }

    );

} else {

    BKMasterSubscriptionBillingControl.init();

}

/*
========================================================
BK BILLING — USAGE ENGINE INTEGRATION
STEP 3 — SAFE CONTROLLER BRIDGE
========================================================
Read-only integration.
No Firestore writes.
No bill publication.
========================================================
*/

(function installBKUsageBillingBridge() {
    "use strict";

    const control =
        window.BKMasterSubscriptionBillingControl;

    if (!control) {
        console.error(
            "BK BILLING BRIDGE: Existing controller unavailable."
        );
        return;
    }

    control.prepareUsageBasedBillingPreview =
        async function (
            restaurantId,
            billingMonth
        ) {
            if (
                typeof window.BKUsageBillingEngine
                    ?.createFromExistingControl !== "function"
            ) {
                throw new Error(
                    "BK Usage Billing Engine is unavailable."
                );
            }

            const engine =
                window.BKUsageBillingEngine
                    .createFromExistingControl();

            const audit =
                await engine.auditMonthlyBillingReadiness(
                    restaurantId,
                    billingMonth
                );
                
                console.log(
    "BK BILLING AUDIT DIAGNOSTIC:",
    {
        success: audit?.success,
        readyForCalculation: audit?.readyForCalculation,
        blockers: audit?.blockers,
        restaurantId: audit?.restaurantId,
        billingMonth: audit?.billingMonth
    }
);

            if (!audit.success) {

return {
    success: false,
    previewOnly: true,
    billingReady: false,
    published: false,
    restaurantId: audit.restaurantId || restaurantId,
    ownerId: audit.ownerId || null,
    billingMonth: audit.billingMonth || billingMonth,
    reason: (audit.blockers || []).includes("USAGE_NOT_FOUND")
        ? "USAGE_NOT_FOUND"
        : "BILLING_READINESS_FAILED",
    blockers: audit.blockers || [],
    message:
        audit.message ||
        "Billing readiness audit failed."
};

            }

            if (!audit.readyForCalculation) {
                return {
                    success: false,
                    previewOnly: true,
                    billingReady: false,
                    published: false,
                    restaurantId: audit.restaurantId,
                    ownerId: audit.ownerId,
                    billingMonth: audit.billingMonth,
                    blockers: audit.blockers,
                    message:
                        "Calculation blocked. Configure pricing and resolve usage mapping issues."
                };
            }

            return {
                success: true,
                previewOnly: true,
                billingReady: false,
                published: false,

                restaurantId: audit.restaurantId,
                ownerId: audit.ownerId,
                billingMonth: audit.billingMonth,

                providerCost: audit.providerCost,
                baseAmount: audit.restaurantCharge,

                pricingVersion: audit.pricingVersion,
                pricingRevision: audit.pricingRevision,

                message:
                    "Usage-based preview prepared. Manual approval and the existing publish validation are still required."
            };
        };

    console.log(
        "BK BILLING BRIDGE: INSTALLED"
    );
})();