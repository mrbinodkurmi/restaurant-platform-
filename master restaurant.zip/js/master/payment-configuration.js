/*
========================================================
BK MASTER — PAYMENT CONFIGURATION ENGINE
Version: 1.0.1
Purpose:
- Master payment configuration foundation
- QR configuration metadata
- Payment identifier
- Payment instructions
- Active / Inactive status
- Save / Update foundation
- Master authorization wait

NOTE:
Actual Firebase Storage QR upload will be connected
in a later controlled step.
========================================================
*/

import {
  masterAuth as auth,
  masterDb as db
} from "../firebase-sessions.js";

import {
  collection,
  doc,
  getDocs,
  setDoc,
  updateDoc,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";


/* ======================================================
   GLOBAL OBJECT
====================================================== */

window.BKMasterPaymentConfiguration = (() => {

  const COLLECTION_NAME = "paymentConfigurations";

  const CONFIGURATION_ID = "MAIN";


  /* ====================================================
     STATE
  ==================================================== */

  const state = {

    initialized: false,

    ready: false,

    loading: false,

    saving: false,

    configuration: null,

    error: null

  };


  /* ====================================================
     LOGGING
  ==================================================== */

  function log(...args) {

    console.log(
      "BK MASTER PAYMENT CONFIG:",
      ...args
    );

  }


  function warn(...args) {

    console.warn(
      "BK MASTER PAYMENT CONFIG:",
      ...args
    );

  }


  function errorLog(...args) {

    console.error(
      "BK MASTER PAYMENT CONFIG:",
      ...args
    );

  }


  /* ====================================================
     MASTER AUTHORIZATION
  ==================================================== */

  async function verifyMasterAccess() {

    try {

      if (!auth.currentUser) {

        throw new Error(
          "Master user is not authenticated."
        );

      }


      if (
        !window.BKMaster ||
        window.BKMaster.state?.authorized !== true
      ) {

        throw new Error(
          "Master authorization is not ready."
        );

      }


      return true;

    } catch (err) {

      errorLog(
        "MASTER ACCESS CHECK FAILED:",
        err
      );

      state.error = err;

      return false;
    }

  }


  /* ====================================================
     MASTER AUTHORIZATION WAIT
  ==================================================== */

  async function waitForMasterAuthorization(
    timeout = 30000,
    interval = 300
  ) {

    const startedAt = Date.now();


    log(
      "WAITING FOR MASTER AUTHORIZATION..."
    );


    while (
      Date.now() - startedAt < timeout
    ) {

      if (
        auth.currentUser &&
        window.BKMaster &&
        window.BKMaster.state?.authorized === true
      ) {

        log(
          "MASTER AUTHORIZATION DETECTED"
        );

        return true;
      }


      await new Promise(
        (resolve) => {
          setTimeout(resolve, interval);
        }
      );

    }


    warn(
      "MASTER AUTHORIZATION WAIT TIMEOUT."
    );


    return false;

  }


  /* ====================================================
     LOAD CONFIGURATION
  ==================================================== */

  async function loadConfiguration() {

    if (state.loading) {

      return state.configuration;

    }


    state.loading = true;

    state.error = null;


    try {

      const authorized =
        await verifyMasterAccess();


      if (!authorized) {

        throw new Error(
          "Master authorization failed."
        );

      }


      log(
        "LOADING PAYMENT CONFIGURATION..."
      );


      const snapshot = await getDocs(
        collection(
          db,
          COLLECTION_NAME
        )
      );


      let configuration = null;


      snapshot.forEach(
        (docSnap) => {

          if (
            docSnap.id === CONFIGURATION_ID
          ) {

            configuration = {

              ...docSnap.data(),

              configId: docSnap.id

            };

          }

        }
      );


state.configuration =
  configuration;


if (configuration) {

  log(
    "PAYMENT CONFIGURATION LOADED:",
    configuration.configId
  );


  /* ----------------------------------------------
     POPULATE PAYMENT CONFIGURATION UI
  ---------------------------------------------- */

  const paymentIdentifierField =
    document.getElementById(
      "bkMasterPaymentIdentifier"
    );


  const payeeNameField =
    document.getElementById(
      "bkMasterPaymentPayeeName"
    );


  const paymentUriField =
    document.getElementById(
      "bkMasterPaymentUri"
    );


  const instructionsField =
    document.getElementById(
      "bkMasterPaymentInstructions"
    );


  const statusField =
    document.getElementById(
      "bkMasterPaymentStatus"
    );


  if (paymentIdentifierField) {

    paymentIdentifierField.value =
      configuration.paymentIdentifier || "";

  }


  if (payeeNameField) {

    payeeNameField.value =
      configuration.payeeName || "";

  }


  if (paymentUriField) {

    paymentUriField.value =
      configuration.paymentUri || "";

  }


  if (instructionsField) {

    instructionsField.value =
      configuration.instructions || "";

  }


  if (statusField) {

    statusField.value =
      configuration.status || "ACTIVE";

  }


} else {

  log(
    "NO PAYMENT CONFIGURATION FOUND YET."
  );

}

      state.ready = true;


      return configuration;


    } catch (err) {

      state.error = err;


      errorLog(
        "PAYMENT CONFIGURATION LOAD FAILED:",
        err
      );


      return null;


    } finally {

      state.loading = false;

    }

  }


  /* ====================================================
     CREATE CONFIGURATION
  ==================================================== */

  async function createConfiguration(
    data = {}
  ) {

    if (state.saving) {

      return {

        success: false,

        error:
          new Error(
            "Another payment configuration operation is already running."
          )

      };

    }


    state.saving = true;

    state.error = null;


    try {

      const authorized =
        await verifyMasterAccess();


      if (!authorized) {

        throw new Error(
          "Master authorization is not ready."
        );

      }


      const paymentIdentifier =
        String(
          data.paymentIdentifier || ""
        ).trim();


      const instructions =
        String(
          data.instructions || ""
        ).trim();


      const status =
        String(
          data.status || "ACTIVE"
        )
          .trim()
          .toUpperCase();


      if (!paymentIdentifier) {

        throw new Error(
          "Payment identifier is required."
        );

      }


      if (
        status !== "ACTIVE" &&
        status !== "INACTIVE"
      ) {

        throw new Error(
          "Payment configuration status must be ACTIVE or INACTIVE."
        );

      }

const payeeName =
  String(
    data.payeeName || ""
  ).trim();


if (!payeeName) {

  throw new Error(
    "Payee name is required."
  );

}


const paymentUri =
  String(
    data.paymentUri || ""
  ).trim();


const configuration = {

  configId:
    CONFIGURATION_ID,

  paymentIdentifier,

  payeeName,

  paymentUri,

  instructions,

  status,

  createdAt:
    serverTimestamp(),

  updatedAt:
    serverTimestamp(),

  updatedBy:
    auth.currentUser.uid

};

      const configRef =
        doc(
          db,
          COLLECTION_NAME,
          CONFIGURATION_ID
        );


      await setDoc(
        configRef,
        configuration
      );


      log(
        "PAYMENT CONFIGURATION CREATED:",
        CONFIGURATION_ID
      );


      await loadConfiguration();


      return {

        success: true,

        configId:
          CONFIGURATION_ID

      };


    } catch (err) {

      state.error = err;


      errorLog(
        "PAYMENT CONFIGURATION CREATE FAILED:",
        err
      );


      return {

        success: false,

        error: err

      };


    } finally {

      state.saving = false;

    }

  }


  /* ====================================================
     UPDATE CONFIGURATION
  ==================================================== */

  async function updateConfiguration(
    data = {}
  ) {

    if (state.saving) {

      return {

        success: false,

        error:
          new Error(
            "Another payment configuration operation is already running."
          )

      };

    }


    state.saving = true;

    state.error = null;


    try {

      const authorized =
        await verifyMasterAccess();


      if (!authorized) {

        throw new Error(
          "Master authorization is not ready."
        );

      }


      const updates = {};


/* ----------------------------------------------
   PAYMENT IDENTIFIER
---------------------------------------------- */

if (
  data.paymentIdentifier !== undefined
) {

  const paymentIdentifier =
    String(
      data.paymentIdentifier || ""
    ).trim();


  if (!paymentIdentifier) {

    throw new Error(
      "Payment identifier cannot be empty."
    );

  }


  updates.paymentIdentifier =
    paymentIdentifier;

}


/* ----------------------------------------------
   PAYEE NAME
---------------------------------------------- */

if (
  data.payeeName !== undefined
) {

  const payeeName =
    String(
      data.payeeName || ""
    ).trim();


  if (!payeeName) {

    throw new Error(
      "Payee name cannot be empty."
    );

  }


  updates.payeeName =
    payeeName;

}


/* ----------------------------------------------
   PAYMENT URI
---------------------------------------------- */

if (
  data.paymentUri !== undefined
) {

  updates.paymentUri =
    String(
      data.paymentUri || ""
    ).trim();

}


/* ----------------------------------------------
   INSTRUCTIONS
---------------------------------------------- */

if (
  data.instructions !== undefined
) {

  updates.instructions =
    String(
      data.instructions || ""
    ).trim();

}

      /* ----------------------------------------------
         STATUS
      ---------------------------------------------- */

      if (
        data.status !== undefined
      ) {

        const status =
          String(
            data.status || ""
          )
            .trim()
            .toUpperCase();


        if (
          status !== "ACTIVE" &&
          status !== "INACTIVE"
        ) {

          throw new Error(
            "Payment configuration status must be ACTIVE or INACTIVE."
          );

        }


        updates.status =
          status;

      }


      /* ----------------------------------------------
         AUDIT FIELDS
      ---------------------------------------------- */

      updates.updatedAt =
        serverTimestamp();


      updates.updatedBy =
        auth.currentUser.uid;


      const configRef =
        doc(
          db,
          COLLECTION_NAME,
          CONFIGURATION_ID
        );


      await updateDoc(
        configRef,
        updates
      );


      log(
        "PAYMENT CONFIGURATION UPDATED:",
        CONFIGURATION_ID
      );


      await loadConfiguration();


      return {

        success: true,

        configId:
          CONFIGURATION_ID

      };


    } catch (err) {

      state.error =
        err;


      errorLog(
        "PAYMENT CONFIGURATION UPDATE FAILED:",
        err
      );


      return {

        success: false,

        error: err

      };


    } finally {

      state.saving =
        false;

    }

  }


  /* ====================================================
     SET STATUS
  ==================================================== */

  async function setStatus(
    status
  ) {

    const normalizedStatus =
      String(
        status || ""
      )
        .trim()
        .toUpperCase();


    if (
      normalizedStatus !== "ACTIVE" &&
      normalizedStatus !== "INACTIVE"
    ) {

      return {

        success: false,

        error:
          new Error(
            "Status must be ACTIVE or INACTIVE."
          )

      };

    }


    return await updateConfiguration({

      status:
        normalizedStatus

    });

  }

function bindConfigurationForm() {
  const form = document.getElementById("bkMasterPaymentConfigurationForm");
  const message = document.getElementById("bkMasterPaymentConfigurationMessage");

  if (!form) {
    warn("PAYMENT CONFIGURATION FORM NOT FOUND.");
    return;
  }

  form.addEventListener("submit", async (event) => {
    event.preventDefault();

    try {
      const data = {
        paymentIdentifier:
          document.getElementById("bkMasterPaymentIdentifier")?.value.trim(),

        payeeName:
          document.getElementById("bkMasterPaymentPayeeName")?.value.trim(),

        paymentUri:
          document.getElementById("bkMasterPaymentUri")?.value.trim(),

        instructions:
          document.getElementById("bkMasterPaymentInstructions")?.value.trim(),

        status:
          document.getElementById("bkMasterPaymentStatus")?.value || "ACTIVE"
      };

      const isUpdate = Boolean(state.configuration);

      const result = isUpdate
        ? await updateConfiguration(data)
        : await createConfiguration(data);

      if (!result?.success) {
        throw result?.error || new Error("Payment configuration save failed.");
      }

      if (message) {
        message.textContent = isUpdate
          ? "Payment configuration updated successfully."
          : "Payment configuration saved successfully.";
      }

      log("PAYMENT CONFIGURATION FORM SAVE: SUCCESS");

    } catch (err) {
      if (message) {
        message.textContent =
          err?.message || "Unable to save payment configuration.";
      }

      errorLog("PAYMENT CONFIGURATION FORM SAVE FAILED:", err);
    }
  });
  
    const resetButton = document.getElementById(
    "bkMasterPaymentConfigurationReset"
  );

  if (resetButton) {

    resetButton.addEventListener("click", async () => {

      try {

        await loadConfiguration();

        const message =
          document.getElementById(
            "bkMasterPaymentConfigurationMessage"
          );

        if (message) {
          message.textContent =
            "Payment configuration reset to the saved values.";
        }

        log("PAYMENT CONFIGURATION RESET: SUCCESS");

      } catch (err) {

        const message =
          document.getElementById(
            "bkMasterPaymentConfigurationMessage"
          );

        if (message) {
          message.textContent =
            err?.message ||
            "Unable to reset payment configuration.";
        }

        errorLog(
          "PAYMENT CONFIGURATION RESET FAILED:",
          err
        );

      }

    });

    log("PAYMENT CONFIGURATION RESET HANDLER: READY");

  } else {

    warn(
      "PAYMENT CONFIGURATION RESET BUTTON NOT FOUND."
    );

  }

  log("PAYMENT CONFIGURATION FORM HANDLER: READY");
}
  /* ====================================================
     INITIALIZE
  ==================================================== */

  async function init() {

    if (state.initialized) {

      return state;

    }


    state.initialized = true;

    state.error = null;


    log(
      "INITIALIZING..."
    );


    const authorized =
      await verifyMasterAccess();


    if (!authorized) {

      warn(
        "MASTER AUTHORIZATION IS NOT READY."
      );


      return state;

    }


    await loadConfiguration();
    
bindConfigurationForm();

state.ready = true;


    log(
      "PAYMENT CONFIGURATION ENGINE: READY"
    );


    log(
      "COLLECTION:",
      COLLECTION_NAME
    );


    log(
      "CONFIGURATION ID:",
      CONFIGURATION_ID
    );


    return state;

  }


  /* ====================================================
     PUBLIC API
  ==================================================== */

  return {

    state,

    init,

    waitForMasterAuthorization,

    loadConfiguration,

    createConfiguration,

    updateConfiguration,

    setStatus

  };

})();


/* ======================================================
   AUTO START
====================================================== */

(async () => {

  try {

    const authorized =
      await window.BKMasterPaymentConfiguration
        .waitForMasterAuthorization();


    if (!authorized) {

      console.warn(
        "BK MASTER PAYMENT CONFIG: AUTHORIZATION NOT READY."
      );

      return;

    }


    await window.BKMasterPaymentConfiguration
      .init();


  } catch (err) {

    console.error(
      "BK MASTER PAYMENT CONFIG: AUTO START FAILED:",
      err
    );

  }

})();