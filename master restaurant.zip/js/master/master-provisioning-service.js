
"use strict";

import { db } from "../firebase.js";

import {
    doc,
    getDoc
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";


/*
 * ==========================================
 * BK MASTER PROVISIONING CONFIGURATION
 * ==========================================
 */

const PROVISIONING_PROVIDER = "SPARK_MANUAL";

const AUTHORITY_COLLECTION = "systemConfig";
const AUTHORITY_DOCUMENT = "masterAuthority";


/*
 * ==========================================
 * SPARK MANUAL PROVISIONING ADAPTER
 * ==========================================
 *
 * Firebase Auth creation:
 * Firebase Console only.
 *
 * Master authorization:
 * Trusted manual approval only.
 *
 * Public browser:
 * Read-only authority verification.
 *
 * No Firestore writes.
 * No Auth account creation.
 */


const SparkManualAdapter = {

    /*
     * --------------------------------------
     * CHECK MASTER AUTHORITY
     * --------------------------------------
     */

    async checkAuthority() {

        try {

            const reference = doc(
                db,
                AUTHORITY_COLLECTION,
                AUTHORITY_DOCUMENT
            );

            const snapshot = await getDoc(reference);


            if (!snapshot.exists()) {

                return {
                    verified: false,
                    status: "NOT_FOUND",
                    canProvision: false,
                    reason:
                        "Master authority document does not exist."
                };
            }


            const authority = snapshot.data();


            const isActive =
                authority.exists === true &&
                authority.status === "ACTIVE";


            const isInactive =
                authority.exists === false &&
                authority.status === "INACTIVE";


            if (isActive) {

                return {
                    verified: true,
                    status: "ACTIVE",
                    canProvision: false,
                    reason:
                        "An active Master authority already exists."
                };
            }


            if (isInactive) {

                return {
                    verified: true,
                    status: "INACTIVE",
                    canProvision: true,
                    reason:
                        "Master provisioning is permitted."
                };
            }


            return {
                verified: false,
                status: "INCONSISTENT",
                canProvision: false,
                reason:
                    "Master authority data is inconsistent."
            };

        } catch (error) {

            console.error(
                "[BK MASTER PROVISIONING] Authority check failed:",
                error
            );

            return {
                verified: false,
                status: "ERROR",
                canProvision: false,
                reason:
                    "Master authority verification failed."
            };
        }
    },


    /*
     * --------------------------------------
     * MANUAL PROVISIONING INSTRUCTIONS
     * --------------------------------------
     */

    getInstructions() {

        return {

            provider: "SPARK_MANUAL",

            accountCreation: "FIREBASE_CONSOLE",

            authorization: "TRUSTED_MANUAL_APPROVAL",

            automaticProvisioning: false,

            firestoreWritesFromBrowser: false,

            steps: [

                {
                    number: 1,

                    title: "Verify Previous Master Status",

                    description:
                        "Confirm that the previous Master has been properly retired under an approved account-rotation plan. Verify the Firebase Authentication account and corresponding masterAdmins document separately. Never delete the current working Master merely to test provisioning."
                },

                {
                    number: 2,

                    title: "Create Firebase Authentication Account",

                    description:
                        "Open Firebase Console, select the correct Firebase project, go to Authentication and create the new Master email and password account."
                },

                {
                    number: 3,

                    title: "Record the New Master UID",

                    description:
                        "Copy the exact UID generated for the new Firebase Authentication account."
                },

                {
                    number: 4,

                    title: "Authorize the New Master",

                    description:
                        "Using trusted administrative access, create masterAdmins/{UID} with the exact new UID as the document ID and set status to ACTIVE."
                },

                {
                    number: 5,

                    title: "Activate Master Authority",

                    description:
                        "After verifying the new Master authorization, update systemConfig/masterAuthority to exists: true and status: ACTIVE using trusted administrative access."
                },

                {
                    number: 6,

                    title: "Verify Master Login",

                    description:
                        "Open the BK Master Login page and verify that the new account successfully receives Master authorization."
                }

            ]
        };
    },


    /*
     * --------------------------------------
     * BEGIN PROVISIONING
     * --------------------------------------
     */

    async beginProvisioning() {

        const authority =
            await this.checkAuthority();


        if (!authority.verified) {

            return {
                allowed: false,
                status: authority.status,
                reason:
                    authority.reason ||
                    "Master authority could not be verified.",
                instructions: null
            };
        }


        if (
            authority.status !== "INACTIVE" ||
            authority.canProvision !== true
        ) {

            return {
                allowed: false,
                status: authority.status,
                reason:
                    "A Master account already exists or provisioning is not permitted.",
                instructions: null
            };
        }


        return {
            allowed: true,
            status: "INACTIVE",
            mode: "MANUAL",
            reason:
                "Master provisioning is permitted through the trusted manual process.",
            instructions: this.getInstructions()
        };
    }

};


/*
 * ==========================================
 * FUTURE CLOUD PROVISIONING ADAPTER
 * ==========================================
 *
 * Placeholder only.
 * No Cloud Function is deployed.
 */


const CloudProvisioningAdapter = {

    async checkAuthority() {

        throw new Error(
            "BK CLOUD PROVISIONING IS NOT CONFIGURED."
        );
    },


    async beginProvisioning() {

        throw new Error(
            "BK CLOUD PROVISIONING IS NOT ACTIVE."
        );
    },


    getInstructions() {

        throw new Error(
            "BK CLOUD PROVISIONING INSTRUCTIONS ARE NOT AVAILABLE."
        );
    }

};


/*
 * ==========================================
 * PROVIDER SELECTOR
 * ==========================================
 */


function getAdapter() {

    switch (PROVISIONING_PROVIDER) {

        case "SPARK_MANUAL":

            return SparkManualAdapter;


        case "CLOUD_FUNCTIONS":

            return CloudProvisioningAdapter;


        default:

            throw new Error(
                "UNKNOWN MASTER PROVISIONING PROVIDER."
            );
    }

}


const adapter = getAdapter();


/*
 * ==========================================
 * CENTRAL BK MASTER PROVISIONING SERVICE
 * ==========================================
 */


const BKMasterProvisioningService = {

    async checkAuthority() {

        return await adapter.checkAuthority();
    },


    async beginProvisioning() {

        return await adapter.beginProvisioning();
    },


    getInstructions() {

        return adapter.getInstructions();
    },


    getProvider() {

        return PROVISIONING_PROVIDER;
    }

};


/*
 * ==========================================
 * GLOBAL SERVICE REGISTRATION
 * ==========================================
 */


window.BKMasterProvisioningService =
    BKMasterProvisioningService;


export {
    BKMasterProvisioningService
};
