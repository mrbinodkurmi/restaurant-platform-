/* ============================================================
   BK RESTAURANT PLATFORM
   MASTER CONTROL
   RESTAURANT CONTROL ENGINE
   Version: 1.0.0
============================================================ */

"use strict";


const BKMasterRestaurantControl = {

    /* ========================================================
       ENGINE STATE
    ======================================================== */

    state: {

        initialized: false,

        ready: false,

        selectedRestaurantId: null,

        selectedRestaurantStatus: null

    },


    /* ========================================================
       RESTAURANT STATUS DEFINITIONS
    ======================================================== */

    STATUS: {

        ACTIVE:
            "ACTIVE",

        INACTIVE:
            "INACTIVE",

        SUSPENDED:
            "SUSPENDED",

        BLOCKED:
            "BLOCKED"

    },


    /* ========================================================
       MASTER ACTION DEFINITIONS
    ======================================================== */

    ACTIONS: {

        ACTIVATE:
            "ACTIVATE",

        DEACTIVATE:
            "DEACTIVATE",

        SUSPEND:
            "SUSPEND",

        BLOCK:
            "BLOCK",

        DELETE:
            "DELETE"

    },


    /* ========================================================
       INITIALIZATION
    ======================================================== */

    init() {

        console.log(
            "=========================================="
        );

        console.log(
            "BK RESTAURANT CONTROL: INITIALIZING"
        );

        console.log(
            "=========================================="
        );


        this.state.initialized =
            true;


        this.state.ready =
            true;


        console.log(
            "BK RESTAURANT CONTROL: READY"
        );

    },


    /* ========================================================
       STATUS NORMALIZER
    ======================================================== */

    normalizeStatus(
        status
    ) {

        if (
            status === undefined ||
            status === null
        ) {

            return this.STATUS.INACTIVE;

        }


        const normalized =
            String(
                status
            )
            .trim()
            .toUpperCase();


        if (
            normalized ===
            this.STATUS.ACTIVE
        ) {

            return this.STATUS.ACTIVE;

        }


        if (
            normalized ===
            this.STATUS.INACTIVE
        ) {

            return this.STATUS.INACTIVE;

        }


        if (
            normalized ===
            this.STATUS.SUSPENDED
        ) {

            return this.STATUS.SUSPENDED;

        }


        if (
            normalized ===
            this.STATUS.BLOCKED
        ) {

            return this.STATUS.BLOCKED;

        }


        /*
           Unknown / old restaurant status
           is safely treated as INACTIVE
           for control purposes.
        */

        return this.STATUS.INACTIVE;

    },


    /* ========================================================
       VALID STATUS CHECK
    ======================================================== */

    isValidStatus(
        status
    ) {

        const normalized =
            this.normalizeStatus(
                status
            );


        return (

            normalized ===
            this.STATUS.ACTIVE

            ||

            normalized ===
            this.STATUS.INACTIVE

            ||

            normalized ===
            this.STATUS.SUSPENDED

            ||

            normalized ===
            this.STATUS.BLOCKED

        );

    },


    /* ========================================================
       STATUS → AVAILABLE MASTER ACTIONS
    ======================================================== */

    getAvailableActions(
        status
    ) {

        const normalized =
            this.normalizeStatus(
                status
            );


        switch (
            normalized
        ) {

            case this.STATUS.ACTIVE:

                return [

                    this.ACTIONS.DEACTIVATE,

                    this.ACTIONS.SUSPEND,

                    this.ACTIONS.BLOCK,

                    this.ACTIONS.DELETE

                ];


            case this.STATUS.INACTIVE:

                return [

                    this.ACTIONS.ACTIVATE,

                    this.ACTIONS.SUSPEND,

                    this.ACTIONS.BLOCK,

                    this.ACTIONS.DELETE

                ];


            case this.STATUS.SUSPENDED:

                return [

                    this.ACTIONS.ACTIVATE,

                    this.ACTIONS.DEACTIVATE,

                    this.ACTIONS.BLOCK,

                    this.ACTIONS.DELETE

                ];


            case this.STATUS.BLOCKED:

                return [

                    this.ACTIONS.ACTIVATE,

                    this.ACTIONS.DEACTIVATE,

                    this.ACTIONS.DELETE

                ];


            default:

                return [

                    this.ACTIONS.ACTIVATE,

                    this.ACTIONS.DELETE

                ];

        }

    },


    /* ========================================================
       ACTION → TARGET STATUS
    ======================================================== */

    getTargetStatus(
        action
    ) {

        const normalizedAction =
            String(
                action || ""
            )
            .trim()
            .toUpperCase();


        switch (
            normalizedAction
        ) {

            case this.ACTIONS.ACTIVATE:

                return this.STATUS.ACTIVE;


            case this.ACTIONS.DEACTIVATE:

                return this.STATUS.INACTIVE;


            case this.ACTIONS.SUSPEND:

                return this.STATUS.SUSPENDED;


            case this.ACTIONS.BLOCK:

                return this.STATUS.BLOCKED;


            case this.ACTIONS.DELETE:

                /*
                   DELETE is NOT a normal status.

                   It will later use a protected
                   destructive workflow.
                */

                return null;


            default:

                return null;

        }

    },


    /* ========================================================
       ACTION VALIDATION
    ======================================================== */

    canPerformAction(
        currentStatus,
        action
    ) {

        const normalizedStatus =
            this.normalizeStatus(
                currentStatus
            );


        const normalizedAction =
            String(
                action || ""
            )
            .trim()
            .toUpperCase();


        const availableActions =
            this.getAvailableActions(
                normalizedStatus
            );


        return availableActions.includes(
            normalizedAction
        );

    },


    /* ========================================================
       SELECT RESTAURANT
    ======================================================== */

    selectRestaurant(
        restaurantId,
        status
    ) {

        if (
            !restaurantId
        ) {

            console.warn(
                "BK RESTAURANT CONTROL: Restaurant ID missing."
            );

            return false;

        }


        this.state.selectedRestaurantId =
            restaurantId;


        this.state.selectedRestaurantStatus =
            this.normalizeStatus(
                status
            );


        console.log(
            "BK RESTAURANT CONTROL: Restaurant selected:",
            restaurantId
        );


        console.log(
            "BK RESTAURANT CONTROL: Current status:",
            this.state.selectedRestaurantStatus
        );


        return true;

    },


    /* ========================================================
       GET CURRENT SELECTED RESTAURANT
    ======================================================== */

    getSelectedRestaurant() {

        return {

            restaurantId:
                this.state.selectedRestaurantId,

            status:
                this.state.selectedRestaurantStatus

        };

    },


    /* ========================================================
       RESET SELECTION
    ======================================================== */

    clearSelection() {

        this.state.selectedRestaurantId =
            null;


        this.state.selectedRestaurantStatus =
            null;


        console.log(
            "BK RESTAURANT CONTROL: Selection cleared."
        );

    },


    /* ========================================================
       ENGINE READY CHECK
    ======================================================== */

    isReady() {

        return (
            this.state.ready === true
        );

    }

};


/* ============================================================
   GLOBAL ACCESS
============================================================ */

window.BKMasterRestaurantControl =
    BKMasterRestaurantControl;


/* ============================================================
   START ENGINE
============================================================ */

if (
    document.readyState === "loading"
) {

    document.addEventListener(
        "DOMContentLoaded",
        () => {

            BKMasterRestaurantControl.init();

        }
    );

} else {

    BKMasterRestaurantControl.init();

}
/* ============================================================
   BK RESTAURANT CONTROL
   PART 2 — SAFE FIRESTORE STATUS ACTION ENGINE
============================================================ */


/* ============================================================
   PERFORM RESTAURANT ACTION
============================================================ */

BKMasterRestaurantControl.performAction =
    async function (
        restaurantId,
        action,
        reason
    ) {

        console.log(
            "BK RESTAURANT CONTROL: Action requested:",
            action,
            restaurantId
        );


        /* =====================================================
           BASIC VALIDATION
        ===================================================== */

        if (
            !restaurantId
        ) {

            console.warn(
                "BK RESTAURANT CONTROL: Restaurant ID missing."
            );

            return {

                success: false,

                error:
                    "Restaurant ID is required."

            };

        }


        if (
            !action
        ) {

            console.warn(
                "BK RESTAURANT CONTROL: Action missing."
            );

            return {

                success: false,

                error:
                    "Action is required."

            };

        }


        /* =====================================================
           REASON REQUIRED
        ===================================================== */

        if (
            !reason ||
            String(
                reason
            ).trim() === ""
        ) {

            console.warn(
                "BK RESTAURANT CONTROL: Action reason required."
            );

            return {

                success: false,

                error:
                    "A reason is required."

            };

        }


        const cleanReason =
            String(
                reason
            ).trim();


        /* =====================================================
           NORMALIZE ACTION
        ===================================================== */

        const normalizedAction =
            String(
                action
            )
            .trim()
            .toUpperCase();


        /* =====================================================
           DELETE PROTECTION
        ===================================================== */

        if (
            normalizedAction ===
            this.ACTIONS.DELETE
        ) {

            console.warn(
                "BK RESTAURANT CONTROL: DELETE requires protected workflow."
            );

            return {

                success: false,

                error:
                    "Delete action is locked for the protected deletion workflow."

            };

        }


        /* =====================================================
           MASTER AUTH CHECK
        ===================================================== */

        if (
            !window.BKMaster ||
            !window.BKMaster.state ||
            window.BKMaster.state.authorized !== true
        ) {

            console.warn(
                "BK RESTAURANT CONTROL: Master authorization unavailable."
            );

            return {

                success: false,

                error:
                    "Master authorization is required."

            };

        }


        try {

            /* =================================================
               LOAD FIREBASE
            ================================================= */

            const firebaseCore =
    await import(
        "../firebase-sessions.js"
    );

            const firestore =
                await import(
                    "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js"
                );


const db =
    firebaseCore.masterDb;

            const {
                doc,
                getDoc,
                updateDoc
            } = firestore;


            /* =================================================
               RESTAURANT REFERENCE
            ================================================= */

            const restaurantRef =
                doc(
                    db,
                    "restaurants",
                    restaurantId
                );


            /* =================================================
               READ CURRENT RESTAURANT
            ================================================= */

            const restaurantSnapshot =
                await getDoc(
                    restaurantRef
                );


            if (
                !restaurantSnapshot.exists()
            ) {

                console.warn(
                    "BK RESTAURANT CONTROL: Restaurant not found:",
                    restaurantId
                );

                return {

                    success: false,

                    error:
                        "Restaurant not found."

                };

            }


            const restaurantData =
                restaurantSnapshot.data();


            /* =================================================
               CURRENT STATUS
            ================================================= */

            const currentStatus =
                this.normalizeStatus(
                    restaurantData.status
                );


            /* =================================================
               ACTION VALIDATION
            ================================================= */

            if (
                !this.canPerformAction(
                    currentStatus,
                    normalizedAction
                )
            ) {

                console.warn(
                    "BK RESTAURANT CONTROL: Action not allowed:",
                    currentStatus,
                    normalizedAction
                );

                return {

                    success: false,

                    error:
                        `Action ${normalizedAction} is not allowed from ${currentStatus}.`

                };

            }


            /* =================================================
               TARGET STATUS
            ================================================= */

            const targetStatus =
                this.getTargetStatus(
                    normalizedAction
                );


            if (
                !targetStatus
            ) {

                console.warn(
                    "BK RESTAURANT CONTROL: Target status unavailable."
                );

                return {

                    success: false,

                    error:
                        "Target status could not be determined."

                };

            }


            /* =================================================
               UPDATE FIRESTORE
            ================================================= */

            await updateDoc(
                restaurantRef,
                {

                    status:
                        targetStatus,

                    lastMasterAction:
                        normalizedAction,

                    lastMasterActionReason:
                        cleanReason

                }
            );


            /* =================================================
               UPDATE LOCAL ENGINE STATE
            ================================================= */

            this.state.selectedRestaurantId =
                restaurantId;


            this.state.selectedRestaurantStatus =
                targetStatus;


            /* =================================================
               SUCCESS
            ================================================= */

            console.log(
                "BK RESTAURANT CONTROL: Status updated successfully."
            );


            console.log(
                "BK RESTAURANT CONTROL: Previous status:",
                currentStatus
            );


            console.log(
                "BK RESTAURANT CONTROL: New status:",
                targetStatus
            );


            console.log(
                "BK RESTAURANT CONTROL: Reason:",
                cleanReason
            );


            return {

                success: true,

                restaurantId:
                    restaurantId,

                action:
                    normalizedAction,

                previousStatus:
                    currentStatus,

                newStatus:
                    targetStatus,

                reason:
                    cleanReason

            };


        } catch (error) {

            console.error(
                "BK RESTAURANT CONTROL: Status action failed:",
                error
            );


            return {

                success: false,

                error:
                    error.message ||
                    "Restaurant status update failed."

            };

        }

    };


/* ============================================================
   PART 2 READY
============================================================ */

console.log(
    "BK RESTAURANT CONTROL: Action engine loaded."
);

/* ============================================================
   BK RESTAURANT CONTROL
   PART 3 — CONTROLLED ACTION WORKFLOW
   Preview + Validation Layer
============================================================ */


/* ============================================================
   PREPARE ACTION
============================================================ */

BKMasterRestaurantControl.prepareAction =
    async function (
        restaurantId,
        action,
        reason
    ) {

        console.log(
            "BK RESTAURANT CONTROL: Preparing action..."
        );


        /* =====================================================
           BASIC VALIDATION
        ===================================================== */

        if (
            !restaurantId
        ) {

            return {

                success: false,

                error:
                    "Restaurant ID is required."

            };

        }


        if (
            !action
        ) {

            return {

                success: false,

                error:
                    "Action is required."

            };

        }


        if (
            !reason ||
            String(
                reason
            ).trim() === ""
        ) {

            return {

                success: false,

                error:
                    "Action reason is required."

            };

        }


        const normalizedAction =
            String(
                action
            )
            .trim()
            .toUpperCase();


        const cleanReason =
            String(
                reason
            ).trim();


        /* =====================================================
           DELETE REMAINS PROTECTED
        ===================================================== */

        if (
            normalizedAction ===
            this.ACTIONS.DELETE
        ) {

            return {

                success: false,

                protected:
                    true,

                error:
                    "DELETE requires the protected deletion workflow."

            };

        }


        /* =====================================================
           MASTER AUTHORIZATION
        ===================================================== */

        if (
            !window.BKMaster ||
            !window.BKMaster.state ||
            window.BKMaster.state.authorized !== true
        ) {

            return {

                success: false,

                error:
                    "Master authorization is required."

            };

        }


        try {

            /* =================================================
               FIREBASE
            ================================================= */

const firebaseCore =
    await import(
        "../firebase-sessions.js"
    );

            const firestore =
                await import(
                    "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js"
                );


const db =
    firebaseCore.masterDb;
            const {
                doc,
                getDoc
            } = firestore;


            /* =================================================
               RESTAURANT
            ================================================= */

            const restaurantRef =
                doc(
                    db,
                    "restaurants",
                    restaurantId
                );


            const snapshot =
                await getDoc(
                    restaurantRef
                );


            if (
                !snapshot.exists()
            ) {

                return {

                    success: false,

                    error:
                        "Restaurant not found."

                };

            }


            const restaurantData =
                snapshot.data();


            /* =================================================
               CURRENT STATUS
            ================================================= */

            const currentStatus =
                this.normalizeStatus(
                    restaurantData.status
                );


            /* =================================================
               ACTION VALIDATION
            ================================================= */

            if (
                !this.canPerformAction(
                    currentStatus,
                    normalizedAction
                )
            ) {

                return {

                    success: false,

                    error:
                        `Action ${normalizedAction} is not allowed from ${currentStatus}.`

                };

            }


            /* =================================================
               TARGET STATUS
            ================================================= */

            const targetStatus =
                this.getTargetStatus(
                    normalizedAction
                );


            if (
                !targetStatus
            ) {

                return {

                    success: false,

                    error:
                        "Target status could not be determined."

                };

            }


            /* =================================================
               ACTION PAYLOAD
            ================================================= */

            const actionPayload = {

                restaurantId:
                    restaurantId,

                action:
                    normalizedAction,

                previousStatus:
                    currentStatus,

                targetStatus:
                    targetStatus,

                reason:
                    cleanReason,

                changedBy:
                    window.BKMaster.state.currentUser
                        ? window.BKMaster.state.currentUser.uid
                        : null,

                mode:
                    "MANUAL",

                requiresOwnerNotice:
                    true,

                requiresAuditLog:
                    true

            };


            /* =================================================
               STORE TEMPORARY SELECTION
            ================================================= */

            this.state.selectedRestaurantId =
                restaurantId;


            this.state.selectedRestaurantStatus =
                currentStatus;


            /* =================================================
               LOG PREVIEW
            ================================================= */

            console.log(
                "=========================================="
            );

            console.log(
                "BK RESTAURANT CONTROL: ACTION PREVIEW"
            );

            console.log(
                "Restaurant:",
                restaurantId
            );

            console.log(
                "Current Status:",
                currentStatus
            );

            console.log(
                "Action:",
                normalizedAction
            );

            console.log(
                "Target Status:",
                targetStatus
            );

            console.log(
                "Reason:",
                cleanReason
            );

            console.log(
                "Mode:",
                "MANUAL"
            );

            console.log(
                "Owner Notice Required:",
                true
            );

            console.log(
                "Audit Log Required:",
                true
            );

            console.log(
                "=========================================="
            );


            /* =================================================
               IMPORTANT
               
               NO FIRESTORE UPDATE HERE.
               
               Real update will be connected after:
               1. Owner Notice Engine
               2. Audit Log Engine
               3. Protected Action Confirmation
            ================================================= */

            return {

                success:
                    true,

                preview:
                    true,

                action:
                    actionPayload

            };


        } catch (error) {

            console.error(
                "BK RESTAURANT CONTROL: Action preparation failed:",
                error
            );


            return {

                success:
                    false,

                error:
                    error.message ||
                    "Action preparation failed."

            };

        }

    };


/* ============================================================
   ACTION ENGINE TEST HELPER
============================================================ */

BKMasterRestaurantControl.testAction =
    async function (
        restaurantId,
        action,
        reason
    ) {

        console.log(
            "BK RESTAURANT CONTROL: TEST ACTION"
        );


        const result =
            await this.prepareAction(
                restaurantId,
                action,
                reason
            );


        if (
            result.success
        ) {

            console.log(
                "BK RESTAURANT CONTROL: TEST ACTION PASSED."
            );

            console.log(
                "BK RESTAURANT CONTROL: No Firestore status was changed."
            );

        } else {

            console.warn(
                "BK RESTAURANT CONTROL: TEST ACTION FAILED:",
                result.error
            );

        }


        return result;

    };


/* ============================================================
   PART 3 READY
============================================================ */

console.log(
    "BK RESTAURANT CONTROL: Controlled action workflow loaded."
);


/* ============================================================
   BK RESTAURANT CONTROL
   PART 4 — REAL EXECUTE ENGINE
   ------------------------------------------------------------
   FINAL EXECUTION:
   1. Re-check Master authorization
   2. Re-check restaurant status
   3. Validate action
   4. Update restaurant status
   5. Create owner notice
   6. Create master audit log
   7. Commit everything together
============================================================ */

BKMasterRestaurantControl.executeAction =
    async function (
        restaurantId,
        action,
        reason
    ) {

        console.log(
            "=========================================="
        );

        console.log(
            "BK RESTAURANT CONTROL: REAL EXECUTE STARTED"
        );

        console.log(
            "=========================================="
        );


        /* =====================================================
           BASIC VALIDATION
        ===================================================== */

        if (!restaurantId) {

            return {

                success: false,

                error:
                    "Restaurant ID is required."

            };

        }


        if (!action) {

            return {

                success: false,

                error:
                    "Action is required."

            };

        }


        if (
            !reason ||
            String(reason).trim() === ""
        ) {

            return {

                success: false,

                error:
                    "A reason is required."

            };

        }


        const normalizedAction =
            String(action)
                .trim()
                .toUpperCase();


        const cleanReason =
            String(reason)
                .trim();


        /* =====================================================
           DELETE PROTECTION
        ===================================================== */

        if (
            normalizedAction ===
            this.ACTIONS.DELETE
        ) {

            return {

                success: false,

                protected: true,

                error:
                    "DELETE requires the protected deletion workflow."

            };

        }


        /* =====================================================
           MASTER AUTHORIZATION
        ===================================================== */

        if (
            !window.BKMaster ||
            !window.BKMaster.state ||
            window.BKMaster.state.authorized !== true
        ) {

            return {

                success: false,

                error:
                    "Master authorization is required."

            };

        }


        const masterUser =
            window.BKMaster.state.currentUser;


        const masterUid =
            masterUser
                ? masterUser.uid
                : null;


        if (!masterUid) {

            return {

                success: false,

                error:
                    "Master user identity is unavailable."

            };

        }


        try {

            /* =================================================
               LOAD FIREBASE
            ================================================= */

            const firebaseCore =
    await import(
        "../firebase-sessions.js"
    );


            const firestore =
                await import(
                    "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js"
                );


const db =
    firebaseCore.masterDb;
            const {
                doc,
                getDoc,
                writeBatch,
                collection,
                serverTimestamp
            } = firestore;


            /* =================================================
               RESTAURANT REFERENCE
            ================================================= */

            const restaurantRef =
                doc(
                    db,
                    "restaurants",
                    restaurantId
                );


            /* =================================================
               RE-CHECK RESTAURANT
               -------------------------------------------------
               Important:
               Preview ke baad status change ho sakta hai.
               Isliye final execution mein fresh read zaroori hai.
            ================================================= */

            const restaurantSnapshot =
                await getDoc(
                    restaurantRef
                );


            if (
                !restaurantSnapshot.exists()
            ) {

                return {

                    success: false,

                    error:
                        "Restaurant not found."

                };

            }


            const restaurantData =
                restaurantSnapshot.data();


            /* =================================================
               OWNER
            ================================================= */

            const ownerId =
                restaurantData.ownerId;


            if (
                !ownerId ||
                typeof ownerId !== "string"
            ) {

                return {

                    success: false,

                    error:
                        "Restaurant owner information is missing."

                };

            }


            /* =================================================
               CURRENT STATUS
            ================================================= */

            const currentStatus =
                this.normalizeStatus(
                    restaurantData.status
                );


            /* =================================================
               ACTION VALIDATION
            ================================================= */

            if (
                !this.canPerformAction(
                    currentStatus,
                    normalizedAction
                )
            ) {

                return {

                    success: false,

                    error:
                        `Action ${normalizedAction} is not allowed from ${currentStatus}.`

                };

            }


            /* =================================================
               TARGET STATUS
            ================================================= */

            const targetStatus =
                this.getTargetStatus(
                    normalizedAction
                );


            if (!targetStatus) {

                return {

                    success: false,

                    error:
                        "Target status could not be determined."

                };

            }


            /* =================================================
               ACTION → NOTICE INFORMATION
            ================================================= */

            let noticeType =
                "GENERAL";


            let noticePriority =
                "NORMAL";


            let noticeTitle =
                "Restaurant Status Updated";


            switch (
                normalizedAction
            ) {

                case this.ACTIONS.ACTIVATE:

                    noticeType =
                        "ACTIVATE";

                    noticePriority =
                        "NORMAL";

                    noticeTitle =
                        "Restaurant Activated";

                    break;


                case this.ACTIONS.DEACTIVATE:

                    noticeType =
                        "DEACTIVATE";

                    noticePriority =
                        "HIGH";

                    noticeTitle =
                        "Restaurant Deactivated";

                    break;


                case this.ACTIONS.SUSPEND:

                    noticeType =
                        "SUSPEND";

                    noticePriority =
                        "HIGH";

                    noticeTitle =
                        "Restaurant Suspended";

                    break;


                case this.ACTIONS.BLOCK:

                    noticeType =
                        "BLOCK";

                    noticePriority =
                        "CRITICAL";

                    noticeTitle =
                        "Restaurant Blocked";

                    break;

            }


            /* =================================================
               NOTICE MESSAGE
            ================================================= */

            const noticeMessage =
                `Your restaurant status has been changed from ${currentStatus} to ${targetStatus} by BK Master Control. Reason: ${cleanReason}`;


            /* =================================================
               GENERATE IDs
               -------------------------------------------------
               IDs are created before the batch so all documents
               can reference their exact identifiers.
            ================================================= */

            const noticeRef =
                doc(
                    collection(
                        db,
                        "notices"
                    )
                );


            const auditRef =
                doc(
                    collection(
                        db,
                        "masterAuditLogs"
                    )
                );


            const noticeId =
                noticeRef.id;


            const auditId =
                auditRef.id;


            /* =================================================
               CREATE BATCH
            ================================================= */

            const batch =
                writeBatch(
                    db
                );


            /* =================================================
               1. RESTAURANT STATUS UPDATE
            ================================================= */

            batch.update(
                restaurantRef,
                {

                    status:
                        targetStatus,

                    lastMasterAction:
                        normalizedAction,

                    lastMasterActionReason:
                        cleanReason,

                    lastMasterActionBy:
                        masterUid,

                    lastMasterActionAt:
                        serverTimestamp()

                }
            );


            /* =================================================
               2. OWNER NOTICE
            ================================================= */

            batch.set(
                noticeRef,
                {

                    noticeId:
                        noticeId,

                    restaurantId:
                        restaurantId,

                    ownerId:
                        ownerId,

                    type:
                        noticeType,

                    priority:
                        noticePriority,

                    title:
                        noticeTitle,

                    message:
                        noticeMessage,

                    action:
                        normalizedAction,

                    reason:
                        cleanReason,

                    source:
                        "BK_MASTER_CONTROL",

                    mode:
                        "MANUAL",

                    read:
                        false,

                    status:
                        "UNREAD",

                    createdBy:
                        masterUid,

                    createdAt:
                        serverTimestamp()

                }
            );


            /* =================================================
               3. MASTER AUDIT LOG
            ================================================= */

            batch.set(
                auditRef,
                {

                    auditId:
                        auditId,

                    restaurantId:
                        restaurantId,

                    ownerId:
                        ownerId,

                    action:
                        normalizedAction,

                    previousStatus:
                        currentStatus,

                    newStatus:
                        targetStatus,

                    reason:
                        cleanReason,

                    changedBy:
                        masterUid,

                    mode:
                        "MANUAL",

                    source:
                        "MASTER_RESTAURANT_CONTROL",

                    createdAt:
                        serverTimestamp()

                }
            );


            /* =================================================
               COMMIT
               -------------------------------------------------
               Restaurant status + owner notice + audit log
               are committed together.
            ================================================= */

            await batch.commit();


            /* =================================================
               UPDATE LOCAL ENGINE STATE
            ================================================= */

            this.state.selectedRestaurantId =
                restaurantId;


            this.state.selectedRestaurantStatus =
                targetStatus;


            /* =================================================
               SUCCESS LOG
            ================================================= */

            console.log(
                "=========================================="
            );

            console.log(
                "BK RESTAURANT CONTROL: FINAL ACTION SUCCESS"
            );

            console.log(
                "Restaurant:",
                restaurantId
            );

            console.log(
                "Previous Status:",
                currentStatus
            );

            console.log(
                "New Status:",
                targetStatus
            );

            console.log(
                "Action:",
                normalizedAction
            );

            console.log(
                "Notice ID:",
                noticeId
            );

            console.log(
                "Audit ID:",
                auditId
            );

            console.log(
                "Changed By:",
                masterUid
            );

            console.log(
                "=========================================="
            );


            return {

                success: true,

                restaurantId:
                    restaurantId,

                action:
                    normalizedAction,

                previousStatus:
                    currentStatus,

                newStatus:
                    targetStatus,

                reason:
                    cleanReason,

                noticeId:
                    noticeId,

                auditId:
                    auditId

            };


        } catch (error) {

            console.error(
                "=========================================="
            );

            console.error(
                "BK RESTAURANT CONTROL: FINAL ACTION FAILED"
            );

            console.error(
                error
            );

            console.error(
                "=========================================="
            );


            return {

                success: false,

                error:
                    error.message ||
                    "Restaurant action execution failed."

            };

        }

    };


/* ============================================================
   PART 4 READY
============================================================ */

console.log(
    "BK RESTAURANT CONTROL: Real Execute Engine loaded."
);