/* ============================================================
   BK RESTAURANT PLATFORM
   MASTER CONTROL
   MASTER DASHBOARD ENGINE
   Version: 1.0.0
============================================================ */

"use strict";


const BKMasterDashboard = {

    state: {

        initialized: false,

        ready: false,

        dataLoaded: false,

        totalRestaurants: 0,

        activeRestaurants: 0,

        activeSubscriptions: 0,

        paymentReview: 0,

        pendingRequests: 0,

        estimatedUsage: 0

    },


    elements: {},


    init() {

        console.log(
            "=========================================="
        );

        console.log(
            "BK MASTER DASHBOARD: INITIALIZING"
        );

        console.log(
            "=========================================="
        );


        this.cacheElements();

        this.verifyMasterCore();

        this.updateOverviewStats();

        this.updateEngineStatus();


        this.state.initialized =
            true;

        this.state.ready =
            true;


        console.log(
            "BK MASTER DASHBOARD: READY"
        );

    },


    cacheElements() {

        this.elements = {

            totalRestaurants:
                document.getElementById(
                    "masterTotalRestaurants"
                ),

            activeRestaurants:
                document.getElementById(
                    "masterActiveRestaurants"
                ),

            activeSubscriptions:
                document.getElementById(
                    "masterActiveSubscriptions"
                ),

            paymentReview:
                document.getElementById(
                    "masterPaymentReview"
                ),

            pendingRequests:
                document.getElementById(
                    "masterPendingRequests"
                ),

            estimatedUsage:
                document.getElementById(
                    "masterEstimatedUsage"
                ),


            authStatus:
                document.getElementById(
                    "masterAuthStatus"
                ),

            subscriptionEngine:
                document.getElementById(
                    "masterSubscriptionEngineStatus"
                ),

            paymentEngine:
                document.getElementById(
                    "masterPaymentEngineStatus"
                ),

            noticeEngine:
                document.getElementById(
                    "masterNoticeEngineStatus"
                ),

            websiteEngine:
                document.getElementById(
                    "masterWebsiteEngineStatus"
                ),

            usageEngine:
                document.getElementById(
                    "masterUsageEngineStatus"
                )

        };


        console.log(
            "BK MASTER DASHBOARD: Elements cached."
        );

    },


    verifyMasterCore() {

        if (
            !window.BKMasterCore
        ) {

            console.warn(
                "BK MASTER DASHBOARD: Master Core not available yet."
            );

            return false;

        }


        if (
            typeof window.BKMasterCore.isReady !==
            "function"
        ) {

            console.warn(
                "BK MASTER DASHBOARD: Master Core readiness check unavailable."
            );

            return false;

        }


        if (
            !window.BKMasterCore.isReady()
        ) {

            console.warn(
                "BK MASTER DASHBOARD: Master Core is not ready."
            );

            return false;

        }


        console.log(
            "BK MASTER DASHBOARD: Master Core verified."
        );


        return true;

    },


    updateOverviewStats() {

        this.setText(
            this.elements.totalRestaurants,
            this.state.totalRestaurants
        );


        this.setText(
            this.elements.activeRestaurants,
            this.state.activeRestaurants
        );


        this.setText(
            this.elements.activeSubscriptions,
            this.state.activeSubscriptions
        );


        this.setText(
            this.elements.paymentReview,
            this.state.paymentReview
        );


        this.setText(
            this.elements.pendingRequests,
            this.state.pendingRequests
        );


        this.setText(
            this.elements.estimatedUsage,
            this.state.estimatedUsage
        );

    },


    updateEngineStatus() {

        this.setStatus(
            this.elements.authStatus,
            "READY"
        );


        this.setStatus(
            this.elements.subscriptionEngine,
            "READY"
        );


        this.setStatus(
            this.elements.paymentEngine,
            "READY"
        );


        this.setStatus(
            this.elements.noticeEngine,
            "READY"
        );


        this.setStatus(
            this.elements.websiteEngine,
            "READY"
        );

this.setStatus(
    this.elements.usageEngine,
    "NOT VERIFIED"
);

    },


    setText(element, value) {

        if (!element) {

            return;

        }


        element.textContent =
            String(value);

    },


    setStatus(element, value) {

        if (!element) {

            return;

        }


        element.textContent =
            String(value);

    },


    isReady() {

        return (
            this.state.ready === true
        );

    }

};

/* ============================================================
   BK MASTER DASHBOARD
   PART 3 — FIRESTORE RESTAURANT DATA
============================================================ */

BKMasterDashboard.loadRestaurantData = async function () {

    console.log(
        "BK MASTER DASHBOARD: Loading restaurant data..."
    );

    try {

        /*
           Firebase Core is loaded dynamically so
           Part 1 does not need to be modified.
        */

        const firebaseSessions =
    await import("../firebase-sessions.js");

        const firestore =
            await import(
                "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js"
            );

const db =
    firebaseSessions.masterDb;
        const {
            collection,
            getDocs
        } = firestore;

        const restaurantsRef =
            collection(
                db,
                "restaurants"
            );

        const snapshot =
            await getDocs(
                restaurantsRef
            );

        let totalRestaurants = 0;
        let activeRestaurants = 0;

        snapshot.forEach(
            (restaurantDoc) => {

                totalRestaurants++;

                const restaurantData =
                    restaurantDoc.data();

                if (
                    restaurantData.status ===
                    "ACTIVE"
                ) {

                    activeRestaurants++;

                }

            }
        );

        this.state.totalRestaurants =
            totalRestaurants;

        this.state.activeRestaurants =
            activeRestaurants;

        this.updateOverviewStats();

        this.state.dataLoaded = true;

        console.log(
            "BK MASTER DASHBOARD: Restaurant data loaded."
        );

        console.log(
            "BK MASTER DASHBOARD: Total Restaurants:",
            totalRestaurants
        );

        console.log(
            "BK MASTER DASHBOARD: Active Restaurants:",
            activeRestaurants
        );

    } catch (error) {

        console.error(
            "BK MASTER DASHBOARD: Restaurant data load failed:",
            error
        );

    }

};


/* ============================================================
   EXTEND DASHBOARD STARTUP
============================================================ */

const originalDashboardInit =
    BKMasterDashboard.init.bind(
        BKMasterDashboard
    );


BKMasterDashboard.init = async function () {

    originalDashboardInit();

    await this.loadRestaurantData();

    console.log(
        "BK MASTER DASHBOARD: Firestore data sync complete."
    );

};


/* ============================================================
   BK MASTER DASHBOARD
   PART 4 — RESTAURANT CONTROL CARDS
============================================================ */


/* ============================================================
   RESTAURANT CARD DATA
   Loads restaurant + owner profile data
============================================================ */

BKMasterDashboard.loadRestaurantCards =
    async function () {

        console.log(
            "BK MASTER DASHBOARD: Loading restaurant cards..."
        );

        const restaurantList =
            document.getElementById(
                "masterRestaurantList"
            );
            const billingList =
    document.getElementById(
        "bkMasterWebsiteBillingList"
    );

        const emptyState =
            document.getElementById(
                "masterRestaurantEmptyState"
            );

        if (!restaurantList) {

            console.warn(
                "BK MASTER DASHBOARD: Restaurant list element not found."
            );

            return;

        }


        try {

            const firebaseSessions =
    await import("../firebase-sessions.js");
            const firestore =
                await import(
                    "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js"
                );


          const db =
    firebaseSessions.masterDb;


            const {
                collection,
                getDocs,
                doc,
                getDoc
            } = firestore;


            /* =================================================
               LOAD RESTAURANTS
            ================================================= */

            const restaurantsRef =
                collection(
                    db,
                    "restaurants"
                );


            const snapshot =
                await getDocs(
                    restaurantsRef
                );


            restaurantList.innerHTML = "";
            if (billingList) {
    billingList.innerHTML = "";
}


            if (snapshot.empty) {

                if (emptyState) {

                    emptyState.classList.remove(
                        "hidden-master-section"
                    );

                }


                console.log(
                    "BK MASTER DASHBOARD: No restaurants found."
                );

                return;

            }


            if (emptyState) {

                emptyState.classList.add(
                    "hidden-master-section"
                );

            }


            /* =================================================
               LOAD RESTAURANTS + OWNER PROFILES
            ================================================= */

            const restaurantCards =
                await Promise.all(

                    snapshot.docs.map(
                        async (
                            restaurantDoc
                        ) => {

                            const restaurantData =
                                restaurantDoc.data();


                            let ownerData =
                                null;


                            const ownerId =
                                restaurantData.ownerId;


                            /* ---------------------------------
                               LOAD OWNER PROFILE
                            --------------------------------- */

                            if (
                                ownerId &&
                                typeof ownerId === "string"
                            ) {

                                try {

                                    const ownerRef =
                                        doc(
                                            db,
                                            "users",
                                            ownerId
                                        );


                                    const ownerSnapshot =
                                        await getDoc(
                                            ownerRef
                                        );


                                    if (
                                        ownerSnapshot.exists()
                                    ) {

                                        ownerData =
                                            ownerSnapshot.data();


                                        console.log(
                                            "BK MASTER DASHBOARD: Owner profile loaded:",
                                            ownerId
                                        );

                                    } else {

                                        console.warn(
                                            "BK MASTER DASHBOARD: Owner profile not found:",
                                            ownerId
                                        );

                                    }

                                } catch (
                                    ownerError
                                ) {

                                    console.warn(
                                        "BK MASTER DASHBOARD: Owner profile load failed:",
                                        ownerId,
                                        ownerError
                                    );

                                }

                            }


                            /* ---------------------------------
                               CREATE CARD
                            --------------------------------- */

const restaurantCard =
    this.createRestaurantCard(
        restaurantDoc.id,
        restaurantData,
        ownerData
    );

const billingCard =
    window.BKMasterSubscriptionBillingControl?.createBillingCard
        ? window.BKMasterSubscriptionBillingControl.createBillingCard(
            restaurantDoc.id,
            restaurantData,
            ownerData
        )
        : null;

return {
    restaurantCard,
    billingCard
};

                        }
                    )

                );


            /* =================================================
               RENDER CARDS
            ================================================= */

restaurantCards.forEach(
    (
        cardData
    ) => {

        /*
        ================================================
        RESTAURANT CONTROL
        Only Restaurant Card goes here.
        ================================================
        */

        if (
            cardData.restaurantCard
        ) {

            restaurantList.appendChild(
                cardData.restaurantCard
            );

        }


        /*
        ================================================
        WEBSITE CONTROL
        Subscription & Billing Card goes here.
        ================================================
        */

        if (
            billingList &&
            cardData.billingCard
        ) {

            billingList.appendChild(
                cardData.billingCard
            );

        }

    }
);

            console.log(
                "BK MASTER DASHBOARD: Restaurant cards rendered:",
                snapshot.size
            );


        } catch (error) {

            console.error(
                "BK MASTER DASHBOARD: Restaurant card load failed:",
                error
            );

        }

    };
    
    /* ============================================================
   RESTAURANT CONTROL ACTIONS
============================================================ */

BKMasterDashboard.getRestaurantControlActions =
    function (status) {

        const normalizedStatus =
            String(status || "INACTIVE")
                .trim()
                .toUpperCase();


        switch (normalizedStatus) {

            case "ACTIVE":

                return [
                    {
                        action: "deactivate",
                        label: "DEACTIVATE",
                        icon: "◐",
                        className: "deactivate"
                    },
                    {
                        action: "suspend",
                        label: "SUSPEND",
                        icon: "Ⅱ",
                        className: "suspend"
                    },
                    {
                        action: "block",
                        label: "BLOCK",
                        icon: "⊘",
                        className: "block"
                    },
                    {
                        action: "delete",
                        label: "DELETE",
                        icon: "⌫",
                        className: "delete"
                    }
                ];


            case "INACTIVE":

                return [
                    {
                        action: "activate",
                        label: "ACTIVATE",
                        icon: "✓",
                        className: "activate"
                    },
                    {
                        action: "suspend",
                        label: "SUSPEND",
                        icon: "Ⅱ",
                        className: "suspend"
                    },
                    {
                        action: "block",
                        label: "BLOCK",
                        icon: "⊘",
                        className: "block"
                    },
                    {
                        action: "delete",
                        label: "DELETE",
                        icon: "⌫",
                        className: "delete"
                    }
                ];


            case "SUSPENDED":

                return [
                    {
                        action: "activate",
                        label: "ACTIVATE",
                        icon: "✓",
                        className: "activate"
                    },
                    {
                        action: "deactivate",
                        label: "DEACTIVATE",
                        icon: "◐",
                        className: "deactivate"
                    },
                    {
                        action: "block",
                        label: "BLOCK",
                        icon: "⊘",
                        className: "block"
                    },
                    {
                        action: "delete",
                        label: "DELETE",
                        icon: "⌫",
                        className: "delete"
                    }
                ];


            case "BLOCKED":

                return [
                    {
                        action: "activate",
                        label: "ACTIVATE",
                        icon: "✓",
                        className: "activate"
                    },
                    {
                        action: "deactivate",
                        label: "DEACTIVATE",
                        icon: "◐",
                        className: "deactivate"
                    },
                    {
                        action: "delete",
                        label: "DELETE",
                        icon: "⌫",
                        className: "delete"
                    }
                ];


            default:

                return [
                    {
                        action: "activate",
                        label: "ACTIVATE",
                        icon: "✓",
                        className: "activate"
                    },
                    {
                        action: "delete",
                        label: "DELETE",
                        icon: "⌫",
                        className: "delete"
                    }
                ];

        }

    };


/* ============================================================
   CREATE PREMIUM RESTAURANT CARD
   Restaurant + Owner Profile + Control Actions
============================================================ */

BKMasterDashboard.createRestaurantCard =
    function (
        restaurantId,
        restaurantData,
        ownerData
    ) {

        const card =
            document.createElement(
                "article"
            );


        card.className =
            "master-restaurant-card";


        /* =================================================
           RESTAURANT DATA
        ================================================= */

        const restaurantName =
            this.getRestaurantValue(
                restaurantData,
                [
                    "restaurantName",
                    "name",
                    "businessName"
                ],
                "Unnamed Restaurant"
            );


        const city =
            this.getRestaurantValue(
                restaurantData,
                [
                    "city",
                    "location",
                    "address"
                ],
                "Location unavailable"
            );


        const state =
            this.getRestaurantValue(
                restaurantData,
                [
                    "state"
                ],
                ""
            );


        const address =
            this.getRestaurantValue(
                restaurantData,
                [
                    "address"
                ],
                "Not available"
            );


        const status =
            this.getRestaurantValue(
                restaurantData,
                [
                    "status"
                ],
                "INACTIVE"
            );


        const websiteStatus =
            this.getRestaurantValue(
                restaurantData,
                [
                    "websiteStatus"
                ],
                "Not Configured"
            );


        const ownerId =
            this.getRestaurantValue(
                restaurantData,
                [
                    "ownerId"
                ],
                "—"
            );


        /* =================================================
           OWNER DATA
        ================================================= */

        const ownerName =
            this.getRestaurantValue(
                ownerData,
                [
                    "ownerName",
                    "name",
                    "fullName",
                    "displayName"
                ],
                "Owner unavailable"
            );


        const email =
            this.getRestaurantValue(
                ownerData,
                [
                    "email",
                    "ownerEmail"
                ],
                "—"
            );


        const mobile =
            this.getRestaurantValue(
                ownerData,
                [
                    "phone",
                    "mobile",
                    "phoneNumber",
                    "ownerMobile"
                ],
                "—"
            );


        /* =================================================
           COVER IMAGE
           Existing card image logic preserved.
        ================================================= */

        const coverImage =
            this.getRestaurantValue(
                restaurantData,
                [
                    "coverImage",
                    "coverUrl",
                    "coverImageUrl",
                    "restaurantImage",
                    "imageUrl",
                    "image"
                ],
                ""
            );


        /* =================================================
           LOCATION
        ================================================= */

        const locationText =
            state
                ? `${city}, ${state}`
                : city;


        /* =================================================
           OWNER INITIAL
        ================================================= */

        const ownerInitial =
            String(
                ownerName
            )
            .trim()
            .charAt(0)
            .toUpperCase() || "B";


        /* =================================================
           COVER
        ================================================= */

        const coverHTML =
            coverImage
                ? `
                    <img
                        class="bk-master-card-cover-image"
                        src="${this.escapeHTML(
                            coverImage
                        )}"
                        alt="${this.escapeHTML(
                            restaurantName
                        )}"
                        loading="lazy"
                    >
                  `
                : `
                    <div
                        class="bk-master-card-cover-fallback"
                    >
                        <div
                            style="
                                font-family:Georgia,'Times New Roman',serif;
                                font-size:42px;
                                font-weight:700;
                                color:#fffdf8;
                                letter-spacing:3px;
                                opacity:.92;
                            "
                        >
                            BK
                        </div>
                    </div>
                  `;


        /* =================================================
           STATUS
        ================================================= */

        const statusClass =
            this.getStatusClass(
                status
            );


        /* =================================================
           CONTROL ACTIONS
        ================================================= */

        const controlActions =
            this.getRestaurantControlActions(
                status
            );


        const controlActionsHTML =
            controlActions
                .map(
                    (control) => {

                        return `
                            <button
                                type="button"
                                class="
                                    bk-master-card-control
                                    ${control.className}
                                "
                                data-master-action="${control.action}"
                                data-restaurant-id="${this.escapeHTML(
                                    restaurantId
                                )}"
                            >
                                <span>
                                    ${control.icon}
                                </span>

                                ${control.label}

                            </button>
                        `;

                    }
                )
                .join("");


        /* =================================================
           CARD HTML
        ================================================= */

        card.innerHTML = `

            <!-- COVER -->

            <div
                class="bk-master-card-cover"
            >

                ${coverHTML}


                <div
                    class="bk-master-card-mark"
                >

                    <div
                        class="bk-master-card-mark-inner"
                    >
                        BK
                    </div>

                </div>

            </div>


            <!-- MAIN -->

            <div
                class="bk-master-card-main"
            >


                <!-- HEADER -->

                <div
                    class="bk-master-card-header"
                >

                    <div>

                        <div
                            class="bk-master-card-kicker"
                        >
                            BK RESTAURANT
                        </div>

                        <h3
                            class="bk-master-card-title"
                        >
                            ${this.escapeHTML(
                                restaurantName
                            )}
                        </h3>

                    </div>


                    <div
                        class="bk-master-card-status ${statusClass}"
                    >

                        <span
                            class="bk-master-card-status-dot"
                        ></span>

                        ${this.escapeHTML(
                            String(status).toUpperCase()
                        )}

                    </div>

                </div>


                <!-- LOCATION -->

                <div
                    class="bk-master-card-location"
                >

                    <span
                        class="bk-master-card-location-icon"
                    >
                        ●
                    </span>

                    <span>
                        ${this.escapeHTML(
                            locationText
                        )}
                    </span>

                </div>


                <!-- SERVICE TAGS -->

                <div
                    class="bk-master-card-tags"
                >

                    <span
                        class="bk-master-card-tag"
                    >
                        Restaurant
                    </span>

                    <span
                        class="bk-master-card-tag"
                    >
                        Online Platform
                    </span>

                    <span
                        class="bk-master-card-tag"
                    >
                        BK Managed
                    </span>

                </div>


                <!-- OWNER -->

                <div
                    class="bk-master-card-owner"
                >

                    <div
                        class="bk-master-card-owner-label"
                    >
                        OWNER
                    </div>


                    <div
                        class="bk-master-card-owner-row"
                    >

                        <div
                            class="bk-master-card-owner-avatar"
                        >
                            ${this.escapeHTML(
                                ownerInitial
                            )}
                        </div>


                        <div>

                            <div
                                class="bk-master-card-owner-name"
                            >
                                ${this.escapeHTML(
                                    ownerName
                                )}
                            </div>


                            <div
                                class="bk-master-card-owner-contact"
                            >

                                <span>
                                    ✉
                                    ${this.escapeHTML(
                                        email
                                    )}
                                </span>

                                <span>
                                    ☎
                                    ${this.escapeHTML(
                                        mobile
                                    )}
                                </span>

                            </div>

                        </div>

                    </div>

                </div>


                <!-- INFORMATION -->

                <div
                    class="bk-master-card-info-grid"
                >

                    <div
                        class="bk-master-card-info-item"
                    >

                        <span
                            class="bk-master-card-info-label"
                        >
                            OWNER ID
                        </span>

                        <span
                            class="bk-master-card-info-value"
                        >
                            ${this.escapeHTML(
                                ownerId
                            )}
                        </span>

                    </div>


                    <div
                        class="bk-master-card-info-item"
                    >

                        <span
                            class="bk-master-card-info-label"
                        >
                            LOCATION
                        </span>

                        <span
                            class="bk-master-card-info-value"
                        >
                            ${this.escapeHTML(
                                locationText
                            )}
                        </span>

                    </div>


                    <div
                        class="bk-master-card-info-item"
                    >

                        <span
                            class="bk-master-card-info-label"
                        >
                            RESTAURANT ID
                        </span>

                        <span
                            class="bk-master-card-info-value"
                        >
                            ${this.escapeHTML(
                                restaurantId
                            )}
                        </span>

                    </div>


                    <div
                        class="bk-master-card-info-item"
                    >

                        <span
                            class="bk-master-card-info-label"
                        >
                            WEBSITE STATUS
                        </span>

                        <span
                            class="bk-master-card-info-value"
                        >
                            ${this.escapeHTML(
                                websiteStatus
                            )}
                        </span>

                    </div>

                </div>


                <!-- DETAILS + PLAN -->

                <div
                    class="bk-master-card-actions"
                >

                    <button
                        type="button"
                        class="bk-master-card-action details"
                        data-master-action="details"
                        data-restaurant-id="${this.escapeHTML(
                            restaurantId
                        )}"
                    >
                        ▣ &nbsp; DETAILS
                    </button>


                    <button
                        type="button"
                        class="bk-master-card-action plan"
                        data-master-action="plan"
                        data-restaurant-id="${this.escapeHTML(
                            restaurantId
                        )}"
                    >
                        ♛ &nbsp; PLAN
                    </button>

                </div>


                <!-- RESTAURANT CONTROL -->


    <div
                    class="bk-master-card-control-section"
                >

                    <div
                        class="bk-master-card-control-label"
                    >
                        RESTAURANT CONTROL
                    </div>


                    <div
                        class="bk-master-card-control-actions"
                    >

                        ${controlActionsHTML}

                    </div>

                </div>


            </div>

        `;


        return card;

    };
            
    

/* ============================================================
   SMART RESTAURANT VALUE HELPER
   Supports normal values + nested objects
============================================================ */

BKMasterDashboard.getRestaurantValue =
    function (
        data,
        keys,
        fallback
    ) {

        if (!data) {
            return fallback;
        }


        for (
            const key of keys
        ) {

            const value =
                data[key];


            if (
                value === undefined ||
                value === null
            ) {
                continue;
            }


            /*
               NORMAL STRING / NUMBER / BOOLEAN
            */

            if (
                typeof value !== "object"
            ) {

                if (
                    String(value).trim() !== ""
                ) {

                    return String(value);

                }

                continue;

            }


            /*
               NESTED OBJECT
            */

            const nestedKeys = [

                "name",
                "fullName",
                "displayName",
                "restaurantName",
                "businessName",
                "value",
                "city",
                "state",
                "address",
                "email",
                "mobile",
                "phone",
                "phoneNumber"

            ];


            for (
                const nestedKey
                of nestedKeys
            ) {

                const nestedValue =
                    value[nestedKey];


                if (
                    nestedValue !== undefined &&
                    nestedValue !== null &&
                    typeof nestedValue !== "object" &&
                    String(
                        nestedValue
                    ).trim() !== ""
                ) {

                    return String(
                        nestedValue
                    );

                }

            }

        }


        return fallback;

    };

/* ============================================================
   STATUS CLASS
============================================================ */

BKMasterDashboard.getStatusClass =
    function (
        status
    ) {

        const normalized =
            String(
                status
            ).toUpperCase();


        if (
            normalized === "ACTIVE"
        ) {

            return "status-active";

        }


        if (
            normalized === "SUSPENDED"
        ) {

            return "status-suspended";

        }


        if (
            normalized === "INACTIVE"
        ) {

            return "status-inactive";

        }


        if (
            normalized === "EXPIRED"
        ) {

            return "status-expired";

        }


        return "status-unknown";

    };


/* ============================================================
   HTML SAFETY
============================================================ */

BKMasterDashboard.escapeHTML =
    function (
        value
    ) {

        return String(
            value
        )
        .replace(
            /&/g,
            "&amp;"
        )
        .replace(
            /</g,
            "&lt;"
        )
        .replace(
            />/g,
            "&gt;"
        )
        .replace(
            /"/g,
            "&quot;"
        )
        .replace(
            /'/g,
            "&#039;"
        );

    };


/* ============================================================
   EXTEND DASHBOARD STARTUP
============================================================ */

const previousDashboardInit =
    BKMasterDashboard.init.bind(
        BKMasterDashboard
    );


BKMasterDashboard.init =
    async function () {

        await previousDashboardInit();

        await this.loadRestaurantCards();

        console.log(
            "BK MASTER DASHBOARD: Restaurant Control ready."
        );

    };
    
/* ============================================================
   BK MASTER DASHBOARD
   PART 5 — RESTAURANT DETAILS
============================================================ */


/* ============================================================
   RESTAURANT DETAILS STATE
============================================================ */

BKMasterDashboard.state.selectedRestaurantId =
    null;


/* ============================================================
   BIND RESTAURANT CARD ACTIONS
   ------------------------------------------------------------
   DETAILS + PLAN + RESTAURANT CONTROL
   Part 2 — Safe Action Preview
============================================================ */

BKMasterDashboard.bindRestaurantActions =
    function () {

        const restaurantList =
            document.getElementById(
                "masterRestaurantList"
            );
            


        if (!restaurantList) {

            console.warn(
                "BK MASTER DASHBOARD: Restaurant list not found."
            );

            return;

        }


        /* ====================================================
           PREVENT DUPLICATE LISTENER
        ==================================================== */

        if (
            restaurantList.dataset
                .restaurantActionsBound === "true"
        ) {

            console.log(
                "BK MASTER DASHBOARD: Restaurant actions already bound."
            );

            return;

        }


        restaurantList.dataset
            .restaurantActionsBound = "true";


        /* ====================================================
           CLICK HANDLER
        ==================================================== */

        restaurantList.addEventListener(
            "click",
            async (event) => {

                const button =
                    event.target.closest(
                        "[data-master-action]"
                    );


                if (!button) {
                    return;
                }


                const action =
                    String(
                        button.dataset.masterAction || ""
                    )
                    .trim()
                    .toLowerCase();


                const restaurantId =
                    button.dataset.restaurantId;


                if (!restaurantId) {

                    console.warn(
                        "BK MASTER DASHBOARD: Restaurant ID missing."
                    );

                    return;

                }


                /* ============================================
                   DETAILS
                ============================================ */

                if (
                    action === "details"
                ) {

                    await this.openRestaurantDetails(
                        restaurantId
                    );

                    return;

                }


                /* ============================================
                   PLAN
                   ------------------------------------------------
                   Subscription/Plan system will be connected
                   later. No action is performed now.
                ============================================ */

                if (
                    action === "plan"
                ) {

                    console.log(
                        "BK MASTER DASHBOARD: PLAN selected:",
                        restaurantId
                    );

                    console.log(
                        "BK MASTER DASHBOARD: Subscription control will be connected later."
                    );

                    return;

                }


                /* ============================================
                   RESTAURANT CONTROL
                ============================================ */

                const allowedControls = [

                    "activate",
                    "deactivate",
                    "suspend",
                    "block",
                    "delete"

                ];


                if (
                    !allowedControls.includes(
                        action
                    )
                ) {

                    console.warn(
                        "BK MASTER DASHBOARD: Unknown action:",
                        action
                    );

                    return;

                }


                /* ============================================
                   OPEN PREMIUM CONTROL MODAL
                   ------------------------------------------------
                   Reason input ab modal ke andar hoga.
                   Abhi Firestore status change nahi hoga.
                ============================================ */

                await this.openRestaurantControlModal(
                    restaurantId,
                    action
                );


                return;
            }
        );


        console.log(
            "BK MASTER DASHBOARD: Restaurant actions bound."
        );

    };

/* ============================================================
   LOAD SELECTED RESTAURANT + OWNER PROFILE
============================================================ */

BKMasterDashboard.openRestaurantDetails =
    async function (
        restaurantId
    ) {

        console.log(
            "BK MASTER DASHBOARD: Opening restaurant details:",
            restaurantId
        );


        try {

            const firebaseCore =
                await import(
                    "../firebase.js"
                );


            const firestore =
                await import(
                    "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js"
                );


            const db =
                firebaseCore.db;


            const {
                doc,
                getDoc
            } = firestore;


            /* =================================================
               LOAD RESTAURANT
            ================================================= */

            const restaurantRef =
                doc(
                    db,
                    "restaurants",
                    restaurantId
                );


            const restaurantSnapshot =
                await getDoc(
                    restaurantRef
                );


            if (
                !restaurantSnapshot.exists()
            ) {

                console.warn(
                    "BK MASTER DASHBOARD: Restaurant not found:",
                    restaurantId
                );

                return;

            }


            const restaurantData =
                restaurantSnapshot.data();


            /* =================================================
               LOAD OWNER PROFILE
               users/{ownerId}
            ================================================= */

            let ownerData =
                null;


            const ownerId =
                restaurantData.ownerId;


            if (
                ownerId &&
                typeof ownerId === "string"
            ) {

                try {

                    const ownerRef =
                        doc(
                            db,
                            "users",
                            ownerId
                        );


                    const ownerSnapshot =
                        await getDoc(
                            ownerRef
                        );


                    if (
                        ownerSnapshot.exists()
                    ) {

                        ownerData =
                            ownerSnapshot.data();


                        console.log(
                            "BK MASTER DASHBOARD: Details owner profile loaded:",
                            ownerId
                        );

                    } else {

                        console.warn(
                            "BK MASTER DASHBOARD: Details owner profile not found:",
                            ownerId
                        );

                    }

                } catch (
                    ownerError
                ) {

                    console.warn(
                        "BK MASTER DASHBOARD: Details owner profile load failed:",
                        ownerId,
                        ownerError
                    );

                }

            }


            /* =================================================
               SAVE SELECTED RESTAURANT
            ================================================= */

            this.state.selectedRestaurantId =
                restaurantId;


            /* =================================================
               RENDER DETAILS
            ================================================= */

            this.renderRestaurantDetails(
                restaurantId,
                restaurantData,
                ownerData
            );


        } catch (error) {

            console.error(
                "BK MASTER DASHBOARD: Restaurant details load failed:",
                error
            );

        }

    };

/* ============================================================
   CREATE DETAILS PANEL
============================================================ */

BKMasterDashboard.createDetailsPanel =
    function () {

        let panel =
            document.getElementById(
                "bkMasterRestaurantDetailsPanel"
            );


        if (panel) {
            return panel;
        }


        panel =
            document.createElement(
                "div"
            );


        panel.id =
            "bkMasterRestaurantDetailsPanel";


        panel.className =
            "bk-master-details-panel";


        panel.innerHTML = `

            <div
                class="bk-master-details-backdrop"
                data-master-details-close="true"
            ></div>


            <section
                class="bk-master-details-modal"
                role="dialog"
                aria-modal="true"
                aria-labelledby="bkMasterDetailsTitle"
            >

                <div class="bk-master-details-header">

                    <div>

                        <div
                            class="bk-master-details-kicker"
                        >
                            RESTAURANT DETAILS
                        </div>

                        <h2
                            id="bkMasterDetailsTitle"
                        >
                            Restaurant
                        </h2>

                    </div>


                    <button
                        type="button"
                        class="bk-master-details-close"
                        data-master-details-close="true"
                        aria-label="Close details"
                    >
                        ×
                    </button>

                </div>


                <div
                    id="bkMasterRestaurantDetailsContent"
                    class="bk-master-details-content"
                ></div>

            </section>

        `;


        document.body.appendChild(
            panel
        );


        panel.addEventListener(
            "click",
            (event) => {

                const closeTarget =
                    event.target.closest(
                        "[data-master-details-close]"
                    );


                if (
                    closeTarget
                ) {

                    this.closeRestaurantDetails();

                }

            }
        );


        return panel;

    };


/* ============================================================
   RENDER RESTAURANT DETAILS
   Restaurant Data + Owner Profile Data
============================================================ */

BKMasterDashboard.renderRestaurantDetails =
    function (
        restaurantId,
        restaurantData,
        ownerData
    ) {

        const panel =
            this.createDetailsPanel();


        const content =
            document.getElementById(
                "bkMasterRestaurantDetailsContent"
            );


        const title =
            document.getElementById(
                "bkMasterDetailsTitle"
            );


        if (
            !content ||
            !title
        ) {

            return;

        }


        /* =================================================
           RESTAURANT INFORMATION
        ================================================= */

        const restaurantName =
            this.getRestaurantValue(
                restaurantData,
                [
                    "restaurantName",
                    "name",
                    "businessName"
                ],
                "Unnamed Restaurant"
            );


        const city =
            this.getRestaurantValue(
                restaurantData,
                [
                    "city",
                    "location"
                ],
                "Not available"
            );


        const state =
            this.getRestaurantValue(
                restaurantData,
                [
                    "state"
                ],
                ""
            );


        const address =
            this.getRestaurantValue(
                restaurantData,
                [
                    "address"
                ],
                "Not available"
            );


        const status =
            this.getRestaurantValue(
                restaurantData,
                [
                    "status"
                ],
                "UNKNOWN"
            );


        const websiteStatus =
            this.getRestaurantValue(
                restaurantData,
                [
                    "websiteStatus"
                ],
                "Not configured"
            );


        /* =================================================
           OWNER INFORMATION
           Source: users/{ownerId}
        ================================================= */

        const ownerId =
            this.getRestaurantValue(
                restaurantData,
                [
                    "ownerId"
                ],
                "Not available"
            );


        const ownerName =
            this.getRestaurantValue(
                ownerData,
                [
                    "ownerName",
                    "name",
                    "fullName",
                    "displayName"
                ],
                "Not available"
            );


        const email =
            this.getRestaurantValue(
                ownerData,
                [
                    "email",
                    "ownerEmail"
                ],
                "Not available"
            );


        const mobile =
            this.getRestaurantValue(
                ownerData,
                [
                    "phone",
                    "mobile",
                    "phoneNumber",
                    "ownerMobile"
                ],
                "Not available"
            );


        /* =================================================
           LOCATION
        ================================================= */

        const location =
            state
                ? `${city}, ${state}`
                : city;


        /* =================================================
           TITLE
        ================================================= */

        title.textContent =
            restaurantName;


        /* =================================================
           DETAILS CONTENT
        ================================================= */

        content.innerHTML = `

            <div
                class="bk-master-details-section"
            >

                <div
                    class="bk-master-details-section-title"
                >
                    RESTAURANT INFORMATION
                </div>


                <div
                    class="bk-master-details-grid"
                >

                    ${this.createDetailItem(
                        "Restaurant Name",
                        restaurantName
                    )}

                    ${this.createDetailItem(
                        "Restaurant ID",
                        restaurantId
                    )}

                    ${this.createDetailItem(
                        "Location",
                        location
                    )}

                    ${this.createDetailItem(
                        "Address",
                        address
                    )}

                    ${this.createDetailItem(
                        "Status",
                        status
                    )}

                    ${this.createDetailItem(
                        "Website Status",
                        websiteStatus
                    )}

                </div>

            </div>


            <div
                class="bk-master-details-section"
            >

                <div
                    class="bk-master-details-section-title"
                >
                    OWNER INFORMATION
                </div>


                <div
                    class="bk-master-details-grid"
                >

                    ${this.createDetailItem(
                        "Owner Name",
                        ownerName
                    )}

                    ${this.createDetailItem(
                        "Owner ID",
                        ownerId
                    )}

                    ${this.createDetailItem(
                        "Email",
                        email
                    )}

                    ${this.createDetailItem(
                        "Mobile",
                        mobile
                    )}

                </div>

            </div>

        `;


        /* =================================================
           OPEN PANEL
        ================================================= */

        panel.classList.add(
            "show"
        );


        document.body.classList.add(
            "bk-master-details-open"
        );


        console.log(
            "BK MASTER DASHBOARD: Restaurant details opened:",
            restaurantId
        );

    };

/* ============================================================
   DETAIL ITEM
============================================================ */

BKMasterDashboard.createDetailItem =
    function (
        label,
        value
    ) {

        return `

            <div
                class="bk-master-detail-item"
            >

                <span>
                    ${this.escapeHTML(
                        label
                    )}
                </span>

                <strong>
                    ${this.escapeHTML(
                        value
                    )}
                </strong>

            </div>

        `;

    };


/* ============================================================
   CLOSE DETAILS
============================================================ */

BKMasterDashboard.closeRestaurantDetails =
    function () {

        const panel =
            document.getElementById(
                "bkMasterRestaurantDetailsPanel"
            );


        if (panel) {

            panel.classList.remove(
                "show"
            );

        }


        document.body.classList.remove(
            "bk-master-details-open"
        );


        this.state.selectedRestaurantId =
            null;


        console.log(
            "BK MASTER DASHBOARD: Restaurant details closed."
        );

    };


/* ============================================================
   ESCAPE KEY
============================================================ */

document.addEventListener(
    "keydown",
    (event) => {

        if (
            event.key === "Escape"
        ) {

            BKMasterDashboard
                .closeRestaurantDetails();

        }

    }
);


/* ============================================================
   EXTEND DASHBOARD STARTUP
============================================================ */

const restaurantCardInit =
    BKMasterDashboard.init.bind(
        BKMasterDashboard
    );


BKMasterDashboard.init =
    async function () {

        await restaurantCardInit();


        this.bindRestaurantActions();


        console.log(
            "BK MASTER DASHBOARD: Restaurant Details ready."
        );

    };


/* ============================================================
   BK MASTER DASHBOARD
   PART 2 — STARTUP + CORE READY WAIT
============================================================ */

function initializeMasterDashboard() {

    if (
        !window.BKMasterDashboard
    ) {

        console.error(
            "BK MASTER DASHBOARD: Engine object not available."
        );

        return;

    }

    /*
       Master Core must be ready first.
       Dashboard waits instead of initializing too early.
    */

    if (
        !window.BKMasterCore ||
        typeof window.BKMasterCore.isReady !== "function" ||
        !window.BKMasterCore.isReady()
    ) {

        console.log(
            "BK MASTER DASHBOARD: Waiting for Master Core..."
        );

        setTimeout(
            initializeMasterDashboard,
            50
        );

        return;

    }

    try {

        BKMasterDashboard.init();

    } catch (error) {

        console.error(
            "BK MASTER DASHBOARD: Initialization failed:",
            error
        );

    }

}


/* ============================================================
   GLOBAL ACCESS
============================================================ */

window.BKMasterDashboard =
    BKMasterDashboard;


/* ============================================================
   DOM STARTUP
============================================================ */

if (
    document.readyState === "loading"
) {

    document.addEventListener(
        "DOMContentLoaded",
        initializeMasterDashboard
    );

} else {

    initializeMasterDashboard();

}
/* ============================================================
   BK MASTER — RESTAURANT CONTROL MODAL
   PART 3 — PREMIUM ACTION CONFIRMATION
============================================================ */

BKMasterDashboard.restaurantControlModal =
    function () {

        let modal =
            document.getElementById(
                "bkMasterRestaurantControlModal"
            );


        if (modal) {
            return modal;
        }


        modal =
            document.createElement("div");


        modal.id =
            "bkMasterRestaurantControlModal";


        modal.className =
            "bk-master-control-modal";


        modal.innerHTML = `

            <div
                class="bk-master-control-backdrop"
                data-control-modal-close="true"
            ></div>


            <section
                class="bk-master-control-dialog"
                role="dialog"
                aria-modal="true"
                aria-labelledby="bkMasterControlTitle"
            >

                <div
                    class="bk-master-control-header"
                >

                    <div>

                        <div
                            class="bk-master-control-kicker"
                        >
                            BK MASTER CONTROL
                        </div>

                        <h2
                            id="bkMasterControlTitle"
                        >
                            Restaurant Action
                        </h2>

                    </div>


                    <button
                        type="button"
                        class="bk-master-control-close"
                        data-control-modal-close="true"
                        aria-label="Close"
                    >
                        ×
                    </button>

                </div>


                <div
                    class="bk-master-control-body"
                >

                    <div
                        class="bk-master-control-status-grid"
                    >

                        <div
                            class="bk-master-control-status-box"
                        >

                            <span>
                                CURRENT STATUS
                            </span>

                            <strong
                                id="bkMasterControlCurrentStatus"
                            >
                                —
                            </strong>

                        </div>


                        <div
                            class="bk-master-control-arrow"
                        >
                            →
                        </div>


                        <div
                            class="bk-master-control-status-box target"
                        >

                            <span>
                                TARGET STATUS
                            </span>

                            <strong
                                id="bkMasterControlTargetStatus"
                            >
                                —
                            </strong>

                        </div>

                    </div>


                    <div
                        class="bk-master-control-action-name"
                    >

                        ACTION:
                        <strong
                            id="bkMasterControlActionName"
                        >
                            —
                        </strong>

                    </div>


                    <div
                        class="bk-master-control-reason-wrap"
                    >

                        <label
                            for="bkMasterControlReason"
                        >
                            ACTION REASON
                        </label>


                        <textarea
                            id="bkMasterControlReason"
                            rows="4"
                            maxlength="500"
                            placeholder="Enter the reason for this action..."
                        ></textarea>


                        <div
                            class="bk-master-control-reason-help"
                        >
                            This reason will be used for the
                            owner notice and audit record.
                        </div>

                    </div>

                </div>


                <div
                    class="bk-master-control-footer"
                >

                    <button
                        type="button"
                        class="bk-master-control-button cancel"
                        data-control-modal-close="true"
                    >
                        CANCEL
                    </button>


                    <button
                        type="button"
                        class="bk-master-control-button review"
                        id="bkMasterControlReviewButton"
                    >
                        REVIEW ACTION
                    </button>

                </div>

            </section>

        `;


        document.body.appendChild(
            modal
        );


        /* ====================================================
           CLOSE HANDLER
        ==================================================== */

        modal.addEventListener(
            "click",
            (event) => {

                const closeTarget =
                    event.target.closest(
                        "[data-control-modal-close]"
                    );


                if (
                    closeTarget
                ) {

                    this.closeRestaurantControlModal();

                }

            }
        );


        /* ====================================================
           REVIEW BUTTON
        ==================================================== */

        const reviewButton =
            modal.querySelector(
                "#bkMasterControlReviewButton"
            );


        if (reviewButton) {

            reviewButton.addEventListener(
                "click",
                async () => {

                    await this.reviewRestaurantControlAction();

                }
            );

        }


        return modal;

    };


/* ============================================================
   OPEN CONTROL MODAL
============================================================ */

BKMasterDashboard.openRestaurantControlModal =
    async function (
        restaurantId,
        action
    ) {

        if (!restaurantId) {

            console.warn(
                "BK MASTER DASHBOARD: Restaurant ID missing."
            );

            return;

        }


        const masterControl =
            window.BKMasterRestaurantControl;


        if (
            !masterControl
        ) {

            console.error(
                "BK MASTER DASHBOARD: Restaurant Control unavailable."
            );

            return;

        }


        try {

            const firebaseSessions =
    await import(
        "../firebase-sessions.js"
    );

            const firestore =
                await import(
                    "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js"
                );


const db =
    firebaseSessions.masterDb;
            const {
                doc,
                getDoc
            } = firestore;


            const restaurantRef =
                doc(
                    db,
                    "restaurants",
                    restaurantId
                );


            const snapshot =
                await getDoc(
                    restaurantRef
                );


            if (
                !snapshot.exists()
            ) {

                window.alert(
                    "Restaurant not found."
                );

                return;

            }


            const restaurantData =
                snapshot.data();


            const currentStatus =
                masterControl.normalizeStatus(
                    restaurantData.status
                );


            const normalizedAction =
                String(
                    action || ""
                )
                .trim()
                .toUpperCase();


            const targetStatus =
                masterControl.getTargetStatus(
                    normalizedAction
                );


            if (
                normalizedAction ===
                masterControl.ACTIONS.DELETE
            ) {

                window.alert(
                    "DELETE requires the protected deletion workflow."
                );

                return;

            }


            if (
                !targetStatus
            ) {

                window.alert(
                    "Target status could not be determined."
                );

                return;

            }


            if (
                !masterControl.canPerformAction(
                    currentStatus,
                    normalizedAction
                )
            ) {

                window.alert(
                    `Action ${normalizedAction} is not allowed from ${currentStatus}.`
                );

                return;

            }


            const modal =
                this.restaurantControlModal();


            modal.dataset.restaurantId =
                restaurantId;


            modal.dataset.action =
                normalizedAction;


            modal.dataset.currentStatus =
                currentStatus;


            modal.dataset.targetStatus =
                targetStatus;


            const currentStatusElement =
                modal.querySelector(
                    "#bkMasterControlCurrentStatus"
                );


            const targetStatusElement =
                modal.querySelector(
                    "#bkMasterControlTargetStatus"
                );


            const actionElement =
                modal.querySelector(
                    "#bkMasterControlActionName"
                );


            const reasonElement =
                modal.querySelector(
                    "#bkMasterControlReason"
                );


            if (
                currentStatusElement
            ) {

                currentStatusElement.textContent =
                    currentStatus;

            }


            if (
                targetStatusElement
            ) {

                targetStatusElement.textContent =
                    targetStatus;

            }


            if (
                actionElement
            ) {

                actionElement.textContent =
                    normalizedAction;

            }


            if (
                reasonElement
            ) {

                reasonElement.value =
                    "";

            }


            modal.classList.add(
                "is-open"
            );


            document.body.classList.add(
                "bk-master-control-modal-open"
            );


            setTimeout(
                () => {

                    if (
                        reasonElement
                    ) {

                        reasonElement.focus();

                    }

                },
                100
            );


            console.log(
                "BK MASTER DASHBOARD: Control modal opened:",
                normalizedAction,
                restaurantId
            );


        } catch (error) {

            console.error(
                "BK MASTER DASHBOARD: Control modal failed:",
                error
            );

        }

    };


/* ============================================================
   CLOSE CONTROL MODAL
============================================================ */

BKMasterDashboard.closeRestaurantControlModal =
    function () {

        const modal =
            document.getElementById(
                "bkMasterRestaurantControlModal"
            );


        if (
            !modal
        ) {
            return;
        }


        modal.classList.remove(
            "is-open"
        );


        document.body.classList.remove(
            "bk-master-control-modal-open"
        );


        console.log(
            "BK MASTER DASHBOARD: Control modal closed."
        );

    };


/* ============================================================
   REVIEW CONTROL ACTION
============================================================ */

BKMasterDashboard.reviewRestaurantControlAction =
    async function () {

        const modal =
            document.getElementById(
                "bkMasterRestaurantControlModal"
            );


        if (
            !modal
        ) {
            return;

        }


        const restaurantId =
            modal.dataset.restaurantId;


        const action =
            modal.dataset.action;


        const reasonElement =
            modal.querySelector(
                "#bkMasterControlReason"
            );


        const reason =
            reasonElement
                ? reasonElement.value.trim()
                : "";


        if (
            !reason
        ) {

            window.alert(
                "A reason is required before continuing."
            );


            if (
                reasonElement
            ) {

                reasonElement.focus();

            }


            return;

        }


        const masterControl =
            window.BKMasterRestaurantControl;


        if (
            !masterControl
        ) {

            window.alert(
                "Restaurant Control is unavailable."
            );

            return;

        }


        try {

            const result =
                await masterControl.prepareAction(
                    restaurantId,
                    action,
                    reason
                );


            if (
                !result ||
                result.success !== true
            ) {

                window.alert(
                    result?.error ||
                    "Action preview failed."
                );

                return;

            }


            console.log(
                "=========================================="
            );

            console.log(
                "BK MASTER DASHBOARD: PREMIUM ACTION REVIEW"
            );

            console.log(
                "Restaurant:",
                restaurantId
            );

            console.log(
                "Previous Status:",
                result.action.previousStatus
            );

            console.log(
                "Action:",
                result.action.action
            );

            console.log(
                "Target Status:",
                result.action.targetStatus
            );

            console.log(
                "Reason:",
                result.action.reason
            );

            console.log(
                "Owner Notice Required:",
                result.action.requiresOwnerNotice
            );

            console.log(
                "Audit Log Required:",
                result.action.requiresAuditLog
            );

            console.log(
                "=========================================="
            );

this.openFinalRestaurantActionConfirmation(
    result.action
);

return;
            

        } catch (error) {

            console.error(
                "BK MASTER DASHBOARD: Action review failed:",
                error
            );


            window.alert(
                error.message ||
                "Action review failed."
            );

        }

    };
    
    /* ============================================================
   BK MASTER — FINAL RESTAURANT ACTION CONFIRMATION
   PART 4 — PROTECTED EXECUTION CONFIRMATION
============================================================ */


/* ============================================================
   OPEN FINAL CONFIRMATION
============================================================ */

BKMasterDashboard.openFinalRestaurantActionConfirmation =
    function (actionData) {

        if (!actionData) {

            console.warn(
                "BK MASTER DASHBOARD: Final action data missing."
            );

            return;

        }


        let modal =
            document.getElementById(
                "bkMasterFinalActionModal"
            );


        /* ====================================================
           CREATE MODAL ON FIRST USE
        ==================================================== */

        if (!modal) {

            modal =
                document.createElement("div");


            modal.id =
                "bkMasterFinalActionModal";


            modal.className =
                "bk-master-final-action-modal";


            modal.innerHTML = `

                <div
                    class="bk-master-final-action-backdrop"
                    data-final-action-close="true"
                ></div>


                <section
                    class="bk-master-final-action-dialog"
                    role="dialog"
                    aria-modal="true"
                    aria-labelledby="bkMasterFinalActionTitle"
                >

                    <div
                        class="bk-master-final-action-header"
                    >

                        <div>

                            <div
                                class="bk-master-final-action-kicker"
                            >
                                FINAL MASTER CONFIRMATION
                            </div>


                            <h2
                                id="bkMasterFinalActionTitle"
                            >
                                Confirm Restaurant Action
                            </h2>

                        </div>


                        <button
                            type="button"
                            class="bk-master-final-action-close"
                            data-final-action-close="true"
                            aria-label="Close"
                        >
                            ×
                        </button>

                    </div>


                    <div
                        class="bk-master-final-action-body"
                    >

                        <div
                            class="bk-master-final-warning"
                        >

                            <div
                                class="bk-master-final-warning-icon"
                            >
                                !
                            </div>


                            <div>

                                <strong>
                                    This action will change the restaurant status.
                                </strong>

                                <p>
                                    Review the information carefully
                                    before executing.
                                </p>

                            </div>

                        </div>


                        <div
                            class="bk-master-final-summary"
                        >

                            <div>
                                <span>RESTAURANT</span>
                                <strong
                                    id="bkMasterFinalRestaurantId"
                                >
                                    —
                                </strong>
                            </div>


                            <div>
                                <span>CURRENT STATUS</span>
                                <strong
                                    id="bkMasterFinalPreviousStatus"
                                >
                                    —
                                </strong>
                            </div>


                            <div>
                                <span>ACTION</span>
                                <strong
                                    id="bkMasterFinalActionName"
                                >
                                    —
                                </strong>
                            </div>


                            <div>
                                <span>TARGET STATUS</span>
                                <strong
                                    id="bkMasterFinalTargetStatus"
                                >
                                    —
                                </strong>
                            </div>


                            <div>
                                <span>REASON</span>
                                <strong
                                    id="bkMasterFinalActionReason"
                                >
                                    —
                                </strong>
                            </div>

                        </div>


                        <div
                            class="bk-master-final-protection"
                        >

                            <span>
                                PROTECTED MASTER ACTION
                            </span>

                            <p>
                                This action will create the owner notice
                                and master audit record together with
                                the restaurant status change.
                            </p>

                        </div>

                    </div>


                    <div
                        class="bk-master-final-action-footer"
                    >

                        <button
                            type="button"
                            class="bk-master-final-button cancel"
                            data-final-action-close="true"
                        >
                            CANCEL
                        </button>


                        <button
                            type="button"
                            class="bk-master-final-button execute"
                            id="bkMasterFinalExecuteButton"
                        >
                            EXECUTE ACTION
                        </button>

                    </div>

                </section>

            `;


            document.body.appendChild(
                modal
            );


            /* =================================================
               CLOSE HANDLER
            ================================================= */

            modal.addEventListener(
                "click",
                (event) => {

                    const closeTarget =
                        event.target.closest(
                            "[data-final-action-close]"
                        );


                    if (
                        closeTarget
                    ) {

                        this.closeFinalRestaurantActionConfirmation();

                    }

                }
            );


            /* =================================================
               EXECUTE HANDLER
            ================================================= */

            const executeButton =
                modal.querySelector(
                    "#bkMasterFinalExecuteButton"
                );


            if (executeButton) {

                executeButton.addEventListener(
                    "click",
                    async () => {

                        await this.executeFinalRestaurantAction();

                    }
                );

            }

        }


        /* ====================================================
           STORE ACTION DATA
        ==================================================== */

        modal._bkActionData =
            {
                ...actionData
            };


        /* ====================================================
           FILL DATA
        ==================================================== */

        const restaurantElement =
            modal.querySelector(
                "#bkMasterFinalRestaurantId"
            );


        const previousStatusElement =
            modal.querySelector(
                "#bkMasterFinalPreviousStatus"
            );


        const actionElement =
            modal.querySelector(
                "#bkMasterFinalActionName"
            );


        const targetStatusElement =
            modal.querySelector(
                "#bkMasterFinalTargetStatus"
            );


        const reasonElement =
            modal.querySelector(
                "#bkMasterFinalActionReason"
            );


        if (restaurantElement) {

            restaurantElement.textContent =
                actionData.restaurantId || "—";

        }


        if (previousStatusElement) {

            previousStatusElement.textContent =
                actionData.previousStatus || "—";

        }


        if (actionElement) {

            actionElement.textContent =
                actionData.action || "—";

        }


        if (targetStatusElement) {

            targetStatusElement.textContent =
                actionData.targetStatus || "—";

        }


        if (reasonElement) {

            reasonElement.textContent =
                actionData.reason || "—";

        }


        /* ====================================================
           OPEN MODAL
        ==================================================== */

        modal.classList.add(
            "is-open"
        );


        document.body.classList.add(
            "bk-master-final-action-open"
        );


        console.log(
            "BK MASTER DASHBOARD: Final confirmation opened."
        );

        console.log(
            "Restaurant:",
            actionData.restaurantId
        );

        console.log(
            "Action:",
            actionData.action
        );

        console.log(
            "Target Status:",
            actionData.targetStatus
        );

    };


/* ============================================================
   CLOSE FINAL CONFIRMATION
============================================================ */

BKMasterDashboard.closeFinalRestaurantActionConfirmation =
    function () {

        const modal =
            document.getElementById(
                "bkMasterFinalActionModal"
            );


        if (!modal) {

            return;

        }


        modal.classList.remove(
            "is-open"
        );


        document.body.classList.remove(
            "bk-master-final-action-open"
        );


        console.log(
            "BK MASTER DASHBOARD: Final confirmation closed."
        );

    };


/* ============================================================
   EXECUTE FINAL RESTAURANT ACTION
============================================================ */

BKMasterDashboard.executeFinalRestaurantAction =
    async function () {

        const modal =
            document.getElementById(
                "bkMasterFinalActionModal"
            );


        if (!modal) {

            console.warn(
                "BK MASTER DASHBOARD: Final confirmation modal not found."
            );

            return;

        }


        const actionData =
            modal._bkActionData;


        if (!actionData) {

            window.alert(
                "Action data is unavailable."
            );

            return;

        }


        const executeButton =
            modal.querySelector(
                "#bkMasterFinalExecuteButton"
            );


        if (executeButton) {

            executeButton.disabled =
                true;

            executeButton.textContent =
                "EXECUTING...";

        }


        try {

            const masterControl =
                window.BKMasterRestaurantControl;


            if (
                !masterControl
            ) {

                throw new Error(
                    "Restaurant Control is unavailable."
                );

            }


            console.log(
                "=========================================="
            );

            console.log(
                "BK MASTER DASHBOARD: EXECUTING FINAL ACTION"
            );

            console.log(
                "=========================================="
            );


            const result =
                await masterControl.executeAction(
                    actionData.restaurantId,
                    actionData.action,
                    actionData.reason
                );


            if (
                !result ||
                result.success !== true
            ) {

                throw new Error(
                    result?.error ||
                    "Restaurant action execution failed."
                );

            }


            console.log(
                "BK MASTER DASHBOARD: FINAL ACTION SUCCESS"
            );


            console.log(
                "Restaurant:",
                result.restaurantId
            );


            console.log(
                "Status:",
                result.previousStatus,
                "→",
                result.newStatus
            );


            console.log(
                "Notice ID:",
                result.noticeId
            );


            console.log(
                "Audit ID:",
                result.auditId
            );


            this.closeFinalRestaurantActionConfirmation();

            this.closeRestaurantControlModal();


            /*
               Refresh dashboard cards and statistics
               so the new status becomes visible immediately.
            */

            await this.loadRestaurantData();

            await this.loadRestaurantCards();


            window.alert(
                "Restaurant action executed successfully."
            );


        } catch (error) {

            console.error(
                "BK MASTER DASHBOARD: Final action execution failed:",
                error
            );


            window.alert(
                error.message ||
                "Restaurant action execution failed."
            );


        } finally {

            if (executeButton) {

                executeButton.disabled =
                    false;

                executeButton.textContent =
                    "EXECUTE ACTION";

            }

        }

    };


/* ============================================================
   FINAL CONFIRMATION ESCAPE KEY
============================================================ */

document.addEventListener(
    "keydown",
    (event) => {

        if (
            event.key !== "Escape"
        ) {

            return;

        }


        const modal =
            document.getElementById(
                "bkMasterFinalActionModal"
            );


        if (
            modal &&
            modal.classList.contains(
                "is-open"
            )
        ) {

            BKMasterDashboard
                .closeFinalRestaurantActionConfirmation();

        }

    }
);


console.log(
    "BK MASTER DASHBOARD: Final action confirmation engine loaded."
);