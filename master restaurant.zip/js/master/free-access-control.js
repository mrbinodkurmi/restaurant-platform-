// ============================================================
// BK FREE ACCESS CONTROL
// File: js/master/free-access-control.js
// Version: 1.1.0
// ============================================================

window.BKFreeAccessControl = (() => {
  "use strict";

  const VERSION = "1.1.0";

  const STATUS = Object.freeze({
    NOT_GRANTED: "NOT_GRANTED",
    ACTIVE: "ACTIVE",
    EXPIRED: "EXPIRED",
    ENDED: "ENDED"
  });

  function normalizeId(value) {
    return typeof value === "string" ? value.trim() : "";
  }

  function parseDate(value) {
    if (!value) return null;

    let date;

    if (value instanceof Date) {
      date = new Date(value.getTime());
    } else if (typeof value.toDate === "function") {
      date = value.toDate();
    } else {
      date = new Date(value);
    }

    return Number.isNaN(date.getTime()) ? null : date;
  }

  function addCalendarMonths(date, months) {
    const result = new Date(date.getTime());
    const originalDay = result.getDate();

    result.setDate(1);
    result.setMonth(result.getMonth() + months);

    const lastDay = new Date(
      result.getFullYear(),
      result.getMonth() + 1,
      0
    ).getDate();

    result.setDate(Math.min(originalDay, lastDay));

    return result;
  }

  function validateGrant(data = {}) {
    const restaurantId = normalizeId(data.restaurantId);
    const reason = normalizeId(data.reason);
    const durationMonths = Number(data.durationMonths);

    if (!restaurantId) {
      return {
        valid: false,
        error: "Restaurant ID is required."
      };
    }

    if (!reason) {
      return {
        valid: false,
        error: "Free Access reason is required."
      };
    }

    if (
      !Number.isInteger(durationMonths) ||
      durationMonths < 1 ||
      durationMonths > 12
    ) {
      return {
        valid: false,
        error: "Duration must be between 1 and 12 months."
      };
    }

    return {
      valid: true,
      data: {
        restaurantId,
        reason,
        durationMonths
      }
    };
  }

  function createGrantRecord(data = {}, now = new Date()) {
    const validation = validateGrant(data);

    if (!validation.valid) {
      return {
        success: false,
        error: validation.error
      };
    }

    const startDate = parseDate(now);

    if (!startDate) {
      return {
        success: false,
        error: "Invalid start date."
      };
    }

    const expiryDate = addCalendarMonths(
      startDate,
      validation.data.durationMonths
    );

    return {
      success: true,
      record: {
        restaurantId: validation.data.restaurantId,
        freeAccessStatus: STATUS.ACTIVE,
        freeAccessStartAt: startDate,
        freeAccessExpiresAt: expiryDate,
        freeAccessDurationMonths:
          validation.data.durationMonths,
        freeAccessReason: validation.data.reason
      }
    };
  }

  function getStatus(record = {}, now = new Date()) {
    if (record.freeAccessStatus === STATUS.ENDED) {
      return STATUS.ENDED;
    }

    if (record.freeAccessStatus !== STATUS.ACTIVE) {
      return STATUS.NOT_GRANTED;
    }

    const expiryDate = parseDate(record.freeAccessExpiresAt);
    const currentDate = parseDate(now);

    if (!expiryDate || !currentDate) {
      return STATUS.EXPIRED;
    }

    return currentDate.getTime() >= expiryDate.getTime()
      ? STATUS.EXPIRED
      : STATUS.ACTIVE;
  }

  function getRemainingMilliseconds(record = {}, now = new Date()) {
    if (getStatus(record, now) !== STATUS.ACTIVE) {
      return 0;
    }

    const expiryDate = parseDate(record.freeAccessExpiresAt);
    const currentDate = parseDate(now);

    return Math.max(
      0,
      expiryDate.getTime() - currentDate.getTime()
    );
  }


async function getFirebaseModules() {

  const firebase = await import(
    "../firebase-sessions.js"
  );

  if (
    !firebase.masterDb ||
    !firebase.masterAuth
  ) {
    throw new Error(
      "BK MASTER FIREBASE SESSION IS UNAVAILABLE."
    );
  }

  const firestore = await import(
    "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js"
  );

  return {
    db: firebase.masterDb,
    auth: firebase.masterAuth,
    doc: firestore.doc,
    getDoc: firestore.getDoc,
    setDoc: firestore.setDoc,
    updateDoc: firestore.updateDoc,
    Timestamp: firestore.Timestamp,
    serverTimestamp: firestore.serverTimestamp
  };
}

  async function requireMaster(auth) {
    const user = auth?.currentUser;

    if (!user?.uid) {
      throw new Error(
        "Sign in with the authorized Master account first."
      );
    }

    const master = window.BKMaster;

    if (
      master?.state &&
      master.state.authorized === false
    ) {
      throw new Error(
        "The current account is not authorized as Master."
      );
    }

    return user;
  }

  async function loadRestaurant(db, doc, getDoc, restaurantId) {
    const restaurantRef = doc(
      db,
      "restaurants",
      restaurantId
    );

    const snapshot = await getDoc(restaurantRef);

    if (!snapshot.exists()) {
      throw new Error("Restaurant record was not found.");
    }

    const restaurant = snapshot.data();
    const ownerId = normalizeId(restaurant.ownerId);

    if (!ownerId) {
      throw new Error(
        "The restaurant record has no valid owner ID."
      );
    }

    return {
      restaurantRef,
      restaurant,
      ownerId
    };
  }

  async function loadFreeAccess(restaurantId) {
    restaurantId = normalizeId(restaurantId);

    if (!restaurantId) {
      throw new Error("Restaurant ID is required.");
    }

    const {
      db,
      auth,
      doc,
      getDoc
    } = await getFirebaseModules();

    await requireMaster(auth);

    const snapshot = await getDoc(
      doc(db, "restaurantFreeAccess", restaurantId)
    );

    if (!snapshot.exists()) {
      return {
        restaurantId,
        freeAccessStatus: STATUS.NOT_GRANTED
      };
    }

    const record = snapshot.data();

    return {
      ...record,
      effectiveStatus: getStatus(record)
    };
  }

  async function grantFreeAccess(data = {}) {
    const validation = validateGrant(data);

    if (!validation.valid) {
      throw new Error(validation.error);
    }

    const {
      db,
      auth,
      doc,
      getDoc,
      setDoc,
      updateDoc,
      Timestamp,
      serverTimestamp
    } = await getFirebaseModules();

    const masterUser = await requireMaster(auth);

    const {
      ownerId
    } = await loadRestaurant(
      db,
      doc,
      getDoc,
      validation.data.restaurantId
    );

    const restaurantId = validation.data.restaurantId;

    const accessRef = doc(
      db,
      "restaurantFreeAccess",
      restaurantId
    );

    const existingSnapshot = await getDoc(accessRef);

    const now = new Date();

    const grant = createGrantRecord({
      restaurantId,
      durationMonths: validation.data.durationMonths,
      reason: validation.data.reason
    }, now);

    if (!grant.success) {
      throw new Error(grant.error);
    }

    const record = {
      ...grant.record,
      ownerId,
      freeAccessStartAt: Timestamp.fromDate(
        grant.record.freeAccessStartAt
      ),
      freeAccessExpiresAt: Timestamp.fromDate(
        grant.record.freeAccessExpiresAt
      ),
      freeAccessGrantedBy: existingSnapshot.exists()
        ? existingSnapshot.data().freeAccessGrantedBy
        : masterUser.uid,
      freeAccessUpdatedAt: serverTimestamp()
    };

    if (existingSnapshot.exists()) {
      await updateDoc(accessRef, record);
    } else {
      await setDoc(accessRef, record);
    }

    console.log(
      "[BK Free Access] GRANT SAVED:",
      restaurantId
    );

    return {
      success: true,
      restaurantId,
      freeAccessStatus: STATUS.ACTIVE,
      freeAccessExpiresAt: grant.record.freeAccessExpiresAt
    };
  }

  async function endFreeAccess(restaurantId) {
    restaurantId = normalizeId(restaurantId);

    if (!restaurantId) {
      throw new Error("Restaurant ID is required.");
    }

    const {
      db,
      auth,
      doc,
      getDoc,
      updateDoc,
      serverTimestamp
    } = await getFirebaseModules();

    await requireMaster(auth);

    const accessRef = doc(
      db,
      "restaurantFreeAccess",
      restaurantId
    );

    const snapshot = await getDoc(accessRef);

    if (!snapshot.exists()) {
      throw new Error(
        "No Free Access record exists for this restaurant."
      );
    }

    const record = snapshot.data();

    if (record.freeAccessStatus !== STATUS.ACTIVE) {
      throw new Error(
        "This Free Access record is not active."
      );
    }

    await updateDoc(accessRef, {
      freeAccessStatus: STATUS.ENDED,
      freeAccessUpdatedAt: serverTimestamp()
    });

    console.log(
      "[BK Free Access] ACCESS ENDED:",
      restaurantId
    );

    return {
      success: true,
      restaurantId,
      freeAccessStatus: STATUS.ENDED
    };
  }

  function selfTest() {
    const fixedNow = new Date(
      "2026-01-31T12:00:00.000Z"
    );

    const grant = createGrantRecord({
      restaurantId: "BK-TEST-001",
      durationMonths: 1,
      reason: "Testing Free Access"
    }, fixedNow);

    if (!grant.success) {
      return {
        success: false,
        error: grant.error
      };
    }

    const activeStatus = getStatus(
      grant.record,
      new Date("2026-02-15T12:00:00.000Z")
    );

    const expiredStatus = getStatus(
      grant.record,
      new Date("2026-03-01T12:00:00.000Z")
    );

    const passed =
      activeStatus === STATUS.ACTIVE &&
      expiredStatus === STATUS.EXPIRED &&
      grant.record.freeAccessExpiresAt.getUTCMonth() === 1 &&
      grant.record.freeAccessExpiresAt.getUTCDate() === 28;

    return {
      success: passed,
      tests: {
        grantRecordCreated: grant.success,
        activeBeforeExpiry: activeStatus === STATUS.ACTIVE,
        expiredAfterExpiry: expiredStatus === STATUS.EXPIRED,
        monthEndHandledCorrectly:
          grant.record.freeAccessExpiresAt.getUTCMonth() === 1 &&
          grant.record.freeAccessExpiresAt.getUTCDate() === 28
      }
    };
  }

  console.log(
    "[BK Free Access] Module loaded:",
    VERSION
  );

  return Object.freeze({
    VERSION,
    STATUS,
    validateGrant,
    createGrantRecord,
    getStatus,
    getRemainingMilliseconds,
    loadFreeAccess,
    grantFreeAccess,
    endFreeAccess,
    selfTest
  });
})();

console.log(
  "[BK Free Access Test]",
  window.BKFreeAccessControl.selfTest()
);