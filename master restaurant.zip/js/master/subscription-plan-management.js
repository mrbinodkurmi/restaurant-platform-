/* =========================================================
   BK MASTER — SUBSCRIPTION PLAN MANAGEMENT
   Part 2 — Plan Creation & Management Foundation
   Version 1.2.0
   ========================================================= */

import {
    masterAuth as auth,
    masterDb as db
} from "../firebase-sessions.js";

import {
  collection,
  doc,
  getDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  writeBatch,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";

window.BKMasterSubscriptionPlanManagement = (() => {

  const COLLECTION_NAME =
    "subscriptionPlans";

  const ENTITLEMENT_COLLECTION_NAME =
    "planEntitlements";


  /*
   * BK PLAN ENTITLEMENT FOUNDATION
   *
   * Central default entitlement registry.
   *
   * IMPORTANT:
   * - Plan names are display labels only.
   * - entitlementKey is the stable access identity.
   * - Owner feature code must not depend on plan names.
   * - Master overrides can later change feature access
   *   without changing owner feature code.
   */

  const DEFAULT_PLAN_ENTITLEMENTS = {

    SILVER: {

      foodImageUrl: true,

      foodImageStorageUpload: false,

      advancedBooking: false,

      tableBooking: false

    },


    GOLD: {

      foodImageUrl: true,

      foodImageStorageUpload: true,

      advancedBooking: true,

      tableBooking: true

    },


    DIAMOND: {

      foodImageUrl: true,

      foodImageStorageUpload: true,

      advancedBooking: true,

      tableBooking: true

    }

  };


  const state = {

    initialized: false,

    ready: false,

    saving: false,

    editing: false,

    editingPlanId: null,

    editingEntitlementKey: null,

    error: null

  };


  /* =======================================================
     INTERNAL HELPERS
     ======================================================= */

  function log(...args) {

    console.log(
      "BK MASTER SUBSCRIPTION PLAN MANAGEMENT:",
      ...args
    );

  }


  function warn(...args) {

    console.warn(
      "BK MASTER SUBSCRIPTION PLAN MANAGEMENT:",
      ...args
    );

  }


  function error(...args) {

    console.error(
      "BK MASTER SUBSCRIPTION PLAN MANAGEMENT:",
      ...args
    );

  }


  function escapeHTML(value) {

    return String(value ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");

  }


  function getSubscriptionSection() {

    return document.getElementById(
      "masterSectionSubscription"
    );

  }


  function getForm() {

    return document.getElementById(
      "bkMasterSubscriptionPlanForm"
    );

  }


  function getField(id) {

    return document.getElementById(id);

  }


  /* =======================================================
     MASTER AUTHORIZATION
     ======================================================= */

  async function verifyMasterAccess() {

    try {

      const currentUser =
        auth.currentUser;


      if (!currentUser) {

        warn(
          "MASTER USER NOT READY"
        );

        return false;

      }


      if (
        window.BKMaster &&
        window.BKMaster.state &&
        window.BKMaster.state.authorized === true
      ) {

        return true;

      }


      warn(
        "MASTER CORE AUTHORIZATION NOT READY"
      );

      return false;

    } catch (err) {

      error(
        "MASTER ACCESS CHECK FAILED:",
        err
      );

      return false;

    }

  }


  /* =======================================================
     PLAN ID GENERATOR
     ======================================================= */

  function createPlanId(planName) {

    const cleanName =
      String(planName || "PLAN")
        .trim()
        .toUpperCase()
        .replace(/[^A-Z0-9]+/g, "-")
        .replace(/^-+|-+$/g, "")
        .slice(0, 24) ||
      "PLAN";


    const now =
      new Date();


    const datePart =
      [
        now.getFullYear(),
        String(
          now.getMonth() + 1
        ).padStart(2, "0"),
        String(
          now.getDate()
        ).padStart(2, "0")
      ].join("");


    const randomPart =
      Math.random()
        .toString(36)
        .substring(2, 7)
        .toUpperCase();


    return `${cleanName}-${datePart}-${randomPart}`;

  }


  /* =======================================================
     PLAN MANAGEMENT UI
     ======================================================= */

  function renderManagementUI() {

    const section =
      getSubscriptionSection();


    if (!section) {

      warn(
        "Subscription section not found"
      );

      return;

    }


    const existingPanel =
      section.querySelector(
        ".bk-master-subscription-management"
      );


    if (existingPanel) {

      return;

    }


    const management =
      document.createElement("div");


    management.className =
      "bk-master-subscription-management";


    management.innerHTML = `

      <div class="bk-master-subscription-management-inner">

        <div class="bk-master-subscription-management-header">

          <div>

            <h2 id="bkMasterSubscriptionFormTitle">
              Subscription Plan Management
            </h2>

            <p>
              Create configurable subscription plans
              for BK restaurants.
            </p>

          </div>

          <div class="bk-master-subscription-management-badge">
            MASTER CONTROL
          </div>

        </div>


        <form
          id="bkMasterSubscriptionPlanForm"
          class="bk-master-subscription-plan-form"
          novalidate
        >

          <div class="bk-master-subscription-form-grid">


            <!-- PLAN NAME -->

            <div class="bk-master-subscription-field">

              <label
                for="bkMasterPlanName"
              >
                Plan Name
              </label>

              <input
                id="bkMasterPlanName"
                name="planName"
                type="text"
                maxlength="80"
                placeholder="Example: Silver"
                autocomplete="off"
                required
              >

            </div>


            <!-- ENTITLEMENT TIER -->

            <div class="bk-master-subscription-field">

              <label
                for="bkMasterPlanEntitlementKey"
              >
                Entitlement Tier
              </label>

              <select
                id="bkMasterPlanEntitlementKey"
                name="entitlementKey"
                required
              >

                <option value="">
                  Select entitlement tier
                </option>

                <option value="SILVER">
                  SILVER
                </option>

                <option value="GOLD">
                  GOLD
                </option>

                <option value="DIAMOND">
                  DIAMOND
                </option>

              </select>

              <small>
                Controls the centralized feature access for this plan.
              </small>

            </div>


            <!-- CURRENCY -->

            <div class="bk-master-subscription-field">

              <label
                for="bkMasterPlanCurrency"
              >
                Currency
              </label>

              <input
                id="bkMasterPlanCurrency"
                name="currency"
                type="text"
                value="INR"
                maxlength="10"
                autocomplete="off"
                required
              >

            </div>


            <!-- BASE AMOUNT -->

            <div class="bk-master-subscription-field">

           <label
  for="bkMasterPlanBaseAmount"
>
  One-Time Activation Amount (₹)
</label>
              <input
                id="bkMasterPlanBaseAmount"
                name="baseAmount"
                type="number"
                min="0"
                step="0.01"
                placeholder="0"
                inputmode="decimal"
                required
              >

            </div>


            <!-- MINIMUM AMOUNT -->

            <div class="bk-master-subscription-field">

              <label
                for="bkMasterPlanMinimumAmount"
              >
                Minimum Amount
              </label>

              <input
                id="bkMasterPlanMinimumAmount"
                name="minimumAmount"
                type="number"
                min="0"
                step="0.01"
                placeholder="0"
                inputmode="decimal"
                required
              >

            </div>


            <!-- MAXIMUM AMOUNT -->

            <div class="bk-master-subscription-field">

              <label
                for="bkMasterPlanMaximumAmount"
              >
                Maximum Amount
              </label>

              <input
                id="bkMasterPlanMaximumAmount"
                name="maximumAmount"
                type="number"
                min="0"
                step="0.01"
                placeholder="0"
                inputmode="decimal"
                required
              >

            </div>


            <!-- BILLING CYCLE -->

            <div class="bk-master-subscription-field">

              <label
                for="bkMasterPlanBillingCycle"
              >
                Billing Cycle
              </label>

              <select
                id="bkMasterPlanBillingCycle"
                name="billingCycle"
                required
              >

                <option value="MONTHLY">
                  Monthly
                </option>

                <option value="QUARTERLY">
                  Quarterly
                </option>

                <option value="YEARLY">
                  Yearly
                </option>

              </select>

            </div>


            <!-- STATUS -->

            <div class="bk-master-subscription-field">

              <label
                for="bkMasterPlanStatus"
              >
                Status
              </label>

              <select
                id="bkMasterPlanStatus"
                name="status"
                required
              >

                <option value="ACTIVE">
                  ACTIVE
                </option>

                <option value="INACTIVE">
                  INACTIVE
                </option>

              </select>

            </div>


            <!-- USAGE PRICING -->

            <div class="bk-master-subscription-field">

              <label
                for="bkMasterPlanUsagePricing"
              >
                Usage Pricing
              </label>

              <select
                id="bkMasterPlanUsagePricing"
                name="usagePricingEnabled"
                required
              >

                <option value="false">
                  Disabled
                </option>

                <option value="true">
                  Enabled
                </option>

              </select>

            </div>


            <!-- DESCRIPTION -->

            <div
              class="bk-master-subscription-field bk-master-subscription-field-full"
            >

              <label
                for="bkMasterPlanDescription"
              >
                Description
              </label>

              <textarea
                id="bkMasterPlanDescription"
                name="description"
                maxlength="500"
                rows="4"
                placeholder="Describe what this subscription plan includes."
              ></textarea>

            </div>


          </div>


          <div
            id="bkMasterSubscriptionPlanFormMessage"
            class="bk-master-subscription-form-message"
            aria-live="polite"
          ></div>


          <div class="bk-master-subscription-form-actions">

            <button
              type="submit"
              id="bkMasterCreateSubscriptionPlan"
              class="bk-master-subscription-create-button"
            >
              Create Subscription Plan
            </button>


            <button
              type="button"
              id="bkMasterCancelSubscriptionPlanEdit"
              class="bk-master-subscription-cancel-button"
              hidden
            >
              Cancel Edit
            </button>

          </div>

        </form>

      </div>

    `;


    section.prepend(
      management
    );


    bindForm();

    bindCancelEdit();

    log(
      "Plan Management UI: READY"
    );

  }


  /* =======================================================
     FORM HELPERS
     ======================================================= */

  function getFormValues(form) {

    const formData =
      new FormData(form);


    const planName =
      String(
        formData.get("planName") || ""
      ).trim();


    const description =
      String(
        formData.get("description") || ""
      ).trim();


    /*
     * IMPORTANT:
     * Disabled entitlement selector is excluded
     * from FormData during edit mode.
     *
     * Create → read from form.
     * Edit → use the locked state value.
     */

    const formEntitlementKey =
      String(
        formData.get("entitlementKey") || ""
      )
        .trim()
        .toUpperCase();


    const entitlementKey =
      formEntitlementKey ||
      String(
        state.editingEntitlementKey || ""
      )
        .trim()
        .toUpperCase();


    const currency =
      String(
        formData.get("currency") || "INR"
      )
        .trim()
        .toUpperCase();


    const baseAmount =
      Number(
        formData.get("baseAmount")
      );


    const minimumAmount =
      Number(
        formData.get("minimumAmount")
      );


    const maximumAmount =
      Number(
        formData.get("maximumAmount")
      );


    const billingCycle =
      String(
        formData.get("billingCycle") || ""
      )
        .trim()
        .toUpperCase();


    const status =
      String(
        formData.get("status") || ""
      )
        .trim()
        .toUpperCase();


    const usagePricingEnabled =
      String(
        formData.get("usagePricingEnabled")
      ) === "true";


    return {

      planName,

      description,

      entitlementKey,

      currency,

      baseAmount,

      minimumAmount,

      maximumAmount,

      billingCycle,

      usagePricingEnabled,

      status

    };

  }


  function validatePlan(data) {

    if (!data.planName) {

      return "Plan name is required.";

    }


    if (data.planName.length > 80) {

      return "Plan name is too long.";

    }


    if (!data.entitlementKey) {

      return "Entitlement tier is required.";

    }


    if (
      !Object.prototype.hasOwnProperty.call(
        DEFAULT_PLAN_ENTITLEMENTS,
        data.entitlementKey
      )
    ) {

      return "Invalid entitlement tier.";

    }


    if (!Number.isFinite(data.baseAmount)) {

      return "Base amount is required.";

    }


    if (!Number.isFinite(data.minimumAmount)) {

      return "Minimum amount is required.";

    }


    if (!Number.isFinite(data.maximumAmount)) {

      return "Maximum amount is required.";

    }


    if (
      data.baseAmount < 0 ||
      data.minimumAmount < 0 ||
      data.maximumAmount < 0
    ) {

      return "Amounts cannot be negative.";

    }


    if (
      data.minimumAmount >
      data.maximumAmount
    ) {

      return "Minimum amount cannot be greater than maximum amount.";

    }


    if (
      data.baseAmount <
      data.minimumAmount ||
      data.baseAmount >
      data.maximumAmount
    ) {

      return "Base amount must be between minimum and maximum amount.";

    }


    if (!data.billingCycle) {

      return "Billing cycle is required.";

    }


    if (!data.status) {

      return "Plan status is required.";

    }


    return null;

  }


  function setFormMessage(
    message,
    type = "info"
  ) {

    const element =
      document.getElementById(
        "bkMasterSubscriptionPlanFormMessage"
      );


    if (!element) {

      return;

    }


    element.textContent =
      message || "";


    element.dataset.type =
      type;

  }


  /* =======================================================
     FORM RESET
     ======================================================= */

  function resetForm() {

    const form =
      getForm();


    if (!form) {

      return;

    }


    form.reset();


    const entitlementKeyField =
      getField(
        "bkMasterPlanEntitlementKey"
      );


    if (entitlementKeyField) {

      entitlementKeyField.disabled =
        false;

      entitlementKeyField.value =
        "";

    }


    const currency =
      getField(
        "bkMasterPlanCurrency"
      );


    if (currency) {

      currency.value =
        "INR";

    }


    const title =
      getField(
        "bkMasterSubscriptionFormTitle"
      );


    if (title) {

      title.textContent =
        "Subscription Plan Management";

    }


    const button =
      getField(
        "bkMasterCreateSubscriptionPlan"
      );


    if (button) {

      button.textContent =
        "Create Subscription Plan";

    }


    const cancelButton =
      getField(
        "bkMasterCancelSubscriptionPlanEdit"
      );


    if (cancelButton) {

      cancelButton.hidden =
        true;

    }


    state.editing =
      false;

    state.editingPlanId =
      null;

    state.editingEntitlementKey =
      null;

  }


  /* =======================================================
     CREATE PLAN
     ======================================================= */

  async function createPlan(data) {

    if (state.saving) {

      return false;

    }


    state.saving =
      true;

    state.error =
      null;


    try {

      const authorized =
        await verifyMasterAccess();


      if (!authorized) {

        throw new Error(
          "Master authorization is not ready."
        );

      }


      const validationError =
        validatePlan(data);


      if (validationError) {

        throw new Error(
          validationError
        );

      }


      log(
        "Creating subscription plan..."
      );


      /*
       * -------------------------------------------------------
       * PLAN ID
       * -------------------------------------------------------
       */

      const planId =
        createPlanId(
          data.planName
        );


      const planRef =
        doc(
          db,
          COLLECTION_NAME,
          planId
        );


      /*
       * -------------------------------------------------------
       * CENTRAL PLAN DATA
       *
       * entitlementKey is the stable access identity.
       * Plan name is display-only.
       * -------------------------------------------------------
       */

      const planData = {

        planId,

        name:
          data.planName,

        description:
          data.description,

        entitlementKey:
          data.entitlementKey,

        baseAmount:
          data.baseAmount,

        minimumAmount:
          data.minimumAmount,

        maximumAmount:
          data.maximumAmount,

        currency:
          data.currency,

        billingCycle:
          data.billingCycle,

        usagePricingEnabled:
          data.usagePricingEnabled,

        status:
          data.status,

        createdAt:
          serverTimestamp(),

        updatedAt:
          serverTimestamp(),

        updatedBy:
          auth.currentUser.uid

      };


      /*
       * -------------------------------------------------------
       * CENTRAL ENTITLEMENT REGISTRY
       * -------------------------------------------------------
       */

const entitlementRef =
        doc(
          db,
          ENTITLEMENT_COLLECTION_NAME,
          planId
        );


      const selectedEntitlements =
        DEFAULT_PLAN_ENTITLEMENTS[
          data.entitlementKey
        ];


      if (!selectedEntitlements) {

        throw new Error(
          "Default entitlement configuration is missing."
        );

      }


      const batch =
        writeBatch(db);


      batch.set(
        planRef,
        planData
      );


      batch.set(
        entitlementRef,
        {

          planId,

          planName:
            data.planName,

          entitlementKey:
            data.entitlementKey,

          features:
            selectedEntitlements,

          source:
            "MASTER_ENTITLEMENT_REGISTRY",

          masterOverrideEnabled:
            true,

          createdAt:
            serverTimestamp(),

          updatedAt:
            serverTimestamp(),

          updatedBy:
            auth.currentUser.uid

        }
      );


      await batch.commit();


      log(
        "ATOMIC PLAN + ENTITLEMENT CREATED:",
        planId,
        data.entitlementKey
      );


      log(
        "Subscription plan created:",
        planId
      );


      return {

        success: true,

        planId

      };


    } catch (err) {

      state.error =
        err;


      error(
        "SUBSCRIPTION PLAN CREATE FAILED:",
        err
      );


      return {

        success: false,

        error: err

      };


    } finally {

      state.saving =
        false;

    }

  }


  /* =======================================================
     UPDATE PLAN
     ======================================================= */
       async function updatePlan(
    planId,
    data
  ) {

    if (state.saving) {

      return false;

    }


    if (!planId) {

      return {

        success: false,

        error: new Error(
          "Plan ID is missing."
        )

      };

    }


    state.saving =
      true;

    state.error =
      null;


    try {

      const authorized =
        await verifyMasterAccess();


      if (!authorized) {

        throw new Error(
          "Master authorization is not ready."
        );

      }


      const validationError =
        validatePlan(data);


      if (validationError) {

        throw new Error(
          validationError
        );

      }


      const planRef =
        doc(
          db,
          COLLECTION_NAME,
          planId
        );


      await updateDoc(
        planRef,
        {

          name:
            data.planName,

          description:
            data.description,

          baseAmount:
            data.baseAmount,

          minimumAmount:
            data.minimumAmount,

          maximumAmount:
            data.maximumAmount,

          currency:
            data.currency,

          billingCycle:
            data.billingCycle,

          usagePricingEnabled:
            data.usagePricingEnabled,

          status:
            data.status,

          updatedAt:
            serverTimestamp(),

          updatedBy:
            auth.currentUser.uid

        }
      );


      log(
        "Subscription plan updated:",
        planId
      );


      return {

        success: true,

        planId

      };


    } catch (err) {

      state.error =
        err;


      error(
        "SUBSCRIPTION PLAN UPDATE FAILED:",
        err
      );


      return {

        success: false,

        error: err

      };

    } finally {

      state.saving =
        false;

    }

  }


  /* =======================================================
     LOAD PLAN INTO FORM
     ======================================================= */

  function editPlan(plan) {

    if (!plan || !plan.planId) {

      warn(
        "Invalid plan supplied for editing."
      );

      return false;

    }


    const fields = {

      name:
        getField(
          "bkMasterPlanName"
        ),

      currency:
        getField(
          "bkMasterPlanCurrency"
        ),

      baseAmount:
        getField(
          "bkMasterPlanBaseAmount"
        ),

      minimumAmount:
        getField(
          "bkMasterPlanMinimumAmount"
        ),

      maximumAmount:
        getField(
          "bkMasterPlanMaximumAmount"
        ),

      billingCycle:
        getField(
          "bkMasterPlanBillingCycle"
        ),

      status:
        getField(
          "bkMasterPlanStatus"
        ),

      usagePricing:
        getField(
          "bkMasterPlanUsagePricing"
        ),

      description:
        getField(
          "bkMasterPlanDescription"
        ),

      entitlementKey:
        getField(
          "bkMasterPlanEntitlementKey"
        )

    };


    if (fields.name) {

      fields.name.value =
        plan.name || "";

    }


    if (fields.currency) {

      fields.currency.value =
        plan.currency || "INR";

    }


    if (fields.baseAmount) {

      fields.baseAmount.value =
        plan.baseAmount ?? "";

    }


    if (fields.minimumAmount) {

      fields.minimumAmount.value =
        plan.minimumAmount ?? "";

    }


    if (fields.maximumAmount) {

      fields.maximumAmount.value =
        plan.maximumAmount ?? "";

    }


    if (fields.billingCycle) {

      fields.billingCycle.value =
        plan.billingCycle || "MONTHLY";

    }


    if (fields.status) {

      fields.status.value =
        plan.status || "ACTIVE";

    }


    if (fields.usagePricing) {

      fields.usagePricing.value =
        String(
          plan.usagePricingEnabled === true
        );

    }


    if (fields.description) {

      fields.description.value =
        plan.description || "";

    }


    state.editingEntitlementKey =
      String(
        plan.entitlementKey || ""
      )
        .trim()
        .toUpperCase();


    if (fields.entitlementKey) {

      fields.entitlementKey.value =
        state.editingEntitlementKey;

      fields.entitlementKey.disabled =
        true;

    }


    state.editing =
      true;

    state.editingPlanId =
      plan.planId;


    const title =
      getField(
        "bkMasterSubscriptionFormTitle"
      );


    if (title) {

      title.textContent =
        `Edit Subscription Plan — ${plan.name || plan.planId}`;

    }


    const button =
      getField(
        "bkMasterCreateSubscriptionPlan"
      );


    if (button) {

      button.textContent =
        "Update Subscription Plan";

    }


    const cancelButton =
      getField(
        "bkMasterCancelSubscriptionPlanEdit"
      );


    if (cancelButton) {

      cancelButton.hidden =
        false;

    }


    setFormMessage(
      `Editing ${plan.name || "plan"} (${plan.planId})`,
      "info"
    );


    log(
      "EDIT MODE:",
      plan.planId
    );


    return true;

  }


  /* =======================================================
     PLAN STATUS CONTROL
     ENABLE / DISABLE
     ======================================================= */

  async function setPlanStatus(
    plan,
    targetStatus
  ) {

    if (
      !plan ||
      !plan.planId
    ) {

      return {

        success: false,

        error: new Error(
          "Plan ID is missing."
        )

      };

    }


    const normalizedStatus =
      String(
        targetStatus || ""
      )
        .trim()
        .toUpperCase();


    if (
      normalizedStatus !== "ACTIVE" &&
      normalizedStatus !== "INACTIVE"
    ) {

      return {

        success: false,

        error: new Error(
          "Invalid subscription plan status."
        )

      };

    }


    const currentStatus =
      String(
        plan.status || ""
      )
        .trim()
        .toUpperCase();


    if (
      currentStatus ===
      normalizedStatus
    ) {

      return {

        success: false,

        error: new Error(
          `Plan is already ${normalizedStatus}.`
        )

      };

    }


    const actionText =
      normalizedStatus === "ACTIVE"
        ? "enable"
        : "disable";


    const confirmed =
      window.confirm(
        `${actionText === "enable" ? "Enable" : "Disable"} "${plan.name || plan.planId}"?\n\n` +
        `Current Status: ${currentStatus || "UNKNOWN"}\n` +
        `New Status: ${normalizedStatus}\n\n` +
        `This will update the subscription plan status.`
      );


    if (!confirmed) {

      log(
        "PLAN STATUS CHANGE: CANCELLED",
        plan.planId
      );


      return {

        success: false,

        cancelled: true

      };

    }


    if (state.saving) {

      return {

        success: false,

        error: new Error(
          "Another subscription plan operation is already running."
        )

      };

    }


    state.saving =
      true;

    state.error =
      null;


    try {

      const authorized =
        await verifyMasterAccess();


      if (!authorized) {

        throw new Error(
          "Master authorization is not ready."
        );

      }


      const planRef =
        doc(
          db,
          COLLECTION_NAME,
          plan.planId
        );


      await updateDoc(
        planRef,
        {

          status:
            normalizedStatus,

          updatedAt:
            serverTimestamp(),

          updatedBy:
            auth.currentUser.uid

        }
      );


      log(
        `PLAN STATUS CHANGED: ${currentStatus} → ${normalizedStatus}`,
        plan.planId
      );


      await refreshPlanDisplay();


      return {

        success: true,

        planId:
          plan.planId,

        status:
          normalizedStatus

      };

    } catch (err) {

      state.error =
        err;


      error(
        "SUBSCRIPTION PLAN STATUS CHANGE FAILED:",
        err
      );


      return {

        success: false,

        error: err

      };

    } finally {

      state.saving =
        false;

    }

  }


  /* =======================================================
     ARCHIVE / DELETE PLAN
     ======================================================= */

  async function deletePlan(plan) {

    if (
      !plan ||
      !plan.planId
    ) {

      return {

        success: false,

        error: new Error(
          "Plan ID is missing."
        )

      };

    }


    const currentStatus =
      String(
        plan.status || ""
      )
        .trim()
        .toUpperCase();


    /*
     * Safety lock:
     * only INACTIVE plans can be permanently deleted.
     */

    if (
      currentStatus !==
      "INACTIVE"
    ) {

      const deleteError =
        new Error(
          "Only INACTIVE subscription plans can be permanently deleted."
        );


      state.error =
        deleteError;


      error(
        "SUBSCRIPTION PLAN DELETE BLOCKED:",
        deleteError
      );


      window.alert(
        "This plan is currently ACTIVE.\n\n" +
        "Disable the plan first, then delete it."
      );


      return {

        success: false,

        error:
          deleteError

      };

    }


    const confirmed =
      window.confirm(
        `Delete "${plan.name || plan.planId}" permanently?\n\n` +
        `Plan ID: ${plan.planId}\n` +
        `Current Status: ${currentStatus}\n\n` +
        `This action permanently removes the subscription plan document.`
      );


    if (!confirmed) {

      log(
        "DELETE PLAN: CANCELLED",
        plan.planId
      );


      return {

        success: false,

        cancelled: true

      };

    }


    if (state.saving) {

      return {

        success: false,

        error: new Error(
          "Another subscription plan operation is already running."
        )

      };

    }


    state.saving =
      true;

    state.error =
      null;


    try {

      const authorized =
        await verifyMasterAccess();


      if (!authorized) {

        throw new Error(
          "Master authorization is not ready."
        );

      }


      /*
       * -------------------------------------------------------
       * ATOMIC PLAN + ENTITLEMENT DELETE
       * -------------------------------------------------------
       */

      const planRef =
        doc(
          db,
          COLLECTION_NAME,
          plan.planId
        );


      const entitlementRef =
        doc(
          db,
          ENTITLEMENT_COLLECTION_NAME,
          plan.planId
        );


      const batch =
        writeBatch(db);


      batch.delete(
        planRef
      );


      batch.delete(
        entitlementRef
      );


      await batch.commit();


      log(
        "SUBSCRIPTION PLAN + ENTITLEMENT DELETED:",
        plan.planId
      );


      await refreshPlanDisplay();


      return {

        success: true,

        planId:
          plan.planId

      };


    } catch (err) {

      state.error =
        err;


      error(
        "SUBSCRIPTION PLAN DELETE FAILED:",
        err
      );


      /*
       * TEMPORARY DIAGNOSTIC ALERT
       *
       * Keep this until Firestore Rules
       * delete permission test is PASS.
       */

      window.alert(
        "DELETE FAILED\n\n" +
        (
          err?.message ||
          String(err)
        )
      );


      return {

        success: false,

        error:
          err

      };

    } finally {

      state.saving =
        false;

    }

  }


  async function archivePlan(plan) {

    return await setPlanStatus(
      plan,
      "INACTIVE"
    );

  }


  /* =======================================================
     ENABLE PLAN
     ======================================================= */

  async function enablePlan(plan) {

    return await setPlanStatus(
      plan,
      "ACTIVE"
    );

  }


  /* =======================================================
     REFRESH PLAN DISPLAY
     ======================================================= */

  async function refreshPlanDisplay() {

    try {

      if (
        window.BKMasterSubscriptionControl &&
        typeof
          window.BKMasterSubscriptionControl.loadPlans ===
          "function"
      ) {

        await
          window.BKMasterSubscriptionControl
            .loadPlans();


        log(
          "PLAN DISPLAY: REFRESHED"
        );

      } else {

        warn(
          "Subscription Control loader not available yet."
        );

      }

    } catch (err) {

      error(
        "PLAN DISPLAY REFRESH FAILED:",
        err
      );

    }

  }


  /* =======================================================
     FORM BINDING
     ======================================================= */

  function bindForm() {

    const form =
      getForm();


    if (!form) {

      warn(
        "Subscription plan form not found"
      );

      return;

    }


    form.addEventListener(
      "submit",
      async event => {

        event.preventDefault();


        if (state.saving) {

          return;

        }


        setFormMessage(
          state.editing
            ? "Updating subscription plan..."
            : "Saving subscription plan...",
          "loading"
        );


        const data =
          getFormValues(
            form
          );


        let result;


        if (
          state.editing &&
          state.editingPlanId
        ) {

          result =
            await updatePlan(
              state.editingPlanId,
              data
            );

        } else {

          result =
            await createPlan(
              data
            );

        }


        if (
          !result ||
          !result.success
        ) {

          setFormMessage(
            result?.error?.message ||
            "Subscription plan could not be saved.",
            "error"
          );

          return;

        }


        setFormMessage(
          state.editing
            ? `Subscription plan updated successfully. Plan ID: ${result.planId}`
            : `Subscription plan created successfully. Plan ID: ${result.planId}`,
          "success"
        );


        resetForm();


        await refreshPlanDisplay();


        log(
          state.editing
            ? "UPDATE PLAN: SUCCESS"
            : "CREATE PLAN: SUCCESS"
        );

      }
    );


    log(
      "Plan Form Handler: READY"
    );

  }


  /* =======================================================
     CANCEL EDIT
     ======================================================= */

  function bindCancelEdit() {

    const button =
      getField(
        "bkMasterCancelSubscriptionPlanEdit"
      );


    if (!button) {

      return;

    }


    button.addEventListener(
      "click",
      () => {

        resetForm();


        setFormMessage(
          "Edit cancelled.",
          "info"
        );


        log(
          "EDIT MODE: CANCELLED"
        );

      }
    );

  }


  /* =======================================================
     INITIALIZATION
     ======================================================= */

  async function init() {

    if (
      state.initialized &&
      state.ready
    ) {

      return true;

    }


    log(
      "INITIALIZING..."
    );


    const authorized =
      await verifyMasterAccess();


    if (!authorized) {

      warn(
        "Waiting for BK Master authorization."
      );

      return false;

    }


    state.initialized =
      true;

    state.ready =
      true;


    log(
      "AUTHORIZATION: READY"
    );


    renderManagementUI();


    log(
      "PART 2 READY"
    );


    return true;

  }


  /* =======================================================
     PUBLIC API
     ======================================================= */

  return {

    state,

    init,

    createPlan,

    updatePlan,

    editPlan,

    archivePlan,

    enablePlan,

    setPlanStatus,

    deletePlan,

    refreshPlanDisplay,

    renderManagementUI

  };

})();


/* =========================================================
   AUTO START
   WAIT FOR MASTER AUTHORIZATION
   ========================================================= */

(async () => {

  try {

    const initialized =
      await window
        .BKMasterSubscriptionPlanManagement
        .init();


    if (!initialized) {

      const waitForMaster =
        setInterval(
          async () => {

            const masterReady =
              window.BKMaster &&
              window.BKMaster.state &&
              window.BKMaster.state.authorized === true;


            if (!masterReady) {

              return;

            }


            clearInterval(
              waitForMaster
            );


            console.log(
              "BK MASTER SUBSCRIPTION PLAN MANAGEMENT: MASTER AUTHORIZATION DETECTED"
            );


            await window
              .BKMasterSubscriptionPlanManagement
              .init();

          },
          500
        );

    }

  } catch (err) {

    console.error(
      "BK MASTER SUBSCRIPTION PLAN MANAGEMENT: AUTO START FAILED:",
      err
    );

  }

})();