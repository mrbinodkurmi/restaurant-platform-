/*
========================================================
BK USAGE BILLING ENGINE
SAFE FOUNDATION — COMPLETE REPLACEMENT
========================================================

Responsibilities:
1. Reuse existing BK billing controller.
2. Load monthly restaurant usage.
3. Load and validate pricing catalog.
4. Map explicitly supported usage metrics.
5. Calculate a non-publishing billing preview.

SAFETY:
- No Firestore writes.
- No bill creation or publication.
- No payment or subscription changes.
- No automatic enabling of pricing services.
- Unknown mappings and units are blocked.
- A partial preview is never marked billing-ready.

========================================================
*/

class BKUsageBillingEngine {

    constructor(billingControl) {

        if (!billingControl) {
            throw new Error(
                "BK Usage Billing Engine requires the existing billing control."
            );
        }

        if (
            typeof billingControl.loadMonthlyUsageRecord !== "function"
        ) {
            throw new Error(
                "Monthly usage loader is unavailable."
            );
        }

        if (
            typeof billingControl.calculateUsageCost !== "function"
        ) {
            throw new Error(
                "Existing usage cost calculator is unavailable."
            );
        }

        this.billingControl = billingControl;
    }


    /*
    ========================================================
    STEP 1 — COMMON VALIDATION HELPERS
    ========================================================
    */

    static validateRestaurantId(restaurantId) {

        if (
            typeof restaurantId !== "string" ||
            !restaurantId.trim()
        ) {
            throw new Error(
                "A valid restaurant ID is required."
            );
        }

        return restaurantId.trim();
    }


    static validateBillingMonth(billingMonth) {

        const month = String(billingMonth || "");

        if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(month)) {
            throw new Error(
                "Invalid billing month. Use YYYY-MM."
            );
        }

        return month;
    }


    static isPlainObject(value) {

        return (
            value !== null &&
            typeof value === "object" &&
            !Array.isArray(value)
        );
    }


    static isValidQuantity(value) {

        return (
            typeof value === "number" &&
            Number.isFinite(value) &&
            value >= 0
        );
    }

static roundMoney(value) {

    if (
        typeof value !== "number" ||
        !Number.isFinite(value)
    ) {
        throw new Error(
            "Invalid monetary calculation."
        );
    }

    const rounded =
        Math.round((value + Number.EPSILON) * 100) / 100;

    if (!Number.isFinite(rounded)) {
        throw new Error(
            "Rounded monetary amount is invalid."
        );
    }

    return rounded;
}
    

    /*
    ========================================================
    STEP 2 — LEGACY USAGE COST CALCULATION
    ========================================================
    Keeps the existing calculator available.
    Does not publish or save a bill.
    ========================================================
    */

    async calculateMonthlyUsageCost(
        restaurantId,
        billingMonth,
        pricing = {}
    ) {

        restaurantId =
            BKUsageBillingEngine.validateRestaurantId(
                restaurantId
            );

        billingMonth =
            BKUsageBillingEngine.validateBillingMonth(
                billingMonth
            );

        if (
            !BKUsageBillingEngine.isPlainObject(pricing)
        ) {
            throw new Error(
                "Pricing input must be a valid object."
            );
        }

        const usageData =
            await this.billingControl.loadMonthlyUsageRecord(
                restaurantId,
                billingMonth
            );

        if (!usageData) {
            return {
                success: false,
                previewOnly: true,
                usageFound: false,
                billingReady: false,
                restaurantId,
                billingMonth,
                estimatedCost: null,
                message:
                    "Monthly usage record not found. No calculation was performed."
            };
        }

        this.validateUsageIdentity(
            usageData,
            restaurantId
        );

        const calculation =
            this.billingControl.calculateUsageCost(
                usageData,
                pricing
            );

        if (
            !BKUsageBillingEngine.isPlainObject(calculation)
        ) {
            throw new Error(
                "Existing usage calculator returned an invalid result."
            );
        }

        return {
            success: true,
            previewOnly: true,
            billingReady: false,
            restaurantId,
            ownerId: usageData.ownerId || null,
            billingMonth,
            usageFound: true,
            calculation,
            message:
                "Legacy calculation only. This result is not a published bill."
        };
    }


    /*
    ========================================================
    STEP 3 — USAGE RECORD IDENTITY VALIDATION
    ========================================================
    */

validateUsageIdentity(
usageData,
restaurantId
) {

    if (
        !BKUsageBillingEngine.isPlainObject(
            usageData
        )
    ) {
        throw new Error(
            "Usage record must be a valid object."
        );
    }

    if (
        usageData.restaurantId !== restaurantId
    ) {
        throw new Error(
            "Restaurant ID missing or mismatched in usage record."
        );
    }

    if (
        typeof usageData.ownerId !== "string" ||
        !usageData.ownerId.trim()
    ) {
        throw new Error(
            "Owner ID missing from usage record."
        );
    }

    return true;
}

    /*
    ========================================================
    STEP 4 — LOAD PRICING CATALOG
    ========================================================
    Read-only operation.
    ========================================================
    */

    async loadPricingCatalog() {

        const pricingControl =
            window.BKPlatformPricingControl;

        if (
            !pricingControl ||
            typeof pricingControl.loadPricing !== "function"
        ) {
            throw new Error(
                "BK Platform Pricing Controller is unavailable."
            );
        }

        const result =
            await pricingControl.loadPricing();

        if (
            !BKUsageBillingEngine.isPlainObject(result) ||
            result.success !== true ||
            !Array.isArray(result.catalog)
        ) {
            throw new Error(
                "Unable to load a valid pricing catalog."
            );
        }

        if (
            typeof pricingControl.validateCatalog === "function"
        ) {

            const validation =
                pricingControl.validateCatalog(
                    result.catalog
                );

            if (
                !validation ||
                validation.valid !== true
            ) {
                throw new Error(
                    "Pricing catalog validation failed."
                );
            }
        }

        const seenIds = new Set();

        const catalog = result.catalog.map(service => {

            if (
                !BKUsageBillingEngine.isPlainObject(
                    service
                )
            ) {
                throw new Error(
                    "Pricing catalog contains an invalid service."
                );
            }

            if (
                typeof service.id !== "string" ||
                !service.id.trim()
            ) {
                throw new Error(
                    "Pricing service has no valid ID."
                );
            }

            if (seenIds.has(service.id)) {
                throw new Error(
                    "Duplicate pricing service ID: " +
                    service.id
                );
            }

            seenIds.add(service.id);

            if (
                typeof service.unit !== "string" ||
                !service.unit.trim()
            ) {
                throw new Error(
                    "Pricing service has no valid unit: " +
                    service.id
                );
            }

            return {
                id: service.id,
                category: service.category || null,
                label: service.label || service.id,
                unit: service.unit,
                providerCostRate:
                    service.providerCostRate,
                restaurantPriceRate:
                    service.restaurantPriceRate,
                enabled: service.enabled === true
            };
        });

        return {
            success: true,
            version: result.version || null,
            schemaVersion: result.schemaVersion || null,
            revision: result.revision ?? null,
            catalog
        };
    }


    /*
    ========================================================
    STEP 5 — EXPLICIT SERVICE-LEVEL MAPPINGS
    ========================================================
    Mapping definitions do not prove that metrics are tracked.
    Every metric must exist as a valid numeric field.
    ========================================================
    */

    getUsageMappings() {

        return {

            "booking.table": {
                metric: "tableBookings",
                unit: "per_booking"
            },

            "booking.advance": {
                metric: "advanceBookings",
                unit: "per_booking"
            },

            "booking.party": {
                metric: "partyBookings",
                unit: "per_booking"
            },

            "booking.event": {
                metric: "eventBookings",
                unit: "per_booking"
            },

            "booking.reject": {
                metric: "bookingRejections",
                unit: "per_operation"
            },

            "booking.cancel": {
                metric: "bookingCancellations",
                unit: "per_operation"
            },

            "order.create": {
                metric: "orders",
                unit: "per_order"
            },

            "order.update": {
                metric: "orderUpdates",
                unit: "per_operation"
            },

            "order.reject": {
                metric: "orderRejections",
                unit: "per_operation"
            },

            "order.cancel": {
                metric: "orderCancellations",
                unit: "per_operation"
            },

            "order.delete": {
                metric: "orderDeletions",
                unit: "per_operation"
            },

            "website.visit": {
                metric: "websiteVisits",
                unit: "per_1000_visits"
            },

            "website.bandwidth": {
                metric: "bandwidthGB",
                unit: "per_gb"
            },

            "website.hosting": {
                metric: "hostingMonths",
                unit: "per_restaurant_month"
            },

            "storage.gb_month": {
                metric: "storageGBMonths",
                unit: "per_gb_month"
            },

            "storage.upload": {
                metric: "storageUploadGB",
                unit: "per_gb"
            },

            "storage.download": {
                metric: "storageDownloadGB",
                unit: "per_gb"
            },

            "menu.item": {
                metric: "menuItems",
                unit: "per_item_month"
            },

            "image.upload": {
                metric: "imageUploads",
                unit: "per_upload"
            },

            "notification.send": {
                metric: "notificationsSent",
                unit: "per_1000_notifications"
            },

            "email.send": {
                metric: "emailsSent",
                unit: "per_1000_emails"
            },

            "future.ai": {
                metric: "aiRequests",
                unit: "per_request"
            },

            "future.analytics": {
                metric: "analyticsReports",
                unit: "per_report"
            },

            "future.custom": {
                metric: "customOperations",
                unit: "per_operation"
            }

        };
        
        
    }
    

    
    /*
    STEP 5A — AUDIT USAGE MAPPING DEFINITIONS
    */

    
auditUsageMappingDefinitions(catalog = []) {
    const mappings = this.getUsageMappings();
    const invalidMappings = [];
    const missingServiceMappings = [];
    const duplicateMetrics = [];

    const metricOwners = new Map();

    for (const [serviceId, mapping] of Object.entries(mappings)) {
        if (
            !mapping ||
            typeof mapping.metric !== "string" ||
            !mapping.metric.trim() ||
            typeof mapping.unit !== "string" ||
            !mapping.unit.trim()
        ) {
            invalidMappings.push(serviceId);
            continue;
        }

        const metric = mapping.metric;

        if (metricOwners.has(metric)) {
            duplicateMetrics.push({
                metric,
                services: [metricOwners.get(metric), serviceId]
            });
        } else {
            metricOwners.set(metric, serviceId);
        }
    }

    if (!Array.isArray(catalog)) {
        throw new Error("Pricing catalog must be an array.");
    }

    for (const service of catalog) {
        if (
            !service ||
            typeof service.id !== "string" ||
            !service.id.trim()
        ) {
            invalidMappings.push("INVALID_CATALOG_SERVICE_ID");
            continue;
        }

        if (
            service.enabled === true &&
            !Object.prototype.hasOwnProperty.call(mappings, service.id)
        ) {
            missingServiceMappings.push(service.id);
        }
    }

    return {
        totalMappings: Object.keys(mappings).length,
        invalidMappings: [...new Set(invalidMappings)],
        missingServiceMappings: [...new Set(missingServiceMappings)],
        duplicateMetrics,
        valid:
            invalidMappings.length === 0 &&
            missingServiceMappings.length === 0 &&
            duplicateMetrics.length === 0
    };
}




    /*
    ========================================================
    STEP 6 — VALIDATE USAGE MAPPING
    ========================================================
    ========================================================
    */

    validateUsageMapping(
        usageData = {},
        catalog = []
    ) {

        if (
            !BKUsageBillingEngine.isPlainObject(
                usageData
            )
        ) {
            throw new Error(
                "Valid usage data is required."
            );
        }

        if (!Array.isArray(catalog)) {
            throw new Error(
                "Pricing catalog must be an array."
            );
        }

for (const service of catalog) {
    if (
        !BKUsageBillingEngine.isPlainObject(service) ||
        typeof service.id !== "string" ||
        service.id.trim() === ""
    ) {
        throw new Error(
            "Every pricing service must have a valid ID."
        );
    }

    if (typeof service.enabled !== "boolean") {
        throw new Error(
            "Every pricing service must have an explicit enabled status."
        );
    }
}

        const mappings = this.getUsageMappings();
        
        
        const availableMetrics = [];
        const missingMetrics = [];

        const enabledServices = catalog
            .filter(service => service.enabled === true)
            .map(service => service.id);
const results = catalog.map(service => {
    const enabled = service.enabled === true;
    const mapping = mappings[service.id];

    // Disabled services do not block billing readiness.
    if (!enabled) {
        return {
            serviceId: service.id,
            enabled: false,
            mapped: true,
            skipped: true,
            reason: "Service is disabled; usage is not billable."
        };
    }

    if (!mapping) {
        return {
            serviceId: service.id,
            enabled: true,
            mapped: false,
            reason: "No explicit usage mapping is defined."
        };
    }

    if (service.unit !== mapping.unit) {
        return {
            serviceId: service.id,
            metric: mapping.metric,
            unit: service.unit,
            enabled: true,
            mapped: false,
            reason: "Pricing unit does not match the declared mapping."
        };
    }

    const exists = Object.prototype.hasOwnProperty.call(
        usageData,
        mapping.metric
    );

    const value = exists
        ? usageData[mapping.metric]
        : undefined;

    const valid =
        exists &&
        BKUsageBillingEngine.isValidQuantity(value);

    if (valid) {
        availableMetrics.push(mapping.metric);
    } else {
        missingMetrics.push(mapping.metric);
    }

    return {
        serviceId: service.id,
        metric: mapping.metric,
        unit: service.unit,
        enabled: true,
        mapped: valid,
        usage: valid ? value : null,
        reason: valid
            ? null
            : "Verified numeric usage metric is missing or invalid."
    };
});
        
        return {
            valid: true,
            availableMetrics: [
                ...new Set(availableMetrics)
            ],
            missingMetrics: [
                ...new Set(missingMetrics)
            ],
            enabledServices,
            results,
            totalServices: results.length,
            mappedServices:
                results.filter(item => item.mapped).length,
            unmappedServices:
                results.filter(item => !item.mapped).length,
            readyForBilling: false,
            message:
                "Mapping validation only. Billing readiness remains disabled."
        };
    }


    /*
    ========================================================
    STEP 7 — BUILD SERVICE-LEVEL USAGE MAPPING
    ========================================================
    ========================================================
    */

    buildUsageMapping(
        usageData = {},
        catalog = []
    ) {

        return this.validateUsageMapping(
            usageData,
            catalog
        );
    }


    /*
    ========================================================
    STEP 8 — SUPPORTED BILLING UNITS
    ========================================================
    Unknown units are blocked.
    ========================================================
    */

    getUnitMultiplier(unit, quantity) {

if (
    typeof quantity !== "number" ||
    !Number.isFinite(quantity) ||
    quantity < 0
) {
    return null;
}

        switch (unit) {

            case "per_1000_reads":
            case "per_1000_writes":
            case "per_1000_updates":
            case "per_1000_deletes":
            case "per_1000_visits":
            case "per_1000_notifications":
            case "per_1000_emails":

                return quantity / 1000;

            case "per_booking":
            case "per_operation":
            case "per_order":
            case "per_gb":
            case "per_restaurant_month":
            case "per_gb_month":
            case "per_item_month":
            case "per_upload":
            case "per_request":
            case "per_report":

                return quantity;

            default:
                return null;
        }
    }


    /*
    ========================================================
    STEP 9 — PRICING CALCULATION PREVIEW
    ========================================================
    Preview only. Never publishes or saves a bill.
    ========================================================
    */

calculatePricingPreview(
        catalog = [],
        mappingResult = {}
    ) {

        if (!Array.isArray(catalog)) {
            throw new Error(
                "Pricing catalog must be an array."
            );
        }

        if (
            !BKUsageBillingEngine.isPlainObject(
                mappingResult
            ) ||
            !Array.isArray(mappingResult.results)
        ) {
            throw new Error(
                "Valid usage mapping is required."
            );
        }

        
const mappingById = new Map();

for (const item of mappingResult.results) {
    if (
        !BKUsageBillingEngine.isPlainObject(item) ||
        typeof item.serviceId !== "string" ||
        !item.serviceId.trim()
    ) {
        throw new Error(
            "Usage mapping contains an invalid service ID."
        );
    }

    if (mappingById.has(item.serviceId)) {
        throw new Error(
            "Usage mapping contains a duplicate service ID."
        );
    }

    mappingById.set(item.serviceId, item);
}


        const lines = [];
        const blockedServices = [];

        let providerCost = 0;
        let restaurantCharge = 0;

        for (const service of catalog) {

    if (
        !BKUsageBillingEngine.isPlainObject(service) ||
        typeof service.id !== "string" ||
        !service.id.trim()
    ) {
        throw new Error(
            "Pricing service has an invalid ID."
        );
    }

    if (typeof service.enabled !== "boolean") {
        throw new Error(
            "Pricing service must have an explicit enabled status."
        );
    }

    const mapping =
        mappingById.get(service.id);

    if (service.enabled === false) {
        continue;
    }
            
            if (!mapping || mapping.mapped !== true) {

                blockedServices.push({
                    serviceId: service.id,
                    reason:
                        mapping?.reason ||
                        "Verified usage mapping is unavailable."
                });

                continue;
            }

            if (
                !BKUsageBillingEngine.isValidQuantity(
                    mapping.usage
                )
            ) {

                blockedServices.push({
                    serviceId: service.id,
                    reason: "Usage quantity is invalid."
                });

                continue;
            }

            const providerRate =
                service.providerCostRate;

            const restaurantRate =
                service.restaurantPriceRate;
                
/*
----------------------------------------
PRICING RATE VALIDATION
----------------------------------------
Both rates must be finite, non-negative
numbers before zero-rate checks.
----------------------------------------
*/

if (
    !BKUsageBillingEngine.isValidQuantity(
        providerRate
    ) ||
    !BKUsageBillingEngine.isValidQuantity(
        restaurantRate
    )
) {
    blockedServices.push({
        serviceId: service.id,
        reason:
            "Pricing rates must be valid non-negative numbers."
    });

    continue;
}

/*
----------------------------------------
ZERO-RATE BILLING SAFETY
----------------------------------------
Both rates must be explicitly configured
above zero before billing.
----------------------------------------
*/

if (
    providerRate <= 0 ||
    restaurantRate <= 0
) {
    blockedServices.push({
        serviceId: service.id,
        reason:
            "Pricing rates must be explicitly configured above zero before billing."
    });

    continue;
}

            const multiplier =
                this.getUnitMultiplier(
                    service.unit,
                    mapping.usage
                );

            if (
                multiplier === null ||
                !Number.isFinite(multiplier) ||
                multiplier < 0
            ) {

                blockedServices.push({
                    serviceId: service.id,
                    reason:
                        "Unsupported or invalid pricing unit."
                });

                continue;
            }

            const lineProviderCost =
                multiplier * providerRate;

            const lineRestaurantCharge =
                multiplier * restaurantRate;

            if (
                !Number.isFinite(lineProviderCost) ||
                !Number.isFinite(lineRestaurantCharge)
            ) {

                blockedServices.push({
                    serviceId: service.id,
                    reason:
                        "Calculation produced an invalid amount."
                });

                continue;
            }

            const roundedProviderCost =
                BKUsageBillingEngine.roundMoney(
                    lineProviderCost
                );

            const roundedRestaurantCharge =
                BKUsageBillingEngine.roundMoney(
                    lineRestaurantCharge
                );

            providerCost += roundedProviderCost;
restaurantCharge += roundedRestaurantCharge;

// Block overflow or invalid accumulated totals.
if (
    !Number.isFinite(providerCost) ||
    !Number.isFinite(restaurantCharge)
) {
    blockedServices.push({
        serviceId: service.id,
        reason:
            "Accumulated billing total is invalid. Calculation blocked."
    });

    // Roll back this service's contribution.
    providerCost -= roundedProviderCost;
    restaurantCharge -= roundedRestaurantCharge;

    continue;
}

lines.push({
                serviceId: service.id,
                label: service.label,
                unit: service.unit,
                quantity: mapping.usage,
                providerRate,
                restaurantRate,
                providerCost: roundedProviderCost,
                restaurantCharge: roundedRestaurantCharge
            });
        }

        providerCost =
            BKUsageBillingEngine.roundMoney(
                providerCost
            );

        restaurantCharge =
            BKUsageBillingEngine.roundMoney(
                restaurantCharge
            );


if (
    !Number.isFinite(providerCost) ||
    !Number.isFinite(restaurantCharge) ||
    providerCost < 0 ||
    restaurantCharge < 0
) {
    throw new Error(
        "Final billing totals are invalid. Preview cannot continue."
    );
}

        const hasBlockedServices =
            blockedServices.length > 0;
            

        return {
            previewOnly: true,

            /*
            Never mark this engine's preview
            as ready to publish a real bill.
            */

            billingReady: false,

            providerCost,
            restaurantCharge,

            marginBeforeOtherAdjustments:
                BKUsageBillingEngine.roundMoney(
                    restaurantCharge - providerCost
                ),

            lines,
            blockedServices,


hasBlockedServices,

billingStatus: hasBlockedServices
    ? "BLOCKED"
    : "PREVIEW_ONLY",

message:


                "Preview only. Missing mappings, disabled services, or unsupported units must be resolved before any future billing approval."
        };
    }


    /*
    ========================================================
    STEP 10 — MONTHLY BILLING PREVIEW
    ========================================================
    Read-only workflow.
    ========================================================
    */

    async previewMonthlyBilling(
        restaurantId,
        billingMonth
    ) {

        restaurantId =
            BKUsageBillingEngine.validateRestaurantId(
                restaurantId
            );

        billingMonth =
            BKUsageBillingEngine.validateBillingMonth(
                billingMonth
            );

        const pricingResult =
            await this.loadPricingCatalog();
            
        const mappingDefinitionAudit =
            this.auditUsageMappingDefinitions(
                pricingResult.catalog
            );


        const usageData =
            await this.billingControl.loadMonthlyUsageRecord(
                restaurantId,
                billingMonth
            );

        if (!usageData) {

            return {
                success: false,
                previewOnly: true,
                billingReady: false,
                restaurantId,
                billingMonth,
                pricingRevision:
                    pricingResult.revision,
                reason: "USAGE_NOT_FOUND",
                message:
                    "Monthly usage record is missing. No billing calculation was performed."
            };
        }

        this.validateUsageIdentity(
            usageData,
            restaurantId
        );

        const mappingResult =
            this.buildUsageMapping(
                usageData,
                pricingResult.catalog
            );

        const calculation =
            this.calculatePricingPreview(
                pricingResult.catalog,
                mappingResult
            );

        return {
            success: true,
            previewOnly: true,
            billingReady: false,
            restaurantId,
            ownerId: usageData.ownerId || null,
            billingMonth,
            pricingVersion: pricingResult.version,
            pricingRevision: pricingResult.revision,
            
            pricingCatalog: pricingResult.catalog,
            mappingDefinitionAudit,
            usageMapping: mappingResult,
            calculation,
            message:
                "Monthly preview completed. No bill was created, published, or saved."
        };
    }


    /*
    ========================================================
    STEP 12 — BILLING READINESS AUDIT
    ========================================================
    Read-only audit.
    Does not create, save, or publish bills.
    ========================================================
    */

    async auditMonthlyBillingReadiness(
        restaurantId,
        billingMonth
    ) {

        restaurantId =
            BKUsageBillingEngine.validateRestaurantId(
                restaurantId
            );

        billingMonth =
            BKUsageBillingEngine.validateBillingMonth(
                billingMonth
            );

        const preview =
            await this.previewMonthlyBilling(
                restaurantId,
                billingMonth
            );

        if (!preview.success) {
            return {
                success: false,
                readyForCalculation: false,
                readyForPublication: false,
                restaurantId,
                billingMonth,
                blockers: [
                    preview.reason || "PREVIEW_FAILED"
                ],
                message: preview.message
            };
        }

const enabledServices =
    Array.isArray(preview.pricingCatalog)
        ? preview.pricingCatalog.filter(
            service => service.enabled === true
        )
        : [];

        
        const blockedServices =
    Array.isArray(preview.calculation.blockedServices)
        ? preview.calculation.blockedServices
        : [];

const validLines =
    Array.isArray(preview.calculation.lines)
        ? preview.calculation.lines
        : [];

const providerCost =
    Number(preview.calculation.providerCost);

const restaurantCharge =
    Number(preview.calculation.restaurantCharge);
        const blockers = [];

        if (enabledServices.length === 0) {
            blockers.push(
                "NO_PRICING_SERVICES_ENABLED"
            );
        }


        if (
            !preview.mappingDefinitionAudit ||
            preview.mappingDefinitionAudit.valid !== true
        ) {
            blockers.push(
                "USAGE_MAPPING_DEFINITION_AUDIT_FAILED"
            );
        }

        if (blockedServices.length > 0) {
            blockers.push(
                "PRICING_OR_USAGE_MAPPINGS_INCOMPLETE"
            );
        }
if (validLines.length === 0) {
    blockers.push("NO_VALID_BILLING_LINES");
}

if (
    !Number.isFinite(providerCost) ||
    providerCost < 0 ||
    !Number.isFinite(restaurantCharge) ||
    restaurantCharge < 0
) {
    blockers.push("INVALID_BILLING_TOTALS");
}


// Master margin validation
const masterMargin =
    BKUsageBillingEngine.roundMoney(
        restaurantCharge - providerCost
    );

if (
    !Number.isFinite(masterMargin) ||
    masterMargin < 0
) {
    blockers.push("INVALID_MASTER_MARGIN");
}

        return {
            success: true,
            readyForCalculation:
                blockers.length === 0,
            readyForPublication: false,

            restaurantId,
            ownerId: preview.ownerId,
            billingMonth,

            pricingVersion: preview.pricingVersion,
pricingRevision: preview.pricingRevision,

            enabledServiceCount:
                enabledServices.length,
validLineCount: validLines.length,

mappingDefinitionAudit:
    preview.mappingDefinitionAudit,

blockedServiceCount:
    blockedServices.length,

providerCost,

restaurantCharge,

            blockers,

            previewOnly: true,

            message: blockers.length === 0
                ? "Preview checks passed. Publication is still disabled."
                : "Billing is blocked until the listed issues are resolved."
        };
    }

    /*
    ========================================================
    STEP 13 — SAFE BILLING PREPARATION
    ========================================================
    Creates a validated in-memory billing draft.
    Does not write to Firestore or publish a bill.
    ========================================================
    */

    async prepareMonthlyBillingDraft(
        restaurantId,
        billingMonth
    ) {

        const audit =
            await this.auditMonthlyBillingReadiness(
                restaurantId,
                billingMonth
            );

        if (!audit.success) {
            throw new Error(
                "Billing preparation failed: " +
                audit.blockers.join(", ")
            );
        }

        if (!audit.readyForCalculation) {
            return {
                success: false,
                draftCreated: false,
                published: false,
                restaurantId: audit.restaurantId,
                billingMonth: audit.billingMonth,
                blockers: audit.blockers,
                message:
                    "Billing draft blocked. Resolve the readiness issues first."
            };
        }

        if (
            typeof audit.providerCost !== "number" ||
            !Number.isFinite(audit.providerCost) ||
            audit.providerCost < 0 ||
            typeof audit.restaurantCharge !== "number" ||
            !Number.isFinite(audit.restaurantCharge) ||
            audit.restaurantCharge < 0
        ) {
            throw new Error(
                "Invalid billing amounts. Draft creation blocked."
            );
        }

        return {
            success: true,
            draftCreated: true,
            published: false,
            previewOnly: true,

            restaurantId: audit.restaurantId,
            ownerId: audit.ownerId,
            billingMonth: audit.billingMonth,

            pricingVersion: audit.pricingVersion,
            pricingRevision: audit.pricingRevision,

            providerCost: audit.providerCost,
            estimatedCost: audit.providerCost,
            baseAmount: audit.restaurantCharge,

            currency: "INR",
            status: "CALCULATED",
            paymentStatus: "UNPAID",

            blockers: [],

            message:
                "Validated in-memory draft prepared. Nothing has been saved or published."
        };
    }


    /*
    ========================================================
    STEP 11 — CREATE FROM EXISTING CONTROL
    ========================================================
    Reuses the current controller.
    ========================================================
    */

    static create(billingControl) {

        return new BKUsageBillingEngine(
            billingControl
        );
    }


    static createFromExistingControl() {

        const control =
            window.BKMasterSubscriptionBillingControl;

        if (!control) {
            throw new Error(
                "Existing BK Master Subscription Billing Control is unavailable."
            );
        }

        return new BKUsageBillingEngine(
            control
        );
    }

}


/*
========================================================
GLOBAL EXPOSURE
========================================================
*/

window.BKUsageBillingEngine =
    BKUsageBillingEngine;