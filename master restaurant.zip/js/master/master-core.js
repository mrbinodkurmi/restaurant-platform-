/* ============================================================
   BK RESTAURANT PLATFORM
   MASTER CONTROL
   MASTER CORE ENGINE
   Version: 1.0.0
============================================================ */

"use strict";


const BKMasterCore = {

    state: {

        currentSection:
            "overview",

        sidebarOpen:
            false,

        initialized:
            false

    },


    sections: {

        overview: {
            title: "Master Overview",
            kicker: "BK MASTER CONTROL"
        },

        restaurants: {
            title: "Restaurant Control",
            kicker: "RESTAURANT MANAGEMENT"
        },

        subscription: {
            title: "Subscription Control",
            kicker: "SUBSCRIPTION MANAGEMENT"
        },

        payments: {
            title: "Payment Control",
            kicker: "PAYMENT MANAGEMENT"
        },

        disputes: {
            title: "Dispute Control",
            kicker: "DISPUTE MANAGEMENT"
        },

        notices: {
            title: "Notice Control",
            kicker: "NOTICE MANAGEMENT"
        },

        website: {
            title: "Website Control",
            kicker: "WEBSITE MANAGEMENT"
        },

        owners: {
            title: "Owner Control",
            kicker: "OWNER MANAGEMENT"
        },

        pricing: {
            title: "Cost & Pricing",
            kicker: "PLATFORM COST & PRICING"
        },

        analytics: {
            title: "Usage & Analytics",
            kicker: "PLATFORM ANALYTICS"
        },

        system: {
            title: "System Control",
            kicker: "SYSTEM MANAGEMENT"
        }

    },


    init() {

        console.log(
            "=========================================="
        );

        console.log(
            "BK MASTER CORE: INITIALIZING"
        );

        console.log(
            "=========================================="
        );


        this.cacheElements();

        this.bindNavigation();

        this.bindMobileSidebar();

        this.bindLogout();

        this.showSection(
            this.state.currentSection
        );


        this.state.initialized =
            true;


        console.log(
            "BK MASTER CORE: READY"
        );

    },


    cacheElements() {

        this.elements = {

            app:
                document.getElementById(
                    "masterApp"
                ),

            sidebar:
                document.getElementById(
                    "masterSidebar"
                ),

            sidebarOverlay:
                document.getElementById(
                    "masterSidebarOverlay"
                ),

            mobileMenuButton:
                document.getElementById(
                    "masterMobileMenuButton"
                ),

            pageTitle:
                document.getElementById(
                    "masterPageTitle"
                ),

            logoutButton:
                document.getElementById(
                    "masterLogoutButton"
                ),

            navItems:
                document.querySelectorAll(
                    "[data-master-section]"
                ),

            sections:
                document.querySelectorAll(
                    "[data-master-dashboard-section]"
                )

        };


        console.log(
            "BK MASTER CORE: Elements cached."
        );

    },


    bindNavigation() {

        if (
            !this.elements.navItems ||
            !this.elements.navItems.length
        ) {

            console.warn(
                "BK MASTER CORE: Navigation items not found."
            );

            return;

        }


        this.elements.navItems.forEach(
            (item) => {

                item.addEventListener(
                    "click",
                    () => {

                        const section =
                            item.dataset.masterSection;


                        if (!section) {

                            return;

                        }


                        this.showSection(
                            section
                        );

                    }
                );

            }
        );

    },


    showSection(sectionName) {

        if (
            !this.sections[sectionName]
        ) {

            console.warn(
                "BK MASTER CORE: Unknown section:",
                sectionName
            );

            return;

        }


        this.state.currentSection =
            sectionName;


        this.updateNavigation(
            sectionName
        );


        this.updatePageTitle(
            sectionName
        );


        this.updateSections(
            sectionName
        );


        this.closeMobileSidebar();

    },


    updateNavigation(sectionName) {

        if (
            !this.elements.navItems
        ) {

            return;

        }


        this.elements.navItems.forEach(
            (item) => {

                const itemSection =
                    item.dataset.masterSection;


                item.classList.toggle(
                    "active",
                    itemSection === sectionName
                );

            }
        );

    },


    updatePageTitle(sectionName) {

        const config =
            this.sections[
                sectionName
            ];


        if (
            !config ||
            !this.elements.pageTitle
        ) {

            return;

        }


        this.elements.pageTitle.textContent =
            config.title;

    },


    updateSections(sectionName) {

        if (
            !this.elements.sections
        ) {

            return;

        }


        this.elements.sections.forEach(
            (section) => {

                const sectionKey =
                    section.dataset
                        .masterDashboardSection;


                const isActive =
                    sectionKey === sectionName;


                section.classList.toggle(
                    "hidden-master-section",
                    !isActive
                );

            }
        );

    },


    bindMobileSidebar() {

        if (
            this.elements.mobileMenuButton
        ) {

            this.elements.mobileMenuButton
                .addEventListener(
                    "click",
                    () => {

                        this.toggleMobileSidebar();

                    }
                );

        }


        if (
            this.elements.sidebarOverlay
        ) {

            this.elements.sidebarOverlay
                .addEventListener(
                    "click",
                    () => {

                        this.closeMobileSidebar();

                    }
                );

        }

    },


    toggleMobileSidebar() {

        if (
            this.state.sidebarOpen
        ) {

            this.closeMobileSidebar();

        } else {

            this.openMobileSidebar();

        }

    },


    openMobileSidebar() {

        if (
            !this.elements.sidebar
        ) {

            return;

        }


        this.elements.sidebar
            .classList.add(
                "mobile-open"
            );


        if (
            this.elements.sidebarOverlay
        ) {

            this.elements.sidebarOverlay
                .classList.add(
                    "show"
                );

        }


        this.state.sidebarOpen =
            true;

    },


    closeMobileSidebar() {

        if (
            this.elements.sidebar
        ) {

            this.elements.sidebar
                .classList.remove(
                    "mobile-open"
                );

        }


        if (
            this.elements.sidebarOverlay
        ) {

            this.elements.sidebarOverlay
                .classList.remove(
                    "show"
                );

        }


        this.state.sidebarOpen =
            false;

    },
    /* ============================================================
   MASTER CORE — LOGOUT
============================================================ */

    bindLogout() {

        if (
            !this.elements.logoutButton
        ) {

            console.warn(
                "BK MASTER CORE: Logout button not found."
            );

            return;

        }


        this.elements.logoutButton
            .addEventListener(
                "click",
                async () => {

                    try {

                        if (
                            window.BKMaster &&
                            typeof window.BKMaster.logout ===
                                "function"
                        ) {

                            await window.BKMaster.logout();

                            console.log(
                                "BK MASTER CORE: Logout successful."
                            );

                            return;

                        }


                        console.warn(
                            "BK MASTER CORE: Master Auth logout unavailable."
                        );

                    } catch (error) {

                        console.error(
                            "BK MASTER CORE: Logout failed:",
                            error
                        );

                    }

                }
            );

    },


    getCurrentSection() {

        return this.state.currentSection;

    },


    isReady() {

        return this.state.initialized;

    }

};


/* ============================================================
   GLOBAL ACCESS
============================================================ */

window.BKMasterCore =
    BKMasterCore;


/* ============================================================
   START MASTER CORE
============================================================ */

document.addEventListener(
    "DOMContentLoaded",
    function() {

        try {

            BKMasterCore.init();

        } catch (error) {

            console.error(
                "BK MASTER CORE INITIALIZATION ERROR:",
                error
            );

        }

    }
);