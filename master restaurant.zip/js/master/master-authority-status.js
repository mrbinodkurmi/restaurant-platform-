
"use strict";

/*
=====================================================
BK MASTER AUTHORITY STATUS CONTROL
=====================================================

ACTIVE   = New Master creation LOCKED
INACTIVE = New Master creation ALLOWED
ERROR    = New Master creation LOCKED

Master Login = ALWAYS AVAILABLE

This file:
- Reads Master Authority from Firestore.
- Does not create Firebase Auth accounts.
- Does not modify Firestore.
- Does not disable Master Login.
=====================================================
*/

import { db } from "../firebase.js";

import {
    doc,
    getDoc
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";


/* =====================================================
   SYSTEM 01: PAGE ELEMENTS
===================================================== */

const statusElement = document.getElementById(
    "masterAuthorityStatus"
);

const createButton = document.getElementById(
    "masterCreateButton"
);

const loginButton = document.getElementById(
    "masterLoginAccessButton"
);


/* =====================================================
   SYSTEM 02: AUTHORITY STATE
===================================================== */

// Default state: LOCKED

let authorityVerified = false;
let masterCreationAllowed = false;


/* =====================================================
   SYSTEM 03: MASTER LOGIN NAVIGATION
===================================================== */

// Login is independent of Master Authority.
// Never disable or block this navigation.

if (loginButton) {

    loginButton.disabled = false;

    loginButton.addEventListener("click", () => {

        window.location.href = "master-login.html";

    });

} else {

    console.error(
        "BK MASTER AUTHORITY: Master Login button missing."
    );

}


/* =====================================================
   SYSTEM 04: MASTER CREATION ACCESS CONTROL
===================================================== */

function setCreationAccess(enabled) {

    authorityVerified = enabled;
    masterCreationAllowed = enabled;

    if (createButton) {

        createButton.disabled = !enabled;

    }

}


/* =====================================================
   SYSTEM 05: STATUS DISPLAY
===================================================== */

function showAuthorityStatus(message, isError = false) {

    if (!statusElement) {

        console.error(
            "BK MASTER AUTHORITY:",
            message
        );

        return;
    }

    statusElement.textContent = message;

    statusElement.classList.toggle(
        "error",
        isError
    );

}


/* =====================================================
   SYSTEM 06: MASTER CREATION NAVIGATION
===================================================== */

if (createButton) {

    // Always locked before verification.

    createButton.disabled = true;

    createButton.addEventListener("click", () => {

        // Recheck access before navigation.

        if (
            !authorityVerified ||
            !masterCreationAllowed
        ) {

            createButton.disabled = true;

            return;
        }

        window.location.href = "master-create.html";

    });

} else {

    console.error(
        "BK MASTER AUTHORITY: Creation button missing."
    );

}


/* =====================================================
   SYSTEM 07: FIRESTORE AUTHORITY VERIFICATION
===================================================== */

async function checkMasterAuthority() {

    // Fail-closed default.

    setCreationAccess(false);

    showAuthorityStatus(
        "Checking Master Authority..."
    );


    try {

        const authorityRef = doc(
            db,
            "systemConfig",
            "masterAuthority"
        );


        const authoritySnapshot = await getDoc(
            authorityRef
        );


        // ---------------------------------------------
        // CASE 01: AUTHORITY DOCUMENT MISSING
        // ---------------------------------------------

        if (!authoritySnapshot.exists()) {

            setCreationAccess(false);

            showAuthorityStatus(
                "Master Authority record not found. Creation is locked.",
                true
            );

            return;
        }


        const authority = authoritySnapshot.data();


        // ---------------------------------------------
        // CASE 02: MASTER ACTIVE
        // ---------------------------------------------

        const isActive =
            authority.exists === true &&
            authority.status === "ACTIVE";


        if (isActive) {

            setCreationAccess(false);

            showAuthorityStatus(
                "Master Authority: ACTIVE. New Master creation is locked."
            );

            return;
        }


        // ---------------------------------------------
        // CASE 03: MASTER INACTIVE
        // ---------------------------------------------

        const isInactive =
            authority.exists === false &&
            authority.status === "INACTIVE";


        if (isInactive) {

            setCreationAccess(true);

            showAuthorityStatus(
                "Master Authority: INACTIVE. New Master creation is available."
            );

            return;
        }


        // ---------------------------------------------
        // CASE 04: INVALID / INCONSISTENT DATA
        // ---------------------------------------------

        setCreationAccess(false);

        showAuthorityStatus(
            "Master Authority requires verification. Creation is locked.",
            true
        );

    } catch (error) {

        console.error(
            "BK MASTER AUTHORITY CHECK ERROR:",
            error
        );


        // Any verification error keeps creation locked.

        setCreationAccess(false);

        showAuthorityStatus(
            "Unable to verify Master Authority. Creation is locked.",
            true
        );

    }

}


/* =====================================================
   SYSTEM 08: INITIALIZATION
===================================================== */

checkMasterAuthority();
