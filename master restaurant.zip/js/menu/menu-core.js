"use strict";

/*
=========================================================
 BK MASTER RESTAURANT PLATFORM
 MENU CORE
 Version: 1.0.1

 Responsibility:
 - Menu system initialization
 - Menu state
 - Restaurant context
 - Module coordination
=========================================================
*/

console.log("BK MENU CORE FILE: LOADED");


window.BKMenu = {

    version: "1.0.1",

    state: {

        initialized: false,

        ownerUid: null,

        restaurantId: null,

        categories: [],

        items: [],

        activeCategoryId: "all",

        searchQuery: "",

        loading: false
    },


    config: {

        collections: {

            restaurants: "restaurants",

            categories: "categories",

            items: "items"
        }
    },


    /*
    =====================================================
     INITIALIZE MENU
    =====================================================
    */

    init: function () {

        if (this.state.initialized) {

            console.log(
                "BK Menu: Already initialized."
            );

            return;
        }


        console.log(
            "------------------------------------------"
        );

        console.log(
            "BK MENU SYSTEM"
        );

        console.log(
            "Initializing Menu Core..."
        );

        console.log(
            "------------------------------------------"
        );


        this.loadRestaurantContext();


        this.state.initialized = true;


        console.log(
            "Menu Core: READY"
        );

        console.log(
            "Owner UID:",
            this.state.ownerUid
        );

        console.log(
            "Restaurant ID:",
            this.state.restaurantId
        );


        console.log(
            "------------------------------------------"
        );

        console.log(
            "BK MENU CORE INITIALIZED"
        );

        console.log(
            "------------------------------------------"
        );
    },


    /*
    =====================================================
     LOAD RESTAURANT CONTEXT
    =====================================================
    */

    loadRestaurantContext: function () {

        /*
        -------------------------------------------------
         FIRST SOURCE
         Existing BK Owner Dashboard state
        -------------------------------------------------
        */

        if (
            window.BKOwner &&
            window.BKOwner.state
        ) {

            const ownerState =
                window.BKOwner.state;


            /*
            Owner UID
            */

            if (
                ownerState.currentUser &&
                ownerState.currentUser.uid
            ) {

                this.state.ownerUid =
                    ownerState.currentUser.uid;
            }


            /*
            Restaurant ID
            */

            if (
                ownerState.restaurantId
            ) {

                this.state.restaurantId =
                    ownerState.restaurantId;
            }


            /*
            Restaurant data fallback
            */

            if (
                ownerState.restaurantData &&
                ownerState.restaurantData.id
            ) {

                this.state.restaurantId =
                    ownerState.restaurantData.id;
            }
        }


        /*
        -------------------------------------------------
         SECOND SOURCE
         LocalStorage fallback
        -------------------------------------------------
        */

        if (!this.state.ownerUid) {

            this.state.ownerUid =
                localStorage.getItem(
                    "bkOwnerUid"
                );
        }


        if (!this.state.restaurantId) {

            this.state.restaurantId =
                localStorage.getItem(
                    "bkRestaurantId"
                );
        }


        /*
        -------------------------------------------------
         SAFETY CHECK
        -------------------------------------------------
        */

        if (!this.state.restaurantId) {

            console.warn(
                "BK Menu: Restaurant ID not available yet."
            );

            return false;
        }


        console.log(
            "BK Menu: Restaurant context loaded."
        );


        return true;
    },


    /*
    =====================================================
     REFRESH RESTAURANT CONTEXT
    =====================================================
    */

    refreshContext: function () {

        const loaded =
            this.loadRestaurantContext();


        if (loaded) {

            console.log(
                "BK Menu: Restaurant context refreshed."
            );

        }

        return loaded;
    },


    /*
    =====================================================
     GET RESTAURANT ID
    =====================================================
    */

    getRestaurantId: function () {

        return this.state.restaurantId;
    },


    /*
    =====================================================
     GET OWNER UID
    =====================================================
    */

    getOwnerUid: function () {

        return this.state.ownerUid;
    },


    /*
    =====================================================
     ACTIVE CATEGORY
    =====================================================
    */

    setActiveCategory: function (
        categoryId
    ) {

        if (!categoryId) {

            categoryId = "all";
        }


        this.state.activeCategoryId =
            categoryId;


        console.log(
            "BK Menu: Active category →",
            categoryId
        );
    },


    getActiveCategory: function () {

        return this.state.activeCategoryId;
    },


    /*
    =====================================================
     SEARCH
    =====================================================
    */

    setSearchQuery: function (
        query
    ) {

        this.state.searchQuery =
            String(query || "").trim();
    },


    getSearchQuery: function () {

        return this.state.searchQuery;
    },


    /*
    =====================================================
     CATEGORY STATE
    =====================================================
    */

    setCategories: function (
        categories
    ) {

        this.state.categories =
            Array.isArray(categories)
                ? categories
                : [];
    },


    getCategories: function () {

        return this.state.categories;
    },


    /*
    =====================================================
     ITEM STATE
    =====================================================
    */

    setItems: function (
        items
    ) {

        this.state.items =
            Array.isArray(items)
                ? items
                : [];
    },


    getItems: function () {

        return this.state.items;
    },


    /*
    =====================================================
     LOADING STATE
    =====================================================
    */

    setLoading: function (
        loading
    ) {

        this.state.loading =
            Boolean(loading);
    },


    isLoading: function () {

        return this.state.loading;
    },


    /*
    =====================================================
     RESET MENU STATE
    =====================================================
    */

    resetMenuState: function () {

        this.state.categories = [];

        this.state.items = [];

        this.state.activeCategoryId =
            "all";

        this.state.searchQuery = "";

        this.state.loading = false;
    },


    /*
    =====================================================
     DESTROY
    =====================================================
    */

    destroy: function () {

        this.resetMenuState();

        this.state.ownerUid = null;

        this.state.restaurantId = null;

        this.state.initialized = false;


        console.log(
            "BK Menu: Core reset."
        );
    }
};


/*
=========================================================
 MENU CORE INITIALIZATION
=========================================================
*/

function initializeBKMenu() {

    if (!window.BKMenu) {

        console.error(
            "BK Menu: Core object not available."
        );

        return;
    }


    /*
    Try immediately
    */

    if (
        window.BKOwner &&
        window.BKOwner.state &&
        window.BKOwner.state.restaurantId
    ) {

        window.BKMenu.init();

        return;
    }


    /*
    Owner dashboard may still be loading Firebase.
    Retry a few times instead of depending on one
    fixed delay.
    */

    let attempts = 0;

    const maxAttempts = 10;


    const retryTimer =
        setInterval(function () {

            attempts++;


            if (
                window.BKOwner &&
                window.BKOwner.state &&
                window.BKOwner.state.restaurantId
            ) {

                clearInterval(retryTimer);

                window.BKMenu.init();

                return;
            }


            /*
            LocalStorage fallback
            */

            if (
                localStorage.getItem(
                    "bkRestaurantId"
                )
            ) {

                clearInterval(retryTimer);

                window.BKMenu.init();

                return;
            }


            if (attempts >= maxAttempts) {

                clearInterval(retryTimer);

                console.warn(
                    "BK Menu: Initialization waiting for restaurant context."
                );
            }

        }, 500);
}


/*
=========================================================
 DOM READY
=========================================================
*/

document.addEventListener(
    "DOMContentLoaded",
    function () {

        initializeBKMenu();

    }
);