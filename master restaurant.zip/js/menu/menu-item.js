"use strict";

import { ownerDb as db } from "../firebase-sessions.js";

import {
    collection,
    addDoc,
    getDocs,
    query,
    orderBy,
    serverTimestamp,
    doc,
    updateDoc,
    deleteDoc
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";

console.log("BK MENU ITEM FILE: LOADED");


/* =====================================================
   BK MENU ITEM MODULE
   FOOD ITEM + CENTRAL IMAGE RESOLVER INTEGRATION
===================================================== */

window.BKMenuItem = {

    state: {
        editingItemId: null,
        items: [],
        loading: false
    },


    /* =================================================
       INITIALIZE
    ================================================= */

    init: function () {

        console.log("------------------------------------------");
        console.log("BK MENU ITEM");
        console.log("Initializing Food Item Module...");

        this.setupButtons();
        this.setupModalControls();
        this.setupFoodItemFilters();
        this.setupImageControls();

        this.loadCategoriesForFoodItem();
        this.loadFoodItems();

        console.log("Food Item Module: READY");
        console.log("------------------------------------------");
    },


    /* =================================================
       RESTAURANT ID
    ================================================= */

    getRestaurantId: function () {

        const restaurantId =
            localStorage.getItem("bkRestaurantId");

        if (!restaurantId) {

            console.error(
                "BK Menu Item: Restaurant ID not found."
            );

            return null;
        }

        return restaurantId;
    },


    /* =================================================
       FIRESTORE COLLECTION
    ================================================= */

    getItemsCollection: function () {

        const restaurantId =
            this.getRestaurantId();

        if (!restaurantId) return null;

        return collection(
            db,
            "restaurants",
            restaurantId,
            "menuItems"
        );
    },


    /* =================================================
       BUTTONS
    ================================================= */

    setupButtons: function () {

        const addFoodItemButton =
            document.getElementById("addFoodItemButton");

        const emptyAddFoodItemButton =
            document.getElementById(
                "emptyAddFoodItemButton"
            );

        const addMenuItemButton =
            document.getElementById(
                "addMenuItemButton"
            );


        if (addFoodItemButton) {

            addFoodItemButton.addEventListener(
                "click",
                () => {

                    console.log(
                        "Add Food Item button clicked."
                    );

                    this.openFoodItemModal();
                }
            );
        }


        if (emptyAddFoodItemButton) {

            emptyAddFoodItemButton.addEventListener(
                "click",
                () => {

                    console.log(
                        "Create First Food Item clicked."
                    );

                    this.openFoodItemModal();
                }
            );
        }


        if (addMenuItemButton) {

            addMenuItemButton.addEventListener(
                "click",
                () => {

                    console.log(
                        "Add Menu Item button clicked."
                    );

                    this.openFoodItemModal();
                }
            );
        }
    },


    /* =================================================
       MODAL CONTROLS
    ================================================= */

    setupModalControls: function () {

        const modal =
            document.getElementById("foodItemModal");

        const closeButton =
            document.getElementById(
                "closeFoodItemModalButton"
            );

        const cancelButton =
            document.getElementById(
                "cancelFoodItemButton"
            );

        const saveButton =
            document.getElementById(
                "saveFoodItemButton"
            );


        if (closeButton) {

            closeButton.addEventListener(
                "click",
                () => {

                    this.closeFoodItemModal();
                }
            );
        }


        if (cancelButton) {

            cancelButton.addEventListener(
                "click",
                () => {

                    this.closeFoodItemModal();
                }
            );
        }


        if (modal) {

            const backdrop =
                modal.querySelector(
                    "[data-close-food-modal]"
                );

            if (backdrop) {

                backdrop.addEventListener(
                    "click",
                    () => {

                        this.closeFoodItemModal();
                    }
                );
            }
        }


        if (saveButton) {

            saveButton.addEventListener(
                "click",
                () => {

                    this.saveFoodItem();
                }
            );
        }


        document.addEventListener(
            "keydown",
            (event) => {

                if (event.key !== "Escape") return;

                const foodModal =
                    document.getElementById(
                        "foodItemModal"
                    );

                if (
                    foodModal &&
                    (
                        foodModal.classList.contains(
                            "is-open"
                        ) ||
                        foodModal.classList.contains(
                            "active"
                        ) ||
                        foodModal.getAttribute(
                            "aria-hidden"
                        ) === "false"
                    )
                ) {

                    this.closeFoodItemModal();
                }
            }
        );
    },


    /* =================================================
       OPEN FOOD ITEM MODAL
    ================================================= */

    openFoodItemModal: function () {

        const modal =
            document.getElementById(
                "foodItemModal"
            );

        const title =
            document.getElementById(
                "foodItemModalTitle"
            );

        const formMessage =
            document.getElementById(
                "foodItemFormMessage"
            );


        if (!modal) {

            console.error(
                "BK Menu Item: Food Item modal not found."
            );

            return;
        }


        this.state.editingItemId = null;


        if (title) {

            title.textContent =
                "Add Food Item";
        }


        this.resetFoodItemForm();


        if (formMessage) {

            formMessage.textContent = "";
            formMessage.style.display = "none";
        }


        modal.classList.add("is-open");
        modal.setAttribute(
            "aria-hidden",
            "false"
        );


        const nameInput =
            document.getElementById(
                "menuItemName"
            );

        if (nameInput) {

            setTimeout(() => {

                nameInput.focus();

            }, 100);
        }


        console.log(
            "BK Menu Item: Add modal OPENED."
        );
    },


    /* =================================================
       CLOSE FOOD ITEM MODAL
    ================================================= */

    closeFoodItemModal: function () {

        const modal =
            document.getElementById(
                "foodItemModal"
            );

        if (!modal) return;


        modal.classList.remove(
            "is-open"
        );

        modal.setAttribute(
            "aria-hidden",
            "true"
        );

        this.state.editingItemId = null;


        console.log(
            "BK Menu Item: Food Item modal CLOSED."
        );
    },


    /* =================================================
       RESET FORM
    ================================================= */

    resetFoodItemForm: function () {

        const fields = [
            "menuItemName",
            "menuItemDescription",
            "menuItemCategory",
            "menuItemPrice",
            "menuItemImageUrl"
        ];


        fields.forEach((id) => {

            const element =
                document.getElementById(id);

            if (!element) return;


            if (
                element.tagName === "SELECT"
            ) {

                element.selectedIndex = 0;

            } else {

                element.value = "";
            }
        });


        const availableCheckbox =
            document.getElementById(
                "menuItemAvailable"
            );

        if (availableCheckbox) {

            availableCheckbox.checked = true;
        }


        const imageFile =
            document.getElementById(
                "menuItemImageFile"
            );

        if (imageFile) {

            imageFile.value = "";
        }


        const imagePreview =
            document.getElementById(
                "menuItemImagePreview"
            );

        if (imagePreview) {

            imagePreview.innerHTML = "";
            imagePreview.style.display = "none";
        }


        const imageMessage =
            document.getElementById(
                "menuItemImageMessage"
            );

        if (imageMessage) {

            imageMessage.textContent = "";
            imageMessage.style.display = "none";
        }
    },


    /* =================================================
       GET FORM DATA
    ================================================= */

    getFormData: function () {

        const nameInput =
            document.getElementById(
                "menuItemName"
            );

        const descriptionInput =
            document.getElementById(
                "menuItemDescription"
            );

        const categoryInput =
            document.getElementById(
                "menuItemCategory"
            );

        const priceInput =
            document.getElementById(
                "menuItemPrice"
            );

        const imageUrlInput =
            document.getElementById(
                "menuItemImageUrl"
            );

        const availableInput =
            document.getElementById(
                "menuItemAvailable"
            );


        const name =
            nameInput
                ? nameInput.value.trim()
                : "";


        const description =
            descriptionInput
                ? descriptionInput.value.trim()
                : "";


        const categoryId =
            categoryInput
                ? categoryInput.value.trim()
                : "";


        const priceValue =
            priceInput
                ? priceInput.value.trim()
                : "";


        const imageUrl =
            imageUrlInput
                ? imageUrlInput.value.trim()
                : "";


        const available =
            availableInput
                ? availableInput.checked
                : true;


        const price =
            Number(priceValue);


        return {

            name,
            description,
            categoryId,
            price,
            imageUrl,
            isAvailable: available

        };
    },


    /* =================================================
       VALIDATE FORM
    ================================================= */

    validateForm: function (data) {

        if (!data.name) {

            this.showFormMessage(
                "Please enter a food item name.",
                true
            );

            return false;
        }


        if (data.name.length < 2) {

            this.showFormMessage(
                "Food item name is too short.",
                true
            );

            return false;
        }


        if (!data.categoryId) {

            this.showFormMessage(
                "Please select a category.",
                true
            );

            return false;
        }


        if (!Number.isFinite(data.price)) {

            this.showFormMessage(
                "Please enter a valid price.",
                true
            );

            return false;
        }


        if (data.price < 0) {

            this.showFormMessage(
                "Price cannot be negative.",
                true
            );

            return false;
        }


        return true;
    },


    /* =================================================
       SAVE FOOD ITEM
    ================================================= */

    saveFoodItem: async function () {

        const restaurantId =
            this.getRestaurantId();

        if (!restaurantId) {

            this.showFormMessage(
                "Restaurant session not found.",
                true
            );

            return;
        }


        const data =
            this.getFormData();


        if (!this.validateForm(data)) {

            return;
        }


        const saveButton =
            document.getElementById(
                "saveFoodItemButton"
            );


        try {

            this.state.loading = true;


            if (saveButton) {

                saveButton.disabled = true;

                saveButton.textContent =
                    "Saving...";
            }


            this.showFormMessage(
                "Saving food item...",
                false
            );


            const itemsRef =
                this.getItemsCollection();


            if (!itemsRef) {

                throw new Error(
                    "Food item collection unavailable."
                );
            }


            /* -----------------------------------------
               UPDATE EXISTING ITEM
            ----------------------------------------- */

            if (this.state.editingItemId) {

                const itemRef =
                    doc(
                        db,
                        "restaurants",
                        restaurantId,
                        "menuItems",
                        this.state.editingItemId
                    );


                await updateDoc(
                    itemRef,
                    {
                        name: data.name,
                        description: data.description,
                        categoryId: data.categoryId,
                        price: data.price,
                        imageUrl: data.imageUrl,
                        isAvailable:
                            data.isAvailable,
                        updatedAt:
                            serverTimestamp()
                    }
                );


                console.log(
                    "BK Menu Item: Food item updated successfully."
                );


            } else {

                /* -------------------------------------
                   CREATE NEW ITEM
                ------------------------------------- */

                await addDoc(
                    itemsRef,
                    {
                        name: data.name,
                        description: data.description,
                        categoryId: data.categoryId,
                        price: data.price,
                        imageUrl: data.imageUrl,
                        isAvailable:
                            data.isAvailable,

                        /*
                         * If owner supplied a URL,
                         * remember that.
                         *
                         * Otherwise resolver/fallback
                         * will handle the visual.
                         */
                        imageStatus:
                            data.imageUrl
                                ? "url"
                                : "resolver",

                        createdAt:
                            serverTimestamp(),

                        updatedAt:
                            serverTimestamp()
                    }
                );


                console.log(
                    "BK Menu Item: Food item saved successfully."
                );
            }


            this.closeFoodItemModal();

            await this.loadFoodItems();


        } catch (error) {

            console.error(
                "=========================================="
            );

            console.error(
                "BK FOOD ITEM SAVE ERROR"
            );

            console.error(
                "Error code:",
                error.code
            );

            console.error(
                "Error message:",
                error.message
            );

            console.error(
                "Full error:",
                error
            );

            console.error(
                "=========================================="
            );


            this.showFormMessage(
                "Error: " +
                (error.code || "unknown"),
                true
            );


        } finally {

            this.state.loading = false;


            if (saveButton) {

                saveButton.disabled = false;

                saveButton.textContent =
                    "Save Food Item";
            }
        }
    },


    /* =================================================
       LOAD FOOD ITEMS
    ================================================= */

    loadFoodItems: async function () {

        const restaurantId =
            this.getRestaurantId();

        if (!restaurantId) return;


        try {

            console.log(
                "BK Menu Item: Loading food items..."
            );


            const itemsRef =
                this.getItemsCollection();


            if (!itemsRef) return;


            const itemsQuery =
                query(
                    itemsRef,
                    orderBy(
                        "createdAt",
                        "asc"
                    )
                );


            const snapshot =
                await getDocs(itemsQuery);


            this.state.items =
                snapshot.docs.map(
                    (itemDoc) => ({

                        id: itemDoc.id,

                        ...itemDoc.data()

                    })
                );


            console.log(
                "BK Menu Item: Food items loaded:",
                this.state.items.length
            );


            await this.renderFoodItems();

            this.updateFoodItemSummary();


        } catch (error) {

            console.error(
                "BK Menu Item: Loading failed.",
                error
            );
        }
    },


    /* =================================================
       RESOLVE IMAGE
       
       PRIORITY:
       1. Manual image URL
       2. BKFoodImageResolver
       3. Premium fallback
    ================================================= */

    resolveItemVisual: async function (item) {

        const manualImageUrl =
            typeof item.imageUrl === "string"
                ? item.imageUrl.trim()
                : "";


        /* ---------------------------------------------
           PRIORITY 1
           MANUALLY SUPPLIED IMAGE URL
        --------------------------------------------- */

if (manualImageUrl) {

            console.log(
                "BK Menu Image: Using manual image URL:",
                item.name
            );


            return {

                status: "manual",

                imageUrl:
                    manualImageUrl

            };
        }


        /* ---------------------------------------------
           PRIORITY 2
           CENTRAL FOOD IMAGE RESOLVER
        --------------------------------------------- */

        if (
            window.BKFoodImageResolver &&
            typeof
            window.BKFoodImageResolver.resolve ===
            "function"
        ) {

            try {

                const result =
                    await
                    window.BKFoodImageResolver.resolve(
                        item.name
                    );


                if (
                    result &&
                    result.status === "matched" &&
                    result.imageUrl
                ) {

                    console.log(
                        "BK Menu Image: Resolver matched:",
                        item.name
                    );


                    return {

                        status: "resolver",

                        imageUrl:
                            result.imageUrl
                    };
                }


                console.warn(
                    "BK Menu Image: Resolver returned fallback:",
                    item.name,
                    result
                );


            } catch (error) {

                console.warn(
                    "BK Menu Image: Resolver error:",
                    item.name,
                    error
                );
            }
        } else {

            console.warn(
                "BK Menu Image: BKFoodImageResolver not available."
            );
        }


        /* ---------------------------------------------
           PRIORITY 3
           PREMIUM #6 FALLBACK
        --------------------------------------------- */

        return {

            status: "fallback",

            imageUrl: null
        };
    },


    /* =================================================
       RENDER FOOD ITEMS
    ================================================= */

    renderFoodItems: async function () {

        const grid =
            document.getElementById(
                "menuItemsGrid"
            );

        const emptyState =
            document.getElementById(
                "menuItemEmptyState"
            );


        if (!grid) {

            console.warn(
                "BK Menu Item: Food item grid not found."
            );

            return;
        }


        grid.innerHTML = "";


        const items =
            this.state.items || [];


        if (items.length === 0) {

            if (emptyState) {

                emptyState.style.display = "";
            }

            return;
        }


        if (emptyState) {

            emptyState.style.display = "none";
        }


        /* ---------------------------------------------
           CREATE CARDS
        --------------------------------------------- */

        for (const item of items) {

            const card =
                await this.createFoodItemCard(item);


            grid.appendChild(card);
        }


        this.setupFoodCardActions();
    },


    /* =================================================
       CREATE FOOD ITEM CARD
    ================================================= */

    createFoodItemCard: async function (item) {

        const card =
            document.createElement(
                "article"
            );


        card.className =
            "menu-item-card";


        card.dataset.itemId =
            item.id;


        const isAvailable =
            item.isAvailable !== false;


        const availabilityText =
            isAvailable
                ? "Available"
                : "Hidden";


        const availabilityClass =
            isAvailable
                ? "is-available"
                : "is-hidden";


        const visual =
            await this.resolveItemVisual(
                item
            );


        let visualHTML = "";


        /* -----------------------------------------
           REAL IMAGE
        ----------------------------------------- */

        if (
            visual.status === "manual" ||
            visual.status === "resolver"
        ) {

            visualHTML = `
                <div
                    class="menu-item-card-image menu-item-real-image"
                    data-food-image
                    data-item-id="${this.escapeHtml(item.id)}"
                >
                    <img
                        src="${this.escapeHtml(visual.imageUrl)}"
                        alt="${this.escapeHtml(item.name)}"
                        loading="lazy"
                        data-item-image
                    >
                </div>
            `;

        } else {

            /* -------------------------------------
               PREMIUM #6 FALLBACK
            ------------------------------------- */

            visualHTML =
                this.createPremiumFallbackHTML(
                    item
                );
        }


        card.innerHTML = `
            ${visualHTML}

            <div class="menu-item-card-content">

                <div class="menu-item-card-top">

                    <span
                        class="menu-item-availability ${availabilityClass}"
                    >
                        <span
                            class="menu-item-status-dot"
                        ></span>

                        ${availabilityText}

                    </span>

                    <span
                        class="menu-item-veg-badge"
                    >
                        VEG
                    </span>

                </div>


                <div class="menu-item-card-info">

                    <h3>
                        ${this.escapeHtml(item.name)}
                    </h3>

                    <p>
                        ${this.escapeHtml(
                            item.description ||
                            "No description added."
                        )}
                    </p>

                </div>


                <div class="menu-item-card-bottom">

                    <strong
                        class="menu-item-price"
                    >
                        ₹${this.formatPrice(item.price)}
                    </strong>

                </div>


                <div class="menu-item-card-actions">

                    <button
                        type="button"
                        class="menu-item-edit-button"
                        data-action="edit-food-item"
                        data-item-id="${this.escapeHtml(item.id)}"
                    >
                        Edit
                    </button>


                    <button
                        type="button"
                        class="menu-item-delete-button"
                        data-action="delete-food-item"
                        data-item-id="${this.escapeHtml(item.id)}"
                    >
                        Delete
                    </button>

                </div>

            </div>
        `;


        /*
         * IMPORTANT:
         * If real image later fails,
         * automatically switch to #6 fallback.
         */

        this.setupFoodImageFallback(
            card,
            item
        );


        return card;
    },


    /* =================================================
       IMAGE FALLBACK
    ================================================= */

    setupFoodImageFallback: function (
        card,
        item
    ) {

        if (!card || !item) return;


        const image =
            card.querySelector(
                "[data-item-image]"
            );


        const imageContainer =
            card.querySelector(
                "[data-food-image]"
            );


        if (
            !image ||
            !imageContainer
        ) {

            return;
        }


        image.addEventListener(
            "error",
            () => {

                console.warn(
                    "BK Menu Image: Image failed, using premium fallback.",
                    item.name
                );


                const fallbackHTML =
                    this.createPremiumFallbackHTML(
                        item
                    );


                imageContainer.outerHTML =
                    fallbackHTML;
            }
        );


        image.addEventListener(
            "load",
            () => {

                image.dataset.fallbackReady =
                    "true";


                console.log(
                    "BK Menu Image: Image loaded successfully.",
                    item.name
                );
            }
        );
    },


    /* =================================================
       FOOD CARD ACTIONS
    ================================================= */

    setupFoodCardActions: function () {

        const grid =
            document.getElementById(
                "menuItemsGrid"
            );


        if (!grid) return;


        if (
            grid.dataset.actionsReady ===
            "true"
        ) {

            return;
        }


        grid.dataset.actionsReady =
            "true";


        grid.addEventListener(
            "click",
            (event) => {

                const button =
                    event.target.closest(
                        "[data-action]"
                    );


                if (!button) return;


                const action =
                    button.dataset.action;


                const itemId =
                    button.dataset.itemId;


                if (!itemId) return;


                if (
                    action ===
                    "edit-food-item"
                ) {

                    this.editFoodItem(
                        itemId
                    );

                    return;
                }


                if (
                    action ===
                    "delete-food-item"
                ) {

                    this.deleteFoodItem(
                        itemId
                    );

                    return;
                }
            }
        );
    },


    /* =================================================
       EDIT FOOD ITEM
    ================================================= */

    editFoodItem: function (itemId) {

        const item =
            (this.state.items || [])
                .find(
                    (foodItem) =>
                        foodItem.id === itemId
                );


        if (!item) {

            console.error(
                "BK Menu Item: Food item not found:",
                itemId
            );

            return;
        }


        this.state.editingItemId =
            itemId;


        const title =
            document.getElementById(
                "foodItemModalTitle"
            );


        if (title) {

            title.textContent =
                "Edit Food Item";
        }


        const nameInput =
            document.getElementById(
                "menuItemName"
            );


        const descriptionInput =
            document.getElementById(
                "menuItemDescription"
            );


        const categoryInput =
            document.getElementById(
                "menuItemCategory"
            );


        const priceInput =
            document.getElementById(
                "menuItemPrice"
            );


        const imageUrlInput =
            document.getElementById(
                "menuItemImageUrl"
            );


        const availableInput =
            document.getElementById(
                "menuItemAvailable"
            );


        if (nameInput) {

            nameInput.value =
                item.name || "";
        }


        if (descriptionInput) {

            descriptionInput.value =
                item.description || "";
        }


        if (categoryInput) {

            categoryInput.value =
                item.categoryId || "";
        }


        if (priceInput) {

            priceInput.value =
                item.price ?? "";
        }


        if (imageUrlInput) {

            imageUrlInput.value =
                item.imageUrl || "";
        }


        if (availableInput) {

            availableInput.checked =
                item.isAvailable !== false;
        }


        const formMessage =
            document.getElementById(
                "foodItemFormMessage"
            );


        if (formMessage) {

            formMessage.textContent = "";

            formMessage.style.display =
                "none";
        }


        const modal =
            document.getElementById(
                "foodItemModal"
            );


        if (modal) {

            modal.classList.add(
                "is-open"
            );

            modal.setAttribute(
                "aria-hidden",
                "false"
            );
        }


        console.log(
            "BK Menu Item: Editing food item:",
            itemId
        );
    },


    /* =================================================
       DELETE FOOD ITEM
    ================================================= */

    deleteFoodItem: async function (
        itemId
    ) {

        const item =
            (this.state.items || [])
                .find(
                    (foodItem) =>
                        foodItem.id === itemId
                );


        if (!item) {

            console.error(
                "BK Menu Item: Food item not found:",
                itemId
            );

            return;
        }


        const confirmed =
            window.confirm(
                `Delete "${item.name}" from the menu?`
            );


        if (!confirmed) return;


        const restaurantId =
            this.getRestaurantId();


        if (!restaurantId) {

            console.error(
                "BK Menu Item: Restaurant ID not found."
            );

            return;
        }


        try {

            console.log(
                "BK Menu Item: Deleting food item:",
                itemId
            );


            const itemRef =
                doc(
                    db,
                    "restaurants",
                    restaurantId,
                    "menuItems",
                    itemId
                );


            await deleteDoc(
                itemRef
            );


            console.log(
                "BK Menu Item: Food item deleted successfully."
            );


            await this.loadFoodItems();


        } catch (error) {

            console.error(
                "BK Menu Item: Delete failed.",
                error
            );


            alert(
                "Unable to delete the food item. Please try again."
            );
        }
    },


    /* =================================================
       SUMMARY
    ================================================= */
updateFoodItemSummary: function () {

        const items =
            this.state.items || [];


        const total =
            items.length;


        const available =
            items.filter(
                (item) =>
                    item.isAvailable === true
            ).length;


        const hidden =
            items.filter(
                (item) =>
                    item.isAvailable === false
            ).length;


        const totalElement =
            document.getElementById(
                "menuTotalItems"
            );


        const availableElement =
            document.getElementById(
                "menuAvailableItems"
            );


        const hiddenElement =
            document.getElementById(
                "menuHiddenItems"
            );


        if (totalElement) {

            totalElement.textContent =
                total;
        }


        if (availableElement) {

            availableElement.textContent =
                available;
        }


        if (hiddenElement) {

            hiddenElement.textContent =
                hidden;
        }


        const countElement =
            document.getElementById(
                "menuItemCount"
            );


        if (countElement) {

            countElement.textContent =
                `${total} ${
                    total === 1
                        ? "Item"
                        : "Items"
                }`;
        }
    },


    /* =================================================
       SEARCH + CATEGORY FILTER
    ================================================= */

    setupFoodItemFilters: function () {

        const searchInput =
            document.getElementById(
                "menuItemSearch"
            );


        const categoryFilter =
            document.getElementById(
                "menuItemCategoryFilter"
            );


        if (searchInput) {

            searchInput.addEventListener(
                "input",
                () => {

                    this.applyFoodItemFilters();
                }
            );
        }


        if (categoryFilter) {

            categoryFilter.addEventListener(
                "change",
                () => {

                    this.applyFoodItemFilters();
                }
            );
        }


        console.log(
            "Food Item Search & Filter: READY"
        );
    },


    /* =================================================
       APPLY FILTER
    ================================================= */

    applyFoodItemFilters: function () {

        const searchInput =
            document.getElementById(
                "menuItemSearch"
            );


        const categoryFilter =
            document.getElementById(
                "menuItemCategoryFilter"
            );


        const searchTerm =
            searchInput
                ? searchInput.value
                    .trim()
                    .toLowerCase()
                : "";


        const selectedCategory =
            categoryFilter
                ? categoryFilter.value
                : "";


        const filteredItems =
            (this.state.items || [])
                .filter(
                    (item) => {

                        const name =
                            String(
                                item.name || ""
                            ).toLowerCase();


                        const description =
                            String(
                                item.description ||
                                ""
                            ).toLowerCase();


                        const searchMatch =
                            !searchTerm ||
                            name.includes(
                                searchTerm
                            ) ||
                            description.includes(
                                searchTerm
                            );


                        const categoryMatch =
                            !selectedCategory ||
                            item.categoryId ===
                            selectedCategory;


                        return (
                            searchMatch &&
                            categoryMatch
                        );
                    }
                );


        this.renderFilteredFoodItems(
            filteredItems
        );
    },


    /* =================================================
       RENDER FILTERED ITEMS
    ================================================= */

    renderFilteredFoodItems:
        async function (items) {

            const grid =
                document.getElementById(
                    "menuItemsGrid"
                );


            const emptyState =
                document.getElementById(
                    "menuItemEmptyState"
                );


            if (!grid) return;


            grid.innerHTML = "";


            if (
                !items ||
                items.length === 0
            ) {

                if (emptyState) {

                    emptyState.style.display =
                        "";
                }


                this.updateFilteredItemCount(
                    0
                );


                return;
            }


            if (emptyState) {

                emptyState.style.display =
                    "none";
            }


            for (const item of items) {

                const card =
                    await this.createFoodItemCard(
                        item
                    );


                grid.appendChild(card);
            }


            this.updateFilteredItemCount(
                items.length
            );


            this.setupFoodCardActions();
        },


    /* =================================================
       IMAGE CONTROLS
    ================================================= */

    setupImageControls: function () {

        const imageUrlInput =
            document.getElementById(
                "menuItemImageUrl"
            );


        const imageFileInput =
            document.getElementById(
                "menuItemImageFile"
            );


        if (imageUrlInput) {

            imageUrlInput.addEventListener(
                "input",
                () => {

                    const fileInput =
                        document.getElementById(
                            "menuItemImageFile"
                        );


                    if (
                        fileInput &&
                        imageUrlInput.value.trim() !== ""
                    ) {

                        fileInput.value = "";
                    }


                    this.previewImageFromUrl();
                }
            );


            imageUrlInput.addEventListener(
                "blur",
                () => {

                    this.previewImageFromUrl();
                }
            );
        }


        if (imageFileInput) {

            imageFileInput.addEventListener(
                "change",
                () => {

                    const urlInput =
                        document.getElementById(
                            "menuItemImageUrl"
                        );


                    if (
                        urlInput &&
                        imageFileInput.files.length > 0
                    ) {

                        urlInput.value = "";
                    }


                    this.previewLocalImage();
                }
            );
        }


        console.log(
            "Food Image Controls: READY"
        );
    },


    /* =================================================
       URL IMAGE PREVIEW
    ================================================= */

    previewImageFromUrl: function () {

        const input =
            document.getElementById(
                "menuItemImageUrl"
            );


        const preview =
            document.getElementById(
                "menuItemImagePreview"
            );


        if (!input || !preview) return;


        const imageUrl =
            input.value.trim();


        if (!imageUrl) {

            preview.innerHTML = "";

            preview.style.display =
                "none";

            return;
        }


        preview.style.display =
            "block";


        preview.innerHTML = `
            <div class="menu-image-preview-loading">
                Checking image...
            </div>
        `;


        const image =
            new Image();


        image.onload = () => {

            preview.innerHTML = `

                <div class="menu-image-preview-box">

                    <img
                        src="${this.escapeHtml(imageUrl)}"
                        alt="Food image preview"
                        class="menu-image-preview-img"
                    >

                    <div
                        class="menu-image-preview-status is-success"
                    >
                        IMAGE READY
                    </div>

                </div>
            `;


            console.log(
                "BK Menu Image: URL image loaded."
            );
        };


        image.onerror = () => {

            preview.innerHTML = `

                <div
                    class="menu-image-preview-box menu-image-preview-fallback"
                >

                    <div
                        class="menu-image-preview-fallback-title"
                    >
                        IMAGE UNAVAILABLE
                    </div>

                    <div
                        class="menu-image-preview-fallback-text"
                    >
                        Premium fallback will be used automatically.
                    </div>

                </div>
            `;


            console.warn(
                "BK Menu Image: URL image failed."
            );
        };


        image.src =
            imageUrl;
    },


    /* =================================================
       LOCAL IMAGE PREVIEW
    ================================================= */

    previewLocalImage: function () {

        const fileInput =
            document.getElementById(
                "menuItemImageFile"
            );


        const preview =
            document.getElementById(
                "menuItemImagePreview"
            );


        if (!fileInput || !preview) return;


        const file =
            fileInput.files &&
            fileInput.files[0];


        if (!file) return;


        if (
            !file.type ||
            !file.type.startsWith(
                "image/"
            )
        ) {

            preview.innerHTML = `

                <div
                    class="menu-image-preview-box menu-image-preview-fallback"
                >

                    <div
                        class="menu-image-preview-fallback-title"
                    >
                        INVALID IMAGE
                    </div>

                    <div
                        class="menu-image-preview-fallback-text"
                    >
                        Please select a valid image file.
                    </div>

                </div>
            `;


            preview.style.display =
                "block";


            console.warn(
                "BK Menu Image: Invalid local file."
            );


            return;
        }


        const temporaryImageUrl =
            URL.createObjectURL(file);


        preview.style.display =
            "block";


        preview.innerHTML = `

            <div class="menu-image-preview-box">

                <img
                    src="${temporaryImageUrl}"
                    alt="Selected food image"
                    class="menu-image-preview-img"
                >

                <div
                    class="menu-image-preview-status is-success"
                >
                    LOCAL IMAGE READY
                </div>

            </div>
        `;


        console.log(
            "BK Menu Image: Local image preview ready.",
            file.name
        );
    },


    /* =================================================
       LOAD CATEGORIES
    ================================================= */

    loadCategoriesForFoodItem:
        async function () {

            const restaurantId =
                this.getRestaurantId();


            if (!restaurantId) {

                console.warn(
                    "BK Menu Item: Restaurant ID not found."
                );

                return;
            }


            const categorySelect =
                document.getElementById(
                    "menuItemCategory"
                );


            const categoryFilter =
                document.getElementById(
                    "menuItemCategoryFilter"
                );


            if (!categorySelect) {

                console.warn(
                    "BK Menu Item: Category select not found."
                );

                return;
            }


            try {

                const categoriesRef =
                    collection(
                        db,
                        "restaurants",
                        restaurantId,
                        "menuCategories"
                    );


                const categoriesQuery =
                    query(
                        categoriesRef,
                        orderBy(
                            "createdAt",
                            "asc"
                        )
                    );


                const snapshot =
                    await getDocs(
                        categoriesQuery
                    );


                const categories =
                    snapshot.docs.map(
                        (categoryDoc) => ({

                            id:
                                categoryDoc.id,

                            ...categoryDoc.data()

                        })
                    );


                categorySelect.innerHTML =
                    `<option value="">Select Category</option>`;


                categories.forEach(
                    (category) => {

                        if (
                            category.isActive ===
                            false
                        ) return;


                        const option =
                            document.createElement(
                                "option"
                            );


                        option.value =
                            category.id;


                        option.textContent =
                            category.name;


                        categorySelect.appendChild(
                            option
                        );
                    }
                );


                if (categoryFilter) {

                    categoryFilter.innerHTML =
                        `<option value="">All Categories</option>`;


                    categories.forEach(
                        (category) => {

                            if (
                                category.isActive ===
                                false
                            ) return;


                            const option =
                                document.createElement(
                                    "option"
                                );


                            option.value =
                                category.id;


                            option.textContent =
                                category.name;


                            categoryFilter.appendChild(
                                option
                            );
                        }
                    );
                }


                console.log(
                    "BK Menu Item: Categories loaded for Food Item dropdown:",
                    categories.length
                );


            } catch (error) {

                console.error(
                    "BK Menu Item: Failed to load categories.",
                    error
                );
            }
        },


    /* =================================================
       PREMIUM #6 FALLBACK
    ================================================= */
/* =================================================
   PREMIUM #7 FALLBACK — ROYAL GOLDEN TABLE
================================================= */
createPremiumFallbackHTML:
    function (item) {

        const itemId =
            this.escapeHtml(
                item.id || ""
            );

        return `

            <div
                class="menu-item-card-image menu-item-premium-fallback"
                data-food-fallback
                data-item-id="${itemId}"
            >

                <div class="menu-fallback-scene">

                    <div class="menu-fallback-glow"></div>

                    <div class="menu-fallback-table"></div>


                    <!-- BK ROYAL BRANDING -->
                    <div class="menu-fallback-brand">

                        <div class="menu-fallback-crown">
                            ♛
                        </div>

                        <div class="menu-fallback-badge">
                            <span>BK</span>
                        </div>

                        <div class="menu-fallback-selection">
                            PREMIUM SELECTION
                        </div>

                    </div>


                    <!-- MAIN MESSAGE -->
                    <div class="menu-fallback-message">

                        <div class="menu-fallback-script">
                            Delicious
                        </div>

                        <strong>
                            Food Awaits
                        </strong>

                        <span>
                            PREMIUM TASTE ALWAYS
                        </span>

                    </div>


                    <!-- CHEF LABEL ONLY -->
                    <div class="menu-fallback-food">

                        <div class="menu-fallback-food-label">
                            CHEF'S SPECIAL
                        </div>

                    </div>


                    <!-- FALLBACK BADGE -->
                    <div class="menu-fallback-tag">
                        FALLBACK IMAGE
                    </div>

                </div>

            </div>

        `;
    },
    /* =================================================
       FILTERED COUNT
    ================================================= */

    updateFilteredItemCount:
        function (count) {

            const countElement =
                document.getElementById(
                    "menuItemCount"
                );


            if (!countElement) return;


            countElement.textContent =
                `${count} ${
                    count === 1
                        ? "Item"
                        : "Items"
                }`;
        },


    /* =================================================
       FORM MESSAGE
    ================================================= */

    showFormMessage:
        function (text, isError) {

            const message =
                document.getElementById(
                    "foodItemFormMessage"
                );


            if (!message) return;


            message.textContent =
                text;


            message.style.display =
                "block";


            message.style.color =
                isError
                    ? "#a34b43"
                    : "#8b713c";
        },


    /* =================================================
       PRICE FORMAT
    ================================================= */

    formatPrice:
        function (value) {

            const number =
                Number(value);


            if (
                !Number.isFinite(number)
            ) {

                return "0";
            }


            return number.toFixed(2);
        },


    /* =================================================
       HTML ESCAPE
    ================================================= */

    escapeHtml:
        function (value) {

            return String(value)

                .replaceAll(
                    "&",
                    "&amp;"
                )

                .replaceAll(
                    "<",
                    "&lt;"
                )

                .replaceAll(
                    ">",
                    "&gt;"
                )

                .replaceAll(
                    '"',
                    "&quot;"
                )

                .replaceAll(
                    "'",
                    "&#039;"
                );
        }
};


/* =====================================================
   DOM READY
===================================================== */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        if (window.BKMenuItem) {

            window.BKMenuItem.init();
        }
    }
);