"use strict";

/* =========================================================
   BK MENU CATEGORY MODULE
   PART 2 — FIRESTORE SAVE + LOAD + RENDER
   ========================================================= */

import { ownerDb as db } from "../firebase-sessions.js";

import {
    collection,
    addDoc,
    getDocs,
    query,
    orderBy,
    serverTimestamp,
    doc,
    updateDoc,
    deleteDoc
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";

console.log("BK MENU CATEGORY FILE: LOADED");


window.BKMenuCategory = {

    state: {
        editingCategoryId: null,
        categories: []
    },


    /* -----------------------------------------------------
       INITIALIZE
       ----------------------------------------------------- */

    init: function () {

        console.log("------------------------------------------");
        console.log("BK MENU CATEGORY");
        console.log("Initializing Category Module...");

        this.setupButtons();
        this.setupModalControls();
        this.setupCategorySearch();

        this.loadCategories();

        console.log("Category Module: READY");
        console.log("------------------------------------------");
    },


    /* -----------------------------------------------------
       GET RESTAURANT ID
       ----------------------------------------------------- */

    getRestaurantId: function () {

        const restaurantId =
            localStorage.getItem("bkRestaurantId");

        if (!restaurantId) {

            console.error(
                "BK Menu: Restaurant ID not found."
            );

            return null;
        }

        return restaurantId;
    },


    /* -----------------------------------------------------
       BUTTON CONTROLS
       ----------------------------------------------------- */

    setupButtons: function () {

        const addCategoryButton =
            document.getElementById("addCategoryButton");

        const emptyAddCategoryButton =
            document.getElementById("emptyAddCategoryButton");


        if (addCategoryButton) {

            addCategoryButton.addEventListener(
                "click",
                () => {

                    console.log(
                        "Add Category button clicked."
                    );

                    this.openCategoryModal();
                }
            );
        }


        if (emptyAddCategoryButton) {

            emptyAddCategoryButton.addEventListener(
                "click",
                () => {

                    console.log(
                        "Create First Category clicked."
                    );

                    this.openCategoryModal();
                }
            );
        }
    },
setupCategorySearch: function () {

    const searchInput =
        document.getElementById(
            "menuCategorySearch"
        );

    if (!searchInput) {

        console.warn(
            "BK: Category search input not found."
        );

        return;
    }


    searchInput.addEventListener(
        "input",
        () => {

            const searchTerm =
                searchInput.value
                    .trim()
                    .toLowerCase();


            const categoryItems =
                document.querySelectorAll(
                    "#section-menu .menu-category-item"
                );


            let visibleCount = 0;


            categoryItems.forEach(
                (item) => {

                    const categoryName =
                        (
                            item.querySelector(
                                ".menu-category-item-info h3"
                            )?.textContent || ""
                        ).toLowerCase();


                    const categoryDescription =
                        (
                            item.querySelector(
                                ".menu-category-item-info p"
                            )?.textContent || ""
                        ).toLowerCase();


                    const matches =
                        categoryName.includes(
                            searchTerm
                        ) ||
                        categoryDescription.includes(
                            searchTerm
                        );


                    if (matches) {

                        item.style.display = "";
                        visibleCount++;

                    } else {

                        item.style.display = "none";

                    }
                }
            );


            const countElement =
                document.getElementById(
                    "menuCategoryCount"
                );


            if (countElement) {

                countElement.textContent =
                    `${visibleCount} ${
                        visibleCount === 1
                            ? "Category"
                            : "Categories"
                    }`;

            }

        }
    );
},

    /* -----------------------------------------------------
       MODAL CONTROLS
       ----------------------------------------------------- */

    setupModalControls: function () {

        const closeButton =
            document.getElementById(
                "closeCategoryModalButton"
            );

        const cancelButton =
            document.getElementById(
                "cancelCategoryButton"
            );

        const modal =
            document.getElementById(
                "categoryModal"
            );


        if (closeButton) {

            closeButton.addEventListener(
                "click",
                () => {

                    this.closeCategoryModal();
                }
            );
        }


        if (cancelButton) {

            cancelButton.addEventListener(
                "click",
                () => {

                    this.closeCategoryModal();
                }
            );
        }


        if (modal) {

            const backdrop =
                modal.querySelector(
                    "[data-close-category-modal]"
                );

            if (backdrop) {

                backdrop.addEventListener(
                    "click",
                    () => {

                        this.closeCategoryModal();
                    }
                );
            }
        }


        document.addEventListener(
            "keydown",
            (event) => {

                if (event.key === "Escape") {

                    this.closeCategoryModal();
                }
            }
        );


        const saveButton =
            document.getElementById(
                "saveCategoryButton"
            );

        if (saveButton) {

            saveButton.addEventListener(
                "click",
                () => {

                    this.saveCategory();
                }
            );
        }
    },


    /* -----------------------------------------------------
       OPEN MODAL
       ----------------------------------------------------- */

    openCategoryModal: function () {

        const modal =
            document.getElementById(
                "categoryModal"
            );

        const title =
            document.getElementById(
                "categoryModalTitle"
            );

        const nameInput =
            document.getElementById(
                "categoryName"
            );

        const descriptionInput =
            document.getElementById(
                "categoryDescription"
            );

        const message =
            document.getElementById(
                "categoryFormMessage"
            );


        if (!modal) {

            console.error(
                "BK Menu: Category modal not found."
            );

            return;
        }


        this.state.editingCategoryId = null;


        if (title) {
            title.textContent = "Add Category";
        }


        if (nameInput) {
            nameInput.value = "";
        }


        if (descriptionInput) {
            descriptionInput.value = "";
        }


        if (message) {

            message.textContent = "";
            message.style.display = "none";
        }


        modal.classList.add("is-open");

        modal.setAttribute(
            "aria-hidden",
            "false"
        );


        if (nameInput) {

            setTimeout(() => {

                nameInput.focus();

            }, 100);
        }


        console.log(
            "BK Menu: Category modal OPENED."
        );
    },


    /* -----------------------------------------------------
       CLOSE MODAL
       ----------------------------------------------------- */

    closeCategoryModal: function () {

        const modal =
            document.getElementById(
                "categoryModal"
            );

        if (!modal) {
            return;
        }


        modal.classList.remove("is-open");

        modal.setAttribute(
            "aria-hidden",
            "true"
        );


        this.state.editingCategoryId = null;


        console.log(
            "BK Menu: Category modal CLOSED."
        );
    },


    /* -----------------------------------------------------
       SAVE CATEGORY
       ----------------------------------------------------- */

    saveCategory: async function () {

        const restaurantId =
            this.getRestaurantId();

        const nameInput =
            document.getElementById(
                "categoryName"
            );

        const descriptionInput =
            document.getElementById(
                "categoryDescription"
            );

        const message =
            document.getElementById(
                "categoryFormMessage"
            );

        const saveButton =
            document.getElementById(
                "saveCategoryButton"
            );


        if (!restaurantId) {

            this.showMessage(
                "Restaurant session not found.",
                true
            );

            return;
        }


        const name =
            nameInput
                ? nameInput.value.trim()
                : "";

        const description =
            descriptionInput
                ? descriptionInput.value.trim()
                : "";


        /* ---------------------------------------------
           VALIDATION
           --------------------------------------------- */

        if (!name) {

            this.showMessage(
                "Please enter a category name.",
                true
            );

            if (nameInput) {
                nameInput.focus();
            }

            return;
        }


        if (name.length < 2) {

            this.showMessage(
                "Category name is too short.",
                true
            );

            return;
        }


        try {

            if (saveButton) {

                saveButton.disabled = true;
                saveButton.textContent =
                    "Saving...";
            }


            this.showMessage(
                "Saving category...",
                false
            );


            /* -----------------------------------------
               FIRESTORE PATH

               restaurants/{restaurantId}
                   └── menuCategories
                           └── categoryId
               ----------------------------------------- */

            const categoriesRef =
                collection(
                    db,
                    "restaurants",
                    restaurantId,
                    "menuCategories"
                );


            if (this.state.editingCategoryId) {

    const categoryRef =
        doc(
            db,
            "restaurants",
            restaurantId,
            "menuCategories",
            this.state.editingCategoryId
        );


    await updateDoc(
        categoryRef,
        {
            name: name,
            description: description,

            updatedAt:
                serverTimestamp()
        }
    );


    console.log(
        "BK Menu: Category updated successfully."
    );

} else {

    await addDoc(
        categoriesRef,
        {
            name: name,
            description: description,

            isActive: true,

            createdAt:
                serverTimestamp(),

            updatedAt:
                serverTimestamp()
        }
    );


    console.log(
        "BK Menu: Category saved successfully."
    );
}


            console.log(
                "BK Menu: Category saved successfully."
            );


            this.closeCategoryModal();

            await this.loadCategories();

} catch (error) {

    console.error("==========================================");
    console.error("BK CATEGORY SAVE ERROR");
    console.error("Error code:", error.code);
    console.error("Error message:", error.message);
    console.error("Full error:", error);
    console.error("==========================================");

    this.showMessage(
        "Error: " + (error.code || "unknown"),
        true
    );
}

 finally {

            if (saveButton) {

                saveButton.disabled = false;
                saveButton.textContent =
                    "Save Category";
            }
        }
    },
    deleteCategory: async function (categoryId) {

    const category =
        this.state.categories.find(
            (item) =>
                item.id === categoryId
        );


    if (!category) {
        return;
    }


    const confirmed =
        window.confirm(
            `Delete "${category.name}" category?`
        );


    if (!confirmed) {
        return;
    }


    const restaurantId =
        this.getRestaurantId();


    if (!restaurantId) {

        console.error(
            "BK Menu: Restaurant ID not found."
        );

        return;
    }


    try {

        console.log(
            "BK Menu: Deleting category:",
            categoryId
        );


        const categoryRef =
            doc(
                db,
                "restaurants",
                restaurantId,
                "menuCategories",
                categoryId
            );


        await deleteDoc(
            categoryRef
        );


        console.log(
            "BK Menu: Category deleted successfully."
        );


        await this.loadCategories();


    } catch (error) {

        console.error(
            "BK Menu: Category delete failed.",
            error
        );


        alert(
            "Could not delete category. Please try again."
        );
    }
},


    /* -----------------------------------------------------
       LOAD CATEGORIES
       ----------------------------------------------------- */

    loadCategories: async function () {

        const restaurantId =
            this.getRestaurantId();


        if (!restaurantId) {
            return;
        }


        try {

            console.log(
                "BK Menu: Loading categories..."
            );


            const categoriesRef =
                collection(
                    db,
                    "restaurants",
                    restaurantId,
                    "menuCategories"
                );


            const categoriesQuery =
                query(
                    categoriesRef,
                    orderBy(
                        "createdAt",
                        "asc"
                    )
                );


            const snapshot =
                await getDocs(
                    categoriesQuery
                );


            this.state.categories =
                snapshot.docs.map(
                    (doc) => {

                        return {
                            id: doc.id,
                            ...doc.data()
                        };
                    }
                );


            console.log(
                "BK Menu: Categories loaded:",
                this.state.categories.length
            );


            this.renderCategories();

            this.updateCategoryCount();


        } catch (error) {

            console.error(
                "BK Menu: Category loading failed.",
                error
            );
        }
    },


    /* -----------------------------------------------------
       RENDER CATEGORIES
       ----------------------------------------------------- */

renderCategories: function () {

    const list =
        document.getElementById(
            "menuCategoryList"
        );

    const emptyState =
        document.getElementById(
            "menuCategoryEmptyState"
        );


    if (!list) {

        console.warn(
            "BK Menu: Category list container not found."
        );

        return;
    }


    list.innerHTML = "";


    if (
        !this.state.categories ||
        this.state.categories.length === 0
    ) {

        if (emptyState) {
            emptyState.style.display = "";
        }

        return;
    }


    if (emptyState) {
        emptyState.style.display = "none";
    }


    this.state.categories.forEach(
        (category) => {

            const card =
                document.createElement("div");


            card.className =
                "menu-category-item";


            card.innerHTML = `

                <div class="menu-category-item-content">

                    <div class="menu-category-item-icon">
                        ◇
                    </div>

                    <div class="menu-category-item-info">

                        <h3>
                            ${this.escapeHtml(
                                category.name
                            )}
                        </h3>

                        <p>
                            ${this.escapeHtml(
                                category.description ||
                                "No description added."
                            )}
                        </p>

                    </div>

                </div>


                <div class="menu-category-item-actions">

                    <button
                        type="button"
                        class="menu-category-edit-button"
                        data-category-action="edit"
                        data-category-id="${category.id}"
                    >
                        Edit
                    </button>

                    <button
                        type="button"
                        class="menu-category-delete-button"
                        data-category-action="delete"
                        data-category-id="${category.id}"
                    >
                        Delete
                    </button>

                </div>
            `;


            list.appendChild(card);
        }
    );


    this.setupCategoryCardActions();
},

setupCategoryCardActions: function () {

    const list =
        document.getElementById(
            "menuCategoryList"
        );


    if (!list) {
        return;
    }


    list.onclick = (event) => {

        const button =
            event.target.closest(
                "[data-category-action]"
            );


        if (!button) {
            return;
        }


        const action =
            button.getAttribute(
                "data-category-action"
            );


        const categoryId =
            button.getAttribute(
                "data-category-id"
            );


        if (!categoryId) {
            return;
        }


        if (action === "edit") {

            this.openEditCategoryModal(
                categoryId
            );

            return;
        }


        if (action === "delete") {

            this.deleteCategory(
                categoryId
            );
        }
    };
},
openEditCategoryModal: function (categoryId) {

    const category =
        this.state.categories.find(
            (item) =>
                item.id === categoryId
        );


    if (!category) {

        console.error(
            "BK Menu: Category not found."
        );

        return;
    }


    const modal =
        document.getElementById(
            "categoryModal"
        );

    const title =
        document.getElementById(
            "categoryModalTitle"
        );

    const nameInput =
        document.getElementById(
            "categoryName"
        );

    const descriptionInput =
        document.getElementById(
            "categoryDescription"
        );

    const message =
        document.getElementById(
            "categoryFormMessage"
        );


    if (!modal) {
        return;
    }


    this.state.editingCategoryId =
        categoryId;


    if (title) {
        title.textContent =
            "Edit Category";
    }


    if (nameInput) {
        nameInput.value =
            category.name || "";
    }


    if (descriptionInput) {
        descriptionInput.value =
            category.description || "";
    }


    if (message) {

        message.textContent = "";

        message.style.display =
            "none";
    }


    modal.classList.add("is-open");

    modal.setAttribute(
        "aria-hidden",
        "false"
    );


    if (nameInput) {

        setTimeout(() => {

            nameInput.focus();

        }, 100);
    }


    console.log(
        "BK Menu: Editing category:",
        categoryId
    );
},

    /* -----------------------------------------------------
       CATEGORY COUNT
       ----------------------------------------------------- */

    updateCategoryCount: function () {

        const countElement =
            document.getElementById(
                "menuCategoryCount"
            );


        if (!countElement) {
            return;
        }


        const count =
            this.state.categories.length;


        countElement.textContent =
            `${count} ${count === 1 ? "Category" : "Categories"}`;


        const summaryCount =
            document.getElementById(
                "menuTotalCategories"
            );


        if (summaryCount) {

            summaryCount.textContent =
                count;
        }
    },


    /* -----------------------------------------------------
       FORM MESSAGE
       ----------------------------------------------------- */

    showMessage: function (
        text,
        isError
    ) {

        const message =
            document.getElementById(
                "categoryFormMessage"
            );


        if (!message) {
            return;
        }


        message.textContent = text;

        message.style.display = "block";

        message.style.color =
            isError
                ? "#a34b43"
                : "#8b713c";
    },


    /* -----------------------------------------------------
       HTML SAFETY
       ----------------------------------------------------- */

    escapeHtml: function (value) {

        return String(value)
            .replaceAll("&", "&amp;")
            .replaceAll("<", "&lt;")
            .replaceAll(">", "&gt;")
            .replaceAll('"', "&quot;")
            .replaceAll("'", "&#039;");
    }
};


/* =========================================================
   AUTO INITIALIZATION
   ========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        if (window.BKMenuCategory) {

            window.BKMenuCategory.init();
        }
    }
);