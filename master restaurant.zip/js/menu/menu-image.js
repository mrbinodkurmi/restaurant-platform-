"use strict";

/* =====================================================
   BK MENU IMAGE ENGINE
   CENTRAL FOOD IMAGE RESOLVER
===================================================== */

console.log("BK MENU IMAGE FILE: LOADED");


/* =====================================================
   FOOD IMAGE DATABASE
   TOTAL: 106 ENTRIES
===================================================== */

const foodImageDatabase = {

    /* =================================================
       🍳 BREAKFAST & TIFFINS — 23
    ================================================= */

    "idli": {
        img: "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&w=900&q=80",
        desc: "Steamed rice and lentil cakes."
    },

    "masala dosa": {
        img: "https://images.unsplash.com/photo-1668236543090-82eba5ee5976?auto=format&fit=crop&w=900&q=80",
        desc: "Crispy fermented crepe with potato filling."
    },

    "dosa": {
        img: "https://images.unsplash.com/photo-1668236543090-82eba5ee5976?auto=format&fit=crop&w=900&q=80",
        desc: "Crispy South Indian delight."
    },

    "aloo paratha": {
        img: "https://images.unsplash.com/photo-1626074353765-517a681e40be?auto=format&fit=crop&w=900&q=80",
        desc: "Stuffed potato flatbread with butter."
    },

    "poha": {
        img: "https://images.unsplash.com/photo-1614088685112-0a760b71a3c8?auto=format&fit=crop&w=900&q=80",
        desc: "Flattened rice cooked with onions and spices."
    },

    "appam": {
        img: "https://images.unsplash.com/photo-1610057099443-fde8c4d50f91?auto=format&fit=crop&w=900&q=80",
        desc: "Lacy fermented rice pancake."
    },

    "upma": {
        img: "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&w=900&q=80",
        desc: "Savory semolina porridge."
    },

    "poori bhaji": {
        img: "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=900&q=80",
        desc: "Deep-fried bread with spiced potato curry."
    },

    "amritsari kulcha": {
        img: "https://images.unsplash.com/photo-1626074353765-517a681e40be?auto=format&fit=crop&w=900&q=80",
        desc: "Stuffed tandoor-baked flatbread."
    },

    "chole bhature": {
        img: "https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?auto=format&fit=crop&w=900&q=80",
        desc: "Spiced chickpeas with fried puffy bread."
    },

    "medu vada": {
        img: "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&w=900&q=80",
        desc: "Crispy fried lentil doughnuts."
    },

    "dhokla": {
        img: "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=900&q=80",
        desc: "Steamed fermented gram flour snack."
    },

    "kachori": {
        img: "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=900&q=80",
        desc: "Deep-fried pastry stuffed with spiced lentils."
    },

    "masala omelette": {
        img: "https://images.unsplash.com/photo-1525351484163-7529414344d8?auto=format&fit=crop&w=900&q=80",
        desc: "Spiced Indian style omelette with onions and herbs."
    },

    "bread omelette": {
        img: "https://images.unsplash.com/photo-1525351484163-7529414344d8?auto=format&fit=crop&w=900&q=80",
        desc: "Classic street style toast wrapped in fluffy omelette."
    },

    "chole kulche": {
        img: "https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?auto=format&fit=crop&w=900&q=80",
        desc: "Tangy spiced chickpea curry served with soft kulchas."
    },

    "misal pav": {
        img: "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=900&q=80",
        desc: "Spicy sprouted bean curry topped with farsan and pav."
    },

    "sabudana khichdi": {
        img: "https://images.unsplash.com/photo-1614088685112-0a760b71a3c8?auto=format&fit=crop&w=900&q=80",
        desc: "Tapioca pearls cooked with roasted peanuts and mild spices."
    },

    "sabudana vada": {
        img: "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=900&q=80",
        desc: "Crispy deep-fried tapioca and potato patties."
    },

    "methi paratha": {
        img: "https://images.unsplash.com/photo-1626074353765-517a681e40be?auto=format&fit=crop&w=900&q=80",
        desc: "Whole wheat flatbread kneaded with fresh fenugreek leaves."
    },

    "paneer paratha": {
        img: "https://images.unsplash.com/photo-1626074353765-517a681e40be?auto=format&fit=crop&w=900&q=80",
        desc: "Stuffed flatbread loaded with spiced grated cottage cheese."
    },

    "pesarattu": {
        img: "https://images.unsplash.com/photo-1668236543090-82eba5ee5976?auto=format&fit=crop&w=900&q=80",
        desc: "Nutritious green gram crepe served with ginger chutney."
    },

    "uttapam": {
        img: "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&w=900&q=80",
        desc: "Thick savory rice pancake topped with onions and tomatoes."
    },


    /* =================================================
       🥘 VEGETARIAN MAIN COURSE — 24
    ================================================= */

    "paneer butter masala": {
        img: "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?auto=format&fit=crop&w=900&q=80",
        desc: "Cottage cheese cubes in a creamy tomato gravy."
    },

    "dal makhani": {
        img: "https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=900&q=80",
        desc: "Slow-cooked black lentils with butter and cream."
    },

    "aloo gobi": {
        img: "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&w=900&q=80",
        desc: "Spiced cauliflower and potato stir-fry."
    },

    "chana masala": {
        img: "https://images.unsplash.com/photo-1588166524941-3bf61a9c41db?auto=format&fit=crop&w=900&q=80",
        desc: "Tangy chickpea curry."
    },

    "baingan bharta": {
        img: "https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=900&q=80",
        desc: "Smoky roasted eggplant mash with spices."
    },

    "palak paneer": {
        img: "https://images.unsplash.com/photo-1613292443284-8d10ef9383fe?auto=format&fit=crop&w=900&q=80",
        desc: "Cottage cheese cubes in thick spinach puree."
    },

    "malai kofta": {
        img: "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?auto=format&fit=crop&w=900&q=80",
        desc: "Fried potato and paneer balls in rich gravy."
    },

    "rajma chawal": {
        img: "https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=900&q=80",
        desc: "Red kidney bean curry served with rice."
    },

    "kadi pakoda": {
        img: "https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=900&q=80",
        desc: "Tangy yogurt gravy with deep-fried fritters."
    },

    "bhindi masala": {
        img: "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&w=900&q=80",
        desc: "Stir-fried okra with onions and spices."
    },

    "sambar": {
        img: "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&w=900&q=80",
        desc: "Tangy lentil soup mixed with vegetables."
    },

    "paneer tikka": {
        img: "https://images.unsplash.com/photo-1567188040759-fb8a883dc6d8?auto=format&fit=crop&w=900&q=80",
        desc: "Smoky, spicy paneer skewers."
    },

    "shahi paneer": {
        img: "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?auto=format&fit=crop&w=900&q=80",
        desc: "Paneer cubes in a rich, sweet cashew and cream gravy."
    },

    "kadai paneer": {
        img: "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?auto=format&fit=crop&w=900&q=80",
        desc: "Paneer toss-fried with bell peppers in fresh wok spices."
    },

    "paneer do pyaza": {
        img: "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?auto=format&fit=crop&w=900&q=80",
        desc: "Paneer cooked with double the onions in rich aromatic gravy."
    },

    "paneer lababdar": {
        img: "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?auto=format&fit=crop&w=900&q=80",
        desc: "Grated and cubed paneer in a luscious tomato-cashew sauce."
    },

    "matar paneer": {
        img: "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?auto=format&fit=crop&w=900&q=80",
        desc: "Classic cottage cheese and green peas gravy dish."
    },

    "mushroom masala": {
        img: "https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=900&q=80",
        desc: "Tender button mushrooms simmered in spicy onion gravy."
    },

    "kadai vegetable": {
        img: "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&w=900&q=80",
        desc: "Assorted vegetables wok-tossed with freshly ground spices."
    },

    "mix vegetable curry": {
        img: "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&w=900&q=80",
        desc: "Garden fresh seasonal veggies in a spiced curry sauce."
    },

    "dum aloo": {
        img: "https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=900&q=80",
        desc: "Baby potatoes slow-cooked in rich aromatic spicy yogurt gravy."
    },

    "aloo matar": {
        img: "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&w=900&q=80",
        desc: "Comfort food pairing potatoes and peas in home style curry."
    },

    "navratan korma": {
        img: "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?auto=format&fit=crop&w=900&q=80",
        desc: "Royal sweet gravy made with 9 veggies, fruits, and nuts."
    },

    "veg kofta curry": {
        img: "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?auto=format&fit=crop&w=900&q=80",
        desc: "Fried vegetable dumplings in rich creamy yellow gravy."
    },


    /* =================================================
       🍗 NON-VEGETARIAN — 19
    ================================================= */

    "butter chicken": {
        img: "https://images.unsplash.com/photo-1588166524941-3bf61a9c41db?auto=format&fit=crop&w=900&q=80",
        desc: "Tandoori chicken in sweet tomato gravy."
    },

    "chicken biryani": {
        img: "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=900&q=80",
        desc: "Fragrant basmati rice with spiced chicken."
    },

    "rogan josh": {
        img: "https://images.unsplash.com/photo-1545247181-516773cae754?auto=format&fit=crop&w=900&q=80",
        desc: "Slow-cooked aromatic lamb curry."
    },

    "chicken tikka masala": {
        img: "https://images.unsplash.com/photo-1599487488170-d11ec9c172f0?auto=format&fit=crop&w=900&q=80",
        desc: "Roasted chicken chunks in spicy sauce."
    },

    "fish curry": {
        img: "https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?auto=format&fit=crop&w=900&q=80",
        desc: "Tangy and spicy coconut-based fish curry."
    },

    "mutton korma": {
        img: "https://images.unsplash.com/photo-1545247181-516773cae754?auto=format&fit=crop&w=900&q=80",
        desc: "Rich mutton curry braised with nuts and yogurt."
    },

    "prawn balchao": {
        img: "https://images.unsplash.com/photo-1559847844-5315695dadae?auto=format&fit=crop&w=900&q=80",
        desc: "Spicy Goan prawn pickle-like curry."
    },

    "chicken curry": {
        img: "https://images.unsplash.com/photo-1588166524941-3bf61a9c41db?auto=format&fit=crop&w=900&q=80",
        desc: "Traditional home style chicken cooked with Indian spices."
    },

    "chicken kadai": {
        img: "https://images.unsplash.com/photo-1599487488170-d11ec9c172f0?auto=format&fit=crop&w=900&q=80",
        desc: "Chicken cooked with capsicum and heavy ground spices in wok."
    },

    "chicken do pyaza": {
        img: "https://images.unsplash.com/photo-1588166524941-3bf61a9c41db?auto=format&fit=crop&w=900&q=80",
        desc: "Juicy chicken pieces tossed with crunchy caramelized onions."
    },

    "chicken handi": {
        img: "https://images.unsplash.com/photo-1588166524941-3bf61a9c41db?auto=format&fit=crop&w=900&q=80",
        desc: "Creamy chicken slow-cooked in a traditional clay pot."
    },

    "chicken chettinad": {
        img: "https://images.unsplash.com/photo-1599487488170-d11ec9c172f0?auto=format&fit=crop&w=900&q=80",
        desc: "Fiery South Indian chicken cooked with freshly roasted spices."
    },

    "chicken 65": {
        img: "https://images.unsplash.com/photo-1567188040759-fb8a883dc6d8?auto=format&fit=crop&w=900&q=80",
        desc: "Spicy deep-fried chicken appetizer tempered with curry leaves."
    },

    "tandoori chicken": {
        img: "https://images.unsplash.com/photo-1599487488170-d11ec9c172f0?auto=format&fit=crop&w=900&q=80",
        desc: "Marinated bone-in chicken roasted to perfection in tandoor."
    },

    "chicken seekh kebab": {
        img: "https://images.unsplash.com/photo-1599487488170-d11ec9c172f0?auto=format&fit=crop&w=900&q=80",
        desc: "Minced chicken skewers seasoned with herbs and spices."
    },

    "mutton rogan josh": {
        img: "https://images.unsplash.com/photo-1545247181-516773cae754?auto=format&fit=crop&w=900&q=80",
        desc: "Classic Kashmiri slow-cooked tender mutton curry."
    },

    "mutton curry": {
        img: "https://images.unsplash.com/photo-1545247181-516773cae754?auto=format&fit=crop&w=900&q=80",
        desc: "Rich and flavor-packed traditional mutton preparation."
    },

    "mutton biryani": {
        img: "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=900&q=80",
        desc: "Layered basmati rice cooked with spiced succulent mutton."
    },

    "fish fry": {
        img: "https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?auto=format&fit=crop&w=900&q=80",
        desc: "Crispy pan-fried fish marinated in coastal spices."
    },


    /* =================================================
       🍜 CHINESE / INDO-CHINESE — 8
    ================================================= */

    "veg hakka noodles": {
        img: "https://images.unsplash.com/photo-1585032226651-759b368d7246?auto=format&fit=crop&w=900&q=80",
        desc: "Wok-tossed noodles with crunchy fresh vegetables."
    },

    "chicken hakka noodles": {
        img: "https://images.unsplash.com/photo-1585032226651-759b368d7246?auto=format&fit=crop&w=900&q=80",
        desc: "Stir-fried noodles loaded with chicken strips and veggies."
    },

    "veg fried rice": {
        img: "https://images.unsplash.com/photo-1603133872878-684f208fb84b?auto=format&fit=crop&w=900&q=80",
        desc: "Aromatic rice tossed with chopped vegetables and soya sauce."
    },

    "chicken fried rice": {
        img: "https://images.unsplash.com/photo-1603133872878-684f208fb84b?auto=format&fit=crop&w=900&q=80",
        desc: "Flavorsome stir-fried rice loaded with juicy chicken bits."
    },

    "veg manchurian": {
        img: "https://images.unsplash.com/photo-1525755662778-989d0524087e?auto=format&fit=crop&w=900&q=80",
        desc: "Veggie balls tossed in tangy and spicy Indo-Chinese sauce."
    },

    "chicken manchurian": {
        img: "https://images.unsplash.com/photo-1525755662778-989d0524087e?auto=format&fit=crop&w=900&q=80",
        desc: "Crispy chicken bites tossed in savory Manchurian gravy."
    },

    "chilli paneer": {
        img: "https://images.unsplash.com/photo-1567188040759-fb8a883dc6d8?auto=format&fit=crop&w=900&q=80",
        desc: "Fried paneer cubes tossed with soy sauce, chillies and capsicum."
    },

    "chilli chicken": {
        img: "https://images.unsplash.com/photo-1567188040759-fb8a883dc6d8?auto=format&fit=crop&w=900&q=80",
        desc: "Indo-Chinese favorite chicken cooked with garlic and chillies."
    },


    /* =================================================
       🍕 FAST FOOD — 5
    ================================================= */

    "margherita pizza": {
        img: "https://images.unsplash.com/photo-1574071318508-1cdbab80d002?auto=format&fit=crop&w=900&q=80",
        desc: "Classic pizza topped with mozzarella cheese and basil."
    },

    "veg burger": {
        img: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=900&q=80",
        desc: "Crispy veggie patty with lettuce and cheese inside soft bun."
    },

    "chicken burger": {
        img: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=900&q=80",
        desc: "Juicy chicken patty layered with mayonnaise and crisp veggies."
    },

    "french fries": {
        img: "https://images.unsplash.com/photo-1576107232684-1279f390859f?auto=format&fit=crop&w=900&q=80",
        desc: "Golden, crispy deep-fried potato strips with salted seasoning."
    },

    "garlic bread": {
        img: "https://images.unsplash.com/photo-1573140247632-f8fd74997d5c?auto=format&fit=crop&w=900&q=80",
        desc: "Toasted bread topped with garlic butter and melted cheese."
    },


    /* =================================================
       🍰 DESSERTS & SWEETS — 13
    ================================================= */

"gulab jamun": {
        img: "https://images.unsplash.com/photo-1622320623274-722a6135dd74?auto=format&fit=crop&w=900&q=80",
        desc: "Deep-fried milk balls in sugar syrup."
    },

    "rasgulla": {
        img: "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&w=900&q=80",
        desc: "Soft spongy cottage cheese balls."
    },

    "kaju katli": {
        img: "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=900&q=80",
        desc: "Diamond-shaped cashew fudge."
    },

    "jalebi": {
        img: "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&w=900&q=80",
        desc: "Spiral fried batter soaked in syrup."
    },

    "kheer": {
        img: "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=900&q=80",
        desc: "Creamy Indian rice pudding."
    },

    "gajar ka halwa": {
        img: "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=900&q=80",
        desc: "Sweet carrot pudding with nuts."
    },

    "rasmalai": {
        img: "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=900&q=80",
        desc: "Soft paneer discs in sweetened milk."
    },

    "rasmalai kulfi": {
        img: "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=900&q=80",
        desc: "Rich frozen kulfi infused with rasmalai flavor and nuts."
    },

    "kulfi": {
        img: "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=900&q=80",
        desc: "Traditional dense creamy Indian ice cream on stick."
    },

    "ice cream": {
        img: "https://images.unsplash.com/photo-1567206563064-6f60f4078b57?auto=format&fit=crop&w=900&q=80",
        desc: "Chilled delightful sweet frozen dessert scoops."
    },

    "brownie": {
        img: "https://images.unsplash.com/photo-1606313564200-e75d5e30476c?auto=format&fit=crop&w=900&q=80",
        desc: "Rich and fudgy chocolate baked square dessert."
    },

    "chocolate cake": {
        img: "https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=900&q=80",
        desc: "Moist chocolate sponge cake coated with dark chocolate icing."
    },

    "fruit custard": {
        img: "https://images.unsplash.com/photo-1551024709-8f23befc6f87?auto=format&fit=crop&w=900&q=80",
        desc: "Creamy vanilla custard mixed with fresh seasonal fruits."
    },


    /* =================================================
       🫓 BREADS & RICE — 5
    ================================================= */

    "naan": {
        img: "https://images.unsplash.com/photo-1626074353765-517a681e40be?auto=format&fit=crop&w=900&q=80",
        desc: "Leavened tandoor-baked flatbread."
    },

    "tandoori roti": {
        img: "https://images.unsplash.com/photo-1626074353765-517a681e40be?auto=format&fit=crop&w=900&q=80",
        desc: "Whole wheat flatbread baked in clay oven."
    },

    "rumali roti": {
        img: "https://images.unsplash.com/photo-1626074353765-517a681e40be?auto=format&fit=crop&w=900&q=80",
        desc: "Extremely thin and soft flatbread."
    },

    "jeera rice": {
        img: "https://images.unsplash.com/photo-1596797038530-2c107229654b?auto=format&fit=crop&w=900&q=80",
        desc: "Basmati rice flavored with cumin seeds."
    },

    "lemon rice": {
        img: "https://images.unsplash.com/photo-1596797038530-2c107229654b?auto=format&fit=crop&w=900&q=80",
        desc: "Tangy rice flavored with lemon and peanuts."
    },


    /* =================================================
       🌶️ STREET FOOD & SNACKS — 9
    ================================================= */

    "samosa": {
        img: "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=900&q=80",
        desc: "Crispy pastry filled with spiced potatoes."
    },

    "pani puri": {
        img: "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=900&q=80",
        desc: "Hollow puris filled with mint water."
    },

    "golgappa": {
        img: "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=900&q=80",
        desc: "Hollow puris filled with mint water."
    },

    "pav bhaji": {
        img: "https://images.unsplash.com/photo-1626132647523-66f5bf380027?auto=format&fit=crop&w=900&q=80",
        desc: "Thick vegetable mash with buttered buns."
    },

    "aloo tikki": {
        img: "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=900&q=80",
        desc: "Crispy potato patties with chutneys."
    },

    "bhel puri": {
        img: "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=900&q=80",
        desc: "Puffed rice with spicy tamarind sauce."
    },

    "vada pav": {
        img: "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=900&q=80",
        desc: "Spicy potato fritter inside bread bun."
    },

    "papdi chaat": {
        img: "https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=900&q=80",
        desc: "Crisp crackers topped with yogurt and chutney."
    },

    "chicken kathi roll": {
        img: "https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?auto=format&fit=crop&w=900&q=80",
        desc: "Skewered chicken wrapped in flatbread."
    }

};


/* =====================================================
   DATABASE COUNT
===================================================== */

const BKFoodImageDatabaseCount =
    Object.keys(foodImageDatabase).length;

console.log(
    "BK Food Image Database Loaded:",
    BKFoodImageDatabaseCount,
    "items"
);


/* =====================================================
   FOOD NAME NORMALIZER
===================================================== */

function normalizeFoodName(value) {

    return String(value || "")
        .normalize("NFKC")
        .trim()
        .toLowerCase()
        .replace(/\s+/g, " ")
        .replace(/[–—]/g, "-")
        .replace(/[’]/g, "'");

}


/* =====================================================
   IMAGE LOAD VERIFIER
===================================================== */

function verifyFoodImage(url) {

    return new Promise((resolve, reject) => {

        if (!url) {

            reject(
                new Error("Image URL is missing.")
            );

            return;
        }

        const image = new Image();

        image.onload = function () {

            resolve({
                success: true,
                url: url
            });

        };

        image.onerror = function () {

            reject(
                new Error("Food image failed to load.")
            );

        };

        image.src = url;

    });

}


/* =====================================================
   GET FOOD DATABASE MATCH
===================================================== */

function getFoodMapping(foodName) {

    const normalizedName =
        normalizeFoodName(foodName);

    const item =
        foodImageDatabase[normalizedName];

    return {

        key: normalizedName,

        item: item || null

    };

}


/* =====================================================
   MAIN FOOD IMAGE RESOLVER
===================================================== */

async function resolveFoodImage(foodName) {

    const cleanName =
        normalizeFoodName(foodName);


    /* ---------------------------------------------
       EMPTY FOOD NAME
    --------------------------------------------- */

    if (!cleanName) {

        return {

            status: "fallback",

            reason: "EMPTY_FOOD_NAME",

            foodName: "",

            item: null,

            imageUrl: null

        };

    }


    /* ---------------------------------------------
       FIND DATABASE MATCH
    --------------------------------------------- */

    const mapping =
        getFoodMapping(cleanName);


    /* ---------------------------------------------
       NO MAPPING
    --------------------------------------------- */

    if (!mapping.item) {

        console.warn(
            "BK Food Resolver: No image mapping found for:",
            foodName
        );

        return {

            status: "fallback",

            reason: "NO_MAPPING",

            foodName: foodName,

            item: null,

            imageUrl: null

        };

    }


    /* ---------------------------------------------
       VERIFY IMAGE
    --------------------------------------------- */

    try {

        await verifyFoodImage(
            mapping.item.img
        );

        console.log(
            "BK Food Resolver: Image verified:",
            foodName
        );

        return {

            status: "matched",

            reason: "IMAGE_VERIFIED",

            foodName: foodName,

            item: mapping.item,

            imageUrl: mapping.item.img

        };

    } catch (error) {

        console.warn(
            "BK Food Resolver: Image failed:",
            foodName,
            error
        );

        return {

            status: "fallback",

            reason: "IMAGE_LOAD_FAILED",

            foodName: foodName,

            item: mapping.item,

            imageUrl: null

        };

    }

}


/* =====================================================
   PUBLIC BK FOOD IMAGE RESOLVER
===================================================== */
window.BKFoodImageResolver = {

    normalize: normalizeFoodName,

    getMapping: getFoodMapping,

    resolve: resolveFoodImage

};


/* =====================================================
   OPTIONAL ES MODULE EXPORTS
===================================================== */

export {

    foodImageDatabase,

    normalizeFoodName,

    verifyFoodImage,

    getFoodMapping,

    resolveFoodImage

};


/* =====================================================
   ENGINE READY
===================================================== */

console.log(
    "BK Food Image Resolver: READY"
);