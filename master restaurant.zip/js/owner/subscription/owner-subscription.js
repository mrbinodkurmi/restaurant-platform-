"use strict";

/*
 * ============================================================
 * BK OWNER SUBSCRIPTION SYSTEM
 * File: owner-subscription.js
 * Version: 1.5.0
 *
 * PURPOSE:
 * - Owner context
 * - Active plan reader
 * - Plan selection
 * - Subscription reader
 * - Payment draft preparation
 * - Payment validation
 * - Firestore payment submission
 * - Owner Subscription UI connection
 *
 * SAFETY:
 * - Payment submission only
 * - No subscription activation
 * - No dashboard lock/unlock
 * - No modification of BKOwner
 * - No modification of BKOwnerAccountGuard
 * ============================================================
 */

import {
  ownerDb as db
} from "../../firebase-sessions.js";

import {
  collection,
  getDocs,
  query,
  where,
  doc,
  getDoc,
  setDoc,
  runTransaction,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";


const BKOwnerSubscription = {

  state: {

    initialized: false,
    ready: false,

    currentUser: null,
    restaurantId: null,

    activePlans: [],

    selectedPlan: null,

    paymentDraft: null,

    lastSubmittedPayment: null,

    subscription: null,
    
    monthlyBilling: null,
    
    access: false

  },


  /* ============================================================
     INIT
     ============================================================ */

  async init() {

    if (this.state.initialized) {
      return;
    }

    this.state.initialized = true;

    console.log(
      "BK OWNER SUBSCRIPTION: INITIALIZING..."
    );

    try {

      await this.waitForOwnerContext();

      const contextReady =
        this.captureOwnerContext();

      if (!contextReady) {

        console.warn(
          "BK OWNER SUBSCRIPTION: OWNER CONTEXT NOT READY"
        );

        return;
      }

      await this.loadActivePlans();

      await this.loadActiveSubscription();
      
      await this.loadCurrentMonthlyBilling();

await this.loadMonthlyPaymentConfiguration();

      this.bindUI();

      this.renderPlans();

      this.renderActiveSubscription();

      this.renderLastPayment();
      
      this.renderMonthlyBilling();

      this.updatePaymentUI();

      this.state.ready = true;

      console.log(
        "BK OWNER SUBSCRIPTION: MODULE READY"
      );

      console.log(
        "BK OWNER SUBSCRIPTION: RESTAURANT ID:",
        this.state.restaurantId
      );

      console.log(
        "BK OWNER SUBSCRIPTION: ACTIVE PLANS:",
        this.state.activePlans.length
      );

    } catch (error) {

      console.error(
        "BK OWNER SUBSCRIPTION: INIT ERROR",
        error
      );

      this.showAccessMessage(
        "Subscription Error",
        error?.message ||
        "Subscription information could not be loaded."
      );

    }

  },


  /* ============================================================
     WAIT FOR OWNER CONTEXT
     ============================================================ */

  waitForOwnerContext() {

    return new Promise((resolve, reject) => {

      const startTime =
        Date.now();

      const timeout =
        15000;

      const check = () => {

        const ownerState =
          window.BKOwner?.state;

        if (
          ownerState &&
          ownerState.currentUser &&
          ownerState.restaurantId
        ) {

          resolve();

          return;
        }

        if (
          Date.now() - startTime >
          timeout
        ) {

          reject(
            new Error(
              "BK Owner context was not ready within 15 seconds."
            )
          );

          return;
        }

        setTimeout(
          check,
          250
        );

      };

      check();

    });

  },


  /* ============================================================
     CAPTURE OWNER CONTEXT
     ============================================================ */

  captureOwnerContext() {

    const ownerState =
      window.BKOwner?.state;

    if (!ownerState) {

      console.warn(
        "BK OWNER SUBSCRIPTION: BKOwner STATE NOT FOUND"
      );

      return false;
    }

    const currentUser =
      ownerState.currentUser || null;

    const restaurantId =
      ownerState.restaurantId || null;

    if (!currentUser) {

      console.warn(
        "BK OWNER SUBSCRIPTION: CURRENT USER NOT FOUND"
      );

      return false;
    }

    if (!restaurantId) {

      console.warn(
        "BK OWNER SUBSCRIPTION: RESTAURANT ID NOT FOUND"
      );

      return false;
    }

    this.state.currentUser =
      currentUser;

    this.state.restaurantId =
      restaurantId;

    return true;

  },


  /* ============================================================
     LOAD ACTIVE PLANS
     ============================================================ */

  async loadActivePlans() {

    console.log(
      "BK OWNER SUBSCRIPTION: LOADING ACTIVE PLANS..."
    );

    const plansQuery =
      query(
        collection(
          db,
          "subscriptionPlans"
        ),
        where(
          "status",
          "==",
          "ACTIVE"
        )
      );

    const snapshot =
      await getDocs(
        plansQuery
      );

    const plans = [];

    snapshot.forEach(
      (docSnapshot) => {

        const data =
          docSnapshot.data();

        plans.push({

          planId:
            docSnapshot.id,

          name:
            data.name || "",

          description:
            data.description || "",

          baseAmount:
            data.baseAmount ?? null,

          minimumAmount:
            data.minimumAmount ?? null,

          maximumAmount:
            data.maximumAmount ?? null,

          currency:
            data.currency || "",

          billingCycle:
            data.billingCycle || "",

          usagePricingEnabled:
            data.usagePricingEnabled === true,

          status:
            data.status || ""

        });

      }
    );

    this.state.activePlans =
      plans;

    console.log(
      "BK OWNER SUBSCRIPTION: ACTIVE PLANS LOADED:",
      plans.length
    );

    plans.forEach(
      (plan) => {

        console.log(
          "BK OWNER SUBSCRIPTION: PLAN",
          plan.planId,
          plan
        );

      }
    );

    return plans;

  },


  /* ============================================================
     SELECT PLAN
     ============================================================ */

  selectPlan(planId) {

    if (!planId) {

      console.warn(
        "BK OWNER SUBSCRIPTION: PLAN ID REQUIRED"
      );

      return false;
    }

    const plan =
      this.state.activePlans.find(
        (item) =>
          item.planId === planId
      );

    if (!plan) {

      console.warn(
        "BK OWNER SUBSCRIPTION: ACTIVE PLAN NOT FOUND:",
        planId
      );

      return false;
    }

    this.state.selectedPlan = {
      ...plan
    };

    this.state.paymentDraft = null;

    console.log(
      "BK OWNER SUBSCRIPTION: PLAN SELECTED:",
      plan.planId,
      plan.name,
      plan.baseAmount,
      plan.currency
    );

    this.updatePaymentUI();
    this.renderPlans();

    return true;

  },


  /* ============================================================
     GET SELECTED PLAN
     ============================================================ */

  getSelectedPlan() {

    if (!this.state.selectedPlan) {
      return null;
    }

    return {
      ...this.state.selectedPlan
    };

  },


  /* ============================================================
     CLEAR SELECTED PLAN
     ============================================================ */

  clearSelectedPlan() {

    this.state.selectedPlan = null;
    this.state.paymentDraft = null;

    console.log(
      "BK OWNER SUBSCRIPTION: SELECTED PLAN CLEARED"
    );

    this.renderPlans();
    this.updatePaymentUI();

  },


  /* ============================================================
     CREATE PAYMENT DRAFT
     ============================================================ */

  createPaymentDraft(data = {}) {

    const selectedPlan =
      this.state.selectedPlan;

    if (!selectedPlan) {

      console.warn(
        "BK OWNER SUBSCRIPTION: SELECT A PLAN FIRST"
      );

      return null;
    }


    const paymentReference =
      String(
        data.paymentReference || ""
      ).trim();


    const paymentMethod =
      String(
        data.paymentMethod || ""
      ).trim();


    const amount =
      Number(
        data.amount ?? selectedPlan.baseAmount
      );


    const currency =
      String(
        data.currency ||
        selectedPlan.currency ||
        ""
      ).trim();


    const draft = {

      restaurantId:
        this.state.restaurantId,

      ownerId:
        this.state.currentUser?.uid || "",

      planId:
        selectedPlan.planId,

      amount:
        Number.isFinite(amount)
          ? amount
          : null,

      currency,

      paymentReference,

      paymentMethod,

      status:
        "PAYMENT_SUBMITTED"

    };


    this.state.paymentDraft = {
      ...draft
    };


    console.log(
      "BK OWNER SUBSCRIPTION: PAYMENT DRAFT CREATED",
      this.state.paymentDraft
    );


    return {
      ...draft
    };

  },


  /* ============================================================
     VALIDATE PAYMENT DRAFT
     ============================================================ */

  validatePaymentDraft(draft = null) {

    const payment =
      draft ||
      this.state.paymentDraft;

    const selectedPlan =
      this.state.selectedPlan;


    const errors = [];


    if (!selectedPlan) {

      errors.push(
        "No subscription plan selected."
      );

    }


    if (!payment) {

      errors.push(
        "Payment draft is missing."
      );

    }


    if (payment && !payment.restaurantId) {

      errors.push(
        "Restaurant ID is missing."
      );

    }


    if (
      payment &&
      !payment.ownerId
    ) {

      errors.push(
        "Owner ID is missing."
      );

    }


    if (
      payment &&
      !payment.planId
    ) {

      errors.push(
        "Plan ID is missing."
      );

    }


    if (
      payment &&
      (
        !Number.isFinite(
          payment.amount
        ) ||
        payment.amount <= 0
      )
    ) {

      errors.push(
        "Payment amount is invalid."
      );

    }


    if (
      selectedPlan &&
      payment &&
      payment.amount !==
      selectedPlan.baseAmount
    ) {

      errors.push(
        "Payment amount does not match the active plan amount."
      );

    }


    if (
      selectedPlan &&
      payment &&
      payment.currency !==
      selectedPlan.currency
    ) {

      errors.push(
        "Payment currency does not match the active plan currency."
      );

    }


    if (
      payment &&
      !payment.paymentReference
    ) {

      errors.push(
        "Payment reference is required."
      );

    }


    if (
      payment &&
      !payment.paymentMethod
    ) {

      errors.push(
        "Payment method is required."
      );

    }


    if (
      payment &&
      payment.status !==
      "PAYMENT_SUBMITTED"
    ) {

      errors.push(
        "Invalid payment draft status."
      );

    }


    const valid =
      errors.length === 0;


    const result = {

      valid,

      errors,

      payment:
        valid
          ? { ...payment }
          : null

    };


    console.log(
      "BK OWNER SUBSCRIPTION: PAYMENT VALIDATION",
      result
    );


    return result;

  },


  /* ============================================================
     CREATE PAYMENT ID
     ============================================================ */

  createPaymentId() {

    if (
      globalThis.crypto &&
      typeof globalThis.crypto.randomUUID ===
      "function"
    ) {

      return (
        "PAY-" +
        globalThis.crypto.randomUUID()
      );

    }


    return (
      "PAY-" +
      Date.now() +
      "-" +
      Math.random()
        .toString(36)
        .slice(2, 10)
        .toUpperCase()
    );

  },


  /* ============================================================
     SUBMIT PAYMENT DRAFT
     ============================================================ */

  async submitPaymentDraft() {

    console.log(
      "BK OWNER SUBSCRIPTION: PAYMENT SUBMISSION STARTING..."
    );


    const validation =
      this.validatePaymentDraft();


    if (!validation.valid) {

      console.warn(
        "BK OWNER SUBSCRIPTION: PAYMENT SUBMISSION BLOCKED",
        validation.errors
      );

      return {

        success: false,

        paymentId: null,

        errors:
          [...validation.errors]

      };

    }


    const payment =
      validation.payment;


    const currentUser =
      this.state.currentUser;


    if (
      !currentUser ||
      !currentUser.uid
    ) {

      console.error(
        "BK OWNER SUBSCRIPTION: AUTHENTICATED OWNER NOT FOUND"
      );

      return {

        success: false,

        paymentId: null,

        errors: [
          "Authenticated owner is required."
        ]

      };

    }


    try {

      /* --------------------------------------------------------
         FRESH RESTAURANT CHECK
         -------------------------------------------------------- */

      const restaurantRef =
        doc(
          db,
          "restaurants",
          payment.restaurantId
        );


      const restaurantSnapshot =
        await getDoc(
          restaurantRef
        );


      if (
        !restaurantSnapshot.exists()
      ) {

        throw new Error(
          "Restaurant was not found."
        );

      }


      const restaurantData =
        restaurantSnapshot.data();


      if (
        restaurantData.ownerId !==
        currentUser.uid
      ) {

        throw new Error(
          "Restaurant ownership verification failed."
        );

      }


      /* --------------------------------------------------------
         FRESH PLAN CHECK
         -------------------------------------------------------- */

      const planRef =
        doc(
          db,
          "subscriptionPlans",
          payment.planId
        );


      const planSnapshot =
        await getDoc(
          planRef
        );


      if (
        !planSnapshot.exists()
      ) {

        throw new Error(
          "Subscription plan was not found."
        );

      }


      const planData =
        planSnapshot.data();


      if (
        planData.status !==
        "ACTIVE"
      ) {

        throw new Error(
          "Selected subscription plan is no longer active."
        );

      }


      const planAmount =
        Number(
          planData.baseAmount
        );


      const planCurrency =
        String(
          planData.currency || ""
        ).trim();


      if (
        !Number.isFinite(planAmount) ||
        planAmount <= 0
      ) {

        throw new Error(
          "Active plan amount is invalid."
        );

      }


      if (!planCurrency) {

        throw new Error(
          "Active plan currency is missing."
        );

      }


      /* --------------------------------------------------------
         FRESH AMOUNT + CURRENCY CHECK
         -------------------------------------------------------- */

      if (
        payment.amount !==
        planAmount
      ) {

        throw new Error(
          "Payment amount no longer matches the active plan."
        );

      }


      if (
        payment.currency !==
        planCurrency
      ) {

        throw new Error(
          "Payment currency no longer matches the active plan."
        );

      }


      /* --------------------------------------------------------
         CREATE PAYMENT DOCUMENT
         -------------------------------------------------------- */

      const paymentId =
        this.createPaymentId();


      const paymentRef =
        doc(
          db,
          "subscriptionPayments",
          paymentId
        );


      const paymentData = {

        paymentId,

        restaurantId:
          payment.restaurantId,

        ownerId:
          currentUser.uid,

        planId:
          payment.planId,

        amount:
          planAmount,

        currency:
          planCurrency,

        paymentReference:
          payment.paymentReference,

        paymentMethod:
          payment.paymentMethod,

        status:
          "PAYMENT_SUBMITTED",

        createdAt:
          serverTimestamp(),

        updatedAt:
          serverTimestamp(),

        submittedAt:
          serverTimestamp()

      };


      await setDoc(
        paymentRef,
        paymentData
      );


      this.state.lastSubmittedPayment = {

        paymentId,

        restaurantId:
          payment.restaurantId,

        ownerId:
          currentUser.uid,

        planId:
          payment.planId,

        amount:
          planAmount,

        currency:
          planCurrency,

        paymentReference:
          payment.paymentReference,

        paymentMethod:
          payment.paymentMethod,

        status:
          "PAYMENT_SUBMITTED"

      };


      console.log(
        "BK OWNER SUBSCRIPTION: PAYMENT SUBMITTED SUCCESSFULLY",
        this.state.lastSubmittedPayment
      );


      return {

        success: true,

        paymentId,

        status:
          "PAYMENT_SUBMITTED",

        payment:
          {
            ...this.state.lastSubmittedPayment
          },

        errors: []

      };


    } catch (error) {

      console.error(
        "BK OWNER SUBSCRIPTION: PAYMENT SUBMISSION ERROR",
        error
      );


      return {

        success: false,

        paymentId: null,

        errors: [
          error?.message ||
          "Payment submission failed."
        ]

      };

    }

  },


  /* ============================================================
     OWNER SUBSCRIPTION READER
     STEP 2A — ACTIVE SUBSCRIPTION + ACCESS STATE
     ============================================================ */

async loadActiveSubscription() {

    try {

      if (!this.state.restaurantId) {

        throw new Error(
          "Restaurant context is required."
        );

      }

      if (!this.state.currentUser?.uid) {

        throw new Error(
          "Owner authentication is required."
        );

      }


      const subscriptionsRef =
        collection(
          db,
          "subscriptions"
        );


      const subscriptionsQuery =
  query(
    subscriptionsRef,
    where("restaurantId", "==", this.state.restaurantId),
    where("ownerId", "==", this.state.currentUser.uid)
  );

      const snapshot =
        await getDocs(
          subscriptionsQuery
        );


      let activeSubscription = null;


      snapshot.forEach(
        (subscriptionDoc) => {

          const data =
            subscriptionDoc.data();


          const sameOwner =
            data.ownerId ===
            this.state.currentUser.uid;


          const active =
            String(
              data.status || ""
            ).toUpperCase() ===
            "ACTIVE";


          if (
            sameOwner &&
            active &&
            !activeSubscription
          ) {

            activeSubscription = {

              id:
                subscriptionDoc.id,

              ...data

            };

          }

        }
      );


      this.state.subscription =
        activeSubscription;


      if (!activeSubscription) {

        this.state.access = {

          allowed: false,

          reason:
            "NO_ACTIVE_SUBSCRIPTION",

          subscriptionId: null

        };

        console.log(
          "BK OWNER SUBSCRIPTION: NO ACTIVE SUBSCRIPTION"
        );

        return null;

      }



let expiresAt =
  activeSubscription.expiresAt;


// PERMANENT SUBSCRIPTION
if (expiresAt === null) {

  this.state.access = {

    allowed: true,

    reason:
      "ACTIVE_PERMANENT_SUBSCRIPTION",

    subscriptionId:
      activeSubscription.subscriptionId ||
      activeSubscription.id,

    expiresAt: null

  };

  console.log(
    "BK OWNER SUBSCRIPTION: PERMANENT ACCESS ACTIVE"
  );

  return activeSubscription;

}


// EXPIRING SUBSCRIPTION
if (
  expiresAt &&
  typeof expiresAt.toDate === "function"
) {

  expiresAt = expiresAt.toDate();

} else {

  expiresAt = new Date(expiresAt);

}


if (
  !(expiresAt instanceof Date) ||
  Number.isNaN(expiresAt.getTime())
) {

  this.state.access = {

    allowed: false,

    reason: "INVALID_EXPIRY_DATE",

    subscriptionId:
      activeSubscription.subscriptionId ||
      activeSubscription.id

  };

  console.error(
    "BK OWNER SUBSCRIPTION: INVALID EXPIRY DATE"
  );

  return activeSubscription;

}


      const now =
        new Date();


      const isCurrentlyValid =
        expiresAt.getTime() >
        now.getTime();


      this.state.access = {

        allowed:
          isCurrentlyValid,

        reason:
          isCurrentlyValid
            ? "ACTIVE_SUBSCRIPTION"
            : "SUBSCRIPTION_EXPIRED",

        subscriptionId:
          activeSubscription.subscriptionId ||
          activeSubscription.id,

        expiresAt

      };


      console.log(
        "BK OWNER SUBSCRIPTION: ACTIVE SUBSCRIPTION LOADED:",
        {
          subscriptionId:
            activeSubscription.subscriptionId ||
            activeSubscription.id,

          restaurantId:
            activeSubscription.restaurantId,

          planId:
            activeSubscription.planId,

          amount:
            activeSubscription.amount,

          status:
            activeSubscription.status,

          expiresAt,

          accessAllowed:
            this.state.access.allowed,

          accessReason:
            this.state.access.reason

        }
      );


      return activeSubscription;


    } catch (error) {

      console.error(
        "BK OWNER SUBSCRIPTION: LOAD FAILED:",
        error
      );

      this.state.subscription =
        null;

      this.state.access = {

        allowed: false,

        reason:
          "SUBSCRIPTION_READ_FAILED",

        subscriptionId: null

      };

      throw error;

    }

  },
  
  /* ============================================================
   LOAD CURRENT MONTHLY BILLING
   STEP 1A — OWNER PUBLISHED BILL READ LAYER
   ============================================================ */

async loadCurrentMonthlyBilling() {

  const restaurantId =
    this.state.restaurantId;

  const ownerId =
    this.state.currentUser?.uid;

  if (!restaurantId || !ownerId) {

    console.warn(
      "BK OWNER BILLING: OWNER CONTEXT NOT READY"
    );

    this.state.monthlyBilling = null;

    return null;
  }

  console.log(
    "BK OWNER BILLING: LOADING LATEST PUBLISHED BILL..."
  );

  try {

    const billingQuery =
      query(
        collection(
          db,
          "billingRecords"
        ),
        where(
          "restaurantId",
          "==",
          restaurantId
        ),
        where(
          "ownerId",
          "==",
          ownerId
        ),
        where(
          "status",
          "==",
          "PUBLISHED"
        )
      );

    const billingSnapshot =
      await getDocs(
        billingQuery
      );

    if (billingSnapshot.empty) {

      console.log(
        "BK OWNER BILLING: NO PUBLISHED BILL FOUND"
      );

      this.state.monthlyBilling = null;

      return null;
    }

    const publishedBills = [];

    billingSnapshot.forEach(
      (billingDoc) => {

        const data =
          billingDoc.data();

        publishedBills.push({

          ...data,

          billingId:
            billingDoc.id

        });

      }
    );

    publishedBills.sort(
      (a, b) => {

        const monthA =
          String(
            a.billingMonth ||
            a.billingPeriod ||
            ""
          );

        const monthB =
          String(
            b.billingMonth ||
            b.billingPeriod ||
            ""
          );

        return monthB.localeCompare(monthA);

      }
    );

    const billingData =
      publishedBills[0];

    this.state.monthlyBilling = {

      billingId:
        billingData.billingId,

      restaurantId,

      ownerId,

      billingMonth:
        billingData.billingMonth ||
        billingData.billingPeriod ||
        "",

      billingPeriod:
        billingData.billingPeriod ||
        billingData.billingMonth ||
        "",

      dueDate:
        billingData.dueDate ||
        null,

      baseAmount:
        Number(
          billingData.baseAmount ?? 0
        ),

      usageAdjustment:
        Number(
          billingData.usageAdjustment ?? 0
        ),

      finalAmount:
        Number(
          billingData.finalAmount ?? 0
        ),

      currency:
        billingData.currency ||
        "INR",

      status:
        billingData.status,

      paymentStatus:
        billingData.paymentStatus ||
        "UNPAID",

      publishedAt:
        billingData.publishedAt ||
        null,

      publishedBy:
        billingData.publishedBy ||
        null,

      updatedAt:
        billingData.updatedAt ||
        null

    };

    console.log(
      "BK OWNER BILLING: LATEST PUBLISHED BILL LOADED:",
      this.state.monthlyBilling
    );

    return {
      ...this.state.monthlyBilling
    };

  } catch (error) {

    console.error(
      "BK OWNER BILLING: CURRENT BILL LOAD FAILED:",
      error
    );

    this.state.monthlyBilling = null;

    throw error;

  }

},

/* ============================================================
   OWNER MONTHLY BILLING
   STEP 2A — MASTER PAYMENT CONFIGURATION READER
   ============================================================ */

async loadMonthlyPaymentConfiguration() {

  console.log(
    "BK OWNER BILLING: LOADING MASTER PAYMENT CONFIGURATION..."
  );

  try {

    const configRef = doc(
      db,
      "paymentConfigurations",
      "MAIN"
    );

    const configSnapshot = await getDoc(configRef);

    if (!configSnapshot.exists()) {

      this.state.paymentConfiguration = null;

      throw new Error(
        "Master payment configuration was not found."
      );

    }

    const data = configSnapshot.data();

    if (
      String(data.status || "").toUpperCase() !== "ACTIVE"
    ) {

      this.state.paymentConfiguration = null;

      throw new Error(
        "Master payment configuration is inactive."
      );

    }

    const paymentIdentifier =
      String(data.paymentIdentifier || "").trim();

    const payeeName =
      String(data.payeeName || "").trim();

    if (!paymentIdentifier || !payeeName) {

      this.state.paymentConfiguration = null;

      throw new Error(
        "Master UPI ID or payee name is missing."
      );

    }

    this.state.paymentConfiguration = {

      paymentIdentifier,

      payeeName,

      status: "ACTIVE"

    };

    console.log(
      "BK OWNER BILLING: MASTER PAYMENT CONFIGURATION LOADED."
    );

    return {
      ...this.state.paymentConfiguration
    };

  } catch (error) {

    this.state.paymentConfiguration = null;

    console.error(
      "BK OWNER BILLING: PAYMENT CONFIGURATION LOAD FAILED:",
      error
    );

    throw error;

  }

},

  /* ============================================================
     UI — BIND
     ============================================================ */

  bindUI() {

    const planGrid =
      document.getElementById(
        "bkOwnerSubscriptionPlanGrid"
      );

    const submitButton =
      document.getElementById(
        "bkOwnerSubscriptionSubmitPayment"
      );

    const paymentReference =
      document.getElementById(
        "bkOwnerPaymentReference"
      );

    const paymentMethod =
      document.getElementById(
        "bkOwnerPaymentMethod"
      );


    if (!planGrid) {

      console.warn(
        "BK OWNER SUBSCRIPTION UI: PLAN GRID NOT FOUND"
      );

    } else {

      planGrid.addEventListener(
        "click",
        (event) => {

          const button =
            event.target.closest(
              "[data-subscription-plan]"
            );

          if (!button) {
            return;
          }

          const planId =
            button.dataset.subscriptionPlan;

          if (planId) {

            this.selectPlan(
              planId
            );

          }

        }
      );

    }


    if (paymentReference) {

      paymentReference.addEventListener(
        "input",
        () => {

          this.updatePaymentUI();

        }
      );

    }


    if (paymentMethod) {

      paymentMethod.addEventListener(
        "change",
        () => {

          this.updatePaymentUI();

        }
      );

    }


    if (submitButton) {

      submitButton.addEventListener(
        "click",
        () =>
          this.handlePaymentSubmit()
      );

    }


    // MONTHLY BILLING — PAY NOW BUTTON

    const monthlyPayButton =
      document.getElementById(
        "bkOwnerMonthlyPayButton"
      );

    if (monthlyPayButton) {

      monthlyPayButton.addEventListener(
        "click",
        () => this.handleMonthlyPayNow()
      );

    }
    
        // MONTHLY BILLING — UTR SUBMISSION BUTTON

    const monthlySubmitButton =
      document.getElementById(
        "bkOwnerMonthlySubmitPaymentButton"
      );

    if (monthlySubmitButton) {

      monthlySubmitButton.addEventListener(
        "click",
        () => this.handleMonthlyPaymentSubmission()
      );

    }
    

    console.log(
      "BK OWNER SUBSCRIPTION UI: EVENTS READY"
    );

  },

// ============================================================
// MONTHLY BILLING — PAY NOW HANDLER
// STEP 3B — UPI PAYMENT HANDOFF
// ============================================================

handleMonthlyPayNow() {

    console.info(
        "BK OWNER BILLING: PAY NOW CLICK RECEIVED."
    );

    try {

        const billing =
            window.BKOwnerMonthlyBilling;

        if (
            !billing ||
            typeof billing.buildUpiPaymentUri !== "function"
        ) {
            throw new Error(
                "Monthly billing UPI builder is unavailable."
            );
        }

        const bill = billing.state?.currentBill;

        const config =
            this.state.paymentConfiguration;

        if (!bill || !config) {
            throw new Error(
                "Monthly bill or payment configuration is missing."
            );
        }

        const uri =
            billing.buildUpiPaymentUri();

        if (
            typeof uri !== "string" ||
            !uri.startsWith("upi://pay?")
        ) {
            throw new Error(
                "Generated UPI payment URI is invalid."
            );
        }

        console.info(
            "BK OWNER BILLING: UPI PAYMENT HANDOFF READY.",
            {
                billingId: bill.billingId,
                amount: bill.finalAmount,
                currency: bill.currency
            }
        );

        window.location.href = uri;

    } catch (error) {

        console.error(
            "BK OWNER BILLING: UPI PAYMENT HANDOFF FAILED.",
            error
        );

        const message =
            document.getElementById(
                "bkOwnerMonthlyBillingMessage"
            );

        if (message) {
            message.textContent =
                error.message ||
                "Unable to start monthly payment.";
        }

    }

},



  // ============================================================
  // MONTHLY BILLING — SUBMIT PAYMENT DETAILS
  // STEP 5 — FIRESTORE TRANSACTION
  // ============================================================

  async handleMonthlyPaymentSubmission() {

    const message =
      document.getElementById(
        "bkOwnerMonthlyBillingMessage"
      );

    const utrInput =
      document.getElementById(
        "bkOwnerMonthlyPaymentUTR"
      );

    const submitButton =
      document.getElementById(
        "bkOwnerMonthlySubmitPaymentButton"
      );

    try {

      const utr =
        String(utrInput?.value || "").trim();

      const currentUser =
        this.state.currentUser;

      const restaurantId =
        this.state.restaurantId;

      const billing =
        window.BKOwnerMonthlyBilling;

      const bill =
        billing?.state?.currentBill;

      if (!currentUser?.uid || !restaurantId) {
        throw new Error(
          "Authenticated owner context is unavailable."
        );
      }

      if (!bill?.billingId) {
        throw new Error(
          "Published monthly bill is unavailable."
        );
      }

      if (!utr || utr.length < 6 || utr.length > 64) {
        throw new Error(
          "UTR/reference must contain 6 to 64 characters."
        );
      }

      if (!/^[A-Za-z0-9-]+$/.test(utr)) {
        throw new Error(
          "UTR/reference contains unsupported characters."
        );
      }

      if (
        bill.restaurantId !== restaurantId ||
        bill.ownerId !== currentUser.uid
      ) {
        throw new Error(
          "Monthly bill ownership verification failed."
        );
      }

      if (
        bill.status !== "PUBLISHED" ||
        !["UNPAID", "NOT_SUBMITTED"].includes(
          bill.paymentStatus
        )
      ) {
        throw new Error(
          "This bill is not eligible for payment submission."
        );
      }

      const amount = Number(bill.finalAmount);

      if (
        bill.currency !== "INR" ||
        !Number.isFinite(amount) ||
        amount <= 0
      ) {
        throw new Error(
          "Monthly bill amount or currency is invalid."
        );
      }

      if (submitButton) {
        submitButton.disabled = true;
        submitButton.textContent = "SUBMITTING...";
      }

      if (message) {
        message.textContent =
          "Verifying bill and submitting payment details...";
      }

      const restaurantRef =
        doc(db, "restaurants", restaurantId);

      const billRef =
        doc(db, "billingRecords", bill.billingId);

      // One payment document per published bill.
      const monthlyPaymentRef =
        doc(db, "billingPayments", bill.billingId);

      const result = await runTransaction(
        db,
        async (transaction) => {

          const restaurantSnapshot =
            await transaction.get(restaurantRef);

          const billSnapshot =
            await transaction.get(billRef);

          const paymentSnapshot =
            await transaction.get(monthlyPaymentRef);

          if (!restaurantSnapshot.exists()) {
            throw new Error("Restaurant was not found.");
          }

          if (
            restaurantSnapshot.data().ownerId !==
            currentUser.uid
          ) {
            throw new Error(
              "Restaurant ownership verification failed."
            );
          }

          if (!billSnapshot.exists()) {
            throw new Error("Monthly bill was not found.");
          }

          const freshBill = billSnapshot.data();

          if (
            freshBill.restaurantId !== restaurantId ||
            freshBill.ownerId !== currentUser.uid
          ) {
            throw new Error(
              "Fresh monthly bill ownership check failed."
            );
          }

          if (freshBill.status !== "PUBLISHED") {
            throw new Error(
              "Monthly bill is no longer published."
            );
          }

          if (
            !["UNPAID", "NOT_SUBMITTED"].includes(
              freshBill.paymentStatus
            )
          ) {
            throw new Error(
              "Monthly bill is not eligible for payment."
            );
          }

          if (
            Number(freshBill.finalAmount) !== amount ||
            freshBill.currency !== "INR"
          ) {
            throw new Error(
              "Monthly bill amount changed. Refresh the bill."
            );
          }

          if (paymentSnapshot.exists()) {
            throw new Error(
              "Payment details have already been submitted for this bill."
            );
          }

          const paymentData = {

            billingId: bill.billingId,

            restaurantId,

            ownerId: currentUser.uid,

            billingMonth:
              freshBill.billingMonth || "",

            amount,

            currency: "INR",

            paymentReference: utr,

            paymentMethod: "UPI",

            status: "PAYMENT_SUBMITTED",

            verificationStatus: "PENDING",

            createdAt: serverTimestamp(),

            submittedAt: serverTimestamp(),

            updatedAt: serverTimestamp()

          };

          transaction.set(
            monthlyPaymentRef,
            paymentData
          );

          return {
            billingId: bill.billingId,
            status: "PAYMENT_SUBMITTED"
          };

        }
      );

      if (utrInput) {
        utrInput.value = "";
      }
      
      // LOCK MONTHLY PAYMENT AFTER SUCCESSFUL SUBMISSION

if (billing?.state) {

    billing.state.currentMonthlyPayment = {
        billingId: result.billingId,
        restaurantId,
        ownerId: currentUser.uid,
        paymentReference: utr,
        paymentMethod: "UPI",
        status: "PAYMENT_SUBMITTED",
        verificationStatus: "PENDING"
    };

    billing.state.monthlyPaymentSubmissionStatus =
        "PAYMENT_SUBMITTED";
}

if (
    billing &&
    typeof billing.syncOverdueState === "function"
) {
    billing.syncOverdueState();
}

      if (message) {
        message.textContent =
          "Payment details submitted. Verification is pending with BK Master.";
      }

      console.info(
        "BK OWNER BILLING: PAYMENT SUBMITTED.",
        result
      );

    } catch (error) {

      console.error(
        "BK OWNER BILLING: PAYMENT SUBMISSION FAILED.",
        error
      );

      if (message) {
        message.textContent =
          error?.message ||
          "Monthly payment submission failed.";
      }

    } 
finally {

    const monthlyBilling =
        window.BKOwnerMonthlyBilling;

    if (
        monthlyBilling?.state?.currentBill &&
        typeof monthlyBilling.renderPremiumBillingUI ===
            "function"
    ) {

        monthlyBilling.renderPremiumBillingUI(
            monthlyBilling.state.currentBill
        );

    }

}
  },


  /* ============================================================
     UI — RENDER PLANS
     ============================================================ */

  renderPlans() {

    const grid =
      document.getElementById(
        "bkOwnerSubscriptionPlanGrid"
      );

    const empty =
      document.getElementById(
        "bkOwnerSubscriptionEmpty"
      );

    const count =
      document.getElementById(
        "bkOwnerSubscriptionPlanCount"
      );


    if (!grid) {
      return;
    }


    grid.innerHTML = "";


    const plans =
      this.state.activePlans || [];


    if (count) {

      count.textContent =
        plans.length === 1
          ? "1 active plan"
          : `${plans.length} active plans`;

    }


    if (!plans.length) {

      if (empty) {
        empty.classList.remove("hidden");
      }

      return;

    }


    if (empty) {
      empty.classList.add("hidden");
    }


    plans.forEach(
      (plan) => {

        const card =
          document.createElement(
            "article"
          );

        card.className =
          "bk-owner-subscription-plan-card";


        if (
          this.state.selectedPlan?.planId ===
          plan.planId
        ) {

          card.classList.add(
            "selected"
          );

        }


        const amount =
          this.formatMoney(
            plan.baseAmount,
            plan.currency
          );


        const billing =
          plan.billingCycle ||
          "Billing cycle not specified";


        card.innerHTML = `

          <div class="bk-owner-subscription-plan-card-top">

              <span class="bk-owner-subscription-plan-kicker">
                  BK PREMIUM PLAN
              </span>

              <span class="bk-owner-subscription-plan-check">
                  ${this.state.selectedPlan?.planId === plan.planId ? "✓ SELECTED" : "AVAILABLE"}
              </span>

          </div>


          <h4>
              ${this.escapeHTML(plan.name || "Subscription Plan")}
          </h4>


          <p>
              ${this.escapeHTML(plan.description || "Premium restaurant platform access.")}
          </p>


          <div class="bk-owner-subscription-plan-price">

              <strong>
                  ${this.escapeHTML(amount)}
              </strong>

              <span>
                  ${this.escapeHTML(billing)}
              </span>

          </div>


          <button
              type="button"
              class="bk-owner-subscription-plan-select"
              data-subscription-plan="${this.escapeHTML(plan.planId)}"
          >
              ${
                this.state.selectedPlan?.planId === plan.planId
                  ? "Selected"
                  : "Choose Plan"
              }
          </button>

        `;


        grid.appendChild(
          card
        );

      }
    );

  },


  /* ============================================================
     UI — ACTIVE SUBSCRIPTION
     ============================================================ */

  renderActiveSubscription() {

    const activeBox =
      document.getElementById(
        "bkOwnerActiveSubscription"
      );

    const title =
      document.getElementById(
        "bkOwnerActivePlanName"
      );

    const planId =
      document.getElementById(
        "bkOwnerActivePlanId"
      );

    const amount =
      document.getElementById(
        "bkOwnerActivePlanAmount"
      );

    const billing =
      document.getElementById(
        "bkOwnerActiveBillingCycle"
      );

    const expiry =
      document.getElementById(
        "bkOwnerActiveExpiry"
      );

    const statusText =
      document.getElementById(
        "bkOwnerSubscriptionStatusText"
      );


    const subscription =
      this.state.subscription;


    if (!subscription) {

      if (activeBox) {
        activeBox.classList.add(
          "hidden"
        );
      }

      if (statusText) {

        statusText.textContent =
          "SUBSCRIPTION REQUIRED";

      }

      this.showAccessMessage(
        "Subscription Required",
        "Choose an active plan and submit your payment to begin subscription verification."
      );

      return;

    }


    if (activeBox) {
      activeBox.classList.remove(
        "hidden"
      );
    }


    if (title) {

      title.textContent =
        this.getPlanName(
          subscription.planId
        );

    }


    if (planId) {

      planId.textContent =
        subscription.planId ||
        "—";

    }


    if (amount) {

      amount.textContent =
        this.formatMoney(
          subscription.amount,
          subscription.currency
        );

    }


    if (billing) {

      billing.textContent =
        this.getPlanBillingCycle(
          subscription.planId
        );

    }


    if (expiry) {

      expiry.textContent =
        this.formatDate(
          this.state.access?.expiresAt ||
          subscription.expiresAt
        );

    }


    if (statusText) {

      statusText.textContent =
        this.state.access?.allowed
          ? "ACTIVE"
          : "EXPIRED";

    }


    if (
      this.state.access?.allowed
    ) {

      this.showAccessMessage(
        "Premium Access Active",
        "Your subscription is active and your payment verification has been completed."
      );

    } else {

      this.showAccessMessage(
        "Subscription Expired",
        "Your subscription has expired. Please choose an active plan for renewal."
      );

    }

  },


  /* ============================================================
     UI — LAST PAYMENT
     ============================================================ */

  renderLastPayment() {

    const box =
      document.getElementById(
        "bkOwnerLastPayment"
      );

    const status =
      document.getElementById(
        "bkOwnerLastPaymentStatus"
      );

    const reference =
      document.getElementById(
        "bkOwnerLastPaymentReference"
      );

    const amount =
      document.getElementById(
        "bkOwnerLastPaymentAmount"
      );


    const payment =
      this.state.lastSubmittedPayment;


    if (!payment) {

      if (box) {
        box.classList.add(
          "hidden"
        );
      }

      return;

    }


    if (box) {
      box.classList.remove(
        "hidden"
      );
    }


    if (status) {

      status.textContent =
        payment.status ||
        "PAYMENT_SUBMITTED";

    }


    if (reference) {

      reference.textContent =
        payment.paymentReference ||
        "—";

    }


    if (amount) {

      amount.textContent =
        this.formatMoney(
          payment.amount,
          payment.currency
        );

    }

  },

/* ============================================================
   UI — MONTHLY USAGE BILL
   STEP 1B-1 — PUBLISHED BILL RENDER
   ============================================================ */

renderMonthlyBilling() {

  const billing =
    this.state.monthlyBilling;


  const status =
    document.getElementById(
      "bkOwnerMonthlyBillingStatus"
    );

  const billingMonth =
    document.getElementById(
      "bkOwnerBillingMonth"
    );

  const baseAmount =
    document.getElementById(
      "bkOwnerBillingBaseAmount"
    );

  const adjustment =
    document.getElementById(
      "bkOwnerBillingAdjustment"
    );

  const finalAmount =
    document.getElementById(
      "bkOwnerBillingFinalAmount"
    );

  const message =
    document.getElementById(
      "bkOwnerMonthlyBillingMessage"
    );


  if (!billing) {

    if (status) {
      status.textContent =
        "NO PUBLISHED BILL";
    }

    if (billingMonth) {
      billingMonth.textContent =
        "—";
    }

    if (baseAmount) {
      baseAmount.textContent =
        "—";
    }

    if (adjustment) {
      adjustment.textContent =
        "—";
    }

    if (finalAmount) {
      finalAmount.textContent =
        "—";
    }

    if (message) {
      message.textContent =
        "No published monthly bill is currently available.";
    }

    return;
  }


  if (status) {
    status.textContent =
      billing.status ||
      "PUBLISHED";
  }


  if (billingMonth) {
    billingMonth.textContent =
      billing.billingMonth ||
      billing.billingPeriod ||
      "—";
  }


  if (baseAmount) {
    baseAmount.textContent =
      this.formatMoney(
        billing.baseAmount,
        billing.currency
      );
  }


  if (adjustment) {
    adjustment.textContent =
      this.formatMoney(
        billing.usageAdjustment,
        billing.currency
      );
  }


  if (finalAmount) {
    finalAmount.textContent =
      this.formatMoney(
        billing.finalAmount,
        billing.currency
      );
  }


  if (message) {
    message.textContent =
      "This monthly usage bill has been published by BK Master.";
  }


  console.log(
    "BK OWNER BILLING UI: PUBLISHED BILL RENDERED:",
    billing
  );

},

  /* ============================================================
     UI — PAYMENT STATE
     ============================================================ */

  updatePaymentUI() {

    const state =
      this.state;


    const selectedPlan =
      state.selectedPlan;


    const stateLabel =
      document.getElementById(
        "bkOwnerSubscriptionPaymentState"
      );

    const selectedName =
      document.getElementById(
        "bkOwnerSelectedPlanName"
      );

    const selectedAmount =
      document.getElementById(
        "bkOwnerSelectedPlanAmount"
      );

    const message =
      document.getElementById(
        "bkOwnerSubscriptionPaymentMessage"
      );

    const submitButton =
      document.getElementById(
        "bkOwnerSubscriptionSubmitPayment"
      );


    if (!selectedPlan) {

      if (stateLabel) {

        stateLabel.textContent =
          "PLAN NOT SELECTED";

      }

      if (selectedName) {

        selectedName.textContent =
          "No plan selected";

      }

      if (selectedAmount) {

        selectedAmount.textContent =
          "—";

      }

      if (message) {

        message.textContent =
          "Select a plan to continue with payment submission.";

      }

      if (submitButton) {

        submitButton.disabled =
          true;

      }

      return;

    }


    if (stateLabel) {

      stateLabel.textContent =
        "READY FOR PAYMENT";

    }


    if (selectedName) {

      selectedName.textContent =
        selectedPlan.name ||
        "Subscription Plan";

    }


    if (selectedAmount) {

      selectedAmount.textContent =
        this.formatMoney(
          selectedPlan.baseAmount,
          selectedPlan.currency
        );

    }


    if (message) {

      message.textContent =
        "Enter your payment reference / UTR and select the payment method.";

    }


    const paymentReference =
      document.getElementById(
        "bkOwnerPaymentReference"
      );

    const paymentMethod =
      document.getElementById(
        "bkOwnerPaymentMethod"
      );


    const ready =
      Boolean(
        selectedPlan &&
        paymentReference?.value.trim() &&
        paymentMethod?.value
      );


    if (submitButton) {

      submitButton.disabled =
        !ready;

    }

  },


  /* ============================================================
     UI — PAYMENT SUBMIT HANDLER
     ============================================================ */

  async handlePaymentSubmit() {

    const submitButton =
      document.getElementById(
        "bkOwnerSubscriptionSubmitPayment"
      );

    const message =
      document.getElementById(
        "bkOwnerSubscriptionPaymentMessage"
      );

    const paymentReference =
      document.getElementById(
        "bkOwnerPaymentReference"
      );

    const paymentMethod =
      document.getElementById(
        "bkOwnerPaymentMethod"
      );


    const selectedPlan =
      this.state.selectedPlan;


    if (!selectedPlan) {

      if (message) {

        message.textContent =
          "Please select a subscription plan first.";

      }

      return;

    }


    const reference =
      paymentReference?.value.trim() ||
      "";

    const method =
      paymentMethod?.value ||
      "";


    if (!reference) {

      if (message) {

        message.textContent =
          "Payment reference / UTR is required.";

      }

      paymentReference?.focus();

      return;

    }


    if (!method) {

      if (message) {

        message.textContent =
          "Please select a payment method.";

      }

      paymentMethod?.focus();

      return;

    }


    const draft =
      this.createPaymentDraft({

        amount:
          selectedPlan.baseAmount,

        currency:
          selectedPlan.currency,

        paymentReference:
          reference,

        paymentMethod:
          method

      });


    if (!draft) {

      if (message) {

        message.textContent =
          "Payment draft could not be created.";

      }

      return;

    }


    const validation =
      this.validatePaymentDraft(
        draft
      );


    if (!validation.valid) {

      if (message) {

        message.textContent =
          validation.errors.join(" ");

      }

      return;

    }


    if (submitButton) {

      submitButton.disabled =
        true;

      submitButton.textContent =
        "Submitting...";

    }


    if (message) {

      message.textContent =
        "Submitting your payment reference securely...";

    }


    try {

      const result =
        await this.submitPaymentDraft();


      if (!result.success) {

        throw new Error(
          result.errors?.join(" ") ||
          "Payment submission failed."
        );

      }


      this.renderLastPayment();


      if (message) {

        message.textContent =
          "Payment submitted successfully. Verification is pending.";

      }


      const stateLabel =
        document.getElementById(
          "bkOwnerSubscriptionPaymentState"
        );

      if (stateLabel) {

        stateLabel.textContent =
          "VERIFICATION PENDING";

      }


      this.showAccessMessage(
        "Payment Verification Pending",
        "Your payment has been submitted. Subscription activation will occur only after payment verification."
      );


      if (paymentReference) {
        paymentReference.value = "";
      }

      if (paymentMethod) {
        paymentMethod.value = "";
      }


      console.log(
        "BK OWNER SUBSCRIPTION UI: PAYMENT SUBMISSION SUCCESS:",
        result
      );


    } catch (error) {

      console.error(
        "BK OWNER SUBSCRIPTION UI: PAYMENT SUBMISSION FAILED:",
        error
      );


      if (message) {

        message.textContent =
          error?.message ||
          "Payment submission failed.";

      }

    } finally {

      this.updatePaymentUI();

      if (submitButton) {

        submitButton.textContent =
          "Submit Payment";

      }

    }

  },


  /* ============================================================
     UI — ACCESS MESSAGE
     ============================================================ */
showAccessMessage(
    title,
    text
  ) {

    const titleElement =
      document.getElementById(
        "bkOwnerSubscriptionAccessTitle"
      );

    const textElement =
      document.getElementById(
        "bkOwnerSubscriptionAccessText"
      );


    if (titleElement) {

      titleElement.textContent =
        title ||
        "Subscription Access";

    }


    if (textElement) {

      textElement.textContent =
        text ||
        "";

    }

  },


  /* ============================================================
     UI — HELPERS
     ============================================================ */

  getPlanName(planId) {

    const plan =
      this.state.activePlans.find(
        (item) =>
          item.planId === planId
      );

    return (
      plan?.name ||
      planId ||
      "Subscription Plan"
    );

  },


  getPlanBillingCycle(planId) {

    const plan =
      this.state.activePlans.find(
        (item) =>
          item.planId === planId
      );

    return (
      plan?.billingCycle ||
      "—"
    );

  },


  formatMoney(
    amount,
    currency
  ) {

    const numericAmount =
      Number(amount);


    if (
      !Number.isFinite(
        numericAmount
      )
    ) {

      return "—";

    }


    const cleanCurrency =
      String(
        currency || "INR"
      ).toUpperCase();


    try {

      return new Intl.NumberFormat(
        "en-IN",
        {
          style: "currency",
          currency: cleanCurrency,
          maximumFractionDigits: 2
        }
      ).format(
        numericAmount
      );

    } catch {

      return `${cleanCurrency} ${numericAmount}`;

    }

  },


  formatDate(value) {

    let date =
      value;


    if (
      date &&
      typeof date.toDate ===
      "function"
    ) {

      date =
        date.toDate();

    }


    if (
      !(date instanceof Date)
    ) {

      date =
        new Date(date);

    }


    if (
      Number.isNaN(
        date.getTime()
      )
    ) {

      return "—";

    }


    return date.toLocaleDateString(
      "en-IN",
      {
        day: "2-digit",
        month: "short",
        year: "numeric"
      }
    );

  },


  escapeHTML(value) {

    return String(
      value ?? ""
    )
      .replaceAll(
        "&",
        "&amp;"
      )
      .replaceAll(
        "<",
        "&lt;"
      )
      .replaceAll(
        ">",
        "&gt;"
      )
      .replaceAll(
        '"',
        "&quot;"
      )
      .replaceAll(
        "'",
        "&#039;"
      );

  },


  /* ============================================================
     GET LAST SUBMITTED PAYMENT
     ============================================================ */

  getLastSubmittedPayment() {

    if (
      !this.state.lastSubmittedPayment
    ) {

      return null;

    }

    return {

      ...this.state.lastSubmittedPayment

    };

  },


  /* ============================================================
     GET PAYMENT DRAFT
     ============================================================ */

  getPaymentDraft() {

    if (!this.state.paymentDraft) {
      return null;
    }

    return {
      ...this.state.paymentDraft
    };

  },


  /* ============================================================
     CLEAR PAYMENT DRAFT
     ============================================================ */

  clearPaymentDraft() {

    this.state.paymentDraft = null;

    console.log(
      "BK OWNER SUBSCRIPTION: PAYMENT DRAFT CLEARED"
    );

  },


  /* ============================================================
     PUBLIC CONTEXT
     ============================================================ */

  getContext() {

    return {

      currentUser:
        this.state.currentUser,

      restaurantId:
        this.state.restaurantId

    };

  },


  /* ============================================================
     PUBLIC ACTIVE PLANS
     ============================================================ */

  getActivePlans() {

    return [
      ...this.state.activePlans
    ];

  },


  /* ============================================================
     PUBLIC SUBSCRIPTION
     ============================================================ */

  getSubscription() {

    return this.state.subscription;

  },


  getAccessState() {

    return this.state.access;

  }

};


/* ================================================================
   GLOBAL EXPOSURE
   ================================================================ */

window.BKOwnerSubscription =
  BKOwnerSubscription;


/* ================================================================
   START
   ================================================================ */

if (
  document.readyState ===
  "loading"
) {

  document.addEventListener(
    "DOMContentLoaded",
    () =>
      BKOwnerSubscription.init()
  );

} else {

  BKOwnerSubscription.init();

}