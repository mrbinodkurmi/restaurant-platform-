
/* =========================================================
   BK SUBSCRIPTION ENGINE V2
   Version: 2.0.0

   OWNER:
   - Load plans
   - Create payment request
   - Open UPI
   - Submit UTR
   - View payment/subscription status

   MASTER:
   - Load pending payments
   - Verify bank payment
   - Reject payment with reason
   - Activate or block restaurant access

   IMPORTANT:
   - UTR submission does NOT activate a subscription.
   - Only an authenticated ACTIVE Master can verify/reject.
   - Monthly Billing is not modified by this file.
========================================================= */

import { auth, db } from "../../firebase.js";

import {
  collection,
  doc,
  getDoc,
  getDocs,
  query,
  where,
  addDoc,
  setDoc,
  updateDoc,
  runTransaction,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";


const BKSubscriptionEngineV2 = {

  version: "2.0.0",

  state: {
    ready: false,
    loading: false,
    error: null,

    ownerId: null,
    restaurantId: null,

    selectedPlan: null,
    plans: [],

    paymentConfiguration: null,
    currentPayment: null,
    activeSubscription: null,

    masterId: null,
    pendingPayments: []
  },


  /* =====================================================
     1. HELPERS
  ===================================================== */

  setError(error) {
    this.state.error =
      error?.message || String(error || "Unknown error");

    console.error("BK SUBSCRIPTION V2:", this.state.error);
  },


  clearError() {
    this.state.error = null;
  },


  getStatus() {
    return {
      version: this.version,
      ready: this.state.ready,
      loading: this.state.loading,
      error: this.state.error,
      ownerId: this.state.ownerId,
      restaurantId: this.state.restaurantId,
      plansCount: this.state.plans.length,
      selectedPlan: this.state.selectedPlan,
      currentPayment: this.state.currentPayment,
      activeSubscription: this.state.activeSubscription
    };
  },


  getOwnerId() {
    return auth?.currentUser?.uid || null;
  },


  getMasterId() {
    return auth?.currentUser?.uid || null;
  },


  /* =====================================================
     2. OWNER INITIALIZATION
  ===================================================== */

  async initOwner() {
    this.clearError();

    const ownerId = this.getOwnerId();

    if (!ownerId) {
      throw new Error("Owner login required.");
    }

    const ownerState = window.BKOwner?.state || {};

    const restaurantData =
      ownerState.restaurantData ||
      ownerState.currentRestaurant ||
      {};

    const restaurantId =
      ownerState.restaurantId ||
      restaurantData.restaurantId ||
      restaurantData.id ||
      localStorage.getItem("bkRestaurantId");

    if (!restaurantId) {
      throw new Error("Restaurant ID not found.");
    }

    const restaurantRef = doc(
      db,
      "restaurants",
      restaurantId
    );

    const restaurantSnapshot = await getDoc(restaurantRef);

    if (!restaurantSnapshot.exists()) {
      throw new Error("Restaurant record not found.");
    }

    const restaurant = restaurantSnapshot.data();

    if (restaurant.ownerId !== ownerId) {
      throw new Error("Restaurant ownership verification failed.");
    }

    this.state.ownerId = ownerId;
    this.state.restaurantId = restaurantId;

    return restaurant;
  },


  /* =====================================================
     3. LOAD ACTIVE PLANS
  ===================================================== */

  async loadPlans() {
    const plansQuery = query(
      collection(db, "subscriptionPlans"),
      where("status", "==", "ACTIVE")
    );

    const snapshot = await getDocs(plansQuery);

    const plans = [];

    snapshot.forEach((item) => {
      const data = item.data();

      plans.push({
        id: item.id,
        planId: item.id,
        name: data.name || "Subscription Plan",
        description: data.description || "",
        baseAmount: Number(data.baseAmount ?? 0),
        currency: data.currency || "INR",
        billingCycle: data.billingCycle || "PERMANENT",
        status: data.status
      });
    });

    this.state.plans = plans;

    return [...plans];
  },


  /* =====================================================
     4. LOAD PAYMENT CONFIGURATION
  ===================================================== */

  async loadPaymentConfiguration() {
    const configRef = doc(
      db,
      "paymentConfigurations",
      "MAIN"
    );

    const snapshot = await getDoc(configRef);

    if (!snapshot.exists()) {
      throw new Error("Payment configuration not found.");
    }

    const data = snapshot.data();

    if (data.status !== "ACTIVE") {
      throw new Error("Payment configuration is inactive.");
    }

    if (!data.paymentIdentifier || !data.payeeName) {
      throw new Error("UPI ID or payee name is missing.");
    }

    this.state.paymentConfiguration = {
      paymentIdentifier: data.paymentIdentifier,
      payeeName: data.payeeName,
      currency: data.currency || "INR"
    };

    return this.state.paymentConfiguration;
  },


  /* =====================================================
     5. LOAD OWNER SUBSCRIPTION STATUS
  ===================================================== */

  async loadOwnerSubscription() {
    const subscriptionsQuery = query(
      collection(db, "subscriptions"),
      where("restaurantId", "==", this.state.restaurantId),
      where("ownerId", "==", this.state.ownerId)
    );

    const snapshot = await getDocs(subscriptionsQuery);

    let active = null;

    snapshot.forEach((item) => {
      const data = item.data();

      if (data.status === "ACTIVE" && !active) {
        active = {
          id: item.id,
          ...data
        };
      }
    });

    if (active) {
      const expiry = active.expiresAt;

      if (expiry === null) {
        this.state.activeSubscription = active;
        return active;
      }

      let expiryDate = null;

      if (expiry?.toDate) {
        expiryDate = expiry.toDate();
      } else if (expiry instanceof Date) {
        expiryDate = expiry;
      } else if (typeof expiry === "string") {
        expiryDate = new Date(expiry);
      }

      if (
        expiryDate &&
        !Number.isNaN(expiryDate.getTime()) &&
        expiryDate.getTime() > Date.now()
      ) {
        this.state.activeSubscription = active;
        return active;
      }
    }

    this.state.activeSubscription = null;

    return null;
  },


  /* =====================================================
     6. START OWNER ENGINE
  ===================================================== */

  async startOwner() {
    try {
      this.state.loading = true;
      this.state.ready = false;
      this.clearError();

      await this.initOwner();

      await Promise.all([
        this.loadPlans(),
        this.loadPaymentConfiguration(),
        this.loadOwnerSubscription()
      ]);

      this.state.ready = true;

      return this.getStatus();

    } catch (error) {
      this.setError(error);
      this.state.ready = false;
      throw error;

    } finally {
      this.state.loading = false;
    }
  },


  /* =====================================================
     7. SELECT PLAN
  ===================================================== */

  selectPlan(planId) {
    if (!this.state.ready) {
      throw new Error("Start the Owner engine first.");
    }

    const plan = this.state.plans.find(
      item => item.id === planId || item.planId === planId
    );

    if (!plan) {
      throw new Error("Plan not found.");
    }

    if (!Number.isFinite(plan.baseAmount) || plan.baseAmount <= 0) {
      throw new Error("Invalid subscription plan amount.");
    }

    this.state.selectedPlan = plan;

    return { ...plan };
  },


  /* =====================================================
     8. CREATE PAYMENT REQUEST
  ===================================================== */


async createPaymentRequest() {
  try {
    if (!this.state.ready) {
      throw new Error("Owner engine is not ready.");
    }

    const plan = this.state.selectedPlan;

    if (!plan) {
      throw new Error("Select a subscription plan first.");
    }

    const restaurantRef = doc(
      db,
      "restaurants",
      this.state.restaurantId
    );

    const restaurantSnapshot = await getDoc(restaurantRef);

    if (!restaurantSnapshot.exists()) {
      throw new Error("Restaurant not found.");
    }

    const restaurant = restaurantSnapshot.data();

    if (restaurant.ownerId !== this.state.ownerId) {
      throw new Error("Owner verification failed.");
    }

    // Generate Firestore document ID before writing.
    const paymentRef = doc(
      collection(db, "subscriptionPayments")
    );

    const paymentId = paymentRef.id;

    const paymentData = {
      paymentId,

      ownerId: this.state.ownerId,
      restaurantId: this.state.restaurantId,

      planId: plan.id,
      planName: plan.name,

      amount: plan.baseAmount,
      currency: plan.currency,

      paymentMethod: "UPI",
      paymentReference: "",

      status: "PAYMENT_INITIATED",
      verificationStatus: "PENDING",

      ownerNotice: {
        status: "PAYMENT_INITIATED",
        message: "Complete your UPI payment and submit the UTR number."
      },

      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    };

    await setDoc(paymentRef, paymentData);

    this.state.currentPayment = {
      id: paymentId,
      ...paymentData
    };

    return { ...this.state.currentPayment };

  } catch (error) {
    this.setError(error);
    throw error;
  }
},


  /* =====================================================
     9. GENERATE UPI LINK
  ===================================================== */

  getUpiPaymentUri() {
    const payment = this.state.currentPayment;
    const config = this.state.paymentConfiguration;

    if (!payment || !config) {
      throw new Error("Create a payment request first.");
    }

    const params = new URLSearchParams({
      pa: config.paymentIdentifier,
      pn: config.payeeName,
      am: String(payment.amount),
      cu: payment.currency,
      tn: "BK Subscription " + payment.id
    });

    return "upi://pay?" + params.toString();
  },


  /* =====================================================
     10. OPEN UPI APP
  ===================================================== */

  openUpiApp() {
    const uri = this.getUpiPaymentUri();

    window.location.href = uri;

    return true;
  },


  /* =====================================================
     11. OWNER SUBMITS UTR
  ===================================================== */


async submitPaymentReference(paymentId, utr) {
  try {
    if (!this.state.ownerId) {
      await this.initOwner();
    }

    const reference = String(utr || "").trim();

    if (!paymentId) {
      throw new Error("Payment ID is required.");
    }

    if (!/^[A-Za-z0-9-]{6,40}$/.test(reference)) {
      throw new Error("Enter a valid UTR/reference number.");
    }

    const normalizedReference = reference
      .replace(/\s+/g, "")
      .toUpperCase();

    const paymentRef = doc(
      db,
      "subscriptionPayments",
      paymentId
    );

    const restaurantRef = doc(
      db,
      "restaurants",
      this.state.restaurantId
    );

    // Same index format used by the existing Master system.
    const referenceIndexRef = doc(
      db,
      "paymentReferenceIndex",
      encodeURIComponent(normalizedReference)
    );

    let updatedPayment = null;

    await runTransaction(db, async (transaction) => {

      // All reads must happen before writes.
      const paymentSnapshot = await transaction.get(paymentRef);
      const restaurantSnapshot = await transaction.get(restaurantRef);
      const referenceSnapshot = await transaction.get(referenceIndexRef);

      if (!paymentSnapshot.exists()) {
        throw new Error("Payment request not found.");
      }

      if (!restaurantSnapshot.exists()) {
        throw new Error("Restaurant record not found.");
      }

      const payment = paymentSnapshot.data();
      const restaurant = restaurantSnapshot.data();

      if (
        payment.ownerId !== this.state.ownerId ||
        payment.restaurantId !== this.state.restaurantId ||
        restaurant.ownerId !== this.state.ownerId
      ) {
        throw new Error("Payment ownership verification failed.");
      }

      if (payment.status !== "PAYMENT_INITIATED") {
        throw new Error("This payment request cannot be submitted.");
      }

      if (referenceSnapshot.exists()) {
        throw new Error(
          "This payment reference has already been used. Duplicate submission blocked."
        );
      }

      const paymentUpdate = {
        paymentId,
        paymentReference: reference,

        status: "VERIFICATION_PENDING",
        verificationStatus: "PENDING",

        ownerNotice: {
          status: "VERIFICATION_PENDING",
          message: "Your payment reference has been submitted. Master verification is pending."
        },

        submittedAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };

      transaction.update(paymentRef, paymentUpdate);

      // Reserve UTR globally to prevent reuse.
      transaction.set(referenceIndexRef, {
        normalizedPaymentReference: normalizedReference,
        paymentId,
        restaurantId: this.state.restaurantId,
        ownerId: this.state.ownerId,
        createdAt: serverTimestamp()
      });

      updatedPayment = {
        ...payment,
        ...paymentUpdate,
        paymentReference: reference,
        status: "VERIFICATION_PENDING",
        verificationStatus: "PENDING"
      };
    });

    this.state.currentPayment = {
      id: paymentId,
      ...updatedPayment
    };

    return { ...this.state.currentPayment };

  } catch (error) {
    this.setError(error);
    throw error;
  }
},


  /* =====================================================
     12. MASTER AUTHORIZATION
  ===================================================== */

  async verifyMasterAccess() {
    const masterId = this.getMasterId();

    if (!masterId) {
      throw new Error("Master login required.");
    }

    const adminRef = doc(
      db,
      "masterAdmins",
      masterId
    );

    const adminSnapshot = await getDoc(adminRef);

    if (!adminSnapshot.exists()) {
      throw new Error("Master authorization denied.");
    }

    const admin = adminSnapshot.data();

    if (admin.status !== "ACTIVE") {
      throw new Error("Master account is not active.");
    }

    this.state.masterId = masterId;

    return true;
  },


  /* =====================================================
     13. MASTER LOADS PENDING PAYMENTS
  ===================================================== */

  async loadPendingPayments() {
    try {
      await this.verifyMasterAccess();

      const pendingQuery = query(
        collection(db, "subscriptionPayments"),
        where("status", "==", "VERIFICATION_PENDING")
      );

      const snapshot = await getDocs(pendingQuery);

      const payments = [];

      snapshot.forEach((item) => {
        payments.push({
          id: item.id,
          ...item.data()
        });
      });

      this.state.pendingPayments = payments;

      return [...payments];

    } catch (error) {
      this.setError(error);
      throw error;
    }
  },


  /* =====================================================
     14. MASTER VERIFY PAYMENT
     Call ONLY after checking the bank account.
  ===================================================== */

    /* =====================================================
     14. MASTER VERIFY PAYMENT
     Shared Master activation engine
  ===================================================== */

  async verifyPayment(paymentId) {
    try {
      await this.verifyMasterAccess();

      if (!paymentId) {
        throw new Error("Payment ID is required.");
      }

      const masterEngine =
        window.BKMasterSubscriptionBillingControl;

      if (
        !masterEngine ||
        typeof masterEngine.reviewPayment !== "function"
      ) {
        throw new Error(
          "Master Subscription Billing Engine is not loaded."
        );
      }

      const paymentRef = doc(
        db,
        "subscriptionPayments",
        paymentId
      );

      const paymentSnapshot = await getDoc(paymentRef);

      if (!paymentSnapshot.exists()) {
        throw new Error("Payment record not found.");
      }

      const payment = {
        id: paymentSnapshot.id,
        ...paymentSnapshot.data()
      };

      if (payment.status !== "VERIFICATION_PENDING") {
        throw new Error(
          "Payment is not pending verification."
        );
      }

      // Master engine performs the actual atomic activation.
      const result = await masterEngine.reviewPayment(
        payment,
        "VERIFY",
        "Bank payment manually verified by Master."
      );

      if (!result || result.success !== true) {
        throw new Error(
          "Master payment verification was not successful."
        );
      }

      this.state.pendingPayments =
        this.state.pendingPayments.filter(
          item => item.id !== paymentId
        );

      return {
        success: true,
        paymentId,
        subscriptionId: result.subscriptionId,
        status: "VERIFIED"
      };

    } catch (error) {
      this.setError(error);
      throw error;
    }
  },

    /* =====================================================
     15. MASTER REJECT PAYMENT
     Shared Master review engine
     Rejection does not block an existing subscription.
  ===================================================== */

  async rejectPayment(paymentId, reason) {
    try {
      await this.verifyMasterAccess();

      if (!paymentId) {
        throw new Error("Payment ID is required.");
      }

      const rejectionReason = String(reason || "").trim();

      if (rejectionReason.length < 5) {
        throw new Error("Enter a clear rejection reason.");
      }

      const masterEngine =
        window.BKMasterSubscriptionBillingControl;

      if (
        !masterEngine ||
        typeof masterEngine.reviewPayment !== "function"
      ) {
        throw new Error(
          "Master Subscription Billing Engine is not loaded."
        );
      }

      const paymentRef = doc(
        db,
        "subscriptionPayments",
        paymentId
      );

      const paymentSnapshot = await getDoc(paymentRef);

      if (!paymentSnapshot.exists()) {
        throw new Error("Payment record not found.");
      }

      const payment = {
        id: paymentSnapshot.id,
        ...paymentSnapshot.data()
      };

      if (payment.status !== "VERIFICATION_PENDING") {
        throw new Error(
          "Only pending payments can be rejected."
        );
      }

      const result = await masterEngine.reviewPayment(
        payment,
        "REJECT",
        rejectionReason
      );

      if (!result || result.success !== true) {
        throw new Error(
          "Master payment rejection was not successful."
        );
      }

      this.state.pendingPayments =
        this.state.pendingPayments.filter(
          item => item.id !== paymentId
        );

      return {
        success: true,
        paymentId,
        status: "REJECTED",
        reason: rejectionReason
      };

    } catch (error) {
      this.setError(error);
      throw error;
    }
  },

  

  /* =====================================================
     16. OWNER REFRESHES PAYMENT STATUS
  ===================================================== */

  async refreshPaymentStatus(paymentId) {
    if (!this.state.ownerId) {
      await this.initOwner();
    }

    const paymentRef = doc(
      db,
      "subscriptionPayments",
      paymentId
    );

    const snapshot = await getDoc(paymentRef);

    if (!snapshot.exists()) {
      throw new Error("Payment record not found.");
    }

    const payment = snapshot.data();

    if (
      payment.ownerId !== this.state.ownerId ||
      payment.restaurantId !== this.state.restaurantId
    ) {
      throw new Error("Payment ownership verification failed.");
    }

    this.state.currentPayment = {
      id: snapshot.id,
      ...payment
    };

    return { ...this.state.currentPayment };
  },


  /* =====================================================
     17. RESET TEMPORARY STATE
  ===================================================== */

  reset() {
    this.state.ready = false;
    this.state.loading = false;
    this.state.error = null;

    this.state.ownerId = null;
    this.state.restaurantId = null;

    this.state.selectedPlan = null;
    this.state.plans = [];

    this.state.paymentConfiguration = null;
    this.state.currentPayment = null;
    this.state.activeSubscription = null;

    this.state.masterId = null;
    this.state.pendingPayments = [];

    return true;
  }

};


/* =========================================================
   18. GLOBAL EXPORT
========================================================= */

window.BKSubscriptionEngineV2 = BKSubscriptionEngineV2;

console.log(
  "BK SUBSCRIPTION ENGINE V2 LOADED",
  BKSubscriptionEngineV2.version
);
