/* ============================================================
   BK OWNER ACCOUNT LOCK
   PART 1 — GLOBAL LOCK FOUNDATION
============================================================ */

"use strict";




const BKOwnerAccountLock = {

    state: {

        initialized: false,

        ready: false,

        accountStatus: null,

        locked: false,

        lockLevel: "NONE",

        restaurantId: null,

        lastSyncedAt: null

    },


    STATUS: {

        ACTIVE: "ACTIVE",

        INACTIVE: "INACTIVE",

        SUSPENDED: "SUSPENDED",

        BLOCKED: "BLOCKED"

    },


    LOCK_LEVEL: {

        NONE: "NONE",

        CONTROLLED: "CONTROLLED"

    },


    normalizeStatus: function (status) {

        const normalizedStatus =
            String(status || "")
                .trim()
                .toUpperCase();


        if (
            normalizedStatus ===
            this.STATUS.ACTIVE
        ) {

            return this.STATUS.ACTIVE;

        }


        if (
            normalizedStatus ===
            this.STATUS.INACTIVE
        ) {

            return this.STATUS.INACTIVE;

        }


        if (
            normalizedStatus ===
            this.STATUS.SUSPENDED
        ) {

            return this.STATUS.SUSPENDED;

        }


        if (
            normalizedStatus ===
            this.STATUS.BLOCKED
        ) {

            return this.STATUS.BLOCKED;

        }


        return null;

    },


    isControlledStatus: function (status) {

        const normalizedStatus =
            this.normalizeStatus(status);


        return (

            normalizedStatus ===
                this.STATUS.INACTIVE

            ||

            normalizedStatus ===
                this.STATUS.SUSPENDED

            ||

            normalizedStatus ===
                this.STATUS.BLOCKED

        );

    },


    isLocked: function () {

        return (
            this.state.locked === true
        );

    },


    isReady: function () {

        return (
            this.state.ready === true
        );

    },


    getState: function () {

        return {

            initialized:
                this.state.initialized,

            ready:
                this.state.ready,

            accountStatus:
                this.state.accountStatus,

            locked:
                this.state.locked,

            lockLevel:
                this.state.lockLevel,

            restaurantId:
                this.state.restaurantId,

            lastSyncedAt:
                this.state.lastSyncedAt

        };

    }

};


/* ============================================================
   GLOBAL ACCESS
============================================================ */

window.BKOwnerAccountLock =
    BKOwnerAccountLock;


/* ============================================================
   PART 1 INITIALIZATION
============================================================ */

BKOwnerAccountLock.state.initialized =
    true;

BKOwnerAccountLock.state.ready =
    true;


console.log(
    "=========================================="
);

console.log(
    "BK OWNER ACCOUNT LOCK: PART 1 LOADED."
);

console.log(
    "Global Lock Foundation: READY"
);

console.log(
    "Account Status Engine: READY"
);

console.log(
    "Lock State Engine: READY"
);

console.log(
    "Controlled Status Resolver: READY"
);

console.log(
    "Global Lock API: READY"
);

console.log(
    "=========================================="
);

 /* ============================================================
    BK OWNER ACCOUNT LOCK
    PART 2 — GUARD STATE SYNCHRONIZATION
 ============================================================ */

BKOwnerAccountLock.state.guardSync = {

    initialized: false,

    lastStatus: null,

    lastLocked: false,

    lastLockLevel: "NONE",

    lastSyncedAt: null

};


/* ============================================================
   SYNC FROM EXISTING OWNER ACCOUNT GUARD
============================================================ */

BKOwnerAccountLock.syncFromGuard =
    function () {

        const guard =
            window.BKOwnerAccountGuard;


        /*
         * ----------------------------------------------------
         * Guard availability check
         * ----------------------------------------------------
         */

        if (
            !guard ||
            !guard.state
        ) {

            console.warn(
                "BK OWNER ACCOUNT LOCK: Owner Account Guard unavailable."
            );

            return false;

        }


        /*
         * ----------------------------------------------------
         * Guard readiness check
         * ----------------------------------------------------
         */

        if (
            guard.state.ready !== true
        ) {

            console.warn(
                "BK OWNER ACCOUNT LOCK: Guard not ready."
            );

            return false;

        }


        /*
         * ----------------------------------------------------
         * Read current account status
         * ----------------------------------------------------
         */

        const status =
            this.normalizeStatus(
                guard.state.accountStatus
            );


        if (!status) {

            console.warn(
                "BK OWNER ACCOUNT LOCK: Guard status unavailable."
            );

            return false;

        }


        /*
         * ----------------------------------------------------
         * Resolve global lock state
         * ----------------------------------------------------
         */

        const controlled =
            this.isControlledStatus(
                status
            );


        /*
         * ----------------------------------------------------
         * Update global lock state
         * ----------------------------------------------------
 */

        this.state.accountStatus =
            status;

        this.state.locked =
            controlled;

        this.state.lockLevel =
            controlled
                ? this.LOCK_LEVEL.CONTROLLED
                : this.LOCK_LEVEL.NONE;

        this.state.restaurantId =
            guard.state.restaurantId ||
            null;

        this.state.lastSyncedAt =
            new Date();


        /*
         * ----------------------------------------------------
         * Update synchronization state
         * ----------------------------------------------------
         */

        this.state.guardSync = {

            initialized: true,

            lastStatus:
                status,

            lastLocked:
                controlled,

            lastLockLevel:
                controlled
                    ? this.LOCK_LEVEL.CONTROLLED
                    : this.LOCK_LEVEL.NONE,

            lastSyncedAt:
                this.state.lastSyncedAt

        };


        /*
         * ----------------------------------------------------
         * Confirmation logs
         * ----------------------------------------------------
         */

        console.log(
            "=========================================="
        );

        console.log(
            "BK OWNER ACCOUNT LOCK: GUARD SYNC COMPLETE."
        );

        console.log(
            "Account Status:",
            this.state.accountStatus
        );

        console.log(
            "Global Locked:",
            this.state.locked
        );

        console.log(
            "Lock Level:",
            this.state.lockLevel
        );

        console.log(
            "Restaurant ID:",
            this.state.restaurantId || "NONE"
        );

        console.log(
            "BK OWNER ACCOUNT LOCK: GUARD STATE SYNCHRONIZED."
        );

        console.log(
            "=========================================="
        );


        return true;

    };


/* ============================================================
   GET GUARD SYNC STATE
============================================================ */

BKOwnerAccountLock.getGuardSyncState =
    function () {

        return {

            initialized:
                this.state.guardSync.initialized,

            lastStatus:
                this.state.guardSync.lastStatus,

            lastLocked:
                this.state.guardSync.lastLocked,

            lastLockLevel:
                this.state.guardSync.lastLockLevel,

            lastSyncedAt:
                this.state.guardSync.lastSyncedAt

        };

    };


/* ============================================================
   INITIAL GUARD SYNC
============================================================ */

BKOwnerAccountLock.startGuardSync =
    function () {

        if (
            this.state.ready !== true
        ) {

            console.warn(
                "BK OWNER ACCOUNT LOCK: Lock engine not ready."
            );

            return false;

        }


        const synced =
            this.syncFromGuard();


        if (!synced) {

            console.warn(
                "BK OWNER ACCOUNT LOCK: Initial Guard synchronization failed."
            );

            return false;

        }


        console.log(
            "BK OWNER ACCOUNT LOCK: INITIAL GUARD SYNC COMPLETE."
        );


        return true;

    };


/* ============================================================
   WAIT FOR EXISTING GUARD
============================================================ */

BKOwnerAccountLock.waitForGuard =
    function () {

        let attempts = 0;

        const maxAttempts = 100;


        const checkGuard =
            function () {

                attempts++;


                const guard =
                    window.BKOwnerAccountGuard;


                if (

                    guard &&

                    guard.state &&

                    guard.state.ready === true &&

                    guard.state.accountStatus

                ) {

                    BKOwnerAccountLock.startGuardSync();

                    return;

                }


                if (
                    attempts >= maxAttempts
                ) {

                    console.warn(
                        "BK OWNER ACCOUNT LOCK: Guard synchronization timeout."
                    );

                    return;

                }


                setTimeout(
                    checkGuard,
                    100
                );

            };


        checkGuard();

    };


/* ============================================================
   PART 2 STARTUP
============================================================ */

setTimeout(
    function () {

        BKOwnerAccountLock.waitForGuard();

    },
    100
);


/* ============================================================
   PART 2 COMPLETE
============================================================ */

console.log(
    "BK OWNER ACCOUNT LOCK: PART 2 GUARD SYNC LOADED."
);

console.log(
    "Guard Detection: READY"
);

console.log(
    "Status Synchronization: READY"
);

console.log(
    "Lock State Synchronization: READY"
);
 /* ============================================================
    BK OWNER ACCOUNT LOCK
    PART 3 — GLOBAL DASHBOARD LOCK CONTROLLER
 ============================================================ */


/* ============================================================
   GLOBAL DASHBOARD LOCK STATE
============================================================ */

BKOwnerAccountLock.state.dashboardLock = {

    initialized: false,

    active: false,

    level: "NONE",

    status: null,

    reason: null,

    source: null,

    mode: null,

    activatedAt: null,

    releasedAt: null

};


/* ============================================================
   DASHBOARD LOCK LEVELS
============================================================ */

BKOwnerAccountLock.DASHBOARD_LOCK_LEVEL = {

    NONE: "NONE",

    GLOBAL: "GLOBAL"

};


/* ============================================================
   BUILD DASHBOARD LOCK STATE
============================================================ */

BKOwnerAccountLock.buildDashboardLockState =
    function () {

        const status =
            this.normalizeStatus(
                this.state.accountStatus
            );


        if (!status) {

            console.warn(
                "BK OWNER ACCOUNT LOCK: Dashboard lock skipped. Account status unavailable."
            );

            return this.state.dashboardLock;

        }


        const controlled =
            this.isControlledStatus(
                status
            );


        const guard =
            window.BKOwnerAccountGuard;


        let reason = null;

        let source = null;

        let mode = null;


        /*
         * ----------------------------------------------------
         * Read Master control information from existing Guard.
         * ----------------------------------------------------
         */

        if (
            guard &&
            guard.state &&
            guard.state.masterControl
        ) {

            reason =
                guard.state.masterControl.reason ||
                null;

            source =
                guard.state.masterControl.source ||
                null;

            mode =
                guard.state.masterControl.mode ||
                null;

        }


        /*
         * ----------------------------------------------------
         * Build central dashboard lock state.
         * ----------------------------------------------------
         */

        const previousActive =
            this.state.dashboardLock.active;


        this.state.dashboardLock = {

            initialized: true,

            active: controlled,

            level: controlled
                ? this.DASHBOARD_LOCK_LEVEL.GLOBAL
                : this.DASHBOARD_LOCK_LEVEL.NONE,

            status: status,

            reason: reason,

            source: source,

            mode: mode,

            activatedAt:
                controlled
                    ? (
                        previousActive
                            ? this.state.dashboardLock.activatedAt
                            : new Date()
                    )
                    : this.state.dashboardLock.activatedAt,

            releasedAt:
                controlled
                    ? null
                    : (
                        previousActive
                            ? new Date()
                            : this.state.dashboardLock.releasedAt
                    )

        };


        /*
         * ----------------------------------------------------
         * Confirmation logs.
         * ----------------------------------------------------
         */

        console.log(
            "=========================================="
        );

        console.log(
            "BK OWNER ACCOUNT LOCK: DASHBOARD LOCK STATE BUILT."
        );

        console.log(
            "Account Status:",
            this.state.dashboardLock.status
        );

        console.log(
            "Dashboard Locked:",
            this.state.dashboardLock.active
        );

        console.log(
            "Dashboard Lock Level:",
            this.state.dashboardLock.level
        );

        console.log(
            "Master Reason:",
            this.state.dashboardLock.reason || "NONE"
        );

        console.log(
            "Lock Source:",
            this.state.dashboardLock.source || "NONE"
        );

        console.log(
            "Lock Mode:",
            this.state.dashboardLock.mode || "NONE"
        );

        console.log(
            "BK OWNER ACCOUNT LOCK: DASHBOARD LOCK STATE READY."
        );

        console.log(
            "=========================================="
        );


        return this.state.dashboardLock;

    };


/* ============================================================
   REFRESH DASHBOARD LOCK
============================================================ */

BKOwnerAccountLock.refreshDashboardLock =
    function () {

        if (
            this.state.ready !== true
        ) {

            console.warn(
                "BK OWNER ACCOUNT LOCK: Cannot refresh dashboard lock. Engine not ready."
            );

            return false;

        }


        if (
            !this.state.accountStatus
        ) {

            console.warn(
                "BK OWNER ACCOUNT LOCK: Cannot refresh dashboard lock. Account status missing."
            );

            return false;

        }


        this.buildDashboardLockState();


        return true;

    };


/* ============================================================
   GET DASHBOARD LOCK STATE
============================================================ */

BKOwnerAccountLock.getDashboardLockState =
    function () {

        return {

            initialized:
                this.state.dashboardLock.initialized,

            active:
                this.state.dashboardLock.active,

            level:
                this.state.dashboardLock.level,

            status:
                this.state.dashboardLock.status,

            reason:
                this.state.dashboardLock.reason,

            source:
                this.state.dashboardLock.source,

            mode:
                this.state.dashboardLock.mode,

            activatedAt:
                this.state.dashboardLock.activatedAt,

            releasedAt:
                this.state.dashboardLock.releasedAt

        };

    };


/* ============================================================
   SIMPLE ACCESS RESOLVER
============================================================ */

BKOwnerAccountLock.canUseDashboard =
    function () {

        return (
            this.state.dashboardLock.active !== true
        );

    };


/* ============================================================
   CONTROLLED ACCOUNT CHECK
============================================================ */

BKOwnerAccountLock.isDashboardLocked =
    function () {

        return (
            this.state.dashboardLock.active === true
        );

    };


/* ============================================================
   SYNC GUARD → DASHBOARD LOCK
============================================================ */

const originalStartGuardSyncForPart3 =
    BKOwnerAccountLock.startGuardSync;


BKOwnerAccountLock.startGuardSync =
    function () {

        const result =
            originalStartGuardSyncForPart3.call(
                this
            );


        if (
            result !== true
        ) {

            return result;

        }


        this.refreshDashboardLock();


        return true;

    };


/* ============================================================
   PART 3 COMPLETE
============================================================ */

console.log(
    "BK OWNER ACCOUNT LOCK: PART 3 DASHBOARD LOCK CONTROLLER LOADED."
);

console.log(
    "Dashboard Lock State: READY"
);

console.log(
    "Global Lock Resolver: READY"
);

console.log(
    "Dashboard Access Resolver: READY"
);

console.log(
    "Guard → Dashboard Lock Bridge: READY"
);

/* ============================================================
   BK OWNER ACCOUNT LOCK
   PART 4 — GLOBAL LOCK UI FOUNDATION
============================================================ */


/* ============================================================
   GLOBAL LOCK UI STATE
============================================================ */

BKOwnerAccountLock.state.lockUI = {

    initialized: false,

    visible: false,

    overlayElement: null,

    messageElement: null,

    statusElement: null,

    reasonElement: null

};


/* ============================================================
   CREATE GLOBAL LOCK UI
============================================================ */

BKOwnerAccountLock.createLockUI =
    function () {

        /*
         * ----------------------------------------------------
         * Prevent duplicate UI
         * ----------------------------------------------------
         */

        if (
            document.getElementById(
                "bkOwnerGlobalAccountLock"
            )
        ) {

            this.cacheLockUI();

            return true;

        }


        /*
         * ----------------------------------------------------
         * Create overlay
         * ----------------------------------------------------
         */

        const overlay =
            document.createElement("div");

        overlay.id =
            "bkOwnerGlobalAccountLock";

        overlay.className =
            "bk-owner-global-account-lock";

        overlay.setAttribute(
            "aria-hidden",
            "true"
        );


        /*
         * ----------------------------------------------------
         * Create content
         * ----------------------------------------------------
         */

        overlay.innerHTML = `

            <div
                class="bk-owner-global-lock-backdrop"
            ></div>

            <div
                class="bk-owner-global-lock-panel"
                role="dialog"
                aria-modal="true"
                aria-labelledby="bkOwnerGlobalLockTitle"
            >

                <div
                    class="bk-owner-global-lock-brand"
                >

                    <div
                        class="bk-owner-global-lock-mark"
                    >
                        BK
                    </div>

                    <div>

                        <span
                            class="bk-owner-global-lock-kicker"
                        >
                            BK ACCOUNT CONTROL
                        </span>

                        <h2
                            id="bkOwnerGlobalLockTitle"
                        >
                            Account Access Controlled
                        </h2>

                    </div>

                </div>


                <div
                    class="bk-owner-global-lock-status"
                >

                    <span
                        class="bk-owner-global-lock-status-dot"
                    ></span>

                    <span
                        id="bkOwnerGlobalLockStatus"
                    >
                        ACCOUNT CONTROLLED
                    </span>

                </div>


                <p
                    class="bk-owner-global-lock-message"
                    id="bkOwnerGlobalLockMessage"
                >
                    Your restaurant dashboard is temporarily
                    unavailable while your account is under
                    BK Master Control.
                </p>


                <div
                    class="bk-owner-global-lock-reason"
                >

                    <span
                        class="bk-owner-global-lock-label"
                    >
                        MASTER REASON
                    </span>

                    <div
                        id="bkOwnerGlobalLockReason"
                    >
                        No reason provided.
                    </div>

                </div>


                <div
                    class="bk-owner-global-lock-actions"
                >

                    <button
                        type="button"
                        id="bkOwnerGlobalLockNoticeButton"
                        class="bk-owner-global-lock-button secondary"
                    >
                        View Account Notice
                    </button>

                    <button
                        type="button"
                        id="bkOwnerGlobalLockSupportButton"
                        class="bk-owner-global-lock-button primary"
                    >
                        Contact Support
                    </button>

                </div>

            </div>
        `;


        /*
         * ----------------------------------------------------
         * Add UI to document
         * ----------------------------------------------------
         */

        document.body.appendChild(
            overlay
        );


        /*
         * ----------------------------------------------------
         * Cache elements
         * ----------------------------------------------------
         */

        this.cacheLockUI();


        /*
         * ----------------------------------------------------
         * Mark initialized
         * ----------------------------------------------------
         */

        this.state.lockUI.initialized =
            true;


        console.log(
            "BK OWNER ACCOUNT LOCK: PART 4 UI CREATED."
        );

        console.log(
            "Global Lock Overlay: READY"
        );

        console.log(
            "Lock Status UI: READY"
        );

        console.log(
            "Master Reason UI: READY"
        );

        console.log(
            "Account Action UI: READY"
        );


        return true;

    };


/* ============================================================
   CACHE LOCK UI ELEMENTS
============================================================ */

BKOwnerAccountLock.cacheLockUI =
    function () {

        const overlay =
            document.getElementById(
                "bkOwnerGlobalAccountLock"
            );


        if (!overlay) {

            console.warn(
                "BK OWNER ACCOUNT LOCK: Lock UI element not found."
            );

            return false;

        }


        this.state.lockUI.overlayElement =
            overlay;

        this.state.lockUI.messageElement =
            document.getElementById(
                "bkOwnerGlobalLockMessage"
            );

        this.state.lockUI.statusElement =
            document.getElementById(
                "bkOwnerGlobalLockStatus"
            );

        this.state.lockUI.reasonElement =
            document.getElementById(
                "bkOwnerGlobalLockReason"
            );


        return true;

    };


/* ============================================================
   RENDER LOCK UI
============================================================ */

BKOwnerAccountLock.renderLockUI =
    function () {

        if (
            !this.state.lockUI.initialized
        ) {

            return false;

        }


        const overlay =
            this.state.lockUI.overlayElement;


        if (!overlay) {

            return false;

        }


        const status =
            this.state.dashboardLock.status ||
            "CONTROLLED";


        const reason =
            this.state.dashboardLock.reason;


        if (
            this.state.lockUI.statusElement
        ) {

            this.state.lockUI.statusElement.textContent =
                status;

        }


        if (
            this.state.lockUI.reasonElement
        ) {

            this.state.lockUI.reasonElement.textContent =
                reason ||
                "No reason provided by BK Master Control.";

        }


        if (
            this.state.lockUI.messageElement
        ) {

            this.state.lockUI.messageElement.textContent =
                "Your restaurant dashboard is temporarily unavailable while your account is under BK Master Control.";

        }


        return true;

    };


/* ============================================================
   SHOW GLOBAL LOCK UI
============================================================ */

BKOwnerAccountLock.showLockUI =
    function () {

        if (
            !this.state.lockUI.initialized
        ) {

            this.createLockUI();

        }


        const overlay =
            this.state.lockUI.overlayElement;


        if (!overlay) {

            return false;

        }


        this.renderLockUI();


        overlay.classList.add(
            "is-visible"
        );


        overlay.setAttribute(
            "aria-hidden",
            "false"
        );


        this.state.lockUI.visible =
            true;


        console.log(
            "BK OWNER ACCOUNT LOCK: GLOBAL LOCK UI VISIBLE."
        );


        return true;

    };


/* ============================================================
   HIDE GLOBAL LOCK UI
============================================================ */

BKOwnerAccountLock.hideLockUI =
    function () {

        const overlay =
            this.state.lockUI.overlayElement;


        if (!overlay) {

            return false;

        }


        overlay.classList.remove(
            "is-visible"
        );


        overlay.setAttribute(
            "aria-hidden",
            "true"
        );


        this.state.lockUI.visible =
            false;


        console.log(
            "BK OWNER ACCOUNT LOCK: GLOBAL LOCK UI HIDDEN."
        );


        return true;

    };


/* ============================================================
   REFRESH GLOBAL LOCK UI
============================================================ */

BKOwnerAccountLock.refreshLockUI =
    function () {

        if (
            this.state.dashboardLock.active === true
        ) {

            return this.showLockUI();

        }


        return this.hideLockUI();

    };


/* ============================================================
   INITIAL UI STARTUP
============================================================ */

BKOwnerAccountLock.startLockUI =
    function () {

        if (
            this.state.ready !== true
        ) {

            console.warn(
                "BK OWNER ACCOUNT LOCK: UI startup skipped. Engine not ready."
            );

            return false;

        }


        this.createLockUI();


        /*
         * ----------------------------------------------------
         * Important:
         * At this stage we only prepare the UI.
         * Actual dashboard enforcement comes later.
         * ----------------------------------------------------
         */

        console.log(
            "BK OWNER ACCOUNT LOCK: LOCK UI FOUNDATION READY."
        );


        return true;

    };


/* ============================================================
   PART 4 STARTUP
============================================================ */

if (
    document.readyState === "loading"
) {

    document.addEventListener(
        "DOMContentLoaded",
        function () {

            BKOwnerAccountLock.startLockUI();

        },
        {
            once: true
        }
    );

} else {

    BKOwnerAccountLock.startLockUI();

}


/* ============================================================
   PART 4 COMPLETE
============================================================ */

console.log(
    "BK OWNER ACCOUNT LOCK: PART 4 UI FOUNDATION LOADED."
);

console.log(
    "Premium Lock Overlay: READY"
);

console.log(
    "Lock UI Renderer: READY"
);

console.log(
    "Lock UI Show/Hide Engine: READY"
);

console.log(
    "Duplicate UI Protection: READY"
);

/* ============================================================
   BK OWNER ACCOUNT LOCK
   PART 5 — AUTOMATIC GUARD → LOCK BRIDGE
============================================================ */


/* ============================================================
   PART 5 STATE
============================================================ */

BKOwnerAccountLock.state.autoBridge = {

    initialized: false,

    active: false,

    lastStatus: null,

    lastLocked: null,

    lastSyncedAt: null,

    originalHandler: null

};


/* ============================================================
   SYNC LOCK FROM GUARD
============================================================ */

BKOwnerAccountLock.syncLockFromGuard =
    function () {

        const guard =
            window.BKOwnerAccountGuard;


        if (!guard) {

            console.warn(
                "BK OWNER ACCOUNT LOCK: Guard not available."
            );

            return false;

        }


        if (
            !guard.state ||
            guard.state.ready !== true
        ) {

            return false;

        }


        /*
         * ----------------------------------------------------
         * Read Guard state
         * ----------------------------------------------------
         */

        const guardStatus =
            this.normalizeStatus(
                guard.state.accountStatus
            );


        const controlled =
            this.isControlledStatus(
                guardStatus
            );


        /*
         * ----------------------------------------------------
         * Synchronize core state
         * ----------------------------------------------------
         */

        this.state.accountStatus =
            guardStatus;


        this.state.locked =
            controlled;


        this.state.lockLevel =
            controlled
                ? this.LOCK_LEVEL.CONTROLLED
                : this.LOCK_LEVEL.NONE;


        this.state.restaurantId =
            guard.state.restaurantId ||
            this.state.restaurantId;


        this.state.lastSyncedAt =
            new Date();


        /*
         * ----------------------------------------------------
         * Refresh dashboard lock state
         * ----------------------------------------------------
         */

        this.refreshDashboardLock();


        /*
         * ----------------------------------------------------
         * Refresh UI
         * ----------------------------------------------------
         */

        this.refreshLockUI();


        /*
         * ----------------------------------------------------
         * Store bridge state
         * ----------------------------------------------------
         */

        this.state.autoBridge.lastStatus =
            guardStatus;

        this.state.autoBridge.lastLocked =
            controlled;

        this.state.autoBridge.lastSyncedAt =
            new Date();


        return true;

    };


/* ============================================================
   GET BRIDGE STATE
============================================================ */

BKOwnerAccountLock.getAutoBridgeState =
    function () {

        return {
            ...this.state.autoBridge
        };

    };


/* ============================================================
   GUARD STATUS CHANGE BRIDGE
============================================================ */

BKOwnerAccountLock.installGuardBridge =
    function () {

        const guard =
            window.BKOwnerAccountGuard;


        if (!guard) {

            console.warn(
                "BK OWNER ACCOUNT LOCK: Cannot install bridge. Guard unavailable."
            );

            return false;

        }


        if (
            this.state.autoBridge.active === true
        ) {

            return true;

        }


        /*
         * ----------------------------------------------------
         * Find Guard status handler
         * ----------------------------------------------------
         */

        if (
            typeof guard.handleStatusChange !==
            "function"
        ) {

            console.warn(
                "BK OWNER ACCOUNT LOCK: Guard status handler not available yet."
            );

            return false;

        }


        /*
         * ----------------------------------------------------
         * Preserve original handler
         * ----------------------------------------------------
         */

        const originalHandler =
            guard.handleStatusChange;


        this.state.autoBridge.originalHandler =
            originalHandler;


        const lockEngine =
            this;


        /*
         * ----------------------------------------------------
         * Create protected bridge
         * ----------------------------------------------------
         */

        guard.handleStatusChange =
            async function (...args) {

                /*
                 * First let the existing Guard
                 * perform its own complete logic.
                 */

                const result =
                    await originalHandler.apply(
                        this,
                        args
                    );


                /*
                 * Then synchronize the
                 * Account Lock engine.
                 */

                try {

                    lockEngine.syncLockFromGuard();

                } catch (error) {

                    console.error(
                        "BK OWNER ACCOUNT LOCK: Automatic bridge sync failed.",
                        error
                    );

                }


                return result;

            };


        /*
         * ----------------------------------------------------
         * Mark bridge installed
         * ----------------------------------------------------
         */

        this.state.autoBridge.active =
            true;


        console.log(
            "=========================================="
        );

        console.log(
            "BK OWNER ACCOUNT LOCK: AUTOMATIC BRIDGE INSTALLED."
        );

        console.log(
            "Guard → Account Lock: CONNECTED"
        );

        console.log(
            "Duplicate Bridge Protection: ACTIVE"
        );

        console.log(
            "=========================================="
        );


        return true;

    };


/* ============================================================
   WAIT FOR GUARD + INSTALL BRIDGE
============================================================ */

BKOwnerAccountLock.startAutoBridge =
    function () {

        const lockEngine =
            this;


        let attempts = 0;

        const maxAttempts = 100;


        function connect() {

            attempts++;


            const guard =
                window.BKOwnerAccountGuard;


            if (
                guard &&
                guard.state &&
                guard.state.ready === true
            ) {

                /*
                 * Initial synchronization
                 */

                lockEngine.syncLockFromGuard();


                /*
                 * Install automatic bridge
                 */

                lockEngine.installGuardBridge();


                /*
                 * Final state
                 */

                lockEngine.state.autoBridge.initialized =
                    true;


                console.log(
                    "BK OWNER ACCOUNT LOCK: PART 5 AUTO BRIDGE READY."
                );


                return;

            }


            if (
                attempts >= maxAttempts
            ) {

                console.warn(
                    "BK OWNER ACCOUNT LOCK: Guard connection timeout."
                );

                return;

            }


            setTimeout(
                connect,
                100
            );

        }


        connect();

    };


/* ============================================================
   PART 5 STARTUP
============================================================ */

BKOwnerAccountLock.startAutoBridge();


/* ============================================================
   PART 5 COMPLETE
============================================================ */

console.log(
    "BK OWNER ACCOUNT LOCK: PART 5 LOADED."
);

console.log(
    "Automatic Guard → Lock Connection: READY"
);

/* ============================================================
   BK OWNER ACCOUNT LOCK
   PART 6 — GLOBAL DASHBOARD ENFORCEMENT
============================================================ */


/* ============================================================
   PART 6 STATE
============================================================ */

BKOwnerAccountLock.state.enforcement = {

    initialized: false,

    active: false,

    lastAppliedStatus: null,

    lastAppliedAt: null,

    shieldElement: null

};


/* ============================================================
   CREATE GLOBAL ENFORCEMENT SHIELD
============================================================ */

BKOwnerAccountLock.createEnforcementShield =
    function () {

        /*
         * Prevent duplicate shield
         */

        const existing =
            document.getElementById(
                "bkOwnerDashboardEnforcementShield"
            );


        if (existing) {

            this.state.enforcement.shieldElement =
                existing;

            return existing;

        }


        /*
         * Create shield
         */

        const shield =
            document.createElement("div");


        shield.id =
            "bkOwnerDashboardEnforcementShield";


        shield.className =
            "bk-owner-dashboard-enforcement-shield";


        shield.setAttribute(
            "aria-hidden",
            "true"
        );


        /*
         * Important:
         * This shield does NOT contain the
         * Account Control modal.
         *
         * The existing Account Control UI
         * remains a separate layer.
         */

        document.body.appendChild(
            shield
        );


        this.state.enforcement.shieldElement =
            shield;


        console.log(
            "BK OWNER ACCOUNT LOCK: GLOBAL ENFORCEMENT SHIELD CREATED."
        );


        return shield;

    };


/* ============================================================
   SHOW ENFORCEMENT SHIELD
============================================================ */

BKOwnerAccountLock.activateEnforcement =
    function () {

        const shield =
            this.createEnforcementShield();


        if (!shield) {

            return false;

        }


        /*
         * Make shield active
         */

        shield.classList.add(
            "is-active"
        );


        shield.setAttribute(
            "aria-hidden",
            "false"
        );


        /*
         * Record state
         */

        this.state.enforcement.active =
            true;


        this.state.enforcement.lastAppliedStatus =
            this.state.accountStatus;


        this.state.enforcement.lastAppliedAt =
            new Date();


        console.log(
            "BK OWNER ACCOUNT LOCK: GLOBAL DASHBOARD ENFORCEMENT ACTIVE."
        );


        return true;

    };


/* ============================================================
   REMOVE ENFORCEMENT SHIELD
============================================================ */

BKOwnerAccountLock.deactivateEnforcement =
    function () {

        const shield =
            this.state.enforcement.shieldElement;


        if (!shield) {

            return false;

        }


        shield.classList.remove(
            "is-active"
        );


        shield.setAttribute(
            "aria-hidden",
            "true"
        );


        /*
         * Record state
         */

        this.state.enforcement.active =
            false;


        this.state.enforcement.lastAppliedStatus =
            this.state.accountStatus;


        this.state.enforcement.lastAppliedAt =
            new Date();


        console.log(
            "BK OWNER ACCOUNT LOCK: GLOBAL DASHBOARD ENFORCEMENT REMOVED."
        );


        return true;

    };


/* ============================================================
   APPLY GLOBAL ENFORCEMENT
============================================================ */

BKOwnerAccountLock.applyGlobalEnforcement =
    function () {

        /*
         * ----------------------------------------------------
         * Controlled account
         * ----------------------------------------------------
         */

        if (
            this.state.locked === true
        ) {

            this.activateEnforcement();

            return true;

        }


        /*
         * ----------------------------------------------------
         * Active account
         * ----------------------------------------------------
         */

        this.deactivateEnforcement();

        return true;

    };


/* ============================================================
   ENFORCEMENT STATUS
============================================================ */

BKOwnerAccountLock.isEnforcementActive =
    function () {

        return (
            this.state.enforcement.active === true
        );

    };


BKOwnerAccountLock.getEnforcementState =
    function () {

        return {
            ...this.state.enforcement
        };

    };


/* ============================================================
   CONNECT ENFORCEMENT TO LOCK STATE
============================================================ */

BKOwnerAccountLock.refreshGlobalEnforcement =
    function () {

        return this.applyGlobalEnforcement();

    };


/* ============================================================
   WRAP LOCK UI REFRESH
============================================================ */

if (
    !BKOwnerAccountLock.__part6RefreshWrapped
) {

    const originalRefreshLockUI =
        BKOwnerAccountLock.refreshLockUI;


    BKOwnerAccountLock.refreshLockUI =
        function () {

            const result =
                originalRefreshLockUI.call(
                    this
                );


            try {

                this.refreshGlobalEnforcement();

            } catch (error) {

                console.error(
                    "BK OWNER ACCOUNT LOCK: Global enforcement refresh failed.",
                    error
                );

            }


            return result;

        };


    BKOwnerAccountLock.__part6RefreshWrapped =
        true;

}


/* ============================================================
   INITIALIZE PART 6
============================================================ */

BKOwnerAccountLock.createEnforcementShield();


BKOwnerAccountLock.refreshGlobalEnforcement();


BKOwnerAccountLock.state.enforcement.initialized =
    true;


/* ============================================================
   PART 6 COMPLETE
============================================================ */

console.log(
    "=========================================="
);

console.log(
    "BK OWNER ACCOUNT LOCK: PART 6 READY."
);

console.log(
    "Global Enforcement Shield: READY"
);

console.log(
    "Controlled Account Enforcement: READY"
);

console.log(
    "Active Account Release: READY"
);

console.log(
    "Duplicate Shield Protection: ACTIVE"
);

console.log(
    "=========================================="
);

/* =====================================================
   PART 7 — MASTER CONTROL → OWNER REASON BRIDGE
   BK OWNER ACCOUNT LOCK
   -----------------------------------------------------
   Purpose:
   1. Master action read karna
   2. Master reason read karna
   3. Master reason Owner ko dikhana
   4. Master reason immutable rakhna
   5. Owner response se separate rakhna
   6. Guard ready hone ke baad automatic sync
====================================================== */

(() => {

    "use strict";


    /* =================================================
       1. MASTER REASON BRIDGE STATE
    ================================================= */

    BKOwnerAccountLock.state.masterReasonBridge = {

        initialized: false,

        active: false,

        masterAction: "NONE",

        masterReason: null,

        masterActionAt: null,

        lastSyncedAt: null

    };


    /* =================================================
       2. READ MASTER CONTROL FROM OWNER GUARD
    ================================================= */

function readMasterControlFromGuard() {

    const guard =
        window.BKOwnerAccountGuard;

    if (
        !guard ||
        !guard.state
    ) {

        return {

            masterAction: "NONE",

            masterReason: null,

            masterActionAt: null

        };

    }


    const guardState =
        guard.state;


    /*
     * ----------------------------------------------------
     * PRIMARY SOURCE
     * BKOwnerAccountGuard Part 5
     * ----------------------------------------------------
     */

    const masterControl =
        guardState.masterControl;


    if (
        masterControl &&
        typeof masterControl === "object"
    ) {

        return {

            masterAction:
                masterControl.action ||
                "NONE",

            masterReason:
                masterControl.reason ||
                null,

            masterActionAt:
                masterControl.changedAt ||
                null

        };

    }


    /*
     * ----------------------------------------------------
     * FALLBACK
     * Keep compatibility with older Guard state.
     * ----------------------------------------------------
     */

    return {

        masterAction:
            guardState.masterAction ||
            "NONE",

        masterReason:
            guardState.masterActionReason ||
            null,

        masterActionAt:
            guardState.lastMasterActionAt ||
            null

    };

}

    /* =================================================
       3. SYNC MASTER CONTROL DATA
    ================================================= */

    function syncMasterControlData() {

        const masterControl =
            readMasterControlFromGuard();


        const bridge =
            BKOwnerAccountLock
                .state
                .masterReasonBridge;


        bridge.masterAction =
            masterControl.masterAction;


        bridge.masterReason =
            masterControl.masterReason;


        bridge.masterActionAt =
            masterControl.masterActionAt;


        bridge.lastSyncedAt =
            new Date();


        bridge.active =
            true;


        /* ---------------------------------------------
           Copy into main Lock state
           --------------------------------------------- */

        BKOwnerAccountLock.state.masterAction =
            masterControl.masterAction;


        BKOwnerAccountLock.state.masterReason =
            masterControl.masterReason;


        BKOwnerAccountLock.state.masterActionAt =
            masterControl.masterActionAt;


        return true;

    }


    /* =================================================
       4. OWNER-SAFE MASTER REASON
    ================================================= */

    BKOwnerAccountLock.getMasterReason =
        function () {

            const bridge =
                BKOwnerAccountLock
                    .state
                    .masterReasonBridge;


            if (
                !bridge ||
                !bridge.masterReason
            ) {

                return "No reason provided by BK Master.";

            }


            return String(
                bridge.masterReason
            );

        };


    /* =================================================
       5. MASTER CONTROL STATE API
    ================================================= */

    BKOwnerAccountLock.getMasterReasonState =
        function () {

            return {

                ...BKOwnerAccountLock
                    .state
                    .masterReasonBridge

            };

        };


    /* =================================================
       6. UPDATE MASTER REASON UI
    ================================================= */

    function renderMasterReason() {

        const reasonElement =
            document.getElementById(
                "bkOwnerGlobalLockReason"
            );


        if (!reasonElement) {

            return false;

        }


        reasonElement.textContent =
            BKOwnerAccountLock.getMasterReason();


        return true;

    }


    /* =================================================
       7. REFRESH LOCK UI BRIDGE
    ================================================= */

    const originalRefreshLockUI =
        BKOwnerAccountLock.refreshLockUI;


    if (
        typeof originalRefreshLockUI ===
            "function" &&

        !originalRefreshLockUI
            .__part7ReasonWrapped
    ) {


        function wrappedRefreshLockUI() {

            /* -----------------------------------------
               First sync latest Master information
            ----------------------------------------- */

            syncMasterControlData();


            /* -----------------------------------------
               Run original Lock UI renderer
            ----------------------------------------- */

            const result =
                originalRefreshLockUI.apply(
                    BKOwnerAccountLock,
                    arguments
                );


            /* -----------------------------------------
               Then render Master reason
            ----------------------------------------- */

            renderMasterReason();


            return result;

        }


        wrappedRefreshLockUI
            .__part7ReasonWrapped = true;


        BKOwnerAccountLock.refreshLockUI =
            wrappedRefreshLockUI;

    }


    /* =================================================
       8. DIRECT MASTER DATA REFRESH API
    ================================================= */

    BKOwnerAccountLock
        .refreshMasterReason =
        function () {

            const synced =
                syncMasterControlData();


            renderMasterReason();


            return synced;

        };


    /* =================================================
       9. WAIT FOR OWNER GUARD
       -------------------------------------------------
       Important:
       Guard Firebase/Auth ke baad ready hota hai.
       Isliye initial "NONE" ko final state
       nahi maana jayega.
    ================================================= */

    function waitForGuardAndSync(
        attempt = 0
    ) {

        const guard =
            window.BKOwnerAccountGuard;


        if (
            guard &&
            guard.state &&
            guard.state.ready === true
        ) {

            syncMasterControlData();

            renderMasterReason();


            console.log(
                "BK OWNER ACCOUNT LOCK: MASTER REASON SYNC COMPLETE."
            );


            console.log(
                "Master Action:",
                BKOwnerAccountLock
                    .state
                    .masterAction
            );


            console.log(
                "Master Reason:",
                BKOwnerAccountLock
                    .getMasterReason()
            );


            console.log(
                "Master Action At:",
                BKOwnerAccountLock
                    .state
                    .masterActionAt ||
                    "NONE"
            );


            return;

        }


        /* ---------------------------------------------
           Retry
           --------------------------------------------- */

        if (
            attempt >= 100
        ) {

            console.warn(
                "BK OWNER ACCOUNT LOCK: MASTER REASON SYNC TIMEOUT."
            );

            return;

        }


        setTimeout(
            () => {

                waitForGuardAndSync(
                    attempt + 1
                );

            },
            100
        );

    }


    /* =================================================
       10. INITIALIZE
    ================================================= */

    waitForGuardAndSync();


    /* =================================================
       11. READY
    ================================================= */

    BKOwnerAccountLock
        .state
        .masterReasonBridge
        .initialized = true;


    console.log(
        "=========================================="
    );

    console.log(
        "BK OWNER ACCOUNT LOCK: PART 7 MASTER REASON BRIDGE READY."
    );

    console.log(
        "Master Reason → Owner UI: READY"
    );

    console.log(
        "Master Reason Preservation: READY"
    );

    console.log(
        "Owner Response Separation: READY"
    );

    console.log(
        "Guard Synchronization: READY"
    );

    console.log(
        "=========================================="
    );

})();

/* =====================================================
   PART 8 — OWNER ACTIVATION REQUEST ENGINE
   BK OWNER ACCOUNT LOCK
====================================================== */

(() => {

    "use strict";


    /* -------------------------------------------------
       1. REQUEST STATE
    ------------------------------------------------- */

    BKOwnerAccountLock.state.activationRequest = {

        initialized: true,

        submitting: false,

        lastRequestId: null,

        lastSubmittedAt: null,

        lastError: null,

        status: "NONE"

    };


    /* -------------------------------------------------
       2. FIRESTORE COLLECTION
    ------------------------------------------------- */

    const REQUEST_COLLECTION =
        "accountControlRequests";


    /* -------------------------------------------------
       3. REQUEST VALIDATION
    ------------------------------------------------- */

    function validateOwnerReason(reason) {

        if (
            typeof reason !== "string"
        ) {

            return {

                valid: false,

                message:
                    "Please enter a valid reason."

            };

        }


        const cleanedReason =
            reason.trim();


        if (!cleanedReason) {

            return {

                valid: false,

                message:
                    "Please enter your reason."

            };

        }


        if (
            cleanedReason.length < 5
        ) {

            return {

                valid: false,

                message:
                    "Please provide a little more detail."

            };

        }


        if (
            cleanedReason.length > 1000
        ) {

            return {

                valid: false,

                message:
                    "Reason cannot exceed 1000 characters."

            };

        }


        return {

            valid: true,

            reason: cleanedReason

        };

    }


    /* -------------------------------------------------
       4. SUBMIT ACTIVATION REQUEST
    ------------------------------------------------- */

    BKOwnerAccountLock.submitActivationRequest =
        async function (ownerReason) {

            const requestState =
                BKOwnerAccountLock
                    .state
                    .activationRequest;


            /* -----------------------------------------
               PREVENT DUPLICATE SUBMISSION
            ----------------------------------------- */

            if (
                requestState.submitting
            ) {

                return {

                    success: false,

                    error:
                        "REQUEST_ALREADY_SUBMITTING"

                };

            }


            /* -----------------------------------------
               OWNER AUTHENTICATION
            ----------------------------------------- */

            const user = window.BKOwner?.state?.currentUser || null;


            if (!user) {

                requestState.lastError =
                    "OWNER_NOT_AUTHENTICATED";


                return {

                    success: false,

                    error:
                        "OWNER_NOT_AUTHENTICATED"

                };

            }


            /* -----------------------------------------
               RESTAURANT CONTEXT
            ----------------------------------------- */

            const restaurantId =
                BKOwnerAccountLock
                    .state
                    .restaurantId;


            if (!restaurantId) {

                requestState.lastError =
                    "RESTAURANT_ID_NOT_READY";


                return {

                    success: false,

                    error:
                        "RESTAURANT_ID_NOT_READY"

                };

            }


            /* -----------------------------------------
               ACCOUNT STATUS
            ----------------------------------------- */

            const accountStatus =
                BKOwnerAccountLock
                    .state
                    .accountStatus;


            if (
                accountStatus === "ACTIVE"
            ) {

                requestState.lastError =
                    "ACCOUNT_ALREADY_ACTIVE";


                return {

                    success: false,

                    error:
                        "ACCOUNT_ALREADY_ACTIVE"

                };

            }


            /* -----------------------------------------
               VALIDATE OWNER REASON
            ----------------------------------------- */

            const validation =
                validateOwnerReason(
                    ownerReason
                );


            if (
                !validation.valid
            ) {

                requestState.lastError =
                    validation.message;


                return {

                    success: false,

                    error:
                        validation.message

                };

            }


            requestState.submitting =
                true;


            requestState.status =
                "SUBMITTING";


            requestState.lastError =
                null;


            try {
                
        const db =
    window.BKOwner?.firebase?.db;

if (!db) {
    throw new Error(
        "BK FIREBASE DB BRIDGE NOT AVAILABLE"
    );
}        


const {
    addDoc,
    collection,
    serverTimestamp
} = await import(
    "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js"
);
                /* -------------------------------------
                   MASTER CONTROL PRESERVATION
                ------------------------------------- */

                const masterAction =
                    BKOwnerAccountLock
                        .state
                        .masterAction ||
                    "NONE";


                const masterReason =
                    BKOwnerAccountLock
                        .state
                        .masterReason ||
                    null;


                const masterActionAt =
                    BKOwnerAccountLock
                        .state
                        .masterActionAt ||
                    null;


                /* -------------------------------------
                   REQUEST DATA
                ------------------------------------- */

                const requestData = {

                    restaurantId:
                        restaurantId,

                    ownerId:
                        user.uid,

                    requestType:
                        "ACTIVATION",

                    status:
                        "PENDING",


                    /* -------------------------------
                       OWNER RESPONSE
                    -------------------------------- */

                    ownerReason:
                        validation.reason,


                    /* -------------------------------
                       MASTER CONTROL SNAPSHOT
                       OWNER CANNOT MODIFY
                    -------------------------------- */

                    masterAction:
                        masterAction,

                    masterReason:
                        masterReason,

                    masterActionAt:
                        masterActionAt,


                    /* -------------------------------
                       ACCOUNT SNAPSHOT
                    -------------------------------- */

                    accountStatus:
                        accountStatus,


                    /* -------------------------------
                       REVIEW STATE
                    -------------------------------- */

                    createdAt: serverTimestamp(),

                    reviewedAt:
                        null,

                    reviewedBy:
                        null,

                    masterResponse:
                        null

                };


                /* -------------------------------------
                   FIRESTORE WRITE
                ------------------------------------- */

                const requestRef =
                    await addDoc(

                        collection(
                            db,
                            REQUEST_COLLECTION
                        ),

                        requestData

                    );


                /* -------------------------------------
                   UPDATE LOCAL STATE
                ------------------------------------- */

                requestState.submitting =
                    false;


                requestState.status =
                    "PENDING";


                requestState.lastRequestId =
                    requestRef.id;


                requestState.lastSubmittedAt =
                    new Date();


                requestState.lastError =
                    null;


                /* -------------------------------------
                   SUCCESS LOG
                ------------------------------------- */

                console.log(
                    "=========================================="
                );

                console.log(
                    "BK OWNER ACCOUNT LOCK: ACTIVATION REQUEST SUBMITTED."
                );

                console.log(
                    "Request ID:",
                    requestRef.id
                );

                console.log(
                    "Restaurant ID:",
                    restaurantId
                );

                console.log(
                    "Owner ID:",
                    user.uid
                );

                console.log(
                    "Request Type:",
                    "ACTIVATION"
                );

                console.log(
                    "Status:",
                    "PENDING"
                );

                console.log(
                    "Master Reason Preserved:",
                    masterReason ||
                    "NONE"
                );

                console.log(
                    "Owner Reason Saved:",
                    validation.reason
                );

                console.log(
                    "=========================================="
                );


                return {

                    success: true,

                    requestId:
                        requestRef.id,

                    status:
                        "PENDING"

                };


            } catch (error) {

                /* -------------------------------------
                   FIRESTORE ERROR
                ------------------------------------- */

                console.error(
                    "BK OWNER ACCOUNT LOCK: ACTIVATION REQUEST FAILED.",
                    error
                );


                requestState.submitting =
                    false;


                requestState.status =
                    "ERROR";


                requestState.lastError =
                    error?.message ||
                    "REQUEST_FAILED";


                return {

                    success: false,

                    error:
                        error?.message ||
                        "REQUEST_FAILED"

                };

            }

        };


    /* -------------------------------------------------
       5. REQUEST STATE API
    ------------------------------------------------- */

    BKOwnerAccountLock
        .getActivationRequestState =
        function () {

            return {

                ...BKOwnerAccountLock
                    .state
                    .activationRequest

            };

        };


    /* -------------------------------------------------
       6. ENGINE READY
    ------------------------------------------------- */

    console.log(
        "=========================================="
    );

    console.log(
        "BK OWNER ACCOUNT LOCK: PART 8 READY."
    );

    console.log(
        "Activation Request Engine: READY"
    );

    console.log(
        "Firestore Connection: READY"
    );

    console.log(
        "Request Collection:",
        REQUEST_COLLECTION
    );

    console.log(
        "Master Reason Preservation: READY"
    );

    console.log(
        "Owner Reason Separation: READY"
    );

    console.log(
        "=========================================="
    );

})();

/* =====================================================
   PART 8-B — OWNER ACTIVATION REQUEST UI
   BK OWNER ACCOUNT LOCK
   PRODUCTION VERSION
====================================================== */

(() => {

    "use strict";


    /* -------------------------------------------------
       1. UI STATE
    ------------------------------------------------- */

    BKOwnerAccountLock.state.activationRequestUI = {

        initialized: false,

        visible: false,

        submitting: false,

        lastMessage: null

    };


    /* -------------------------------------------------
       2. CREATE REQUEST UI
    ------------------------------------------------- */

    function createActivationRequestUI() {

        const lockPanel =
            document.querySelector(
                ".bk-owner-global-lock-panel"
            );


        if (!lockPanel) {

            return false;

        }


        /* ---------------------------------------------
           Duplicate protection
        --------------------------------------------- */

        if (
            document.getElementById(
                "bkOwnerActivationRequestSection"
            )
        ) {

            return true;

        }


        const section =
            document.createElement("div");


        section.id =
            "bkOwnerActivationRequestSection";


        section.className =
            "bk-owner-activation-request";


        section.innerHTML = `

            <div class="bk-owner-activation-divider"></div>

            <div class="bk-owner-activation-header">

                <span class="bk-owner-global-lock-label">
                    ACTIVATION REQUEST
                </span>

                <h3>
                    Request Account Activation
                </h3>

                <p>
                    Send your response to BK Master for review.
                </p>

            </div>


            <div class="bk-owner-activation-field">

                <label
                    for="bkOwnerActivationReason"
                >
                    YOUR RESPONSE
                </label>

                <textarea
                    id="bkOwnerActivationReason"
                    class="bk-owner-activation-textarea"
                    maxlength="1000"
                    rows="4"
                    placeholder="Explain why your account should be activated..."
                ></textarea>

                <div
                    id="bkOwnerActivationCounter"
                    class="bk-owner-activation-counter"
                >
                    0 / 1000
                </div>

            </div>


            <div
                id="bkOwnerActivationMessage"
                class="bk-owner-activation-message"
                aria-live="polite"
            ></div>


            <button
                id="bkOwnerActivationSubmitButton"
                type="button"
                class="bk-owner-global-lock-button primary bk-owner-activation-submit"
            >
                Request Activation
            </button>

        `;


        const actions =
            lockPanel.querySelector(
                ".bk-owner-global-lock-actions"
            );


        if (actions) {

            lockPanel.insertBefore(
                section,
                actions
            );

        } else {

            lockPanel.appendChild(
                section
            );

        }


        return true;

    }


    /* -------------------------------------------------
       3. CACHE UI ELEMENTS
    ------------------------------------------------- */

    function cacheActivationRequestUI() {

        const state =
            BKOwnerAccountLock
                .state
                .activationRequestUI;


        state.section =
            document.getElementById(
                "bkOwnerActivationRequestSection"
            );


        state.reasonInput =
            document.getElementById(
                "bkOwnerActivationReason"
            );


        state.counter =
            document.getElementById(
                "bkOwnerActivationCounter"
            );


        state.message =
            document.getElementById(
                "bkOwnerActivationMessage"
            );


        state.submitButton =
            document.getElementById(
                "bkOwnerActivationSubmitButton"
            );

    }


    /* -------------------------------------------------
       4. UPDATE CHARACTER COUNTER
    ------------------------------------------------- */

    function updateCharacterCounter() {

        const state =
            BKOwnerAccountLock
                .state
                .activationRequestUI;


        if (
            !state.reasonInput ||
            !state.counter
        ) {

            return;

        }


        const length =
            state.reasonInput.value.length;


        state.counter.textContent =
            `${length} / 1000`;

    }


    /* -------------------------------------------------
       5. SET MESSAGE
    ------------------------------------------------- */

    function setActivationMessage(
        message,
        type = "normal"
    ) {

        const state =
            BKOwnerAccountLock
                .state
                .activationRequestUI;


        if (!state.message) {

            return;

        }


        state.message.textContent =
            message || "";


        state.message.dataset.type =
            type;

    }


    /* -------------------------------------------------
       6. SUBMIT BUTTON STATE
    ------------------------------------------------- */

    function setSubmittingState(
        submitting
    ) {

        const state =
            BKOwnerAccountLock
                .state
                .activationRequestUI;


        if (!state.submitButton) {

            return;

        }


        state.submitting =
            submitting;


        if (submitting) {

            state.submitButton.disabled =
                true;

            state.submitButton.textContent =
                "Submitting Request...";

        } else {

            state.submitButton.disabled =
                false;

            state.submitButton.textContent =
                "Request Activation";

        }

    }


    /* -------------------------------------------------
       7. USER-FRIENDLY ERROR MESSAGE
    ------------------------------------------------- */

    function getFriendlyRequestError(
        error
    ) {

        const errorCode =
            String(
                error?.error ||
                error?.code ||
                ""
            ).toUpperCase();


        const errorMessage =
            String(
                error?.message ||
                ""
            ).toLowerCase();


        if (
            errorCode.includes(
                "REQUEST_ALREADY_SUBMITTING"
            )
        ) {

            return (
                "Your activation request is already being submitted."
            );

        }


        if (
            errorCode.includes(
                "INVALID_REASON"
            )
        ) {

            return (
                "Please enter a valid response before submitting."
            );

        }


        if (
            errorCode.includes(
                "USER_NOT_AUTHENTICATED"
            )
        ) {

            return (
                "Your session has expired. Please sign in again."
            );

        }


        if (
            errorCode.includes(
                "RESTAURANT_ID_MISSING"
            )
        ) {

            return (
                "We could not identify your restaurant account. Please try again."
            );

        }


        if (
            errorCode.includes(
                "ACCOUNT_ALREADY_ACTIVE"
            )
        ) {

            return (
                "Your account is already active."
            );

        }


        if (
            errorMessage.includes(
                "permission"
            )
        ) {

            return (
                "Your request could not be submitted. Please try again."
            );

        }


        if (
            errorMessage.includes(
                "network"
            ) ||
            errorMessage.includes(
                "offline"
            )
        ) {

            return (
                "Connection problem. Please check your internet and try again."
            );

        }


        return (
            "We could not submit your request right now. Please try again."
        );

    }


    /* -------------------------------------------------
       8. SUBMIT HANDLER
    ------------------------------------------------- */

    async function handleActivationRequest() {

        const state =
            BKOwnerAccountLock
                .state
                .activationRequestUI;


        if (state.submitting) {

            return;

        }


        if (
            typeof BKOwnerAccountLock
                .submitActivationRequest !==
            "function"
        ) {

            setActivationMessage(
                "Activation service is temporarily unavailable. Please try again.",
                "error"
            );

            state.lastMessage =
                "REQUEST_ENGINE_UNAVAILABLE";

            return;

        }


        const reason =
            state.reasonInput
                ? state.reasonInput.value
                : "";


        setSubmittingState(true);


        setActivationMessage(
            "Submitting your activation request...",
            "normal"
        );


        try {

            const result =
                await BKOwnerAccountLock
                    .submitActivationRequest(
                        reason
                    );


            if (
                result &&
                result.success
            ) {

                /*
                 * Clear response field
                 */

                if (state.reasonInput) {

                    state.reasonInput.value =
                        "";

                }


                updateCharacterCounter();


                setSubmittingState(false);


                setActivationMessage(
                    "Your activation request has been submitted successfully. BK Master Control will review it.",
                    "success"
                );


                state.lastMessage =
                    "REQUEST_SUBMITTED";


                return;

            }


            /*
             * Request engine returned a controlled error.
             */

            setSubmittingState(false);


            setActivationMessage(
                getFriendlyRequestError(
                    result
                ),
                "error"
            );


            state.lastMessage =
                "REQUEST_FAILED";


        } catch (error) {

            setSubmittingState(false);


            setActivationMessage(
                getFriendlyRequestError(
                    error
                ),
                "error"
            );


            state.lastMessage =
                "REQUEST_ERROR";

        }

    }


    /* -------------------------------------------------
       9. BIND EVENTS
    ------------------------------------------------- */

    function bindActivationRequestEvents() {

        const state =
            BKOwnerAccountLock
                .state
                .activationRequestUI;


        if (!state.reasonInput) {

            return;

        }


        if (
            !state.reasonInput.__bkActivationBound
        ) {

            state.reasonInput.addEventListener(
                "input",
                updateCharacterCounter
            );


            state.reasonInput.__bkActivationBound =
                true;

        }


        if (
            state.submitButton &&
            !state.submitButton.__bkActivationBound
        ) {

            state.submitButton.addEventListener(
                "click",
                handleActivationRequest
            );


            state.submitButton.__bkActivationBound =
                true;

        }

    }


    /* -------------------------------------------------
       10. START UI
    ------------------------------------------------- */

    function startActivationRequestUI() {

        const created =
            createActivationRequestUI();


        if (!created) {

            setTimeout(
                startActivationRequestUI,
                250
            );

            return;

        }


        cacheActivationRequestUI();

        bindActivationRequestEvents();

        updateCharacterCounter();


        BKOwnerAccountLock
            .state
            .activationRequestUI
            .initialized = true;


        console.log(
            "BK OWNER ACCOUNT LOCK: ACTIVATION REQUEST UI READY."
        );

    }


    /* -------------------------------------------------
       11. PUBLIC UI API
    ------------------------------------------------- */

    BKOwnerAccountLock
        .getActivationRequestUIState =
        function () {

            return {

                initialized:
                    BKOwnerAccountLock
                        .state
                        .activationRequestUI
                        .initialized,

                visible:
                    BKOwnerAccountLock
                        .state
                        .activationRequestUI
                        .visible,

                submitting:
                    BKOwnerAccountLock
                        .state
                        .activationRequestUI
                        .submitting,

                lastMessage:
                    BKOwnerAccountLock
                        .state
                        .activationRequestUI
                        .lastMessage

            };

        };


    /* -------------------------------------------------
       12. DOM START
    ------------------------------------------------- */

    if (
        document.readyState ===
        "loading"
    ) {

        document.addEventListener(
            "DOMContentLoaded",
            startActivationRequestUI,
            {
                once: true
            }
        );

    } else {

        startActivationRequestUI();

    }

})();