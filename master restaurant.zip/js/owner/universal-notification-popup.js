
/* ============================================================
   BK UNIVERSAL OWNER NOTIFICATION SYSTEM
   Independent Module — Step 1
   Purpose: Safe integration check
============================================================ */

"use strict";

import {
    ownerAuth as auth,
    ownerDb as db
} from "../firebase-sessions.js";

import {
    onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-auth.js";

import {
    collection,
    doc,
    query,
    where,
    getDocs,
    updateDoc,
    onSnapshot
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-firestore.js";

/* ============================================================
   MODULE INITIALIZATION
============================================================ */

const BKUniversalOwnerNotifications = {

state: {
    initialized: false,
    currentUser: null,
    popupReady: false,
    noticeQueue: [],
    currentNotice: null,
    popupBound: false,
    dismissedUntilOverview: false,
    loadingNotices: false,
    noticeUnsubscribe: null
},    
        loadOwnerNotices: async function () {

        const user = this.state.currentUser;

        if (!user) {
            console.warn(
                "BK UNIVERSAL NOTIFICATIONS: OWNER SESSION NOT AVAILABLE."
            );
            return [];
        }

        try {

            const noticesRef = collection(db, "notices");

            const noticesQuery = query(
                noticesRef,
                where("ownerId", "==", user.uid)
            );

            const snapshot = await getDocs(noticesQuery);
const unreadNotices = snapshot.docs
    .map((noticeDoc) => ({
        id: noticeDoc.id,
        ...noticeDoc.data()
    }))
    .filter((notice) => notice.read === false)
    .sort((a, b) => {
        const aTime = a.createdAt?.toMillis?.() || 0;
        const bTime = b.createdAt?.toMillis?.() || 0;

        return aTime - bTime;
    });

this.state.noticeQueue = unreadNotices;

console.log(
    "BK UNIVERSAL NOTIFICATIONS: UNREAD NOTICES LOADED.",
    unreadNotices.length
);

return unreadNotices;


        } catch (error) {

            console.error(
                "BK UNIVERSAL NOTIFICATIONS: NOTICE READ FAILED.",
                error
            );

            return [];

        }

    },

/* ============================================================
   REALTIME OWNER NOTICE LISTENER
============================================================ */

startNoticeListener: function () {

    if (!this.state.currentUser) {
        return;
    }

    // Prevent duplicate listeners
    if (this.state.noticeUnsubscribe) {
        return;
    }

    const noticesQuery = query(
        collection(db, "notices"),
        where(
            "ownerId",
            "==",
            this.state.currentUser.uid
        )
    );

    this.state.noticeUnsubscribe = onSnapshot(
        noticesQuery,

        (snapshot) => {

            const unreadNotices = snapshot.docs
                .map((noticeDoc) => ({
                    id: noticeDoc.id,
                    ...noticeDoc.data()
                }))
                .filter((notice) => notice.read === false)
                .sort((a, b) => {

                    const timeA = a.createdAt?.toMillis
                        ? a.createdAt.toMillis()
                        : 0;

                    const timeB = b.createdAt?.toMillis
                        ? b.createdAt.toMillis()
                        : 0;

                    return timeA - timeB;
                });

            const currentId =
                this.state.currentNotice?.id;

            this.state.noticeQueue = unreadNotices;

            if (currentId) {

                const updatedCurrent =
                    unreadNotices.find(
                        (notice) => notice.id === currentId
                    );

                if (updatedCurrent) {

                    this.state.currentNotice =
                        updatedCurrent;

                } else {

                    this.state.currentNotice = null;

                    const backdrop = document.getElementById(
                        "bkUniversalNotificationBackdrop"
                    );

                    if (backdrop) {
                        backdrop.hidden = true;
                    }

                }

            }

            const isOverviewOpen =
                window.BKOwner &&
                BKOwner.state.currentSection === "overview";

            if (
                isOverviewOpen &&
                !this.state.dismissedUntilOverview &&
                !this.state.currentNotice
            ) {

                this.showNextNotice();

            }

            console.log(
                "BK UNIVERSAL NOTIFICATIONS: REALTIME UPDATE.",
                unreadNotices.length
            );

        },

        (error) => {

            console.error(
                "BK UNIVERSAL NOTIFICATIONS: REALTIME LISTENER ERROR.",
                error
            );

        }
    );

    console.log(
        "BK UNIVERSAL NOTIFICATIONS: REALTIME LISTENER STARTED."
    );

},


    init: function () {

        if (this.state.initialized) {
            return;
        }

        this.state.initialized = true;

        console.log(
            "BK UNIVERSAL NOTIFICATIONS: MODULE LOADED."
        );

        if (this.checkPopupElements()) {
    this.bindPopupButtons();
}

        onAuthStateChanged(
            auth,
            (user) => {

                if (!user) {
                    this.state.currentUser = null;

                    console.log(
                        "BK UNIVERSAL NOTIFICATIONS: Waiting for owner session."
                    );

                    return;
                }

                this.state.currentUser = user;
            
            this.startNoticeListener();    
                
                this.onOverviewOpened();

                console.log(
                    "BK UNIVERSAL NOTIFICATIONS: OWNER SESSION DETECTED.",
                    user.uid
                );

            }
        );

    },

    checkPopupElements: function () {

        const requiredElements = [
            "bkUniversalNotificationBackdrop",
            "bkUniversalNotificationDialog",
            "bkUniversalNotificationType",
            "bkUniversalNotificationTitle",
            "bkUniversalNotificationMessage",
            "bkUniversalNotificationDetails",
            "bkUniversalNotificationCancel",
            "bkUniversalNotificationOkay"
        ];

        const missingElements =
            requiredElements.filter(
                (id) => !document.getElementById(id)
            );

        if (missingElements.length > 0) {

            console.error(
                "BK UNIVERSAL NOTIFICATIONS: REQUIRED HTML ELEMENTS MISSING.",
                missingElements
            );

            return false;
        }

        this.state.popupReady = true;

        console.log(
            "BK UNIVERSAL NOTIFICATIONS: POPUP HTML CHECK PASS."
        );

        return true;

    },
    
        /* ============================================================
       SHOW NEXT OWNER NOTIFICATION
    ============================================================ */

    showNextNotice: function () {

        if (!this.state.popupReady) {
            return;
        }

        if (this.state.dismissedUntilOverview) {
            return;
        }

        if (this.state.currentNotice) {
            return;
        }

        const notice =
            this.state.noticeQueue[0];

        if (!notice) {
            return;
        }

        const backdrop =
            document.getElementById(
                "bkUniversalNotificationBackdrop"
            );

        const typeElement =
            document.getElementById(
                "bkUniversalNotificationType"
            );

        const titleElement =
            document.getElementById(
                "bkUniversalNotificationTitle"
            );

        const messageElement =
            document.getElementById(
                "bkUniversalNotificationMessage"
            );

        const detailsElement =
            document.getElementById(
                "bkUniversalNotificationDetails"
            );

        if (
            !backdrop ||
            !typeElement ||
            !titleElement ||
            !messageElement ||
            !detailsElement
        ) {
            console.error(
                "BK UNIVERSAL NOTIFICATIONS: POPUP ELEMENTS NOT AVAILABLE."
            );

            return;
        }

        this.state.currentNotice = notice;

        typeElement.textContent =
            String(notice.type || "GENERAL").toUpperCase();

        titleElement.textContent =
            notice.title || "BK Official Notice";

        messageElement.textContent =
            notice.message || "You have a new notification.";

        const detailLines = [];

        if (notice.billingMonth) {
            detailLines.push(
                "Billing Month: " + notice.billingMonth
            );
        }

        if (
            notice.amount !== undefined &&
            notice.amount !== null
        ) {
            detailLines.push(
                "Amount: " +
                (notice.currency || "INR") +
                " " +
                notice.amount
            );
        }

        if (notice.reason) {
            detailLines.push(
                "Reason: " + notice.reason
            );
        }

        if (
            typeof notice.details === "string" &&
            notice.details.trim()
        ) {
            detailLines.push(notice.details);
        }

        detailsElement.textContent =
            detailLines.join("\n");

        detailsElement.hidden =
            detailLines.length === 0;

        backdrop.hidden = false;

        console.log(
            "BK UNIVERSAL NOTIFICATIONS: NOTICE DISPLAYED.",
            notice.id
        );

    },
    
        /* ============================================================
       OVERVIEW OPENED — LOAD AND DISPLAY NOTICES
    ============================================================ */

    onOverviewOpened: async function () {

        if (
            !this.state.popupReady ||
            !this.state.currentUser
        ) {
            return;
        }

        if (
            window.BKOwner &&
            BKOwner.state.currentSection !== "overview"
        ) {
            return;
        }

        if (this.state.loadingNotices) {
            return;
        }

        this.state.dismissedUntilOverview = false;
        this.state.loadingNotices = true;

        try {

            await this.loadOwnerNotices();

            this.showNextNotice();

        } finally {

            this.state.loadingNotices = false;

        }

    },
    
        /* ============================================================
       BIND OKAY AND CANCEL BUTTONS
    ============================================================ */

    bindPopupButtons: function () {

        if (
            !this.state.popupReady ||
            this.state.popupBound
        ) {
            return;
        }

        const okayButton =
            document.getElementById(
                "bkUniversalNotificationOkay"
            );

        const cancelButton =
            document.getElementById(
                "bkUniversalNotificationCancel"
            );

        if (!okayButton || !cancelButton) {

            console.error(
                "BK UNIVERSAL NOTIFICATIONS: BUTTONS NOT FOUND."
            );

            return;
        }

        okayButton.addEventListener(
            "click",
            () => {
                this.markCurrentNoticeRead();
            }
        );

        cancelButton.addEventListener(
            "click",
            () => {

                this.state.dismissedUntilOverview = true;
                this.state.currentNotice = null;

                const backdrop =
                    document.getElementById(
                        "bkUniversalNotificationBackdrop"
                    );

                if (backdrop) {
                    backdrop.hidden = true;
                }

                console.log(
                    "BK UNIVERSAL NOTIFICATIONS: NOTICE DISMISSED TEMPORARILY."
                );

            }
        );

        this.state.popupBound = true;

        console.log(
            "BK UNIVERSAL NOTIFICATIONS: POPUP BUTTONS BOUND."
        );

    },
    
        /* ============================================================
       MARK CURRENT NOTICE AS READ
    ============================================================ */

    markCurrentNoticeRead: async function () {

        const notice = this.state.currentNotice;

        if (!notice || !notice.id) {
            return;
        }

        try {

            await updateDoc(
                doc(db, "notices", notice.id),
                {
                    read: true
                }
            );

            this.state.noticeQueue =
                this.state.noticeQueue.filter(
                    (item) => item.id !== notice.id
                );

            this.state.currentNotice = null;

            const backdrop =
                document.getElementById(
                    "bkUniversalNotificationBackdrop"
                );

            if (backdrop) {
                backdrop.hidden = true;
            }

            console.log(
                "BK UNIVERSAL NOTIFICATIONS: NOTICE MARKED AS READ.",
                notice.id
            );

            if (
                window.BKOwner &&
                BKOwner.state.currentSection === "overview" &&
                !this.state.dismissedUntilOverview
            ) {
                this.showNextNotice();
            }

        } catch (error) {

            console.error(
                "BK UNIVERSAL NOTIFICATIONS: MARK AS READ FAILED.",
                error
            );

        }

    },

};


/* ============================================================
   START MODULE
============================================================ */

BKUniversalOwnerNotifications.init();

window.BKUniversalOwnerNotifications =
    BKUniversalOwnerNotifications;
