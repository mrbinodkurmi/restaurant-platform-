"use strict";

/*
========================================================
BK OWNER — MONTHLY BILLING
VERSION 1.1.0
SAFE INITIALIZATION FOUNDATION
========================================================

Responsibilities:
1. Capture authenticated Owner context.
2. Validate Owner ID and Restaurant ID.
3. Support safe, retryable initialization.
4. Prepare current monthly billing state.
5. Avoid modifying subscription and Master controls.
6. Perform no Firestore writes in this version.

IMPORTANT:
This module does not automatically initialize on
DOMContentLoaded. Owner dashboard startup calls init()
after its Firebase context is ready.

========================================================
*/

const BKOwnerMonthlyBilling = {

    VERSION: "1.1.0",

    state: {
        initialized: false,
        ready: false,
        loading: false,
        error: null,

        currentUser: null,
        ownerId: null,
        restaurantId: null,

currentBill: null,
paymentStatus: "NOT_LOADED",

currentMonthlyPayment: null,
monthlyPaymentSubmissionStatus: "NOT_LOADED",

billingLockActive: false

    },

    /*
    ========================================================
    INITIALIZATION
    ========================================================
    */

    init() {

        /*
         * Do not repeat successful initialization
         * for the same Owner and Restaurant.
         */

        if (this.state.ready) {

            try {

                const context =
                    this.refreshOwnerContext();

                console.info(
                    "BK MONTHLY BILLING: ALREADY READY.",
                    {
                        restaurantId: context.restaurantId
                    }
                );

                return true;

            } catch (error) {

                /*
                 * Context may have changed or become
                 * unavailable. Allow a fresh attempt.
                 */

                this.reset();

            }

        }

        this.state.loading = true;
        this.state.error = null;

        try {

            /*
             * Read the existing Owner dashboard state.
             */

            const ownerState =
                window.BKOwner?.state;

            if (!ownerState) {

                throw new Error(
                    "BK Owner dashboard state is unavailable."
                );

            }

            const currentUser =
                ownerState.currentUser;

            const ownerId =
                String(
                    currentUser?.uid || ""
                ).trim();

            const restaurantId =
                String(
                    ownerState.restaurantId || ""
                ).trim();

            /*
             * Authentication must already be available.
             */

            if (!currentUser || !ownerId) {

                throw new Error(
                    "Authenticated Owner is not available."
                );

            }

            /*
             * Restaurant context is mandatory.
             */

            if (!restaurantId) {

                throw new Error(
                    "Restaurant ID is missing."
                );

            }

            /*
             * Capture the verified available context.
             *
             * This is a frontend context check only.
             * It does not replace server-side ownership
             * verification or Firestore Security Rules.
             */

            this.state.currentUser =
                currentUser;

            this.state.ownerId =
                ownerId;

            this.state.restaurantId =
                restaurantId;

            this.state.initialized = true;
            this.state.ready = true;
            this.state.loading = false;
            this.state.error = null;

/*
 * Load the current monthly bill after
 * authenticated Owner context is ready.
 */

Promise.resolve().then(async () => {

    if (
        typeof this.loadPremiumBillingUI !== "function"
    ) {
        console.warn(
            "BK MONTHLY BILLING: PREMIUM BILL LOADER NOT READY."
        );

        return;
    }

    const loaded =
        await this.loadPremiumBillingUI();

    console.info(
        "BK MONTHLY BILLING: INITIAL BILL LOAD RESULT.",
        { loaded }
    );

});


            console.info(
                "BK MONTHLY BILLING: FOUNDATION READY.",
                {
                    version: this.VERSION,
                    restaurantId: restaurantId,
                    ownerIdAvailable: Boolean(ownerId)
                }
            );

            return true;

        } catch (error) {

            /*
             * Keep initialization retryable.
             */

            this.state.initialized = false;
            this.state.ready = false;
            this.state.loading = false;

            this.state.error =
                error?.message ||
                "Monthly billing initialization failed.";

            console.error(
                "BK MONTHLY BILLING: INITIALIZATION FAILED.",
                this.state.error,
                error?.stack || "",
                error
            );

            return false;

        }

    },

    /*
    ========================================================
    REFRESH OWNER CONTEXT
    ========================================================
    */

    refreshOwnerContext() {

        const ownerState =
            window.BKOwner?.state;

        if (!ownerState) {

            throw new Error(
                "BK Owner dashboard state is unavailable."
            );

        }

        const currentUser =
            ownerState.currentUser;

        const ownerId =
            String(
                currentUser?.uid || ""
            ).trim();

        const restaurantId =
            String(
                ownerState.restaurantId || ""
            ).trim();

        if (!currentUser || !ownerId) {

            throw new Error(
                "Authenticated Owner is not available."
            );

        }

        if (!restaurantId) {

            throw new Error(
                "Restaurant ID is missing."
            );

        }

        /*
         * Refresh the captured context.
         */

        this.state.currentUser =
            currentUser;

        this.state.ownerId =
            ownerId;

        this.state.restaurantId =
            restaurantId;

        return {
            ownerId: ownerId,
            restaurantId: restaurantId
        };

    },

    /*
    ========================================================
    IDENTITY PAIR VALIDATION
    ========================================================
    */

    validateIdentityPair({
        ownerId,
        restaurantId
    } = {}) {

        const currentOwnerId =
            String(
                this.state.ownerId || ""
            ).trim();

        const currentRestaurantId =
            String(
                this.state.restaurantId || ""
            ).trim();

        const requestedOwnerId =
            String(
                ownerId || ""
            ).trim();

        const requestedRestaurantId =
            String(
                restaurantId || ""
            ).trim();

        if (
            !currentOwnerId ||
            !currentRestaurantId ||
            !requestedOwnerId ||
            !requestedRestaurantId
        ) {

            return false;

        }

        return (
            requestedOwnerId === currentOwnerId &&
            requestedRestaurantId === currentRestaurantId
        );

    },

    /*
    ========================================================
    CURRENT BILL VALIDATION
    ========================================================
    */

    validateCurrentBill(bill) {

        if (
            !bill ||
            typeof bill !== "object"
        ) {

            return {
                valid: false,
                reason: "BILL_NOT_AVAILABLE"
            };

        }

        const identityMatches =
            this.validateIdentityPair({

                ownerId: bill.ownerId,

                restaurantId: bill.restaurantId

            });

        if (!identityMatches) {

            return {
                valid: false,
                reason: "BILL_IDENTITY_MISMATCH"
            };

        }

        const amount =
            Number(bill.finalAmount);

        if (
            !Number.isFinite(amount) ||
            amount < 0
        ) {

            return {
                valid: false,
                reason: "INVALID_BILL_AMOUNT"
            };

        }

        const billingMonth =
            String(
                bill.billingMonth ||
                bill.billingPeriod ||
                ""
            ).trim();

        if (
            !/^\d{4}-(0[1-9]|1[0-2])$/.test(
                billingMonth
            )
        ) {

            return {
                valid: false,
                reason: "INVALID_BILLING_MONTH"
            };

        }

        return {

            valid: true,

            reason: null,

            billingMonth: billingMonth,

            finalAmount: amount,

            currency: String(
                bill.currency || "INR"
            )

        };

    },

    /*
    ========================================================
    CLEANUP / RESET
    ========================================================
    */

    reset() {

        this.state.initialized = false;
        this.state.ready = false;
        this.state.loading = false;
        this.state.error = null;

        this.state.currentUser = null;
        this.state.ownerId = null;
        this.state.restaurantId = null;

        this.state.currentBill = null;
        this.state.paymentStatus = "NOT_LOADED";
        this.state.billingLockActive = false;

        console.info(
            "BK MONTHLY BILLING: STATE RESET."
        );

    }

};


/*
========================================================
GLOBAL EXPOSURE
========================================================
*/

window.BKOwnerMonthlyBilling =
    BKOwnerMonthlyBilling;


/*
========================================================
NO AUTOMATIC STARTUP
========================================================

The Owner dashboard must call:

window.BKOwnerMonthlyBilling.init();

after the authenticated Owner context is available.

========================================================
*/

console.info(
    "BK OWNER MONTHLY BILLING MODULE LOADED.",
    BKOwnerMonthlyBilling.VERSION
);


/*
========================================================
BK OWNER MONTHLY BILLING
STEP 2A — LOAD LATEST PUBLISHED MONTHLY BILL
========================================================
*/

window.BKOwnerMonthlyBilling =
    window.BKOwnerMonthlyBilling || {};

window.BKOwnerMonthlyBilling.loadCurrentBill =
    async function (restaurantId, ownerId) {

        restaurantId = String(
            restaurantId || ""
        ).trim();

        ownerId = String(
            ownerId || ""
        ).trim();

        if (!restaurantId || !ownerId) {
            throw new Error(
                "Restaurant ID and Owner ID are required."
            );
        }

        if (
            typeof window.BKOwner
                ?.getMonthlyBillingFirebaseModules !==
            "function"
        ) {
            throw new Error(
                "BK Owner Firebase bridge is unavailable."
            );
        }

        const {
            db,
            collection,
            query,
            where,
            getDocs
        } = window.BKOwner
            .getMonthlyBillingFirebaseModules();

        if (
            !db ||
            !collection ||
            !query ||
            !where ||
            !getDocs
        ) {
            throw new Error(
                "Required Firestore query modules are unavailable."
            );
        }

        try {

            console.info(
                "BK OWNER BILLING: SEARCHING MONTHLY BILL RECORDS.",
                { restaurantId }
            );

            const billingCollection = collection(
                db,
                "billingRecords"
            );

const billingQuery = query(
    billingCollection,
    where(
        "restaurantId",
        "==",
        restaurantId
    ),
    where(
        "ownerId",
        "==",
        ownerId
    ),
    where(
        "status",
        "==",
        "PUBLISHED"
    )
);
            const billingSnapshot = await getDocs(
                billingQuery
            );

            if (billingSnapshot.empty) {

                console.info(
                    "BK OWNER BILLING: NO MONTHLY RECORDS FOUND.",
                    restaurantId
                );

                return null;
            }

            const publishedBills = [];

            billingSnapshot.forEach((billingDocument) => {

                const billingData =
                    billingDocument.data();

                if (
                    billingData.restaurantId !== restaurantId ||
                    billingData.ownerId !== ownerId ||
                    String(billingData.status || "")
                        .toUpperCase() !== "PUBLISHED"
                ) {
                    return;
                }

                const billingMonth = String(
                    billingData.billingMonth ||
                    billingData.billingPeriod ||
                    ""
                ).trim();

                if (
                    !/^\d{4}-(0[1-9]|1[0-2])$/.test(
                        billingMonth
                    )
                ) {
                    return;
                }

                publishedBills.push({
                    ...billingData,
                    billingMonth,
                    documentId: billingDocument.id
                });

            });

            if (publishedBills.length === 0) {

                console.info(
                    "BK OWNER BILLING: NO PUBLISHED BILL FOUND.",
                    { restaurantId }
                );

                return null;
            }

            publishedBills.sort((a, b) =>
                b.billingMonth.localeCompare(
                    a.billingMonth
                )
            );

            const billingData = publishedBills[0];

            const finalAmount = Number(
                billingData.finalAmount
            );

            if (
                !Number.isFinite(finalAmount) ||
                finalAmount < 0
            ) {
                throw new Error(
                    "The current billing amount is invalid."
                );
            }

            const currentBill = {

                billingId:
                    billingData.billingId ||
                    billingData.documentId,

                restaurantId,

                ownerId,

                billingMonth:
                    billingData.billingMonth,

                billingPeriod:
                    billingData.billingPeriod ||
                    billingData.billingMonth,

                finalAmount,

                currency:
                    billingData.currency || "INR",

                status:
                    billingData.status,

                dueDate:
                    billingData.dueDate || null,

                paymentStatus:
                    billingData.paymentStatus || "UNKNOWN"

            };

            console.info(
                "BK OWNER BILLING: LATEST PUBLISHED BILL LOADED.",
                {
                    restaurantId,
                    billingMonth: currentBill.billingMonth,
                    finalAmount: currentBill.finalAmount,
                    status: currentBill.status,
                    paymentStatus: currentBill.paymentStatus
                }
            );

            return currentBill;

        } catch (error) {

            console.error(
                "BK OWNER BILLING: MONTHLY BILL LOAD FAILED.",
                error
            );

            throw error;
        }
    };
    
    /*
========================================================
STEP 7B — LOAD EXISTING MONTHLY PAYMENT
READ ONLY — NO FIRESTORE WRITES
========================================================
*/

window.BKOwnerMonthlyBilling =
    window.BKOwnerMonthlyBilling || {};

window.BKOwnerMonthlyBilling.loadCurrentMonthlyPayment =
    async function (billingId) {

        const billing = this;

        billingId = String(
            billingId || ""
        ).trim();

        if (!billingId) {
            throw new Error(
                "Billing ID is required."
            );
        }

        const {
            db,
            doc,
            getDoc
        } = window.BKOwner
            .getMonthlyBillingFirebaseModules();

        if (!db || !doc || !getDoc) {
            throw new Error(
                "Required Firestore read modules are unavailable."
            );
        }

        const paymentRef = doc(
            db,
            "billingPayments",
            billingId
        );

        const paymentSnapshot =
            await getDoc(paymentRef);

        if (!paymentSnapshot.exists()) {
            return null;
        }

        const paymentData =
            paymentSnapshot.data();

        if (
            paymentData.billingId !== billingId ||
            paymentData.restaurantId !== billing.state.restaurantId ||
            paymentData.ownerId !== billing.state.ownerId
        ) {
            throw new Error(
                "Monthly payment identity mismatch."
            );
        }

        return {
            ...paymentData,
            documentId: paymentSnapshot.id
        };
    };

console.info(
    "BK OWNER BILLING: MONTHLY PAYMENT READER READY."
);

console.info(
    "BK OWNER BILLING: MONTHLY BILL READER READY."
);


/*
========================================================
BK OWNER MONTHLY BILLING
STEP 2B — BILL DISPLAY DATA
========================================================
*/

window.BKOwnerMonthlyBilling =
    window.BKOwnerMonthlyBilling || {};

window.BKOwnerMonthlyBilling.formatBillForDisplay =
    function (bill) {

        if (!bill || typeof bill !== "object") {
            return null;
        }

        const amount = Number(bill.finalAmount);

        if (
            !Number.isFinite(amount) ||
            amount < 0
        ) {
            throw new Error(
                "Cannot display an invalid billing amount."
            );
        }

        const month = String(
            bill.billingMonth || ""
        );

        const currency = String(
            bill.currency || "INR"
        );

        const status = String(
            bill.status || "UNKNOWN"
        ).toUpperCase();

        const paymentStatus = String(
            bill.paymentStatus || "UNKNOWN"
        ).toUpperCase();

        const dueDate = bill.dueDate || null;

        let formattedMonth = month;

        if (/^\d{4}-(0[1-9]|1[0-2])$/.test(month)) {
            const [year, monthNumber] = month
                .split("-")
                .map(Number);

            formattedMonth = new Date(
                Date.UTC(year, monthNumber - 1, 1)
            ).toLocaleDateString("en-IN", {
                month: "long",
                year: "numeric",
                timeZone: "UTC"
            });
        }

        let formattedAmount;

        try {
            formattedAmount = new Intl.NumberFormat(
                "en-IN",
                {
                    style: "currency",
                    currency,
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                }
            ).format(amount);
        } catch {
            formattedAmount = `${currency} ${amount.toFixed(2)}`;
        }

        return {
            billingId: String(bill.billingId || ""),
            billingMonth: month,
            displayMonth: formattedMonth,
            amount,
            formattedAmount,
            currency,
            status,
            paymentStatus,
            dueDate,
         canPay:
    status === "PUBLISHED" &&
    (
        paymentStatus === "NOT_SUBMITTED" ||
        paymentStatus === "UNPAID"
    )
        };
    };

/*
========================================================
BK MONTHLY BILLING — IST OVERDUE DATE CHECKER
DATE ONLY — NO FIRESTORE WRITES
========================================================
*/

window.BKOwnerMonthlyBilling.isPastDueDate =
    function (dueDate, currentTime = new Date()) {

        const dueDateString =
            String(dueDate || "").trim();

        if (
            !/^\d{4}-\d{2}-\d{2}$/.test(dueDateString)
        ) {
            throw new Error(
                "Invalid monthly billing due date."
            );
        }

        const [year, month, day] =
            dueDateString.split("-").map(Number);

        const parsedDueDate =
            new Date(Date.UTC(year, month - 1, day));

        if (
            parsedDueDate.getUTCFullYear() !== year ||
            parsedDueDate.getUTCMonth() !== month - 1 ||
            parsedDueDate.getUTCDate() !== day
        ) {
            throw new Error(
                "Monthly billing due date is invalid."
            );
        }

        const istParts =
            new Intl.DateTimeFormat("en-GB", {
                timeZone: "Asia/Kolkata",
                year: "numeric",
                month: "2-digit",
                day: "2-digit"
            }).formatToParts(currentTime);

        const istDate = {};

        istParts.forEach((part) => {
            if (part.type !== "literal") {
                istDate[part.type] = part.value;
            }
        });

        const todayIST =
            `${istDate.year}-${istDate.month}-${istDate.day}`;

        return todayIST > dueDateString;
    };

console.info(
    "BK OWNER BILLING: IST OVERDUE DATE CHECKER READY."
);

console.info(
    "BK OWNER BILLING: BILL DISPLAY FORMATTER READY."
);
/*
========================================================
BK OWNER MONTHLY BILLING
STEP 2C — BILLING CARD RENDERER
========================================================
*/

window.BKOwnerMonthlyBilling =
    window.BKOwnerMonthlyBilling || {};

window.BKOwnerMonthlyBilling.renderBillingCard =
    function (container, bill) {

        if (typeof container === "string") {
            container = document.querySelector(container);
        }

        if (
            !container ||
            typeof container.replaceChildren !== "function"
        ) {
            throw new Error(
                "A valid billing card container is required."
            );
        }

        const billing =
            window.BKOwnerMonthlyBilling
                .formatBillForDisplay(bill);

        if (!billing) {
            container.replaceChildren();

            const message = document.createElement("p");

            message.className =
                "bk-billing-empty-message";

            message.textContent =
                "No billing information is available.";

            container.appendChild(message);

            return false;
        }

        const card = document.createElement("section");

        card.className = "bk-owner-billing-card";

        card.setAttribute(
            "aria-label",
            "Monthly billing information"
        );

        const heading = document.createElement("h3");

        heading.className = "bk-billing-heading";

        heading.textContent = "Monthly Billing";

        const month = document.createElement("p");

        month.className = "bk-billing-month";

        month.textContent =
            billing.displayMonth || "Current Billing Period";

        const amountLabel = document.createElement("p");

        amountLabel.className = "bk-billing-amount-label";

        amountLabel.textContent = "Total Amount Due";

        const amount = document.createElement("p");

        amount.className = "bk-billing-amount";

        amount.textContent = billing.formattedAmount;

        const status = document.createElement("p");

        status.className = "bk-billing-status";

        status.textContent =
            "Bill Status: " + billing.status.replace(/_/g, " ");

        const paymentStatus = document.createElement("p");

        paymentStatus.className =
            "bk-billing-payment-status";

        paymentStatus.textContent =
            "Payment Status: " +
            billing.paymentStatus.replace(/_/g, " ");

        const dueDate = document.createElement("p");

        dueDate.className = "bk-billing-due-date";

        let dueDateText = "Not specified";

        if (billing.dueDate) {
            const parsedDate =
                typeof billing.dueDate.toDate === "function"
                    ? billing.dueDate.toDate()
                    : new Date(billing.dueDate);

            if (
                parsedDate instanceof Date &&
                Number.isFinite(parsedDate.getTime())
            ) {
                dueDateText = parsedDate.toLocaleDateString(
                    "en-IN",
                    {
                        day: "2-digit",
                        month: "short",
                        year: "numeric"
                    }
                );
            } else {
                dueDateText = "Not available";
            }
        }

        dueDate.textContent = "Due Date: " + dueDateText;

        const payButton = document.createElement("button");

        payButton.type = "button";

        payButton.className = "bk-billing-pay-button";

        payButton.textContent = "PAY NOW";

        payButton.disabled = !billing.canPay;

        payButton.dataset.action = "pay-now";

        payButton.dataset.billingId = billing.billingId;

        payButton.setAttribute(
            "aria-label",
            "Pay current monthly bill"
        );

        card.append(
            heading,
            month,
            amountLabel,
            amount,
            status,
            paymentStatus,
            dueDate,
            payButton
        );

        container.replaceChildren(card);

        console.info(
            "BK OWNER BILLING: BILLING CARD RENDERED.",
            {
                billingMonth: billing.billingMonth,
                amount: billing.amount,
                status: billing.status,
                paymentStatus: billing.paymentStatus
            }
        );

        return true;
    };

console.info(
    "BK OWNER BILLING: BILLING CARD RENDERER READY."
);
/*
========================================================
BK OWNER MONTHLY BILLING
STEP 2D — LOAD AND RENDER CURRENT BILL
========================================================
*/

window.BKOwnerMonthlyBilling =
    window.BKOwnerMonthlyBilling || {};

window.BKOwnerMonthlyBilling.loadAndRenderCurrentBill =
    async function (container, restaurantId, ownerId) {

        if (
            !window.BKOwnerMonthlyBilling.loadCurrentBill ||
            !window.BKOwnerMonthlyBilling.renderBillingCard
        ) {
            throw new Error(
                "BK Owner Billing components are not ready."
            );
        }

        try {
            console.info(
                "BK OWNER BILLING: LOADING BILL FOR DISPLAY."
            );

            const bill =
                await window.BKOwnerMonthlyBilling
                    .loadCurrentBill(
                        restaurantId,
                        ownerId
                    );

            const rendered =
                window.BKOwnerMonthlyBilling
                    .renderBillingCard(
                        container,
                        bill
                    );

            console.info(
                "BK OWNER BILLING: LOAD AND RENDER COMPLETE.",
                {
                    restaurantId,
                    billFound: Boolean(bill),
                    rendered
                }
            );

            return {
                success: true,
                billFound: Boolean(bill),
                rendered,
                bill
            };

        } catch (error) {
            console.error(
                "BK OWNER BILLING: LOAD AND RENDER FAILED.",
                error
            );

            throw error;
        }
    };

console.info(
    "BK OWNER BILLING: LOAD-AND-RENDER WORKFLOW READY."
);      

/*
========================================================
BK OWNER MONTHLY BILLING
STEP 2E — PREMIUM BILLING UI CONNECTOR
========================================================
*/

window.BKOwnerMonthlyBilling =
    window.BKOwnerMonthlyBilling || {};

window.BKOwnerMonthlyBilling.renderPremiumBillingUI =
    function (bill) {

        const getElement = (id) =>
            document.getElementById(id);

        const statusElement =
            getElement("bkOwnerMonthlyBillingStatus");

        const monthElement =
            getElement("bkOwnerBillingMonth");

        const amountElement =
            getElement("bkOwnerBillingFinalAmount");

        const messageElement =
            getElement("bkOwnerMonthlyBillingMessage");

        if (
            !statusElement ||
            !monthElement ||
            !amountElement ||
            !messageElement
        ) {
            console.error(
                "BK OWNER BILLING: PREMIUM UI ELEMENTS MISSING."
            );

            return false;
        }

if (!bill) {

    statusElement.textContent = "NO BILL";
    monthElement.textContent = "—";
    amountElement.textContent = "—";

    messageElement.textContent =
        "No current monthly bill is available yet.";

    const payButton =
        getElement("bkOwnerMonthlyPayButton");

    const utrInput =
        getElement("bkOwnerMonthlyPaymentUTR");

    const submitButton =
        getElement("bkOwnerMonthlySubmitPaymentButton");

    if (payButton) {
        payButton.disabled = true;
        payButton.setAttribute("aria-disabled", "true");
        payButton.textContent = "PAYMENT UNAVAILABLE";
    }

    if (utrInput) {
        utrInput.disabled = true;
    }

    if (submitButton) {
        submitButton.disabled = true;
        submitButton.setAttribute("aria-disabled", "true");
    }

    return true;
}


        const formatted =
            window.BKOwnerMonthlyBilling
                .formatBillForDisplay(bill);

        if (!formatted) {
            return false;
        }

        statusElement.textContent =
            formatted.status.replace(/_/g, " ");

        monthElement.textContent =
            formatted.displayMonth || "Current Period";

        amountElement.textContent =
            formatted.formattedAmount;

        messageElement.textContent =
            "Payment Status: " +
            formatted.paymentStatus.replace(/_/g, " ");
            
            /*
========================================================
STEP 2G — MONTHLY PAYMENT ELIGIBILITY
UI ONLY — NO PAYMENT SUBMISSION
========================================================
*/

const payButton =
    document.getElementById(
        "bkOwnerMonthlyPayButton"
    );

if (payButton) {

const canPay =
    formatted.canPay === true &&
    this.state.monthlyPaymentSubmissionStatus ===
        "NOT_FOUND";
    payButton.disabled = !canPay;

    payButton.setAttribute(
        "aria-disabled",
        String(!canPay)
    );

    payButton.textContent =
        canPay
            ? "PAY BILL NOW"
            : "PAYMENT UNAVAILABLE";

    console.info(
        "BK MONTHLY BILLING: PAYMENT ELIGIBILITY UPDATED.",
        {
            canPay,
            status: formatted.status,
            paymentStatus: formatted.paymentStatus
        }
    );

}


/*
========================================================
STEP 2H — MONTHLY UTR CONTROLS
UI ONLY — NO FIRESTORE WRITES
========================================================
*/

const canSubmitMonthlyPayment =
    formatted.canPay === true &&
    this.state.monthlyPaymentSubmissionStatus ===
        "NOT_FOUND";

const utrInput =
    document.getElementById(
        "bkOwnerMonthlyPaymentUTR"
    );

const submitPaymentButton =
    document.getElementById(
        "bkOwnerMonthlySubmitPaymentButton"
    );

if (utrInput) {
    utrInput.disabled =
        !canSubmitMonthlyPayment;
}

if (submitPaymentButton) {

    submitPaymentButton.disabled =
        !canSubmitMonthlyPayment;

    submitPaymentButton.setAttribute(
        "aria-disabled",
        String(!canSubmitMonthlyPayment)
    );

}

console.info(
    "BK MONTHLY BILLING: UTR CONTROLS UPDATED.",
    {
        canSubmitMonthlyPayment
    }
);



        console.info(
            "BK OWNER BILLING: PREMIUM UI UPDATED.",
            {
                billingMonth: formatted.billingMonth,
                amount: formatted.amount,
                status: formatted.status
            }
        );

        return true;
    };

console.info(
    "BK OWNER BILLING: PREMIUM UI CONNECTOR READY."
);

/*
========================================================
BK OWNER MONTHLY BILLING
STEP 2F — LOAD CURRENT BILL INTO PREMIUM UI
========================================================
*/

window.BKOwnerMonthlyBilling =
    window.BKOwnerMonthlyBilling || {};

window.BKOwnerMonthlyBilling.loadPremiumBillingUI =
    async function () {

        const billing =
            window.BKOwnerMonthlyBilling;

        if (!billing.state?.ready) {
            console.warn(
                "BK BILLING: OWNER CONTEXT IS NOT READY."
            );

            return false;
        }

        const container =
            document.getElementById(
                "bkOwnerMonthlyBilling"
            );

        if (!container) {
            console.error(
                "BK BILLING: PREMIUM CONTAINER NOT FOUND."
            );

            return false;
        }

        try {

            const bill =
                await billing.loadCurrentBill(
                    billing.state.restaurantId,
                    billing.state.ownerId
                );

// LOAD EXISTING MONTHLY PAYMENT — READ ONLY

billing.state.currentMonthlyPayment = null;

billing.state.monthlyPaymentSubmissionStatus =
    "NOT_FOUND";

if (bill) {

    const existingPayment =
        await billing.loadCurrentMonthlyPayment(
            bill.billingId
        );

    billing.state.currentMonthlyPayment =
        existingPayment;

    billing.state.monthlyPaymentSubmissionStatus =
        existingPayment
            ? String(
                existingPayment.status || "UNKNOWN"
            ).toUpperCase()
            : "NOT_FOUND";

} else {

    billing.state.currentMonthlyPayment = null;

    billing.state.monthlyPaymentSubmissionStatus =
        "NOT_FOUND";
}

            const rendered =
                billing.renderPremiumBillingUI(bill);

if (rendered) {

    billing.state.currentBill =
        bill || null;

    billing.state.paymentStatus =
        bill
            ? String(
                bill.paymentStatus || "UNKNOWN"
            ).toUpperCase()
            : "NO_BILL";

billing.syncOverdueState();

}

            console.info(
                "BK BILLING: PREMIUM BILL LOAD COMPLETE.",
                {
                    billFound: Boolean(bill),
                    rendered
                }
            );

            return rendered;

        } catch (error) {

            console.error(
                "BK BILLING: PREMIUM BILL LOAD FAILED.",
                error
            );

            const message =
                document.getElementById(
                    "bkOwnerMonthlyBillingMessage"
                );

            if (message) {
                message.textContent =
                    "Unable to load your bill. Please try again later.";
            }

            return false;
        }
    };

console.info(
    "BK OWNER BILLING: PREMIUM BILL LOADER READY."
);

/*
========================================================
BK OWNER MONTHLY BILLING
STEP 3A — BUILD UPI PAYMENT URI
NO FIRESTORE WRITES
========================================================
*/

window.BKOwnerMonthlyBilling =
    window.BKOwnerMonthlyBilling || {};

window.BKOwnerMonthlyBilling.buildUpiPaymentUri =
    function () {

        const billing = this;

        const bill = billing.state?.currentBill;

        const paymentConfig =
            window.BKOwnerSubscription
                ?.state?.paymentConfiguration;

        if (!bill) {
            throw new Error(
                "Current monthly bill is unavailable."
            );
        }

        const validation =
            billing.validateCurrentBill(bill);

        if (!validation.valid) {
            throw new Error(
                "Monthly bill validation failed: " +
                validation.reason
            );
        }

        if (
            String(bill.status || "").toUpperCase() !==
            "PUBLISHED" ||
            !["UNPAID", "NOT_SUBMITTED"].includes(
                String(
                    bill.paymentStatus || ""
                ).toUpperCase()
            )
        ) {
            throw new Error(
                "This monthly bill is not eligible for payment."
            );
        }

        if (
            !paymentConfig ||
            String(paymentConfig.status || "")
                .toUpperCase() !== "ACTIVE"
        ) {
            throw new Error(
                "Active Master payment configuration is unavailable."
            );
        }

        const paymentId =
            String(
                paymentConfig.paymentIdentifier || ""
            ).trim();

        const payeeName =
            String(
                paymentConfig.payeeName || ""
            ).trim();

        if (
            !paymentId ||
            !payeeName ||
            !/^[^\s@]+@[^\s@]+$/.test(paymentId)
        ) {
            throw new Error(
                "Master UPI payment details are invalid."
            );
        }

        if (
            validation.currency !== "INR" ||
            validation.finalAmount <= 0
        ) {
            throw new Error(
                "Invalid monthly payment amount or currency."
            );
        }

        const params = new URLSearchParams({
            pa: paymentId,
            pn: payeeName,
            am: validation.finalAmount.toFixed(2),
            cu: "INR",
            tn: `BK Monthly Bill ${validation.billingMonth}`,
            tr: String(bill.billingId || "")
        });

        return "upi://pay?" + params.toString();
    };

console.info(
    "BK OWNER BILLING: UPI URI BUILDER READY."
);



/*
========================================================
BK MONTHLY BILLING — OVERDUE POPUP CONTROLLER
IST DATE + MASTER VERIFIED PAYMENT CHECK
NO FIRESTORE WRITES
========================================================
*/

window.BKOwnerMonthlyBilling =
    window.BKOwnerMonthlyBilling || {};

window.BKOwnerMonthlyBilling.showOverduePopup =
    function (bill) {

        const backdrop = document.getElementById(
            "bkMonthlyOverdueBackdrop"
        );

        if (!backdrop || !bill) {
            console.error(
                "BK OVERDUE POPUP: REQUIRED ELEMENTS OR BILL MISSING."
            );
            return false;
        }

        const setText = (id, value) => {
            const element = document.getElementById(id);
            if (element) element.textContent = value;
        };

        const month = String(
            bill.billingMonth || bill.billingPeriod || "—"
        );

        let displayMonth = month;

        if (/^\d{4}-(0[1-9]|1[0-2])$/.test(month)) {
            const [year, monthNumber] = month.split("-").map(Number);

            displayMonth = new Date(
                Date.UTC(year, monthNumber - 1, 1)
            ).toLocaleDateString("en-IN", {
                month: "long",
                year: "numeric",
                timeZone: "UTC"
            });
        }

        const dueDate = String(bill.dueDate || "—");

        let displayDueDate = dueDate;

        if (/^\d{4}-\d{2}-\d{2}$/.test(dueDate)) {
            const [year, monthNumber, day] =
                dueDate.split("-").map(Number);

            displayDueDate = new Date(
                Date.UTC(year, monthNumber - 1, day)
            ).toLocaleDateString("en-IN", {
                day: "2-digit",
                month: "short",
                year: "numeric",
                timeZone: "UTC"
            });
        }

        const amount = Number(bill.finalAmount);

        let displayAmount = "Unavailable";

        if (Number.isFinite(amount) && amount >= 0) {
            displayAmount = new Intl.NumberFormat("en-IN", {
                style: "currency",
                currency: String(bill.currency || "INR"),
                minimumFractionDigits: 2
            }).format(amount);
        }

        setText("bkOverdueBillingMonth", displayMonth);
        setText("bkOverdueDueDate", displayDueDate);
        setText("bkOverdueAmount", displayAmount);
        setText(
            "bkOverduePaymentStatus",
            String(bill.paymentStatus || "UNPAID").toUpperCase()
        );

        backdrop.hidden = false;
        backdrop.setAttribute("aria-hidden", "false");

        console.info(
            "BK MONTHLY BILLING: OVERDUE POPUP OPENED.",
            {
                billingMonth: month,
                dueDate,
                amount: displayAmount
            }
        );

        return true;
    };


window.BKOwnerMonthlyBilling.hideOverduePopup =
    function () {

        const backdrop = document.getElementById(
            "bkMonthlyOverdueBackdrop"
        );

        if (!backdrop) return false;

        backdrop.hidden = true;
        backdrop.setAttribute("aria-hidden", "true");

        return true;
    };

/*
========================================================
BK MONTHLY BILLING
PAYMENT SUBMITTED — VERIFICATION PENDING POPUP
NO FIRESTORE WRITES
========================================================
*/

window.BKOwnerMonthlyBilling.showPaymentVerificationPopup =
    function (bill) {

        const backdrop = document.getElementById(
            "bkMonthlyOverdueBackdrop"
        );

        if (!backdrop || !bill) {
            console.error(
                "BK PAYMENT NOTICE: POPUP OR BILL MISSING."
            );
            return false;
        }

        const setText = (id, value) => {
            const element = document.getElementById(id);
            if (element) {
                element.textContent = value;
            }
        };

        setText(
            "bkMonthlyOverdueTitle",
            "Payment Successfully Submitted"
        );

        setText(
            "bkMonthlyOverdueMessage",
            "Your payment has been submitted successfully. It is currently under verification. Your Owner Dashboard will be unlocked as soon as the verification process is completed. Thank you for your payment. We appreciate your patience."
        );

        setText(
            "bkOverduePaymentStatus",
            "VERIFICATION PENDING"
        );

        const headerStatus = backdrop.querySelector(
            ".bk-overdue-header span:last-child"
        );

        if (headerStatus) {
            headerStatus.textContent =
                "VERIFICATION PENDING";
        }

        const button = document.getElementById(
            "bkOverdueOpenBillingButton"
        );

        if (button) {
            button.textContent = "VIEW BILLING STATUS";
        }

        const footer = backdrop.querySelector(
            ".bk-overdue-footer"
        );

        if (footer) {
            footer.textContent =
                "Dashboard access will be restored after Master verification.";
        }

        backdrop.hidden = false;
        backdrop.setAttribute("aria-hidden", "false");

        console.info(
            "BK MONTHLY BILLING: PAYMENT VERIFICATION POPUP READY."
        );

        return true;
    };

console.info(
    "BK MONTHLY BILLING: PAYMENT VERIFICATION POPUP READY."
);


/*
 * This is a UI-only test.
 * It does not change Firestore or billing state.
 */

window.BKOwnerMonthlyBilling.testOverduePopup =
    function () {

        const testBill = {
            billingId: "BK-OVERDUE-UI-TEST",
            billingMonth: "2026-10",
            dueDate: "2026-10-31",
            finalAmount: 100,
            currency: "INR",
            status: "PUBLISHED",
            paymentStatus: "UNPAID"
        };

        const opened = this.showOverduePopup(testBill);

        console.info(
            "BK OVERDUE POPUP UI TEST:",
            opened ? "PASS" : "FAIL"
        );

        return opened;
    };


/*
 * Only Master-verified payment can release the lock.
 */

window.BKOwnerMonthlyBilling.isMasterPaymentVerified =
    function (bill, payment) {

        if (!bill || !payment) return false;

        return (
            String(bill.paymentStatus || "").toUpperCase() === "PAID" &&
            String(payment.status || "").toUpperCase() === "VERIFIED" &&
            String(payment.verificationStatus || "").toUpperCase() === "VERIFIED" &&
            String(payment.billingId || "") === String(bill.billingId || "") &&
            String(payment.restaurantId || "") === String(bill.restaurantId || "") &&
            String(payment.ownerId || "") === String(bill.ownerId || "")
        );
    };


/*
 * Evaluate actual overdue status using IST calendar date.
 */

window.BKOwnerMonthlyBilling.syncOverdueState =
    function (currentTime = new Date()) {

        const billing = this;
        const bill = billing.state.currentBill;
        const payment = billing.state.currentMonthlyPayment;

        if (!bill) {
            billing.state.billingLockActive = false;
            billing.hideOverduePopup();
            return false;
        }

        if (
            String(bill.status || "").toUpperCase() !== "PUBLISHED"
        ) {
            billing.state.billingLockActive = false;
            billing.hideOverduePopup();
            return false;
        }

        let pastDue = false;

        try {
            pastDue = billing.isPastDueDate(
                bill.dueDate,
                currentTime
            );
        } catch (error) {
            billing.state.billingLockActive = false;
            billing.hideOverduePopup();

            console.error(
                "BK OVERDUE CHECK: INVALID DUE DATE.",
                error
            );

            return false;
        }

const verified =
    billing.isMasterPaymentVerified(bill, payment);

const paymentSubmitted =
    String(payment?.status || "").toUpperCase() ===
        "PAYMENT_SUBMITTED" &&
    String(payment?.verificationStatus || "").toUpperCase() ===
        "PENDING";

const overdue = pastDue && !verified;

billing.state.billingLockActive = overdue;

if (overdue && paymentSubmitted) {

    billing.showPaymentVerificationPopup(bill);

} else if (overdue) {

    billing.showOverduePopup(bill);

} else {

    billing.hideOverduePopup();

}
        console.info(
            "BK MONTHLY BILLING: OVERDUE STATE CHECKED.",
            {
                pastDue,
                masterPaymentVerified: verified,
                billingLockActive: overdue
            }
        );

        return overdue;
    };


/*
 * Payment navigation button.
 * This button does not verify or submit payment.
 */

(function attachOverdueBillingButton() {

    const button = document.getElementById(
        "bkOverdueOpenBillingButton"
    );

    if (!button || button.dataset.bkOverdueBound === "true") {
        return;
    }

    button.dataset.bkOverdueBound = "true";

    button.addEventListener("click", function () {

        window.BKOwnerMonthlyBilling.hideOverduePopup();

        if (
            typeof window.BKOwner?.showSection === "function"
        ) {
            window.BKOwner.showSection("subscription");
        }

        const billingSection = document.getElementById(
            "bkOwnerMonthlyBilling"
        );

        if (billingSection) {
            billingSection.scrollIntoView({
                behavior: "smooth",
                block: "start"
            });
        }

        console.info(
            "BK OVERDUE POPUP: OWNER OPENED MONTHLY BILLING."
        );
    });

})();


console.info(
    "BK MONTHLY BILLING: OVERDUE POPUP CONTROLLER READY."
);
